// Docklet Design Lab – opus-compact · Gemeinsamer Stack-Logstream (Docklet-Vorbild)
// Logs aller Services zusammengeführt, Herkunft pro Zeile über Servicename und Farbe, Filter nach Service.
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, computed, effect, inject, input, signal, untracked, viewChild } from '@angular/core';
import { LOGS, type LogLine, type Stack } from './data';
import { CxIcon } from './icon';

const SVC_COLORS = ['#38bdf8', '#c084fc', '#fbbf24', '#34d399', '#f472b6', '#818cf8', '#fb923c'];

const SAMPLE: Record<string, string[]> = {
  jellyfin: ['[INF] Playback gestartet: Beispielfilm (2024)', '[INF] Bibliotheksscan: 0 neue Elemente'],
  redis: ['* Background saving terminated with success', '* Accepted 192.0.2.34:51234'],
  nextcloud: ['[core] Cron-Job erfolgreich (1,8 s)', '"GET /status.php HTTP/1.1" 200'],
  postgres: ['LOG:  checkpoint starting: time', 'LOG:  automatic vacuum of table "oc_filecache"'],
  minecraft: ['[Server thread/INFO]: spieler_eins hat einen Erfolg erzielt', "[Server thread/WARN]: Can't keep up! Running 2100ms behind"],
};

@Component({
  selector: 'cx-stack-logs',
  imports: [CxIcon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-2 flex flex-wrap items-center gap-1.5">
      <span class="mr-1 text-[12px] font-medium text-zinc-600">Services:</span>
      @for (s of services(); track s.name) {
        <button type="button" class="inline-flex h-7 items-center gap-1.5 rounded-md border px-2 font-mono text-[12px]" [class]="isOn(s.name) ? 'border-zinc-300 bg-white text-zinc-900' : 'border-dashed border-zinc-300 text-zinc-400 line-through'" [attr.aria-pressed]="isOn(s.name)" (click)="toggle(s.name)">
          <span class="size-2 rounded-full" [style.background-color]="s.color"></span>{{ s.name }}
        </button>
      }
      @if (hidden().length) {
        <button type="button" class="text-[12px] font-medium text-zinc-600 underline" (click)="hidden.set([])">Alle zeigen</button>
      }
      <div class="ml-auto flex flex-wrap items-center gap-2">
        <div class="relative">
          <cx-icon name="search" [size]="13" class="pointer-events-none absolute left-2 top-2 text-zinc-400" />
          <input type="search" class="h-7 w-44 rounded-md border border-zinc-200 bg-white pl-7 pr-2 text-[12px] outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="In Logs suchen" aria-label="In Logs suchen" [value]="query()" (input)="query.set(v($event))" />
        </div>
        <label class="flex items-center gap-1.5 text-[12px] text-zinc-700"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="times()" (change)="times.set(!times())" />Zeit</label>
        <label class="flex items-center gap-1.5 text-[12px] text-zinc-700"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="follow()" (change)="toggleFollow()" />Folgen</label>
        <button type="button" class="text-[12px] font-medium text-zinc-600 underline" (click)="extra.set([])">Leeren</button>
      </div>
    </div>
    <div #box class="h-[min(56vh,460px)] overflow-auto rounded-lg border border-[#27272a] bg-[#0c0c0f] py-2 font-mono text-[12px] leading-5 text-[#e4e4e7]" role="log" aria-live="off" aria-label="Gemeinsamer Logstream">
      @for (l of lines(); track $index) {
        <div class="flex gap-2 px-3 hover:bg-white/5" [class]="l.level === 'error' ? 'bg-red-500/10' : ''">
          @if (times()) { <span class="shrink-0 text-[#71717a]">{{ l.t }}</span> }
          <span class="w-24 shrink-0 truncate font-semibold" [style.color]="colorOf(l.svc)">{{ l.svc }}</span>
          <span class="min-w-0 whitespace-pre-wrap break-words" [class]="l.level === 'error' ? 'text-[#fca5a5]' : l.level === 'warn' ? 'text-[#fcd34d]' : ''">{{ l.text }}</span>
        </div>
      } @empty {
        <div class="px-3 text-[#a1a1aa]">Keine Zeilen für diesen Filter.</div>
      }
    </div>
    <p class="mt-1.5 text-[11.5px] text-zinc-500">{{ lines().length }} Zeilen · Logstream der Stack-Services zusammengeführt (simuliert). Einzelne Container-Logs bleiben über die Services-Tabelle erreichbar.</p>
  `,
})
export class CxStackLogs {
  readonly stack = input.required<Stack>();
  /** Optional vorausgewählter Service (z. B. aus „Logs“ in der Services-Tabelle). */
  readonly only = input<string | null>(null);

  protected readonly hidden = signal<string[]>([]);
  protected readonly query = signal('');
  protected readonly times = signal(true);
  protected readonly follow = signal(false);
  protected readonly extra = signal<LogLine[]>([]);
  private readonly box = viewChild<ElementRef<HTMLElement>>('box');
  private timer: ReturnType<typeof setInterval> | null = null;

  protected readonly services = computed(() => this.stack().services.map((s, i) => ({ name: s.name, id: s.id, color: SVC_COLORS[i % SVC_COLORS.length] })));

  private readonly base = computed<LogLine[]>(() => {
    const out: LogLine[] = [];
    for (const s of this.stack().services) {
      const seed = LOGS[s.id];
      if (seed) out.push(...seed.map((l) => ({ ...l, svc: s.name })));
      else out.push({ t: '10:00:00', svc: s.name, text: s.state === 'running' ? 'Container gestartet (Demo)' : 'Container nicht gestartet' });
    }
    return out.sort((a, b) => a.t.localeCompare(b.t));
  });

  protected readonly lines = computed(() => {
    const q = this.query().trim().toLowerCase();
    const hidden = this.hidden();
    return [...this.base(), ...this.extra()].filter((l) => !hidden.includes(l.svc) && (!q || l.text.toLowerCase().includes(q)));
  });

  constructor() {
    inject(DestroyRef).onDestroy(() => this.stop());
    effect(() => {
      const only = this.only();
      if (only) this.hidden.set(untracked(() => this.stack().services.map((s) => s.name).filter((n) => n !== only)));
    });
    effect(() => {
      this.lines();
      const el = this.box()?.nativeElement;
      if (el && this.follow()) setTimeout(() => (el.scrollTop = el.scrollHeight));
    });
  }

  protected v(e: Event): string {
    return (e.target as HTMLInputElement).value;
  }

  protected isOn(name: string): boolean {
    return !this.hidden().includes(name);
  }

  protected toggle(name: string): void {
    this.hidden.update((h) => (h.includes(name) ? h.filter((x) => x !== name) : [...h, name]));
  }

  protected colorOf(name: string): string {
    return this.services().find((s) => s.name === name)?.color ?? '#a1a1aa';
  }

  protected toggleFollow(): void {
    if (this.follow()) {
      this.stop();
      return;
    }
    this.follow.set(true);
    this.timer = setInterval(() => {
      const svcs = this.stack().services.filter((s) => s.state === 'running');
      if (svcs.length === 0) return;
      const s = svcs[Math.floor(Math.random() * svcs.length)];
      const pool = SAMPLE[s.id] ?? ['Heartbeat ok'];
      const text = pool[Math.floor(Math.random() * pool.length)];
      const t = new Date().toLocaleTimeString('de-DE');
      this.extra.update((l) => [...l.slice(-60), { t, svc: s.name, text, level: text.includes('WARN') ? 'warn' : undefined }]);
    }, 1400);
  }

  private stop(): void {
    this.follow.set(false);
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
