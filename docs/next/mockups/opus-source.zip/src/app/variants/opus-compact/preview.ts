// Docklet Design Lab – opus-compact · Vorschau Proxy & Games
// Ausdrücklich als Vorschau gekennzeichnet: Projektbasis und Integration werden später evaluiert.
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { CxIcon } from './icon';
import { CxStore, nowTime } from './store';
import { CxHost, CxStatus } from './ui';

interface Route {
  host: string;
  target: string;
  hostId: string;
  tls: 'gültig' | 'läuft ab';
  middleware: string;
}

@Component({
  selector: 'cx-preview',
  imports: [ZardButtonComponent, CxIcon, CxHost, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-3 flex gap-2 rounded-lg border border-sky-200 bg-sky-50 p-3 text-[12.5px] text-sky-950">
      <cx-icon name="info" [size]="16" class="mt-0.5" />
      <p><b>Vorschau, keine fertige Funktion.</b> Proxy (zuerst HTTP/HTTPS) und Games (Konsole, Status, Spielerzahl) sind bestätigte Ziele. Projektbasis, Einbindung und Platzierung in Navigation oder Tabs werden später evaluiert.</p>
    </div>

    <div class="grid items-start gap-3 xl:grid-cols-2">
      <section class="rounded-lg border border-zinc-200 bg-white" aria-labelledby="pv-proxy">
        <header class="flex items-center gap-2 border-b border-zinc-100 px-3 py-2">
          <cx-icon name="globe" [size]="15" /><h2 id="pv-proxy" class="text-[13px] font-semibold">Proxy · HTTP/HTTPS-Routen</h2>
          <span class="ml-auto rounded border border-zinc-200 px-1.5 text-[11px] text-zinc-600">Traefik/Caddy – offen</span>
        </header>
        <div class="overflow-x-auto">
          <table class="w-full min-w-[520px] text-left text-[12.5px]">
            <thead class="bg-zinc-50 text-[11px] uppercase tracking-wide text-zinc-500">
              <tr><th class="px-3 py-1.5 font-semibold">Domain</th><th class="px-3 py-1.5 font-semibold">Ziel</th><th class="px-3 py-1.5 font-semibold">Zertifikat</th><th class="px-3 py-1.5 font-semibold">Middleware</th></tr>
            </thead>
            <tbody>
              @for (r of routes; track r.host) {
                @let h = store.host(r.hostId);
                <tr class="border-t border-zinc-100">
                  <td class="px-3 py-1.5 font-mono font-medium">{{ r.host }}</td>
                  <td class="px-3 py-1.5"><span class="mr-1.5 font-mono">{{ r.target }}</span><cx-host [name]="h.name" [color]="h.color" [soft]="h.soft" /></td>
                  <td class="px-3 py-1.5"><cx-status [kind]="r.tls === 'gültig' ? 'success' : 'update'" [label]="r.tls === 'gültig' ? 'gültig' : 'läuft in 9 Tagen ab'" /></td>
                  <td class="px-3 py-1.5 text-zinc-700">{{ r.middleware }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <p class="px-3 py-2 text-[11.5px] text-zinc-500">Vorhandene Proxy-Installationen und gebündelte Migration werden berücksichtigt. TCP/UDP folgt später.</p>
      </section>

      <section class="rounded-lg border border-zinc-200 bg-white" aria-labelledby="pv-games">
        <header class="flex flex-wrap items-center gap-2 border-b border-zinc-100 px-3 py-2">
          <cx-icon name="gamepad" [size]="15" /><h2 id="pv-games" class="text-[13px] font-semibold">Games · Craft (Minecraft)</h2>
          <cx-status kind="unhealthy" />
          <span class="ml-auto text-[12px] text-zinc-600"><b class="tabular-nums text-zinc-900">3</b> / 12 Spieler</span>
        </header>
        <div class="p-3">
          <div class="mb-2 grid grid-cols-3 gap-2 text-center">
            <div class="rounded-md bg-zinc-50 p-2"><div class="font-mono text-[15px] font-semibold">18,4</div><div class="text-[11px] text-zinc-500">TPS</div></div>
            <div class="rounded-md bg-zinc-50 p-2"><div class="font-mono text-[15px] font-semibold">3,4 GB</div><div class="text-[11px] text-zinc-500">RAM</div></div>
            <div class="rounded-md bg-zinc-50 p-2"><div class="font-mono text-[15px] font-semibold">1.21.8</div><div class="text-[11px] text-zinc-500">Version</div></div>
          </div>
          <pre class="h-44 overflow-auto rounded-md bg-[#0c0c0f] p-2.5 font-mono text-[11.5px] leading-5 text-[#e4e4e7]" aria-label="Spielkonsole" aria-live="polite">@for (l of consoleLines(); track $index) {<span>{{ l }}</span>
}</pre>
          <form class="mt-2 flex gap-1.5" (submit)="send($event)">
            <label class="sr-only" for="pv-cmd">Konsolenbefehl</label>
            <input id="pv-cmd" class="h-8 min-w-0 flex-1 rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" placeholder="list, say Hallo …" [value]="cmd()" (input)="cmd.set(v($event))" />
            <button z-button zSize="sm" type="submit" [zDisabled]="!cmd().trim()"><cx-icon name="terminal" [size]="13" />Senden</button>
          </form>
          <p class="mt-1.5 text-[11.5px] text-zinc-500">Konsole über Docker Attach/RCON (simuliert, lokal). Start/Stop, Updates, Dateien und Backups kommen aus der allgemeinen Verwaltung.</p>
          <button z-button zType="outline" zSize="sm" type="button" class="mt-2" (click)="store.openStack('craft')"><cx-icon name="layers" [size]="13" />Stack Craft öffnen</button>
        </div>
      </section>
    </div>
  `,
})
export class CxPreview {
  protected readonly store = inject(CxStore);
  protected readonly cmd = signal('');
  protected readonly consoleLines = signal<string[]>([
    '[09:38:10] Done (18.402s)! For help, type "help"',
    '[09:39:12] spieler_eins joined the game',
    '[09:40:01] spieler_zwei joined the game',
    '[09:40:55] spieler_drei joined the game',
    "[09:41:02] Can't keep up! Running 5214ms behind",
  ]);

  protected readonly routes: Route[] = [
    { host: 'media.example.com', target: 'jellyfin:8096', hostId: 'atlas', tls: 'gültig', middleware: 'Header, Kompression' },
    { host: 'cloud.example.com', target: 'nextcloud:443', hostId: 'boreal', tls: 'gültig', middleware: 'Redirect HTTPS, HSTS' },
    { host: 'whoami.example.com', target: 'whoami:80', hostId: 'boreal', tls: 'läuft ab', middleware: 'Basic Auth' },
  ];

  protected v(e: Event): string {
    return (e.target as HTMLInputElement).value;
  }

  protected send(e: Event): void {
    e.preventDefault();
    const c = this.cmd().trim();
    if (!c) return;
    const reply = c === 'list' ? 'There are 3 of a max of 12 players online: spieler_eins, spieler_zwei, spieler_drei' : c.startsWith('say ') ? `[Server] ${c.slice(4)}` : `Befehl „${c}“ simuliert ausgeführt`;
    this.consoleLines.update((l) => [...l, `> ${c}`, `[${nowTime()}] ${reply}`]);
    this.cmd.set('');
  }
}
