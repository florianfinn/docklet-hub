// Docklet Design Lab – opus-compact · Hub-Einstellungen (nach Arcane settings, kompakt)
// Abschnitte: Anmeldung, Benutzer, Benachrichtigungen, Updates & Zeitpläne, Backupziele, Schwachstellenscans, Auto Heal.
// Alles lokal und simuliert; keine echten Schlüssel, keine Requests.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ZardButtonComponent } from '../../shared/components/button';
import { CxIcon, type IconName } from './icon';
import {
  CHANNEL_TYPES,
  CxHubSettings,
  EVENT_TYPES,
  TARGET_TYPES,
  type Access,
  type AuthMode,
  type BackupTargetType,
} from './settings-state';
import { CxStore } from './store';
import { CxDialog, CxHost } from './ui';

type Section = 'auth' | 'users' | 'notify' | 'updates' | 'backup' | 'scan' | 'heal';

const SECTIONS: { id: Section; label: string; icon: IconName }[] = [
  { id: 'auth', label: 'Anmeldung', icon: 'key' },
  { id: 'users', label: 'Benutzer', icon: 'users' },
  { id: 'notify', label: 'Benachrichtigungen', icon: 'bell' },
  { id: 'updates', label: 'Updates & Zeitpläne', icon: 'update' },
  { id: 'backup', label: 'Backupziele', icon: 'archive' },
  { id: 'scan', label: 'Schwachstellenscans', icon: 'shield' },
  { id: 'heal', label: 'Auto Heal', icon: 'heart' },
];

const INPUT = 'h-8 w-full rounded-md border border-zinc-300 bg-white px-2 text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/15';

@Component({
  selector: 'cx-settings',
  imports: [FormsModule, ZardButtonComponent, CxIcon, CxDialog, CxHost],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid items-start gap-3 lg:grid-cols-[220px_minmax(0,1fr)]">
      <nav class="rounded-lg border border-zinc-200 bg-white p-1.5 lg:sticky lg:top-16" aria-label="Einstellungsbereiche">
        <ul class="flex gap-0.5 overflow-x-auto lg:block lg:space-y-0.5">
          @for (s of sections; track s.id) {
            <li class="shrink-0">
              <button type="button" class="flex h-8 w-full items-center gap-2 rounded-md px-2 text-left text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-zinc-900" [class]="section() === s.id ? 'bg-zinc-100 font-medium' : 'text-zinc-600 hover:bg-zinc-50'" [attr.aria-current]="section() === s.id ? 'true' : null" (click)="section.set(s.id)">
                <cx-icon [name]="s.icon" [size]="14" />{{ s.label }}
              </button>
            </li>
          }
        </ul>
      </nav>

      <section class="min-w-0 rounded-lg border border-zinc-200 bg-white" [attr.aria-label]="current().label">
        <header class="flex items-center gap-2 border-b border-zinc-200 px-4 py-3">
          <cx-icon [name]="current().icon" [size]="16" />
          <h2 class="text-[15px] font-semibold">{{ current().label }}</h2>
        </header>
        <div class="space-y-4 p-4">
          @switch (section()) {
            @case ('auth') {
              <fieldset class="space-y-1.5">
                <legend class="mb-1 text-[12px] font-medium text-zinc-700">Anmeldeart</legend>
                @for (a of authModes; track a.id) {
                  <label class="flex cursor-pointer gap-2.5 rounded-md border p-2.5 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-zinc-900" [class]="hub.authMode() === a.id ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-200 hover:bg-zinc-50'">
                    <input type="radio" name="auth" class="mt-0.5 size-4 accent-zinc-900" [checked]="hub.authMode() === a.id" (change)="setAuth(a.id)" />
                    <span><span class="block font-medium">{{ a.label }}</span><span class="block text-[12px] text-zinc-600">{{ a.hint }}</span></span>
                  </label>
                }
              </fieldset>
              @if (hub.authMode() === 'none') {
                <div class="flex gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 p-2.5 text-[12.5px] text-amber-800"><cx-icon name="alert" [size]="15" class="mt-px shrink-0" />Ohne Login hat jeder im Netz Vollzugriff. Nur in vertrauenswürdigen Netzen verwenden.</div>
              }
              @if (hub.authMode() === 'proxy') {
                <div class="grid gap-3 sm:grid-cols-2">
                  <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Benutzer-Header</span><input [class]="inputCls + ' font-mono'" [ngModel]="hub.proxyHeader()" (ngModelChange)="hub.proxyHeader.set($event)" /></label>
                  <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Vertrauenswürdige Proxys</span><input [class]="inputCls + ' font-mono'" [ngModel]="hub.trustedProxies()" (ngModelChange)="hub.trustedProxies.set($event)" /></label>
                </div>
              }
            }
            @case ('users') {
              <p class="text-[12.5px] text-zinc-600">Optionale zusätzliche Benutzer mit einfachen Rechten auf zugewiesene Stacks. Geringe Priorität; keine feingranularen Rollen.</p>
              <div class="overflow-x-auto rounded-md border border-zinc-200">
                <table class="w-full min-w-[560px] text-left text-[12.5px]">
                  <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500"><tr><th class="px-3 py-2 font-semibold">Name</th><th class="px-3 py-2 font-semibold">Zugriff</th><th class="px-3 py-2 font-semibold">Stacks</th><th class="px-3 py-2"><span class="sr-only">Aktionen</span></th></tr></thead>
                  <tbody>
                    @for (u of hub.users(); track u.id) {
                      <tr class="border-b border-zinc-100 last:border-0">
                        <td class="px-3 py-2"><div class="font-medium">{{ u.name }}</div><div class="text-[11.5px] text-zinc-500">{{ u.email }}</div></td>
                        <td class="px-3 py-2">
                          @if (u.admin) { <span class="rounded-md border border-zinc-300 px-1.5 text-[11px] font-medium">Admin</span> }
                          @else {
                            <select class="h-7 rounded-md border border-zinc-200 bg-white px-1.5 text-[12px]" [attr.aria-label]="'Zugriff für ' + u.name" (change)="setAccess(u.id, sel($event))">
                              <option value="voll" [selected]="u.access === 'voll'">Vollzugriff</option>
                              <option value="eingeschraenkt" [selected]="u.access === 'eingeschraenkt'">Eingeschränkt</option>
                            </select>
                          }
                        </td>
                        <td class="px-3 py-2">{{ u.admin ? 'alle' : stackNames(u.stacks) }}</td>
                        <td class="px-3 py-2 text-right">@if (!u.admin) { <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-500 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="u.name + ' entfernen'" (click)="removeUser(u.id)"><cx-icon name="trash" [size]="14" /></button> }</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
              <ul class="space-y-1 text-[12px] text-zinc-600">
                <li><b>Vollzugriff:</b> zugewiesene Stacks inkl. Updates und Compose-Editor. Keine zugesicherte Sicherheitsgrenze für fremde Benutzer.</li>
                <li><b>Eingeschränkt:</b> Start/Stop, Logs und Shell.</li>
              </ul>
              <button z-button zType="outline" zSize="sm" type="button" (click)="openUser()"><cx-icon name="plus" [size]="13" />Benutzer hinzufügen</button>
            }
            @case ('notify') {
              <p class="text-[12.5px] text-zinc-600">Nur eingerichtete Kanäle werden angezeigt. Den Kanaltyp wählen Sie beim Hinzufügen.</p>
              <ul class="space-y-2">
                @for (c of hub.channels(); track c.id) {
                  <li class="rounded-md border border-zinc-200 p-2.5">
                    <div class="flex flex-wrap items-center gap-2">
                      <cx-icon [name]="c.type === 'email' ? 'mail' : 'bell'" [size]="15" class="text-zinc-500" />
                      <span class="font-medium">{{ c.name }}</span>
                      <span class="rounded-md border border-zinc-200 px-1.5 text-[11px] text-zinc-600">{{ typeLabel(c.type) }}</span>
                      <span class="truncate font-mono text-[11.5px] text-zinc-500">{{ c.target }}</span>
                      <label class="ml-auto flex items-center gap-1.5 text-[12px]"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="c.enabled" (change)="toggleChannel(c.id)" />Aktiv</label>
                      <button z-button zType="ghost" zSize="xs" type="button" (click)="store.notify('Testnachricht an ' + c.name + ' (simuliert).')">Test</button>
                      <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-500 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="c.name + ' entfernen'" (click)="removeChannel(c.id)"><cx-icon name="trash" [size]="14" /></button>
                    </div>
                    <div class="mt-1.5 flex flex-wrap gap-1">@for (e of c.events; track e) { <span class="rounded-full bg-zinc-100 px-2 text-[11px] text-zinc-700">{{ e }}</span> }</div>
                  </li>
                } @empty {
                  <li class="rounded-md border border-dashed border-zinc-300 p-4 text-center text-zinc-600">Noch kein Kanal eingerichtet.</li>
                }
              </ul>
              <button z-button zType="outline" zSize="sm" type="button" (click)="openChannel()"><cx-icon name="plus" [size]="13" />Kanal hinzufügen</button>
            }
            @case ('updates') {
              <div class="grid gap-3 sm:grid-cols-3">
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Prüfintervall</span>
                  <select [class]="inputCls" [ngModel]="hub.checkInterval()" (ngModelChange)="hub.checkInterval.set($event)"><option value="1h">stündlich</option><option value="6h">alle 6 Stunden</option><option value="24h">täglich</option></select>
                </label>
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Standard für neue Stacks</span>
                  <select [class]="inputCls" [ngModel]="hub.defaultPolicy()" (ngModelChange)="hub.defaultPolicy.set($event)"><option value="pruefen">Nur prüfen (empfohlen)</option><option value="auto">Automatisch nach Zeitplan</option></select>
                </label>
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Wartungsfenster</span><input type="time" [class]="inputCls" [ngModel]="hub.maintenanceWindow()" (ngModelChange)="hub.maintenanceWindow.set($event)" /></label>
              </div>
              <p class="text-[12px] text-zinc-600">Automatische Installation nur nach ausdrücklicher Aktivierung je Stack. Bei Fehlern keine automatische Rückkehr – vorheriges Image und Konfiguration stehen zur manuellen Wiederherstellung bereit.</p>
              <div class="overflow-x-auto rounded-md border border-zinc-200">
                <table class="w-full min-w-[480px] text-left text-[12.5px]">
                  <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500"><tr><th class="px-3 py-2 font-semibold">Stack</th><th class="px-3 py-2 font-semibold">Host</th><th class="px-3 py-2 font-semibold">Richtlinie</th><th class="px-3 py-2 font-semibold">Backup-Zeitplan</th></tr></thead>
                  <tbody>
                    @for (s of store.stacks(); track s.id) {
                      <tr class="border-b border-zinc-100 last:border-0">
                        <td class="px-3 py-1.5"><button type="button" class="font-medium hover:underline" (click)="store.openStack(s.id, 'updates')">{{ s.name }}</button></td>
                        <td class="px-3 py-1.5"><cx-host [name]="store.host(s.hostId).name" [color]="store.host(s.hostId).color" /></td>
                        <td class="px-3 py-1.5">{{ s.autoUpdate === 'pruefen' ? 'nur prüfen' : s.autoUpdate === 'taeglich' ? 'automatisch täglich' : 'automatisch wöchentlich' }}</td>
                        <td class="px-3 py-1.5 text-zinc-600">{{ s.backup.schedule }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            }
            @case ('backup') {
              <p class="text-[12.5px] text-zinc-600">Ziele für Volume-, Bind-Mount- und Systembackups: lokale Verzeichnisse, vorhandene Host-Mounts sowie eigene SMB-/NFS-Anbindung. Kein S3.</p>
              <ul class="space-y-1.5">
                @for (t of hub.targets(); track t.id) {
                  <li class="flex flex-wrap items-center gap-2 rounded-md border border-zinc-200 px-2.5 py-2">
                    <cx-icon [name]="t.type === 'smb' || t.type === 'nfs' ? 'network' : 'drive'" [size]="15" class="text-zinc-500" />
                    <span class="font-medium">{{ t.name }}</span>
                    <span class="rounded-md border border-zinc-200 px-1.5 text-[11px] text-zinc-600">{{ targetLabel(t.type) }}</span>
                    <span class="font-mono text-[11.5px] text-zinc-500">{{ t.path }}</span>
                    @if (t.hostId) { <cx-host [name]="store.host(t.hostId).name" [color]="store.host(t.hostId).color" /> }
                    <button z-button zType="ghost" zSize="xs" type="button" class="ml-auto" (click)="store.notify('Ziel ' + t.name + ' erreichbar, beschreibbar (simuliert).')">Prüfen</button>
                    <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-500 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="t.name + ' entfernen'" (click)="removeTarget(t.id)"><cx-icon name="trash" [size]="14" /></button>
                  </li>
                }
              </ul>
              <button z-button zType="outline" zSize="sm" type="button" (click)="openTarget()"><cx-icon name="plus" [size]="13" />Backupziel hinzufügen</button>
            }
            @case ('scan') {
              <label class="flex items-center gap-2.5"><input type="checkbox" class="size-4 accent-zinc-900" [checked]="store.scanEnabled()" (change)="store.scanEnabled.set(!store.scanEnabled())" /><span class="font-medium">Schwachstellenscans aktivieren (optional)</span></label>
              <div class="grid gap-3 sm:grid-cols-2">
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Zeitplan</span>
                  <select [class]="inputCls" [disabled]="!store.scanEnabled()" [ngModel]="store.scanSchedule()" (ngModelChange)="store.scanSchedule.set($event)"><option value="täglich 04:00">täglich 04:00</option><option value="wöchentlich So 04:00">wöchentlich So 04:00</option><option value="nur manuell">nur manuell</option></select>
                </label>
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Benachrichtigen ab</span>
                  <select [class]="inputCls" [disabled]="!store.scanEnabled()"><option>Hoch</option><option>Kritisch</option><option>Nie</option></select>
                </label>
              </div>
              <p class="text-[12px] text-zinc-600">Getrennt von der Update-Erkennung. Ergebnisse unter <button type="button" class="font-medium underline" (click)="store.go('security')">Sicherheit</button> und optional als Dashboard-Widget.</p>
            }
            @case ('heal') {
              <label class="flex items-center gap-2.5"><input type="checkbox" class="size-4 accent-zinc-900" [checked]="hub.healEnabled()" (change)="hub.healEnabled.set(!hub.healEnabled())" /><span class="font-medium">Unhealthy Container begrenzt neu starten</span></label>
              <div class="grid gap-3 sm:grid-cols-2">
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Max. Neustarts</span><input type="number" min="1" max="10" [class]="inputCls" [disabled]="!hub.healEnabled()" [ngModel]="hub.healMax()" (ngModelChange)="hub.healMax.set(+$event)" /></label>
                <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Zeitfenster</span>
                  <select [class]="inputCls" [disabled]="!hub.healEnabled()" [ngModel]="hub.healWindow()" (ngModelChange)="hub.healWindow.set($event)"><option value="1 h">1 Stunde</option><option value="6 h">6 Stunden</option><option value="24 h">24 Stunden</option></select>
                </label>
              </div>
              <div>
                <div class="mb-1 text-[12px] font-medium text-zinc-700">Ausnahmen</div>
                <div class="flex flex-wrap gap-1.5">
                  @for (c of healCandidates(); track c.id) {
                    <label class="inline-flex items-center gap-1.5 rounded-md border border-zinc-200 px-2 py-1 text-[12px]"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="hub.healExceptions().includes(c.id)" (change)="toggleException(c.id)" />{{ c.name }}</label>
                  }
                </div>
              </div>
              <p class="text-[12px] text-zinc-600">Unerwartete Stopps regeln die Docker-Neustartregeln (restart:). Eine zusätzliche Selbstheilung gestoppter Container gibt es nicht.</p>
            }
          }
        </div>
      </section>
    </div>

    <!-- Dialoge -->
    <cx-dialog [open]="dlg() === 'user'" heading="Benutzer hinzufügen" description="Einfache Rechte auf zugewiesene Stacks." icon="users" (closed)="dlg.set(null)">
      <form id="cx-user-form" class="space-y-3 px-4 pb-4" (ngSubmit)="addUser()">
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block"><span class="mb-1 block text-[12px] font-medium">Name *</span><input [class]="inputCls" name="n" required autofocus [(ngModel)]="fName" /></label>
          <label class="block"><span class="mb-1 block text-[12px] font-medium">E-Mail</span><input [class]="inputCls" name="e" placeholder="name@example.com" [(ngModel)]="fEmail" /></label>
        </div>
        <fieldset><legend class="mb-1 text-[12px] font-medium">Zugriff</legend>
          <div class="flex gap-3 text-[12.5px]">
            <label class="flex items-center gap-1.5"><input type="radio" name="acc" class="accent-zinc-900" [checked]="fAccess === 'voll'" (change)="fAccess = 'voll'" />Vollzugriff</label>
            <label class="flex items-center gap-1.5"><input type="radio" name="acc" class="accent-zinc-900" [checked]="fAccess === 'eingeschraenkt'" (change)="fAccess = 'eingeschraenkt'" />Eingeschränkt</label>
          </div>
        </fieldset>
        <fieldset><legend class="mb-1 text-[12px] font-medium">Stacks</legend>
          <div class="flex flex-wrap gap-1.5">
            @for (s of store.stacks(); track s.id) {
              <label class="inline-flex items-center gap-1.5 rounded-md border border-zinc-200 px-2 py-1 text-[12px]"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="fStacks.includes(s.id)" (change)="toggleFStack(s.id)" />{{ s.name }}</label>
            }
          </div>
        </fieldset>
      </form>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="dlg.set(null)">Abbrechen</button>
        <button z-button zSize="sm" type="submit" form="cx-user-form" [zDisabled]="!fName.trim()">Hinzufügen</button>
      </div>
    </cx-dialog>

    <cx-dialog [open]="dlg() === 'channel'" heading="Kanal hinzufügen" description="Kanaltyp wählen, Ziel eintragen, Ereignisse festlegen." icon="bell" (closed)="dlg.set(null)">
      <form id="cx-ch-form" class="space-y-3 px-4 pb-4" (ngSubmit)="addChannel()">
        <label class="block"><span class="mb-1 block text-[12px] font-medium">Kanaltyp</span>
          <select [class]="inputCls" name="t" autofocus [(ngModel)]="fType">
            @for (t of channelTypes; track t.id) { <option [value]="t.id">{{ t.label }}</option> }
          </select>
        </label>
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block"><span class="mb-1 block text-[12px] font-medium">Name *</span><input [class]="inputCls" name="n" required [(ngModel)]="fName" [placeholder]="typeLabel(fType) + ' Homelab'" /></label>
          <label class="block"><span class="mb-1 block text-[12px] font-medium">{{ typeMeta().field }} *</span><input [class]="inputCls + ' font-mono'" name="z" required [(ngModel)]="fTarget" [placeholder]="typeMeta().placeholder" /></label>
        </div>
        <fieldset><legend class="mb-1 text-[12px] font-medium">Ereignisse</legend>
          <div class="flex flex-wrap gap-1.5">
            @for (e of eventTypes; track e) {
              <label class="inline-flex items-center gap-1.5 rounded-md border border-zinc-200 px-2 py-1 text-[12px]"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="fEvents.includes(e)" (change)="toggleFEvent(e)" />{{ e }}</label>
            }
          </div>
        </fieldset>
      </form>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="dlg.set(null)">Abbrechen</button>
        <button z-button zSize="sm" type="submit" form="cx-ch-form" [zDisabled]="!fName.trim() || !fTarget.trim()">Kanal anlegen</button>
      </div>
    </cx-dialog>

    <cx-dialog [open]="dlg() === 'target'" heading="Backupziel hinzufügen" description="Lokal, Host-Mount, SMB oder NFS. S3 wird nicht unterstützt." icon="archive" (closed)="dlg.set(null)">
      <form id="cx-bt-form" class="space-y-3 px-4 pb-4" (ngSubmit)="addTarget()">
        <fieldset><legend class="mb-1 text-[12px] font-medium">Art</legend>
          <div class="grid gap-1.5 sm:grid-cols-2">
            @for (t of targetTypes; track t.id) {
              <label class="flex cursor-pointer gap-2 rounded-md border p-2 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-zinc-900" [class]="fTType === t.id ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-200'">
                <input type="radio" name="tt" class="mt-0.5 accent-zinc-900" [checked]="fTType === t.id" (change)="fTType = t.id" />
                <span><span class="block text-[12.5px] font-medium">{{ t.label }}</span><span class="block text-[11.5px] text-zinc-600">{{ t.hint }}</span></span>
              </label>
            }
          </div>
        </fieldset>
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block"><span class="mb-1 block text-[12px] font-medium">Name *</span><input [class]="inputCls" name="n" required [(ngModel)]="fName" /></label>
          <label class="block"><span class="mb-1 block text-[12px] font-medium">Pfad / Freigabe *</span><input [class]="inputCls + ' font-mono'" name="p" required [(ngModel)]="fTarget" [placeholder]="targetMeta().placeholder" /></label>
        </div>
        @if (fTType === 'smb') {
          <div class="grid gap-3 sm:grid-cols-2">
            <label class="block"><span class="mb-1 block text-[12px] font-medium">Benutzer</span><input [class]="inputCls" name="su" placeholder="backup" /></label>
            <label class="block"><span class="mb-1 block text-[12px] font-medium">Passwort</span><input type="password" [class]="inputCls" name="sp" placeholder="nur Demo" autocomplete="off" /></label>
          </div>
        }
        <p class="text-[11.5px] text-zinc-500">Rechte und Mount-Umsetzung werden später evaluiert; hier nur simuliert.</p>
      </form>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="dlg.set(null)">Abbrechen</button>
        <button z-button zSize="sm" type="submit" form="cx-bt-form" [zDisabled]="!fName.trim() || !fTarget.trim()">Ziel anlegen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxSettings {
  protected readonly store = inject(CxStore);
  protected readonly hub = inject(CxHubSettings);
  protected readonly sections = SECTIONS;
  protected readonly section = signal<Section>('auth');
  protected readonly dlg = signal<'user' | 'channel' | 'target' | null>(null);
  protected readonly inputCls = INPUT;
  protected readonly channelTypes = CHANNEL_TYPES;
  protected readonly eventTypes = EVENT_TYPES;
  protected readonly targetTypes = TARGET_TYPES;

  protected readonly authModes: { id: AuthMode; label: string; hint: string }[] = [
    { id: 'none', label: 'Kein Login', hint: 'Für isolierte Heimnetze. Jeder mit Zugriff auf den Hub ist Admin.' },
    { id: 'local', label: 'Lokaler Admin-Login', hint: 'Benutzername und Passwort, im Hub gespeichert.' },
    { id: 'proxy', label: 'Reverse-Proxy', hint: 'Anmeldung erfolgt vorgelagert (z. B. SSO); Docklet liest den Benutzer aus einem Header.' },
  ];

  // Formularfelder der Dialoge
  protected fName = '';
  protected fEmail = '';
  protected fAccess: Access = 'eingeschraenkt';
  protected fStacks: string[] = [];
  protected fType = 'discord';
  protected fTarget = '';
  protected fEvents: string[] = ['Aktion fehlgeschlagen'];
  protected fTType: BackupTargetType = 'smb';
  private readonly typeTick = signal(0);

  protected readonly current = computed(() => SECTIONS.find((s) => s.id === this.section()) ?? SECTIONS[0]);
  protected readonly healCandidates = computed(() => [
    ...this.store.stacks().flatMap((s) => s.services.map((x) => ({ id: x.id, name: `${s.name}/${x.name}` }))),
    ...this.store.standalone().map((c) => ({ id: c.id, name: c.name })),
  ]);

  protected typeMeta() {
    this.typeTick();
    return CHANNEL_TYPES.find((t) => t.id === this.fType) ?? CHANNEL_TYPES[0];
  }

  protected targetMeta() {
    return TARGET_TYPES.find((t) => t.id === this.fTType) ?? TARGET_TYPES[0];
  }

  protected typeLabel(id: string): string {
    return CHANNEL_TYPES.find((t) => t.id === id)?.label ?? id;
  }

  protected targetLabel(id: BackupTargetType): string {
    return TARGET_TYPES.find((t) => t.id === id)?.label ?? id;
  }

  protected stackNames(ids: string[]): string {
    return ids.map((id) => this.store.stacks().find((s) => s.id === id)?.name ?? id).join(', ') || '–';
  }

  protected sel(e: Event): string {
    return (e.target as HTMLSelectElement).value;
  }

  protected setAuth(mode: AuthMode): void {
    this.hub.authMode.set(mode);
    this.store.notify('Anmeldeart geändert (simuliert, wirkt erst nach Neustart des Hubs).');
  }

  protected setAccess(id: string, value: string): void {
    const access: Access = value === 'voll' ? 'voll' : 'eingeschraenkt';
    this.hub.users.update((l) => l.map((u) => (u.id === id ? { ...u, access } : u)));
  }

  protected removeUser(id: string): void {
    this.hub.users.update((l) => l.filter((u) => u.id !== id));
  }

  private resetForm(): void {
    this.fName = '';
    this.fEmail = '';
    this.fTarget = '';
    this.fStacks = [];
    this.fEvents = ['Aktion fehlgeschlagen'];
  }

  protected openUser(): void {
    this.resetForm();
    this.fAccess = 'eingeschraenkt';
    this.dlg.set('user');
  }

  protected openChannel(): void {
    this.resetForm();
    this.fType = 'discord';
    this.dlg.set('channel');
  }

  protected openTarget(): void {
    this.resetForm();
    this.fTType = 'smb';
    this.dlg.set('target');
  }

  protected toggleFStack(id: string): void {
    this.fStacks = this.fStacks.includes(id) ? this.fStacks.filter((x) => x !== id) : [...this.fStacks, id];
  }

  protected toggleFEvent(e: string): void {
    this.fEvents = this.fEvents.includes(e) ? this.fEvents.filter((x) => x !== e) : [...this.fEvents, e];
  }

  protected addUser(): void {
    if (!this.fName.trim()) return;
    this.hub.users.update((l) => [...l, { id: this.hub.nextId('u'), name: this.fName.trim(), email: this.fEmail.trim() || '–', admin: false, access: this.fAccess, stacks: [...this.fStacks] }]);
    this.dlg.set(null);
    this.store.notify('Benutzer angelegt (simuliert, keine Einladung versendet).');
  }

  protected addChannel(): void {
    if (!this.fName.trim() || !this.fTarget.trim()) return;
    this.hub.channels.update((l) => [...l, { id: this.hub.nextId('c'), type: this.fType, name: this.fName.trim(), target: this.fTarget.trim(), events: [...this.fEvents], enabled: true }]);
    this.dlg.set(null);
    this.store.notify(`${this.typeLabel(this.fType)}-Kanal angelegt.`);
  }

  protected removeChannel(id: string): void {
    this.hub.channels.update((l) => l.filter((c) => c.id !== id));
  }

  protected toggleChannel(id: string): void {
    this.hub.channels.update((l) => l.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c)));
  }

  protected addTarget(): void {
    if (!this.fName.trim() || !this.fTarget.trim()) return;
    this.hub.targets.update((l) => [...l, { id: this.hub.nextId('b'), type: this.fTType, name: this.fName.trim(), path: this.fTarget.trim() }]);
    this.dlg.set(null);
    this.store.notify('Backupziel angelegt (simuliert).');
  }

  protected removeTarget(id: string): void {
    this.hub.targets.update((l) => l.filter((t) => t.id !== id));
  }

  protected toggleException(id: string): void {
    this.hub.healExceptions.update((l) => (l.includes(id) ? l.filter((x) => x !== id) : [...l, id]));
  }
}
