// Docklet Design Lab – opus-compact
// Compose-Synchronisation über `yaml` (parseDocument). Der Raw-Text ist die einzige
// Quelle der Wahrheit. Easy-Formulare ändern ausschließlich unterstützte Felder im
// geparsten Dokument; alle unbekannten Schlüssel, Kommentare und Langformen bleiben erhalten.
import { isMap, isScalar, isSeq, Pair, parseDocument, Scalar, YAMLMap, YAMLSeq, type Document } from 'yaml';

export interface EnvRow {
  key: string;
  value: string;
}

export interface ServiceModel {
  key: string;
  image: string;
  containerName: string;
  restart: string;
  ports: string[];
  portsExtra: number;
  volumes: string[];
  volumesExtra: number;
  env: EnvRow[];
  envStyle: 'map' | 'list';
  healthTest: string;
  healthInterval: string;
  healthRetries: string;
  unknownKeys: string[];
}

export interface ComposeModel {
  name: string;
  services: ServiceModel[];
  topUnknown: string[];
}

export interface ComposeError {
  message: string;
  line?: number;
}

export interface ParseResult {
  ok: boolean;
  model: ComposeModel | null;
  errors: ComposeError[];
}

export type Hint = { level: 'pflicht' | 'hinweis'; text: string; service?: number };

export type ScalarField = 'image' | 'container_name' | 'restart';
export type ListField = 'ports' | 'volumes';
export type HealthField = 'test' | 'interval' | 'retries';

const KNOWN_SERVICE_KEYS = new Set(['image', 'container_name', 'restart', 'ports', 'volumes', 'environment', 'healthcheck']);
const KNOWN_TOP_KEYS = new Set(['name', 'services']);

export const PORT_PATTERN = /^((\d{1,3}\.){3}\d{1,3}:)?(\d{1,5}(-\d{1,5})?:)?\d{1,5}(-\d{1,5})?(\/(tcp|udp))?$/;

function str(v: unknown): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') return '';
  return String(v);
}

function keyOf(p: Pair<unknown, unknown>): string {
  return isScalar(p.key) ? str(p.key.value) : str(p.key);
}

function needsQuote(v: string): boolean {
  return v === '' || /^(true|false|yes|no|on|off|null|~|-?\d+(\.\d+)?|0x[0-9a-f]+)$/i.test(v) || /[:#{}[\],&*!|>'"%@`]/.test(v);
}

function scalarFor(v: string): Scalar<string> {
  const s = new Scalar(v);
  if (needsQuote(v)) s.type = 'QUOTE_DOUBLE';
  return s;
}

/* ------------------------------------------------------------------ Parsen */

export function parseCompose(text: string): ParseResult {
  const doc = parseDocument(text);
  if (doc.errors.length > 0) {
    return {
      ok: false,
      model: null,
      errors: doc.errors.map((e) => ({ message: e.message.split('\n')[0], line: e.linePos?.[0]?.line })),
    };
  }
  const root = doc.contents;
  if (root !== null && !isMap(root)) {
    return { ok: false, model: null, errors: [{ message: 'Die oberste Ebene muss eine Zuordnung (Map) sein.', line: 1 }] };
  }
  const services = doc.get('services');
  if (services !== undefined && services !== null && !isMap(services)) {
    return { ok: false, model: null, errors: [{ message: '„services“ muss eine Zuordnung von Servicenamen sein.' }] };
  }
  return { ok: true, model: readModel(doc), errors: [] };
}

function readModel(doc: Document): ComposeModel {
  const model: ComposeModel = { name: str(doc.get('name')), services: [], topUnknown: [] };
  const root = doc.contents;
  if (isMap(root)) {
    for (const p of root.items) {
      const k = keyOf(p);
      if (!KNOWN_TOP_KEYS.has(k)) model.topUnknown.push(k);
    }
  }
  const services = doc.get('services');
  if (isMap(services)) {
    for (const p of services.items) {
      model.services.push(readService(keyOf(p), isMap(p.value) ? p.value : null));
    }
  }
  return model;
}

function readService(key: string, m: YAMLMap | null): ServiceModel {
  const svc: ServiceModel = {
    key,
    image: '',
    containerName: '',
    restart: '',
    ports: [],
    portsExtra: 0,
    volumes: [],
    volumesExtra: 0,
    env: [],
    envStyle: 'map',
    healthTest: '',
    healthInterval: '',
    healthRetries: '',
    unknownKeys: [],
  };
  if (!m) return svc;
  svc.image = str(m.get('image'));
  svc.containerName = str(m.get('container_name'));
  svc.restart = str(m.get('restart'));
  const ports = readStringList(m.get('ports'));
  svc.ports = ports.values;
  svc.portsExtra = ports.extra;
  const vols = readStringList(m.get('volumes'));
  svc.volumes = vols.values;
  svc.volumesExtra = vols.extra;

  const env = m.get('environment');
  if (isMap(env)) {
    svc.envStyle = 'map';
    svc.env = env.items.map((p) => ({ key: keyOf(p), value: isScalar(p.value) ? str(p.value.value) : '' }));
  } else if (isSeq(env)) {
    svc.envStyle = 'list';
    svc.env = env.items
      .filter((i): i is Scalar => isScalar(i))
      .map((i) => {
        const raw = str(i.value);
        const at = raw.indexOf('=');
        return at < 0 ? { key: raw, value: '' } : { key: raw.slice(0, at), value: raw.slice(at + 1) };
      });
  }

  const hc = m.get('healthcheck');
  if (isMap(hc)) {
    const t = hc.get('test');
    if (isSeq(t)) {
      const parts = t.items.map((i) => (isScalar(i) ? str(i.value) : ''));
      svc.healthTest = parts[0] === 'CMD-SHELL' || parts[0] === 'CMD' ? parts.slice(1).join(' ') : parts.join(' ');
    } else {
      svc.healthTest = str(t);
    }
    svc.healthInterval = str(hc.get('interval'));
    svc.healthRetries = str(hc.get('retries'));
  }

  for (const p of m.items) {
    const k = keyOf(p);
    if (!KNOWN_SERVICE_KEYS.has(k)) svc.unknownKeys.push(k);
  }
  return svc;
}

function readStringList(node: unknown): { values: string[]; extra: number } {
  if (!isSeq(node)) return { values: [], extra: 0 };
  const values: string[] = [];
  let extra = 0;
  for (const item of node.items) {
    if (isScalar(item)) values.push(str(item.value));
    else extra++;
  }
  return { values, extra };
}

/* ------------------------------------------------------------- Bearbeiten */

/** Wendet eine Änderung auf den Raw-Text an. Bei ungültigem YAML bleibt der Text unverändert. */
export function editCompose(text: string, fn: (doc: Document) => void): string {
  const doc = parseDocument(text);
  if (doc.errors.length > 0) return text;
  if (doc.contents === null) doc.contents = doc.createNode({}) as never;
  fn(doc);
  return doc.toString();
}

function ensureServices(doc: Document): YAMLMap {
  const s = doc.get('services');
  if (isMap(s)) return s;
  const m = doc.createNode({}) as YAMLMap;
  doc.set('services', m);
  return m;
}

function ensureService(doc: Document, key: string): YAMLMap {
  const services = ensureServices(doc);
  const s = services.get(key);
  if (isMap(s)) return s;
  const m = doc.createNode({}) as YAMLMap;
  services.set(key, m);
  return m;
}

export function setStackName(doc: Document, name: string): void {
  if (name === '') doc.delete('name');
  else doc.set('name', name);
}

export function setScalarField(doc: Document, key: string, field: ScalarField, value: string): void {
  const svc = ensureService(doc, key);
  if (value === '' && field !== 'image') {
    svc.delete(field);
    return;
  }
  const existing = svc.get(field, true);
  if (isScalar(existing)) {
    existing.value = value;
    if (value === '') existing.type = 'QUOTE_DOUBLE';
  } else {
    svc.set(field, value === '' ? scalarFor('') : value);
  }
}

/** Aktualisiert die Kurzform-Einträge einer Liste in-place. Langform-Einträge (Maps) bleiben erhalten. */
export function setStringList(doc: Document, key: string, field: ListField, values: string[]): void {
  const svc = ensureService(doc, key);
  const existing: unknown = svc.get(field);
  const quote = field === 'ports';
  if (!isSeq(existing)) {
    if (values.length === 0) {
      svc.delete(field);
      return;
    }
    const seq = doc.createNode([]) as YAMLSeq;
    for (const v of values) seq.items.push(quote ? quoted(v) : scalarFor(v));
    svc.set(field, seq);
    return;
  }
  const scalarIdx = existing.items.map((it, i) => (isScalar(it) ? i : -1)).filter((i) => i >= 0);
  values.forEach((v, i) => {
    if (i < scalarIdx.length) {
      const node = existing.items[scalarIdx[i]] as Scalar;
      node.value = v;
    } else {
      existing.items.push(quote ? quoted(v) : scalarFor(v));
    }
  });
  const remove = new Set(scalarIdx.slice(values.length));
  existing.items = existing.items.filter((_, i) => !remove.has(i));
  if (existing.items.length === 0) svc.delete(field);
}

function quoted(v: string): Scalar<string> {
  const s = new Scalar(v);
  s.type = 'QUOTE_DOUBLE';
  return s;
}

export function setEnv(doc: Document, key: string, rows: EnvRow[], style: 'map' | 'list'): void {
  const svc = ensureService(doc, key);
  const clean = rows.filter((r) => r.key.trim() !== '');
  if (clean.length === 0) {
    svc.delete('environment');
    return;
  }
  const existing: unknown = svc.get('environment');
  if (style === 'list') {
    const seq = isSeq(existing) ? existing : (doc.createNode([]) as YAMLSeq);
    const scalars = seq.items.filter((i) => isScalar(i)) as Scalar[];
    const others = seq.items.filter((i) => !isScalar(i));
    seq.items = [
      ...others,
      ...clean.map((r, i) => {
        const text = `${r.key}=${r.value}`;
        const node = scalars[i];
        if (node) {
          node.value = text;
          return node;
        }
        return scalarFor(text);
      }),
    ];
    if (!isSeq(existing)) svc.set('environment', seq);
    return;
  }
  // Zeilen entsprechen der Reihenfolge der vorhandenen Paare (so werden sie gelesen).
  // Bestehende Paare werden in-place aktualisiert, damit Kommentare und Quoting erhalten bleiben.
  const map = isMap(existing) ? existing : (doc.createNode({}) as YAMLMap);
  const old = map.items;
  map.items = clean.map((r, i) => {
    const pair = old[i];
    if (!pair) return new Pair(new Scalar(r.key), scalarFor(r.value));
    if (isScalar(pair.key)) pair.key.value = r.key;
    else pair.key = new Scalar(r.key);
    if (isScalar(pair.value)) {
      pair.value.value = r.value;
      if (needsQuote(r.value) && (pair.value.type === 'PLAIN' || pair.value.type === undefined)) pair.value.type = 'QUOTE_DOUBLE';
    } else {
      pair.value = scalarFor(r.value);
    }
    return pair;
  });
  if (!isMap(existing)) svc.set('environment', map);
}

export function setHealthField(doc: Document, key: string, field: HealthField, value: string): void {
  const svc = ensureService(doc, key);
  let hc: unknown = svc.get('healthcheck');
  if (!isMap(hc)) {
    if (value === '') return;
    hc = doc.createNode({}) as YAMLMap;
    svc.set('healthcheck', hc);
  }
  const map = hc as YAMLMap;
  if (value === '') {
    map.delete(field);
    if (map.items.length === 0) svc.delete('healthcheck');
    return;
  }
  if (field === 'test') {
    const old: unknown = map.get('test');
    const first: unknown = isSeq(old) ? old.items[0] : undefined;
    const execForm = isScalar(first) && first.value === 'CMD';
    const parts = execForm ? ['CMD', ...value.split(/\s+/).filter(Boolean)] : ['CMD-SHELL', value];
    const seq = doc.createNode(parts) as YAMLSeq;
    seq.flow = true;
    map.set('test', seq);
  } else if (field === 'retries' && /^\d+$/.test(value)) {
    map.set('retries', Number(value));
  } else {
    map.set(field, value);
  }
}

export function addService(doc: Document, key: string, body: Record<string, unknown>): void {
  const services = ensureServices(doc);
  services.set(key, doc.createNode(body));
}

export function removeService(doc: Document, key: string): void {
  const services = doc.get('services');
  if (isMap(services)) services.delete(key);
}

export function renameService(doc: Document, oldKey: string, newKey: string): void {
  const services = doc.get('services');
  if (!isMap(services) || newKey === '' || oldKey === newKey) return;
  if (services.items.some((p) => keyOf(p) === newKey)) return;
  const pair = services.items.find((p) => keyOf(p) === oldKey);
  if (!pair) return;
  if (isScalar(pair.key)) pair.key.value = newKey;
  else pair.key = new Scalar(newKey);
}

export function uniqueKey(model: ComposeModel | null, base: string): string {
  const clean = (base.toLowerCase().replace(/[^a-z0-9_.-]+/g, '-').replace(/^-+|-+$/g, '') || 'service').slice(0, 40);
  const taken = new Set((model?.services ?? []).map((s) => s.key));
  if (!taken.has(clean)) return clean;
  let i = 2;
  while (taken.has(`${clean}-${i}`)) i++;
  return `${clean}-${i}`;
}

/* -------------------------------------------------------------- Prüfungen */

export function collectHints(model: ComposeModel | null): Hint[] {
  if (!model) return [];
  const hints: Hint[] = [];
  if (!model.name.trim()) hints.push({ level: 'pflicht', text: 'Stackname fehlt (Grundlagen).' });
  if (model.services.length === 0) hints.push({ level: 'pflicht', text: 'Mindestens ein Service wird benötigt.' });
  model.services.forEach((s, i) => {
    if (!s.image.trim()) hints.push({ level: 'pflicht', service: i, text: `${s.key}: Image fehlt.` });
    s.ports.forEach((p) => {
      if (p.trim() === '') hints.push({ level: 'pflicht', service: i, text: `${s.key}: leerer Port-Eintrag.` });
      else if (!PORT_PATTERN.test(p.trim())) hints.push({ level: 'hinweis', service: i, text: `${s.key}: Port „${p}“ hat kein bekanntes Format (Host:Container).` });
    });
    s.volumes.forEach((v) => {
      if (v.trim() === '') hints.push({ level: 'pflicht', service: i, text: `${s.key}: leerer Mount-Eintrag.` });
    });
    s.env.forEach((e) => {
      if (e.key && e.value === '') hints.push({ level: 'hinweis', service: i, text: `${s.key}: Variable ${e.key} ist leer.` });
    });
  });
  return hints;
}

/* ---------------------------------------------------------- docker run */

export interface ImportResult {
  ok: boolean;
  key: string;
  body: Record<string, unknown>;
  notes: string[];
  error?: string;
}

export function tokenize(cmd: string): string[] {
  const src = cmd.replace(/\\\r?\n/g, ' ');
  const out: string[] = [];
  let cur = '';
  let quote: '"' | "'" | null = null;
  let has = false;
  for (const ch of src) {
    if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
      has = true;
    } else if (/\s/.test(ch)) {
      if (has || cur) out.push(cur);
      cur = '';
      has = false;
    } else {
      cur += ch;
      has = true;
    }
  }
  if (has || cur) out.push(cur);
  return out;
}

const VALUE_FLAGS: Record<string, string> = {
  '-p': 'ports', '--publish': 'ports',
  '-v': 'volumes', '--volume': 'volumes',
  '-e': 'environment', '--env': 'environment',
  '--name': 'container_name',
  '--restart': 'restart',
  '--network': 'networks', '--net': 'networks',
  '--health-cmd': 'health',
  '--health-interval': 'health-interval',
  '--health-retries': 'health-retries',
  '-l': 'labels', '--label': 'labels',
  '-h': 'hostname', '--hostname': 'hostname',
  '-w': 'working_dir', '--workdir': 'working_dir',
  '-u': 'user', '--user': 'user',
  '-m': 'mem_limit', '--memory': 'mem_limit',
  '--env-file': 'env_file',
  '--entrypoint': 'entrypoint',
  '--cap-add': 'cap_add',
  '--device': 'devices',
};
const BOOL_FLAGS: Record<string, string | null> = {
  '-d': null, '--detach': null, '--rm': null, '-i': null, '-t': null, '--interactive': null, '--tty': null,
  '--privileged': 'privileged', '--init': 'init',
};

export function dockerRunToService(cmd: string, model: ComposeModel | null): ImportResult {
  const tokens = tokenize(cmd.trim());
  let i = 0;
  if (tokens[i] === 'sudo') i++;
  if (tokens[i] === 'docker') i++;
  if (tokens[i] === 'container') i++;
  if (tokens[i] === 'run' || tokens[i] === 'create') i++;
  else return { ok: false, key: '', body: {}, notes: [], error: 'Kein „docker run“-Befehl erkannt.' };

  const body: Record<string, unknown> = {};
  const lists: Record<string, string[]> = {};
  const env: Record<string, string> = {};
  const labels: Record<string, string> = {};
  const health: Record<string, unknown> = {};
  const notes: string[] = [];
  let image = '';
  const command: string[] = [];

  while (i < tokens.length) {
    let t = tokens[i];
    if (image) {
      command.push(t);
      i++;
      continue;
    }
    let inline: string | undefined;
    if (t.startsWith('--') && t.includes('=')) {
      inline = t.slice(t.indexOf('=') + 1);
      t = t.slice(0, t.indexOf('='));
    }
    if (t in BOOL_FLAGS) {
      const target = BOOL_FLAGS[t];
      if (target) body[target] = true;
      i++;
      continue;
    }
    if (/^-[a-zA-Z]{2,}$/.test(t) && [...t.slice(1)].every((c) => 'dit'.includes(c))) {
      i++;
      continue;
    }
    if (t in VALUE_FLAGS) {
      const target = VALUE_FLAGS[t];
      const value = inline ?? tokens[i + 1] ?? '';
      i += inline !== undefined ? 1 : 2;
      switch (target) {
        case 'ports': case 'volumes': case 'networks': case 'cap_add': case 'devices':
          (lists[target] ??= []).push(value);
          break;
        case 'environment': {
          const at = value.indexOf('=');
          env[at < 0 ? value : value.slice(0, at)] = at < 0 ? '' : value.slice(at + 1);
          break;
        }
        case 'labels': {
          const at = value.indexOf('=');
          labels[at < 0 ? value : value.slice(0, at)] = at < 0 ? '' : value.slice(at + 1);
          break;
        }
        case 'health': health['test'] = ['CMD-SHELL', value]; break;
        case 'health-interval': health['interval'] = value; break;
        case 'health-retries': health['retries'] = /^\d+$/.test(value) ? Number(value) : value; break;
        default: body[target] = value;
      }
      continue;
    }
    if (t.startsWith('-')) {
      notes.push(`Nicht übernommen: ${t} (bitte im Advanced-Modus ergänzen)`);
      const next = tokens[i + 1];
      i += inline === undefined && next !== undefined && !next.startsWith('-') && tokens.length - i > 2 ? 2 : 1;
      continue;
    }
    image = t;
    i++;
  }

  if (!image) return { ok: false, key: '', body: {}, notes, error: 'Kein Image im Befehl gefunden.' };
  const ordered: Record<string, unknown> = { image };
  if (body['container_name']) ordered['container_name'] = body['container_name'];
  ordered['restart'] = body['restart'] ?? 'unless-stopped';
  if (lists['ports']) ordered['ports'] = lists['ports'];
  if (lists['volumes']) ordered['volumes'] = lists['volumes'];
  if (Object.keys(env).length) ordered['environment'] = env;
  if (Object.keys(health).length) ordered['healthcheck'] = health;
  if (lists['networks']) ordered['networks'] = lists['networks'];
  if (Object.keys(labels).length) ordered['labels'] = labels;
  if (lists['cap_add']) ordered['cap_add'] = lists['cap_add'];
  if (lists['devices']) ordered['devices'] = lists['devices'];
  for (const k of ['hostname', 'working_dir', 'user', 'mem_limit', 'env_file', 'entrypoint', 'privileged', 'init']) {
    if (body[k] !== undefined) ordered[k] = body[k];
  }
  if (command.length) ordered['command'] = command;
  if (!body['restart']) notes.push('Keine Neustartregel angegeben – „unless-stopped“ vorgeschlagen.');
  const base = String(body['container_name'] ?? image.split('/').pop()?.split(':')[0] ?? 'service');
  return { ok: true, key: uniqueKey(model, base), body: ordered, notes };
}

/* ------------------------------------------- GitHub / Docker Hub (simuliert) */

const HUB_META: Record<string, { ports: string[]; volumes: string[]; env: Record<string, string> }> = {
  nginx: { ports: ['8080:80'], volumes: [], env: {} },
  redis: { ports: [], volumes: ['/data'], env: {} },
  postgres: { ports: [], volumes: ['/var/lib/postgresql/data'], env: { POSTGRES_PASSWORD: '' } },
  'louislam/uptime-kuma': { ports: ['3001:3001'], volumes: ['/app/data'], env: {} },
  'vaultwarden/server': { ports: ['8081:80'], volumes: ['/data'], env: { DOMAIN: 'https://vault.example.com' } },
};

export function dockerHubImport(ref: string, model: ComposeModel | null): ImportResult {
  const image = ref.trim().replace(/^https?:\/\/hub\.docker\.com\/(r|_)\//, '').replace(/\/$/, '');
  if (!/^[a-z0-9][a-z0-9._/-]*(:[\w.-]+)?$/.test(image)) {
    return { ok: false, key: '', body: {}, notes: [], error: 'Ungültiger Image-Name, z. B. „louislam/uptime-kuma“.' };
  }
  const name = image.split(':')[0];
  const meta = HUB_META[name] ?? { ports: [], volumes: [], env: {} };
  const body: Record<string, unknown> = { image: image.includes(':') ? image : `${image}:latest`, restart: 'unless-stopped' };
  const notes = ['Simulierte Metadaten (EXPOSE, VOLUME, ENV) aus Docker Hub übernommen.'];
  if (meta.ports.length) body['ports'] = meta.ports;
  else notes.push('Kein Port veröffentlicht – bei Bedarf unter „Ports“ ergänzen.');
  if (meta.volumes.length) body['volumes'] = meta.volumes;
  if (Object.keys(meta.env).length) body['environment'] = meta.env;
  if (Object.values(meta.env).some((v) => v === '')) notes.push('Pflichtvariablen ohne Wert wurden leer angelegt.');
  return { ok: true, key: uniqueKey(model, name.split('/').pop() ?? name), body, notes };
}

export function githubImport(url: string, model: ComposeModel | null): ImportResult {
  const m = /^https?:\/\/github\.com\/([\w.-]+)\/([\w.-]+)/.exec(url.trim());
  if (!m) return { ok: false, key: '', body: {}, notes: [], error: 'Bitte eine GitHub-URL angeben, z. B. https://github.com/example/whoami-stack' };
  const [, owner, repo] = m;
  const body: Record<string, unknown> = {
    image: `ghcr.io/${owner.toLowerCase()}/${repo.toLowerCase()}:latest`,
    restart: 'unless-stopped',
    ports: ['8080:8080'],
    environment: { TZ: 'Europe/Berlin', APP_URL: '' },
    labels: { 'org.opencontainers.image.source': `https://github.com/${owner}/${repo}` },
  };
  return {
    ok: true,
    key: uniqueKey(model, repo),
    body,
    notes: [
      `compose.yaml in ${owner}/${repo} gefunden (simuliert, einmaliger Import).`,
      'APP_URL hat im Repository keinen Standardwert – bitte ausfüllen.',
      'Kein Git Sync: spätere Änderungen im Repository werden nicht übernommen.',
    ],
  };
}

export function mountSource(volume: string): string {
  const parts = volume.split(':');
  return parts.length > 1 ? parts[0] : '';
}
