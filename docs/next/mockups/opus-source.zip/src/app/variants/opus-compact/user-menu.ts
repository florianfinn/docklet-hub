// Docklet Design Lab – opus-compact · Benutzer-Menü unten links (nach Arcane sidebar-user)
// Profil, Hub-Einstellungen, Abmelden (simuliert). Tastatur: Pfeiltasten, Escape, Fokus-Rückgabe.
import { ChangeDetectionStrategy, Component, ElementRef, computed, inject, output, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import type { PageId } from './data';
import { CxIcon } from './icon';
import { CxStore } from './store';
import { CxDialog } from './ui';

@Component({
  selector: 'cx-user-menu',
  imports: [ZardButtonComponent, CxIcon, CxDialog],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'relative block', '(document:click)': 'onDocClick($event)' },
  template: `
    <button
      #trigger
      type="button"
      class="flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left outline-none hover:bg-[#18181b] focus-visible:ring-2 focus-visible:ring-sky-400"
      aria-haspopup="menu"
      [attr.aria-expanded]="open()"
      aria-controls="cx-user-menu"
      (click)="toggle()"
      (keydown.arrowUp)="openAndFocus($event)"
      (keydown.arrowDown)="openAndFocus($event)"
    >
      <span class="grid size-8 shrink-0 place-items-center rounded-full bg-[#3f3f46] text-[12.5px] font-semibold text-white">{{ initial() }}</span>
      <span class="grid min-w-0 flex-1 leading-tight">
        <span class="truncate text-[13px] font-medium text-white">{{ store.profileName() }}</span>
        <span class="truncate text-[11px] text-[#a1a1aa]">{{ store.profileEmail() }}</span>
      </span>
      <cx-icon name="chevronUp" [size]="14" class="text-[#71717a]" />
    </button>

    @if (open()) {
      <div
        id="cx-user-menu"
        role="menu"
        aria-label="Benutzermenü"
        class="absolute bottom-full left-0 z-50 mb-1.5 w-full min-w-56 rounded-lg border border-zinc-200 bg-white p-1 text-zinc-900 shadow-xl"
        (keydown)="onMenuKey($event)"
      >
        <div class="flex items-center gap-2.5 px-2 py-2">
          <span class="grid size-8 place-items-center rounded-full bg-zinc-200 text-[12.5px] font-semibold">{{ initial() }}</span>
          <span class="grid min-w-0 leading-tight">
            <span class="truncate text-[13px] font-medium">{{ store.profileName() }}</span>
            <span class="truncate text-[11.5px] text-zinc-500">{{ store.profileEmail() }}</span>
          </span>
        </div>
        <div class="my-1 h-px bg-zinc-200" role="separator"></div>
        <button type="button" role="menuitem" class="cx-mi flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left text-[13px] outline-none hover:bg-zinc-100 focus-visible:bg-zinc-100" (click)="pick('profile')">
          <cx-icon name="user" [size]="15" class="text-zinc-500" />Profil
        </button>
        <button type="button" role="menuitem" class="cx-mi flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left text-[13px] outline-none hover:bg-zinc-100 focus-visible:bg-zinc-100" (click)="pick('settings')">
          <cx-icon name="settings" [size]="15" class="text-zinc-500" />Hub-Einstellungen
        </button>
        <div class="my-1 h-px bg-zinc-200" role="separator"></div>
        <button type="button" role="menuitem" class="cx-mi flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left text-[13px] text-red-700 outline-none hover:bg-red-500/10 focus-visible:bg-red-500/10" (click)="askLogout()">
          <cx-icon name="logout" [size]="15" />Abmelden
        </button>
      </div>
    }

    <cx-dialog [open]="logoutOpen()" heading="Abmelden?" description="In dieser Demo wird keine echte Sitzung beendet." icon="logout" tone="danger" width="sm" (closed)="logoutOpen.set(false)">
      <p class="px-4 pb-3 text-[13px] text-zinc-700">Je nach Anmeldeart (lokaler Admin oder Reverse-Proxy) würde Docklet zur Anmeldeseite bzw. zum Proxy zurückleiten.</p>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="logoutOpen.set(false)">Abbrechen</button>
        <button z-button zType="destructive" zSize="sm" type="button" (click)="logout()"><cx-icon name="logout" [size]="13" />Abmelden</button>
      </div>
    </cx-dialog>
  `,
})
export class CxUserMenu {
  protected readonly store = inject(CxStore);
  private readonly el = inject<ElementRef<HTMLElement>>(ElementRef);
  readonly navigate = output<PageId>();
  protected readonly open = signal(false);
  protected readonly logoutOpen = signal(false);
  protected readonly initial = computed(() => (this.store.profileName().trim().charAt(0) || '?').toUpperCase());

  protected toggle(): void {
    this.open.update((v) => !v);
    if (this.open()) this.focusItem(0);
  }

  protected openAndFocus(e: Event): void {
    e.preventDefault();
    this.open.set(true);
    this.focusItem(0);
  }

  protected pick(page: PageId): void {
    this.close();
    this.navigate.emit(page);
  }

  protected askLogout(): void {
    this.close();
    this.logoutOpen.set(true);
  }

  protected logout(): void {
    this.logoutOpen.set(false);
    this.store.notify('Abgemeldet (simuliert). In der Demo bleibt die Sitzung bestehen.');
  }

  protected onDocClick(e: MouseEvent): void {
    if (this.open() && !this.el.nativeElement.contains(e.target as Node)) this.open.set(false);
  }

  protected onMenuKey(e: KeyboardEvent): void {
    const items = this.items();
    const i = items.indexOf(document.activeElement as HTMLElement);
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      this.close();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      items[(i + 1) % items.length]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      items[(i - 1 + items.length) % items.length]?.focus();
    } else if (e.key === 'Tab') {
      this.open.set(false);
    }
  }

  private close(): void {
    this.open.set(false);
    setTimeout(() => this.el.nativeElement.querySelector<HTMLElement>('button[aria-haspopup]')?.focus());
  }

  private items(): HTMLElement[] {
    return Array.from(this.el.nativeElement.querySelectorAll<HTMLElement>('.cx-mi'));
  }

  private focusItem(i: number): void {
    setTimeout(() => this.items()[i]?.focus());
  }
}
