// Docklet Design Lab – opus-compact
// Lokaler Signal-Zustand. Alle Aktionen sind simuliert; es gibt keine Requests.
import { DestroyRef, Injectable, computed, inject, signal } from '@angular/core';
import {
  DEFAULT_WIDGETS,
  DEPLOY_STEPS,
  EMPTY_COMPOSE,
  SEED_ACTIONS,
  SEED_EVENTS,
  SEED_FINDINGS,
  SEED_HOSTS,
  SEED_MOUNTS,
  SEED_NETWORKS,
  SEED_SCAN_HISTORY,
  SEED_STACKS,
  SEED_STANDALONE,
  type ActionItem,
  type AutoUpdate,
  type EventItem,
  type EventLevel,
  type Host,
  type ImageFindings,
  type Origin,
  type PageId,
  type Service,
  type Stack,
  type StandaloneContainer,
  type ThemePref,
  type WidgetId,
} from './data';
import type { ComposeModel } from './compose';

export interface RunOptions {
  title: string;
  hostId: string;
  steps: string[];
  lines?: string[][];
  failAt?: number;
  failMessage?: string;
  restorable?: boolean;
  stackId?: string;
  services?: string[];
  onDone?: () => void;
}

export type EditorMode = 'easy' | 'advanced';
export type EditorFile = 'compose' | 'env';
export type StackTab = 'overview' | 'editor' | 'logs' | 'files' | 'updates' | 'backups';
export type StacksView = 'easy' | 'full';
export type StackOp = 'start' | 'stop' | 'restart' | 'redeploy';

export interface Toast {
  id: string;
  kind: 'action' | 'info' | 'error';
  text: string;
  actionId?: string;
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

export function nowTime(): string {
  return new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
}

@Injectable()
export class CxStore {
  private readonly destroyRef = inject(DestroyRef);
  private readonly timers = new Set<ReturnType<typeof setInterval>>();
  private readonly timeouts = new Set<ReturnType<typeof setTimeout>>();
  private seq = 0;

  readonly page = signal<PageId>('dashboard');
  readonly hosts = signal<Host[]>(clone(SEED_HOSTS));
  readonly stacks = signal<Stack[]>(clone(SEED_STACKS));
  readonly standalone = signal<StandaloneContainer[]>(clone(SEED_STANDALONE));
  readonly mounts = signal(clone(SEED_MOUNTS));
  readonly networks = signal(clone(SEED_NETWORKS));
  readonly hostFilter = signal<string[]>([]);
  readonly widgets = signal<WidgetId[]>([...DEFAULT_WIDGETS]);
  readonly actions = signal<ActionItem[]>(clone(SEED_ACTIONS));
  readonly events = signal<EventItem[]>(clone(SEED_EVENTS));
  readonly actionCenterOpen = signal(false);
  readonly focusActionId = signal<string | null>(null);
  readonly fileTarget = signal<string | null>(null);
  readonly toasts = signal<Toast[]>([]);
  readonly restorePoints = signal<Record<string, Record<string, string>>>({});

  // Sicherheit (optional, getrennt von Updates)
  readonly scanEnabled = signal(true);
  readonly scanSchedule = signal('täglich 04:00');
  readonly lastScan = signal('heute 04:00');
  readonly findings = signal<ImageFindings[]>(clone(SEED_FINDINGS));
  readonly scanHistory = signal(clone(SEED_SCAN_HISTORY));

  // Stack-Seite und Übersicht
  readonly stackPageId = signal<string | null>(null);
  readonly stackTab = signal<StackTab>('overview');
  readonly stacksView = signal<StacksView>('easy');
  readonly selectMode = signal(false);
  readonly labelFilter = signal<string[]>([]);

  // Editor-Entwurf bleibt beim Seitenwechsel erhalten.
  readonly draftRaw = signal<string>(EMPTY_COMPOSE);
  readonly draftStackId = signal<string | null>(null);
  readonly draftHostId = signal<string>('atlas');
  readonly draftEnv = signal<string>('');
  readonly draftLabels = signal<string[]>([]);
  readonly editorMode = signal<EditorMode>('easy');
  readonly editorStep = signal<string>('basics');
  readonly editorFile = signal<EditorFile>('compose');

  // Profil und Darstellung
  readonly theme = signal<ThemePref>('hell');
  readonly profileName = signal('Demo Admin');
  readonly profileEmail = signal('admin@example.com');
  readonly language = signal<'de' | 'en'>('de');
  private readonly systemDark = signal(false);
  readonly isDark = computed(() => this.theme() === 'dunkel' || (this.theme() === 'system' && this.systemDark()));

  /** Simulierte Live-Werte (Dashboard, Topologie). Kein echter Datenstrom. */
  readonly live = signal(true);

  constructor() {
    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      this.systemDark.set(mq.matches);
      const onChange = (e: MediaQueryListEvent) => this.systemDark.set(e.matches);
      mq.addEventListener('change', onChange);
      this.destroyRef.onDestroy(() => mq.removeEventListener('change', onChange));
    }
    const liveTimer = setInterval(() => {
      if (this.live()) this.tick();
    }, 3000);
    this.timers.add(liveTimer);
    this.destroyRef.onDestroy(() => {
      this.timers.forEach((t) => clearInterval(t));
      this.timeouts.forEach((t) => clearTimeout(t));
    });
  }

  private later(fn: () => void, ms: number): void {
    const t = setTimeout(() => {
      this.timeouts.delete(t);
      fn();
    }, ms);
    this.timeouts.add(t);
  }

  /* --------------------------------------------------------- Ableitungen */

  readonly hostMap = computed(() => new Map(this.hosts().map((h) => [h.id, h])));

  host(id: string): Host {
    return this.hostMap().get(id) ?? { ...SEED_HOSTS[0], id, name: id, color: '#71717a', soft: '#f4f4f5' };
  }

  readonly filterActive = computed(() => this.hostFilter().length > 0);

  visible(hostId: string): boolean {
    const f = this.hostFilter();
    return f.length === 0 || f.includes(hostId);
  }

  readonly visibleStacks = computed(() => this.stacks().filter((s) => this.visible(s.hostId)));
  readonly visibleStandalone = computed(() => this.standalone().filter((c) => this.visible(c.hostId)));
  readonly visibleHosts = computed(() => this.hosts().filter((h) => this.visible(h.id)));

  readonly allLabels = computed(() => [...new Set(this.stacks().flatMap((s) => s.labels))].sort());

  readonly allServices = computed(() => {
    const list: { svc: Service; hostId: string; stackId: string | null }[] = [];
    for (const s of this.stacks()) for (const svc of s.services) list.push({ svc, hostId: s.hostId, stackId: s.id });
    for (const c of this.standalone()) list.push({ svc: c, hostId: c.hostId, stackId: null });
    return list;
  });

  readonly kpis = computed(() => {
    const items = this.allServices().filter((i) => this.visible(i.hostId));
    const hosts = this.visibleHosts();
    return {
      running: items.filter((i) => i.svc.state === 'running').length,
      total: items.length,
      updates: items.filter((i) => !!i.svc.newTag).length,
      problems: items.filter((i) => i.svc.health === 'unhealthy' || (i.svc.state === 'exited' && this.isDeployed(i.stackId))).length,
      hostsOnline: hosts.filter((h) => h.status === 'online').length,
      hostsTotal: hosts.length,
    };
  });

  private isDeployed(stackId: string | null): boolean {
    if (!stackId) return true;
    return this.stacks().find((s) => s.id === stackId)?.deployed ?? true;
  }

  readonly problems = computed(() =>
    this.allServices().filter(
      (i) => this.visible(i.hostId) && (i.svc.health === 'unhealthy' || (i.svc.state === 'exited' && this.isDeployed(i.stackId))),
    ),
  );

  readonly updates = computed(() => this.allServices().filter((i) => this.visible(i.hostId) && !!i.svc.newTag));
  readonly runningActions = computed(() => this.actions().filter((a) => a.status === 'running').length);
  readonly currentStack = computed(() => this.stacks().find((s) => s.id === this.stackPageId()) ?? null);

  stackStatus(s: Stack): 'running' | 'partial' | 'exited' | 'unhealthy' | 'entwurf' | 'restarting' {
    if (!s.deployed) return 'entwurf';
    if (s.services.some((x) => x.health === 'unhealthy')) return 'unhealthy';
    if (s.services.some((x) => x.state === 'restarting')) return 'restarting';
    const run = s.services.filter((x) => x.state === 'running').length;
    if (run === 0) return 'exited';
    return run === s.services.length ? 'running' : 'partial';
  }

  /* ------------------------------------------------------------ Navigation */

  go(page: PageId): void {
    this.page.set(page);
  }

  openStack(id: string, tab: StackTab = 'overview'): void {
    this.stackPageId.set(id);
    this.setStackTab(tab);
    this.page.set('stack');
  }

  setStackTab(tab: StackTab): void {
    const id = this.stackPageId();
    if (tab === 'editor' && id && this.draftStackId() !== id) this.loadDraft(id);
    this.stackTab.set(tab);
  }

  /** „Neuer Stack“ öffnet die Stack-Seite im Entwurfsmodus mit Editor. */
  newStack(): void {
    this.draftRaw.set(EMPTY_COMPOSE);
    this.draftStackId.set(null);
    this.draftEnv.set('');
    this.draftLabels.set([]);
    const firstOnline = this.hosts().find((h) => h.status === 'online' && this.visible(h.id)) ?? this.hosts().find((h) => h.status === 'online');
    this.draftHostId.set(firstOnline?.id ?? 'atlas');
    this.editorStep.set('basics');
    this.editorMode.set('easy');
    this.editorFile.set('compose');
    this.stackPageId.set(null);
    this.stackTab.set('editor');
    this.page.set('stack');
  }

  openEditor(stackId: string | null): void {
    if (stackId) this.openStack(stackId, 'editor');
    else this.newStack();
  }

  private loadDraft(id: string): void {
    const s = this.stacks().find((x) => x.id === id);
    if (!s) return;
    this.draftRaw.set(s.compose);
    this.draftStackId.set(s.id);
    this.draftHostId.set(s.hostId);
    this.draftEnv.set(s.env);
    this.draftLabels.set([...s.labels]);
    this.editorStep.set('basics');
    this.editorFile.set('compose');
  }

  openFiles(mountId: string | null): void {
    this.fileTarget.set(mountId);
    this.page.set('files');
  }

  toggleHost(id: string): void {
    this.hostFilter.update((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  }

  clearFilter(): void {
    this.hostFilter.set([]);
  }

  toggleLabel(label: string): void {
    this.labelFilter.update((f) => (f.includes(label) ? f.filter((x) => x !== label) : [...f, label]));
  }

  /* ---------------------------------------------------------------- Toasts */

  notify(text: string, kind: 'info' | 'error' = 'info'): void {
    const id = `t${++this.seq}`;
    this.toasts.update((t) => [...t.slice(-3), { id, kind, text }]);
    this.later(() => this.dismissToast(id), kind === 'error' ? 6000 : 3200);
  }

  dismissToast(id: string): void {
    this.toasts.update((t) => t.filter((x) => x.id !== id));
  }

  showActionDetails(actionId: string | null): void {
    this.focusActionId.set(actionId);
    this.actionCenterOpen.set(true);
  }

  /* --------------------------------------------------------------- Widgets */

  toggleWidget(id: WidgetId): void {
    this.widgets.update((w) => (w.includes(id) ? w.filter((x) => x !== id) : [...w, id]));
  }

  moveWidget(id: WidgetId, dir: -1 | 1): void {
    this.widgets.update((w) => {
      const i = w.indexOf(id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= w.length) return w;
      const next = [...w];
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  }

  resetWidgets(): void {
    this.widgets.set([...DEFAULT_WIDGETS]);
  }

  /* ------------------------------------------------------- Live-Simulation */

  private tick(): void {
    this.hosts.update((list) =>
      list.map((h) => {
        if (h.status !== 'online') return h;
        const cpu = Math.round(clamp(h.cpu + (Math.random() - 0.5) * 9, 4, 92));
        const mem = Math.round(clamp(h.mem + (Math.random() - 0.5) * 3, 10, 90));
        return { ...h, cpu, mem, cpuHistory: [...h.cpuHistory.slice(1), cpu] };
      }),
    );
    const jitter = (s: Service): Service =>
      s.state === 'running' ? { ...s, cpu: Math.round(clamp(s.cpu * (0.8 + Math.random() * 0.4), 0.1, 90) * 10) / 10 } : s;
    this.stacks.update((list) => list.map((st) => ({ ...st, services: st.services.map(jitter) })));
    this.standalone.update((list) => list.map((c) => ({ ...c, ...jitter(c) })));
  }

  /* -------------------------------------------------------------- Aktionen */

  logEvent(level: EventLevel, hostId: string, text: string): void {
    this.events.update((e) => [{ id: `e${++this.seq}`, time: nowTime(), level, hostId, text }, ...e]);
  }

  /** Startet eine simulierte Aktion. Fortschritt erscheint als Popup rechts oben; das Aktionszentrum öffnet sich nicht automatisch. */
  runAction(o: RunOptions): string {
    const id = `a${++this.seq}`;
    const item: ActionItem = {
      id,
      title: o.title,
      hostId: o.hostId,
      status: 'running',
      progress: 0,
      steps: o.steps,
      step: 0,
      output: [`> ${o.title} (Simulation, keine echte Aktion)`],
      startedAt: nowTime(),
      stackId: o.stackId,
      services: o.services,
    };
    this.actions.update((a) => [item, ...a]);
    const toastId = `t${++this.seq}`;
    this.toasts.update((t) => [...t.slice(-3), { id: toastId, kind: 'action', text: o.title, actionId: id }]);
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const failed = o.failAt !== undefined && step === o.failAt;
      const lines = o.lines?.[step - 1] ?? [`${o.steps[step - 1]} … ok`];
      this.patchAction(id, (a) => ({
        ...a,
        step: failed ? step - 1 : step,
        progress: Math.round(((failed ? step - 1 : step) / o.steps.length) * 100),
        output: [...a.output, ...(failed ? [`Fehler: ${o.failMessage ?? 'unbekannt'}`] : lines)],
        status: failed ? 'error' : step >= o.steps.length ? 'success' : 'running',
        restorable: failed ? o.restorable : undefined,
      }));
      if (failed || step >= o.steps.length) {
        clearInterval(timer);
        this.timers.delete(timer);
        if (failed) this.logEvent('fehler', o.hostId, `${o.title} fehlgeschlagen`);
        else {
          this.logEvent('erfolg', o.hostId, `${o.title} abgeschlossen`);
          o.onDone?.();
        }
        this.later(() => this.dismissToast(toastId), failed ? 9000 : 4500);
      }
    }, 850);
    this.timers.add(timer);
    return id;
  }

  private patchAction(id: string, fn: (a: ActionItem) => ActionItem): void {
    this.actions.update((list) => list.map((a) => (a.id === id ? fn(a) : a)));
  }

  clearFinished(): void {
    this.actions.update((list) => list.filter((a) => a.status === 'running'));
  }

  private patchStack(id: string, fn: (s: Stack) => Stack): void {
    this.stacks.update((list) => list.map((s) => (s.id === id ? fn(s) : s)));
  }

  private patchService(stackId: string | null, svcId: string, fn: (s: Service) => Service): void {
    if (stackId) {
      this.patchStack(stackId, (s) => ({ ...s, services: s.services.map((x) => (x.id === svcId ? fn(x) : x)) }));
    } else {
      this.standalone.update((list) => list.map((c) => (c.id === svcId ? { ...c, ...fn(c) } : c)));
    }
  }

  stackOp(stackId: string, op: StackOp): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    const names = s.services.map((x) => x.name);
    const label = { start: 'Start', stop: 'Stopp', restart: 'Neustart', redeploy: 'Neu bereitstellen' }[op];
    const steps =
      op === 'stop'
        ? ['Prüfung', 'Container stoppen']
        : op === 'start'
          ? ['Prüfung', 'Start', 'Zustandsprüfung']
          : op === 'restart'
            ? ['Prüfung', 'Container stoppen', 'Start', 'Zustandsprüfung']
            : DEPLOY_STEPS;
    if (op !== 'stop') this.patchStack(stackId, (st) => ({ ...st, services: st.services.map((x) => ({ ...x, state: 'restarting' })) }));
    this.runAction({
      title: `${label} ${s.name}`,
      hostId: s.hostId,
      steps,
      stackId,
      services: names,
      onDone: () =>
        this.patchStack(stackId, (st) => ({
          ...st,
          deployed: true,
          services: st.services.map((x) =>
            op === 'stop'
              ? { ...x, state: 'exited', cpu: 0 }
              : { ...x, state: 'running', cpu: x.cpu || 0.5, health: x.health === 'none' ? 'none' : 'healthy' },
          ),
        })),
    });
  }

  removeStack(stackId: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    this.runAction({
      title: `Entfernen ${s.name}`,
      hostId: s.hostId,
      steps: ['Container stoppen', 'Container entfernen', 'Netzwerke aufräumen'],
      stackId,
      services: s.services.map((x) => x.name),
      onDone: () => this.stacks.update((l) => l.filter((x) => x.id !== stackId)),
    });
    if (this.stackPageId() === stackId) this.page.set('stacks');
  }

  installUpdates(stackId: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    const targets = s.services.filter((x) => x.newTag);
    if (targets.length === 0) return;
    this.restorePoints.update((r) => ({ ...r, [stackId]: Object.fromEntries(targets.map((t) => [t.id, t.tag])) }));
    this.runAction({
      title: `Update ${s.name}`,
      hostId: s.hostId,
      steps: DEPLOY_STEPS,
      stackId,
      services: targets.map((t) => t.name),
      lines: [
        ['Compose gültig · Wiederherstellungspunkt angelegt (Image + Compose)'],
        targets.map((t) => `pull ${t.image}:${t.newTag} … fertig`),
        targets.map((t) => `recreate ${t.name} … ok`),
        targets.map((t) => `start ${t.name} … ok`),
        ['Alle Container healthy'],
      ],
      onDone: () =>
        this.patchStack(stackId, (st) => ({
          ...st,
          services: st.services.map((x) => (x.newTag ? { ...x, tag: x.newTag, newTag: undefined } : x)),
        })),
    });
  }

  restorePrevious(stackId: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    const point = this.restorePoints()[stackId];
    if (!s || !point) return;
    this.runAction({
      title: `Wiederherstellung ${s.name}`,
      hostId: s.hostId,
      steps: ['Prüfung', 'Vorheriges Image', 'Erstellen/Austausch', 'Start'],
      stackId,
      services: Object.keys(point),
      lines: [['Sicherung gefunden'], Object.entries(point).map(([k, v]) => `${k} → ${v}`), ['compose.yaml aus Sicherung', 'recreate … ok'], ['start … ok']],
      onDone: () => {
        this.patchStack(stackId, (st) => ({
          ...st,
          services: st.services.map((x) => (point[x.id] ? { ...x, newTag: x.tag, tag: point[x.id] } : x)),
        }));
        this.restorePoints.update((r) => {
          const next = { ...r };
          delete next[stackId];
          return next;
        });
      },
    });
  }

  restoreAction(actionId: string): void {
    const a = this.actions().find((x) => x.id === actionId);
    if (!a) return;
    this.patchAction(actionId, (x) => ({ ...x, restorable: false }));
    this.runAction({
      title: 'Wiederherstellung whoami v1.10',
      hostId: a.hostId,
      steps: ['Prüfung', 'Vorheriges Image traefik/whoami:v1.10', 'Erstellen/Austausch', 'Start'],
      services: ['whoami'],
    });
  }

  restartService(stackId: string | null, svcId: string, name: string, hostId: string): void {
    this.patchService(stackId, svcId, (s) => ({ ...s, state: 'restarting' }));
    this.runAction({
      title: `Neustart ${name}`,
      hostId,
      steps: ['Container stoppen', 'Start', 'Zustandsprüfung'],
      stackId: stackId ?? undefined,
      services: [name],
      onDone: () => this.patchService(stackId, svcId, (s) => ({ ...s, state: 'running', health: s.health === 'none' ? 'none' : 'healthy' })),
    });
  }

  setServiceState(stackId: string | null, svcId: string, name: string, hostId: string, start: boolean): void {
    this.runAction({
      title: `${start ? 'Start' : 'Stopp'} ${name}`,
      hostId,
      steps: start ? ['Start', 'Zustandsprüfung'] : ['Container stoppen'],
      stackId: stackId ?? undefined,
      services: [name],
      onDone: () =>
        this.patchService(stackId, svcId, (s) => ({ ...s, state: start ? 'running' : 'exited', cpu: start ? s.cpu || 0.5 : 0 })),
    });
  }

  backupNow(stackId: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    this.runAction({
      title: `Backup ${s.name}`,
      hostId: s.hostId,
      steps: ['Konsistenz: Stack kurz anhalten', 'Volumes und Bind-Mounts sichern', 'Stack starten', 'Aufbewahrung anwenden'],
      stackId,
      services: s.services.map((x) => x.name),
      lines: [['stop … ok'], s.mounts.map((m) => `${m} → ${s.backup.target}`), ['start … ok'], [`Aufbewahrung ${s.backup.retention}`]],
      onDone: () => this.patchStack(stackId, (st) => ({ ...st, backup: { ...st.backup, last: `heute ${nowTime()}` } })),
    });
  }

  setAutoUpdate(stackId: string, v: AutoUpdate): void {
    this.patchStack(stackId, (s) => ({ ...s, autoUpdate: v }));
    this.notify(v === 'pruefen' ? 'Nur prüfen – Updates werden nicht automatisch installiert.' : 'Automatische Updates mit Zeitplan aktiviert.');
  }

  setAutoHeal(stackId: string, v: boolean): void {
    this.patchStack(stackId, (s) => ({ ...s, autoHeal: v }));
  }

  setOrigin(id: string, origin: Origin): void {
    this.standalone.update((list) => list.map((c) => (c.id === id ? { ...c, origin } : c)));
    this.notify('Zuordnung manuell geändert.');
  }

  runScan(): void {
    if (!this.scanEnabled()) return;
    this.runAction({
      title: 'Schwachstellenscan',
      hostId: this.visibleHosts()[0]?.id ?? 'atlas',
      steps: ['Images ermitteln', 'Datenbank aktualisieren', 'Images scannen', 'Befunde zusammenführen'],
      lines: [[`${this.findings().length} Images auf ${this.hosts().filter((h) => h.status === 'online').length} Hosts`], ['Schwachstellen-Datenbank aktuell (Demo)'], this.findings().map((f) => `scan ${f.image} … fertig`), ['Befunde synthetisch aktualisiert']],
      onDone: () => {
        const t = nowTime();
        this.lastScan.set(`heute ${t}`);
        this.findings.update((list) => list.map((f) => (f.niedrig > 0 && Math.random() > 0.5 ? { ...f, niedrig: f.niedrig - 1 } : f)));
        const total = this.findings().reduce((a, f) => a + f.kritisch + f.hoch + f.mittel + f.niedrig, 0);
        this.scanHistory.update((h) => [...h.slice(1), { day: 'Sa', time: t, total, manual: true }]);
      },
    });
  }

  /* ---------------------------------------------------------- Editor-Abläufe */

  private servicesFrom(model: ComposeModel, name: string, running: boolean): Service[] {
    return model.services.map((m): Service => {
      const [image, tag] = splitImage(m.image);
      return {
        id: `${name}-${m.key}`,
        name: m.key,
        image,
        tag,
        state: running ? 'running' : 'exited',
        health: running && m.healthTest ? 'healthy' : 'none',
        cpu: running ? 0.3 : 0,
        memMb: running ? 48 : 0,
        ports: m.ports,
        networks: [`${name}_default`],
      };
    });
  }

  private merge(prev: Stack, next: Service[]): Service[] {
    return next.map((svc): Service => {
      const old = prev.services.find((o) => o.name === svc.name);
      return old ? { ...old, image: svc.image, tag: svc.tag, ports: svc.ports, newTag: old.newTag && old.newTag !== svc.tag ? old.newTag : undefined } : svc;
    });
  }

  private createStack(model: ComposeModel, raw: string, deployed: boolean): Stack {
    const hostId = this.draftHostId();
    const host = this.host(hostId);
    const name = model.name || 'stack';
    return {
      id: `${name}-${++this.seq}`,
      name: name.charAt(0).toUpperCase() + name.slice(1),
      hostId,
      description: 'Im Stack-Editor erstellt',
      path: `${host.projectDir}/${name}`,
      labels: [...this.draftLabels()],
      services: this.servicesFrom(model, name, deployed),
      mounts: [],
      autoUpdate: 'pruefen',
      autoHeal: false,
      backup: { last: 'noch nie', schedule: 'nicht geplant', target: 'Lokal · /mnt/backups', retention: '7 Tage' },
      compose: raw,
      env: this.draftEnv(),
      deployed,
    };
  }

  /** Speichern ohne Bereitstellung (Arcane: „Save“). */
  saveDraft(model: ComposeModel, raw: string): void {
    const existingId = this.draftStackId();
    const prev = existingId ? this.stacks().find((s) => s.id === existingId) : undefined;
    if (prev) {
      this.patchStack(prev.id, (s) => ({ ...s, compose: raw, env: this.draftEnv(), labels: [...this.draftLabels()] }));
      this.notify(`${prev.name}: compose.yaml und .env gespeichert – noch nicht bereitgestellt.`);
      return;
    }
    const stack = this.createStack(model, raw, false);
    this.stacks.update((l) => [...l, stack]);
    this.draftStackId.set(stack.id);
    this.stackPageId.set(stack.id);
    this.notify(`Stack ${stack.name} als Entwurf gespeichert.`);
  }

  deploy(model: ComposeModel, raw: string): void {
    const hostId = this.draftHostId();
    const host = this.host(hostId);
    const existingId = this.draftStackId();
    const name = model.name || 'stack';
    const prev = existingId ? this.stacks().find((s) => s.id === existingId) : undefined;
    let targetId = prev?.id ?? null;
    if (!prev) {
      const stack = this.createStack(model, raw, false);
      this.stacks.update((l) => [...l, stack]);
      this.draftStackId.set(stack.id);
      targetId = stack.id;
      if (this.page() === 'stack' && this.stackPageId() === null) this.stackPageId.set(stack.id);
    } else {
      this.patchStack(prev.id, (s) => ({ ...s, compose: raw, env: this.draftEnv(), labels: [...this.draftLabels()] }));
    }
    const id = targetId as string;
    const keys = model.services.map((s) => s.key);
    this.runAction({
      title: `Bereitstellung ${name} → ${host.name}`,
      hostId,
      steps: DEPLOY_STEPS,
      stackId: id,
      services: keys,
      lines: [
        [`Compose gültig · ${model.services.length} Service(s), ${model.topUnknown.length} weitere Top-Level-Schlüssel erhalten`, `${host.projectDir}/${name}/compose.yaml geschrieben`],
        model.services.map((s) => `pull ${s.image || '(kein Image)'} … fertig`),
        [`network ${name}_default … bereit`, ...keys.map((k) => `create ${name}-${k}-1 … ok`)],
        keys.map((k) => `start ${name}-${k}-1 … ok`),
        model.services.map((s) => (s.healthTest ? `${s.key}: healthy` : `${s.key}: läuft (kein Healthcheck)`)),
      ],
      onDone: () => {
        const cur = this.stacks().find((s) => s.id === id);
        if (!cur) return;
        const fresh = this.servicesFrom(model, name, true);
        this.patchStack(id, (s) => ({ ...s, deployed: true, services: cur.deployed ? this.merge(cur, fresh) : fresh, hostId }));
      },
    });
  }

  addHost(h: Host): void {
    this.hosts.update((l) => [...l, h]);
    this.runAction({
      title: `Host ${h.name} verbinden`,
      hostId: h.id,
      steps: ['Agent-Installation abwarten', h.mode === 'edge' ? 'Edge-Tunnel zum Hub' : 'Direkte Verbindung', 'Docker-Socket-Gruppe erkennen', 'Rechte Projektverzeichnis prüfen'],
      lines: [['Installer gemeldet (simuliert)'], ['Handshake ok'], ['Socket-Gruppe 998 automatisch erkannt'], [`${h.projectDir} beschreibbar`]],
      onDone: () => this.hosts.update((l) => l.map((x) => (x.id === h.id ? { ...x, status: 'online', cpu: 4, mem: 12, lastSeen: 'gerade eben' } : x))),
    });
  }
}

export function splitImage(ref: string): [string, string] {
  const at = ref.lastIndexOf(':');
  if (at > 0 && !ref.slice(at).includes('/')) return [ref.slice(0, at), ref.slice(at + 1)];
  return [ref, 'latest'];
}
