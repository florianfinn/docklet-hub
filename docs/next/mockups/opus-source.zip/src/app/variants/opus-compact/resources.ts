// Docklet Design Lab – opus-compact · Volumes & Dateien, Images
// Dateibrowser für Volumes und Bind-Mounts (aus Stack-Editor/Details verlinkt), Image-Übersicht mit Updates/Scan.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { FILE_TREES, type FileNode, type MountRef } from './data';
import { CxIcon } from './icon';
import { CxStore } from './store';
import { CxHost, CxStatus } from './ui';

function size(mb: number): string {
  if (mb >= 1024 * 1024) return `${(mb / 1024 / 1024).toFixed(1)} TB`;
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
  return `${mb} MB`;
}

@Component({
  selector: 'cx-files',
  imports: [ZardButtonComponent, CxIcon, CxHost],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid items-start gap-3 lg:grid-cols-[300px_minmax(0,1fr)]">
      <nav class="rounded-lg border border-zinc-200 bg-white" aria-label="Volumes und Bind-Mounts">
        @for (g of groups(); track g.label) {
          <div class="border-b border-zinc-100 px-3 pb-1 pt-2.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 last:border-0">{{ g.label }}</div>
          <ul class="px-1.5 pb-2">
            @for (m of g.items; track m.id) {
              @let h = store.host(m.hostId);
              <li>
                <button type="button" class="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left outline-none focus-visible:ring-2 focus-visible:ring-zinc-900" [class]="current()?.id === m.id ? 'bg-zinc-100' : 'hover:bg-zinc-50'" [attr.aria-current]="current()?.id === m.id ? 'true' : null" (click)="pick(m.id)">
                  <span class="size-2 shrink-0 rounded-sm" [style.background-color]="h.color" [title]="h.name"></span>
                  <span class="min-w-0 flex-1">
                    <span class="block truncate font-mono text-[12px]">{{ m.name }}</span>
                    <span class="block text-[11px] text-zinc-500">{{ fmt(m.sizeMb) }} · {{ m.usedBy.join(', ') }}</span>
                  </span>
                </button>
              </li>
            }
          </ul>
        } @empty {
          <p class="p-3 text-zinc-600">Keine Mounts für diesen Filter.</p>
        }
      </nav>

      @if (current(); as m) {
        @let h = store.host(m.hostId);
        <section class="min-w-0 rounded-lg border border-zinc-200 bg-white" aria-labelledby="fb-title">
          <header class="border-b border-zinc-100 p-3">
            <div class="flex flex-wrap items-center gap-2">
              <cx-icon [name]="m.kind === 'volume' ? 'database' : 'drive'" [size]="16" />
              <h2 id="fb-title" class="font-mono text-[13.5px] font-semibold">{{ m.name }}</h2>
              <cx-host [name]="h.name" [color]="h.color" [soft]="h.soft" />
              <span class="rounded border border-zinc-200 px-1.5 text-[11px] text-zinc-600">{{ m.kind === 'volume' ? 'Volume' : 'Bind-Mount' }}</span>
              <div class="ml-auto flex gap-1.5">
                <button z-button zType="outline" zSize="sm" type="button" (click)="store.notify('Upload in ' + m.name + ' (Demo, keine Dateien übertragen).')"><cx-icon name="upload" [size]="13" />Hochladen</button>
                @if (stackOf(m); as sid) {
                  <button z-button zType="outline" zSize="sm" type="button" (click)="store.openStack(sid)"><cx-icon name="layers" [size]="13" />Stack</button>
                }
              </div>
            </div>
            <p class="mt-1 truncate font-mono text-[11.5px] text-zinc-500">{{ m.source }}</p>
            <nav class="mt-2 flex flex-wrap items-center gap-1 text-[12.5px]" aria-label="Pfad">
              <button type="button" class="rounded px-1 font-medium hover:bg-zinc-100" (click)="setPath([])">/</button>
              @for (seg of path(); track $index; let i = $index) {
                <cx-icon name="chevronRight" [size]="12" class="text-zinc-400" />
                <button type="button" class="rounded px-1 font-medium hover:bg-zinc-100" [attr.aria-current]="i === path().length - 1 ? 'location' : null" (click)="setPath(path().slice(0, i + 1))">{{ seg }}</button>
              }
            </nav>
          </header>
          <div class="grid md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            <ul class="divide-y divide-zinc-100 md:border-r md:border-zinc-100" aria-label="Dateien">
              @if (path().length) {
                <li><button type="button" class="flex w-full items-center gap-2 px-3 py-1.5 text-left text-zinc-600 hover:bg-zinc-50" (click)="setPath(path().slice(0, -1))"><cx-icon name="arrowUp" [size]="14" />..</button></li>
              }
              @for (e of entries(); track e.name) {
                <li>
                  <button type="button" class="flex w-full items-center gap-2 px-3 py-1.5 text-left hover:bg-zinc-50" [class]="file()?.name === e.name ? 'bg-zinc-50' : ''" (click)="open(e)">
                    <cx-icon [name]="e.kind === 'dir' ? 'folder' : 'file'" [size]="14" [class]="e.kind === 'dir' ? 'text-amber-600' : 'text-zinc-500'" />
                    <span class="min-w-0 flex-1 truncate font-mono text-[12px]">{{ e.name }}</span>
                    <span class="text-[11px] text-zinc-500">{{ e.kind === 'dir' ? (e.children?.length ?? 0) + ' Einträge' : e.size }}</span>
                  </button>
                </li>
              } @empty {
                <li class="px-3 py-4 text-zinc-600">Ordner ist leer.</li>
              }
            </ul>
            <div class="min-w-0 p-3" aria-live="polite">
              @if (file(); as f) {
                <div class="mb-1.5 flex items-center gap-2"><cx-icon name="file" [size]="14" /><span class="font-mono text-[12.5px] font-semibold">{{ f.name }}</span><span class="ml-auto text-[11px] text-zinc-500">{{ f.size }} · {{ f.modified }}</span></div>
                @if (f.content) {
                  <pre class="max-h-72 overflow-auto rounded-md bg-[#0c0c0f] p-2.5 font-mono text-[11.5px] leading-5 text-[#e4e4e7]">{{ f.content }}</pre>
                } @else {
                  <p class="rounded-md border border-dashed border-zinc-300 p-3 text-[12.5px] text-zinc-600">Keine Vorschau (Binärdatei oder zu groß).</p>
                }
                <button z-button zType="outline" zSize="sm" type="button" class="mt-2" (click)="store.notify(f.name + ' würde heruntergeladen (Demo).')"><cx-icon name="download" [size]="13" />Herunterladen</button>
              } @else {
                <p class="text-[12.5px] text-zinc-600">Datei auswählen, um eine Vorschau zu sehen. Schreibzugriffe sind in der Demo deaktiviert.</p>
              }
            </div>
          </div>
        </section>
      }
    </div>
  `,
})
export class CxFiles {
  protected readonly store = inject(CxStore);
  private readonly paths = signal<Record<string, string[]>>({});
  protected readonly file = signal<FileNode | null>(null);

  protected readonly visibleMounts = computed(() => this.store.mounts().filter((m) => this.store.visible(m.hostId)));
  protected readonly groups = computed(() =>
    [
      { label: 'Volumes', items: this.visibleMounts().filter((m) => m.kind === 'volume') },
      { label: 'Bind-Mounts', items: this.visibleMounts().filter((m) => m.kind === 'bind') },
    ].filter((g) => g.items.length > 0),
  );

  protected readonly current = computed<MountRef | null>(() => {
    const list = this.visibleMounts();
    return list.find((m) => m.id === this.store.fileTarget()) ?? list[0] ?? null;
  });

  protected readonly path = computed(() => {
    const m = this.current();
    return m ? (this.paths()[m.id] ?? []) : [];
  });

  protected readonly entries = computed<FileNode[]>(() => {
    const m = this.current();
    if (!m) return [];
    let nodes = FILE_TREES[m.id] ?? [];
    for (const seg of this.path()) nodes = nodes.find((n) => n.name === seg && n.kind === 'dir')?.children ?? [];
    return [...nodes].sort((a, b) => (a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === 'dir' ? -1 : 1));
  });

  protected fmt(mb: number): string {
    return size(mb);
  }

  protected pick(id: string): void {
    this.store.fileTarget.set(id);
    this.file.set(null);
  }

  protected setPath(p: string[]): void {
    const m = this.current();
    if (!m) return;
    this.paths.update((all) => ({ ...all, [m.id]: p }));
    this.file.set(null);
  }

  protected open(e: FileNode): void {
    if (e.kind === 'dir') this.setPath([...this.path(), e.name]);
    else this.file.set(e);
  }

  protected stackOf(m: MountRef): string | null {
    return this.store.stacks().find((s) => s.mounts.includes(m.id))?.id ?? null;
  }
}

interface ImageRow {
  key: string;
  ref: string;
  tag: string;
  newTag?: string;
  hostId: string;
  usedBy: string[];
  size: string;
  findings: { high: number; medium: number };
}

const SIZES: Record<string, string> = {
  'jellyfin/jellyfin': '1,4 GB', redis: '138 MB', nextcloud: '1,2 GB', postgres: '432 MB',
  'itzg/minecraft-server': '702 MB', 'linuxserver/legacy-app': '310 MB', 'traefik/whoami': '7 MB', 'docklet/agent': '41 MB',
};

@Component({
  selector: 'cx-images',
  imports: [ZardButtonComponent, CxIcon, CxHost, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-3 flex flex-wrap items-center gap-2">
      <p class="text-[13px] text-zinc-600">{{ rows().length }} Images · {{ updates() }} mit Update. Update-Erkennung und Schwachstellenscan sind getrennt.</p>
      <div class="ml-auto flex gap-1.5">
        <button z-button zType="outline" zSize="sm" type="button" (click)="checkUpdates()"><cx-icon name="update" [size]="13" />Nach Updates suchen</button>
        <button z-button zType="outline" zSize="sm" type="button" (click)="toggleScan()"><cx-icon name="shield" [size]="13" />{{ store.scanEnabled() ? 'Scans deaktivieren' : 'Scans aktivieren' }}</button>
        <button z-button zType="ghost" zSize="sm" type="button" (click)="prune()"><cx-icon name="trash" [size]="13" />Ungenutzte entfernen</button>
      </div>
    </div>
    <div class="overflow-x-auto rounded-lg border border-zinc-200 bg-white">
      <table class="w-full min-w-[720px] text-left text-[12.5px]">
        <thead class="bg-zinc-50 text-[11px] uppercase tracking-wide text-zinc-500">
          <tr>
            <th class="px-3 py-1.5 font-semibold">Image</th><th class="px-3 py-1.5 font-semibold">Tag</th><th class="px-3 py-1.5 font-semibold">Host</th>
            <th class="px-3 py-1.5 font-semibold">Verwendet von</th><th class="px-3 py-1.5 font-semibold">Größe</th><th class="px-3 py-1.5 font-semibold">Status</th>
            @if (store.scanEnabled()) { <th class="px-3 py-1.5 font-semibold">Befunde</th> }
          </tr>
        </thead>
        <tbody>
          @for (r of rows(); track r.key) {
            @let h = store.host(r.hostId);
            <tr class="border-t border-zinc-100 hover:bg-zinc-50/60">
              <td class="px-3 py-1.5 font-mono font-medium">{{ r.ref }}</td>
              <td class="px-3 py-1.5 font-mono">{{ r.tag }}@if (r.newTag) { <span class="text-indigo-700"> → {{ r.newTag }}</span> }</td>
              <td class="px-3 py-1.5"><cx-host [name]="h.name" [color]="h.color" [soft]="h.soft" /></td>
              <td class="px-3 py-1.5">{{ r.usedBy.join(', ') }}</td>
              <td class="px-3 py-1.5 font-mono tabular-nums">{{ r.size }}</td>
              <td class="px-3 py-1.5">@if (r.newTag) { <cx-status kind="update" /> } @else { <span class="text-zinc-500">aktuell</span> }</td>
              @if (store.scanEnabled()) {
                <td class="px-3 py-1.5">
                  @if (r.findings.high || r.findings.medium) {
                    <span class="mr-1 rounded bg-orange-50 px-1.5 font-medium text-orange-800">{{ r.findings.high }} hoch</span><span class="rounded bg-amber-50 px-1.5 font-medium text-amber-800">{{ r.findings.medium }} mittel</span>
                  } @else { <span class="text-emerald-700">keine</span> }
                </td>
              }
            </tr>
          }
        </tbody>
      </table>
    </div>
    <p class="mt-2 text-[12px] text-zinc-500">Images werden innerhalb von Stacks per Compose „build“ gebaut – keine eigenständige Build-Werkstatt.</p>
  `,
})
export class CxImages {
  protected readonly store = inject(CxStore);

  protected readonly rows = computed<ImageRow[]>(() => {
    const map = new Map<string, ImageRow>();
    for (const i of this.store.allServices()) {
      if (!this.store.visible(i.hostId)) continue;
      const key = `${i.svc.image}:${i.svc.tag}@${i.hostId}`;
      const row = map.get(key);
      if (row) row.usedBy.push(i.svc.name);
      else
        map.set(key, {
          key,
          ref: i.svc.image,
          tag: i.svc.tag,
          newTag: i.svc.newTag,
          hostId: i.hostId,
          usedBy: [i.svc.name],
          size: SIZES[i.svc.image] ?? '—',
          findings: this.findingsOf(i.svc.image),
        });
    }
    return [...map.values()];
  });

  protected readonly updates = computed(() => this.rows().filter((r) => r.newTag).length);

  private findingsOf(image: string): { high: number; medium: number } {
    const f = this.store.findings().find((x) => x.image === image);
    return { high: (f?.kritisch ?? 0) + (f?.hoch ?? 0), medium: f?.mittel ?? 0 };
  }

  protected checkUpdates(): void {
    this.store.runAction({ title: 'Update-Prüfung', hostId: 'atlas', steps: ['Registries abfragen (simuliert)', 'Digests vergleichen'] });
  }

  protected toggleScan(): void {
    this.store.scanEnabled.update((v) => !v);
    this.store.notify(this.store.scanEnabled() ? 'Schwachstellenscans aktiviert (Demo).' : 'Schwachstellenscans deaktiviert.');
  }

  protected prune(): void {
    this.store.runAction({ title: 'Ungenutzte Images entfernen', hostId: 'atlas', steps: ['Ungenutzte Images ermitteln', 'Entfernen'], lines: [['3 ungenutzte Images (1,1 GB)'], ['Entfernt (simuliert)']] });
  }
}
