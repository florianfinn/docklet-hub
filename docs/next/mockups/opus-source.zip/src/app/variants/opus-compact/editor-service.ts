// Docklet Design Lab – opus-compact · Service-Formular (Easy-Wizard, Unterschritte)
import { ChangeDetectionStrategy, Component, computed, inject, input } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { PORT_PATTERN, mountSource, type EnvRow, type ServiceModel } from './compose';
import { CxDraft, type SubStep } from './draft';
import { CxIcon } from './icon';
import { CxStore } from './store';

const INPUT = 'h-8 w-full rounded-md border bg-white px-2 text-[13px] outline-none transition-shadow focus:ring-2 focus:ring-zinc-900/15';

@Component({
  selector: 'cx-service-form',
  imports: [ZardButtonComponent, CxIcon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let s = svc();
    @switch (sub()) {
      @case ('image') {
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Servicename</span>
            <input [class]="inputCls + ' border-zinc-300 font-mono'" [value]="s.key" (change)="draft.renameService(s.key, v($event))" aria-describedby="svc-key-hint" />
            <span id="svc-key-hint" class="mt-1 block text-[11.5px] text-zinc-500">Wird beim Verlassen des Feldes übernommen.</span>
          </label>
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Image <span class="text-red-600" aria-hidden="true">*</span></span>
            <input
              [class]="inputCls + ' font-mono ' + (s.image ? 'border-zinc-300' : 'border-red-400 bg-red-50/40')"
              [value]="s.image"
              placeholder="z. B. nginx:1.27"
              required
              [attr.aria-invalid]="!s.image"
              aria-describedby="svc-image-hint"
              (input)="draft.setField(s.key, 'image', v($event))"
            />
            <span id="svc-image-hint" class="mt-1 block text-[11.5px]" [class]="s.image ? 'text-zinc-500' : 'text-red-700'">
              {{ s.image ? 'Synchron mit „image:“ im Raw-Editor.' : 'Pflichtfeld: Image angeben.' }}
            </span>
          </label>
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Containername <span class="font-normal text-zinc-500">(optional)</span></span>
            <input [class]="inputCls + ' border-zinc-300 font-mono'" [value]="s.containerName" placeholder="automatisch" (input)="draft.setField(s.key, 'container_name', v($event))" />
          </label>
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Neustartregel</span>
            <select [class]="inputCls + ' border-zinc-300'" [value]="s.restart" (change)="draft.setField(s.key, 'restart', v($event))">
              @for (r of restarts; track r.id) {
                <option [value]="r.id" [selected]="s.restart === r.id">{{ r.label }}</option>
              }
            </select>
          </label>
        </div>
      }
      @case ('ports') {
        <p class="mb-2 text-[12.5px] text-zinc-600">Kurzform <span class="font-mono">Host:Container[/udp]</span>, optional mit IP.</p>
        <ul class="space-y-1.5">
          @for (p of s.ports; track $index; let i = $index) {
            <li>
              <div class="flex gap-1.5">
                <input [id]="'f-ports-' + i" [class]="inputCls + ' font-mono ' + (portOk(p) ? 'border-zinc-300' : 'border-amber-400')" [value]="p" placeholder="8080:80" [attr.aria-label]="'Port ' + (i + 1)" (input)="setItem('ports', i, v($event))" />
                <button type="button" class="grid size-8 shrink-0 place-items-center rounded-md border border-zinc-200 text-zinc-500 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="'Port ' + (i + 1) + ' entfernen'" (click)="removeItem('ports', i)"><cx-icon name="trash" [size]="14" /></button>
              </div>
              @if (!portOk(p)) {
                <span class="mt-0.5 block text-[11.5px] text-amber-800">{{ p ? 'Unbekanntes Format – im Raw-Editor bleibt der Wert unverändert.' : 'Leerer Eintrag – bitte ausfüllen oder entfernen.' }}</span>
              }
            </li>
          }
        </ul>
        @if (s.portsExtra) { <p class="mt-2 text-[12px] text-zinc-600">{{ s.portsExtra }} Eintrag/Einträge in Langform – nur im Advanced-Modus bearbeitbar, bleiben erhalten.</p> }
        <button z-button zType="outline" zSize="sm" type="button" class="mt-2" (click)="addItem('ports')"><cx-icon name="plus" [size]="13" />Port hinzufügen</button>
      }
      @case ('mounts') {
        <p class="mb-2 text-[12.5px] text-zinc-600"><span class="font-mono">quelle:ziel[:ro]</span> – benannte Volumes oder Bind-Mounts (Pfad mit / oder ./).</p>
        <ul class="space-y-1.5">
          @for (m of s.volumes; track $index; let i = $index) {
            <li class="flex flex-wrap items-center gap-1.5 sm:flex-nowrap">
              <span class="w-[86px] shrink-0 text-[11.5px] font-medium text-zinc-600">{{ kind(m) }}</span>
              <input [id]="'f-volumes-' + i" [class]="inputCls + ' min-w-0 flex-1 font-mono ' + (m ? 'border-zinc-300' : 'border-red-400')" [value]="m" placeholder="daten:/data" [attr.aria-label]="'Mount ' + (i + 1)" (input)="setItem('volumes', i, v($event))" />
              @if (mountId(m); as id) {
                <button z-button zType="outline" zSize="sm" type="button" (click)="store.openFiles(id)" [attr.aria-label]="'Mount ' + (i + 1) + ' im Dateibrowser öffnen'"><cx-icon name="folder" [size]="13" />Dateien</button>
              }
              <button type="button" class="grid size-8 shrink-0 place-items-center rounded-md border border-zinc-200 text-zinc-500 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="'Mount ' + (i + 1) + ' entfernen'" (click)="removeItem('volumes', i)"><cx-icon name="trash" [size]="14" /></button>
            </li>
          }
        </ul>
        @if (s.volumesExtra) { <p class="mt-2 text-[12px] text-zinc-600">{{ s.volumesExtra }} Mount(s) in Langform bleiben erhalten (Advanced).</p> }
        <button z-button zType="outline" zSize="sm" type="button" class="mt-2" (click)="addItem('volumes')"><cx-icon name="plus" [size]="13" />Mount hinzufügen</button>
      }
      @case ('env') {
        <p class="mb-2 text-[12.5px] text-zinc-600">Service-Variablen ({{ s.envStyle === 'map' ? 'Map-Schreibweise' : 'Listen-Schreibweise' }} wird beibehalten). Stack-weite Werte gehören in die .env unter Grundlagen.</p>
        <ul class="space-y-1.5">
          @for (e of s.env; track $index; let i = $index) {
            <li class="grid grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)_auto] gap-1.5">
              <input [id]="'f-env-' + i" [class]="inputCls + ' border-zinc-300 font-mono'" [value]="e.key" placeholder="NAME" [attr.aria-label]="'Variablenname ' + (i + 1)" (input)="setEnvRow(i, 'key', v($event))" />
              <input [class]="inputCls + ' font-mono ' + (e.value ? 'border-zinc-300' : 'border-amber-400')" [value]="e.value" placeholder="Wert" [attr.aria-label]="'Wert für ' + (e.key || 'Variable ' + (i + 1))" (input)="setEnvRow(i, 'value', v($event))" />
              <button type="button" class="grid size-8 place-items-center rounded-md border border-zinc-200 text-zinc-500 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="'Variable ' + (e.key || i + 1) + ' entfernen'" (click)="removeEnv(i)"><cx-icon name="trash" [size]="14" /></button>
            </li>
          }
        </ul>
        <button z-button zType="outline" zSize="sm" type="button" class="mt-2" (click)="addEnv()"><cx-icon name="plus" [size]="13" />Variable hinzufügen</button>
      }
      @case ('health') {
        <div class="grid gap-3 sm:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]">
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Prüfbefehl</span>
            <input [class]="inputCls + ' border-zinc-300 font-mono'" [value]="s.healthTest" placeholder="curl -fs http://localhost/ || exit 1" (input)="draft.setHealth(s.key, 'test', v($event))" />
          </label>
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Intervall</span>
            <input [class]="inputCls + ' border-zinc-300 font-mono'" [value]="s.healthInterval" placeholder="30s" (input)="draft.setHealth(s.key, 'interval', v($event))" />
          </label>
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">Wiederholungen</span>
            <input [class]="inputCls + ' border-zinc-300 font-mono'" inputmode="numeric" [value]="s.healthRetries" placeholder="3" (input)="draft.setHealth(s.key, 'retries', v($event))" />
          </label>
        </div>
        <div class="mt-2 flex flex-wrap gap-1.5">
          @if (httpPort()) {
            <button z-button zType="outline" zSize="sm" type="button" (click)="presetHttp()"><cx-icon name="wand" [size]="13" />HTTP-Prüfung auf Port {{ httpPort() }}</button>
          }
          @if (s.healthTest) {
            <button z-button zType="ghost" zSize="sm" type="button" (click)="clearHealth()">Healthcheck entfernen</button>
          }
        </div>
        <p class="mt-2 text-[12px] text-zinc-600">Unhealthy-Container können per Auto-Heal begrenzt neu gestartet werden (Stack-Einstellung).</p>
      }
    }

    @if (s.unknownKeys.length) {
      <div class="mt-4 rounded-md border border-dashed border-zinc-300 bg-zinc-50 p-2.5">
        <div class="flex items-center gap-1.5 text-[12px] font-medium text-zinc-700"><cx-icon name="lock" [size]="13" />Weitere Felder bleiben erhalten</div>
        <div class="mt-1.5 flex flex-wrap gap-1">
          @for (k of s.unknownKeys; track k) { <span class="rounded border border-zinc-200 bg-white px-1.5 py-0.5 font-mono text-[11.5px] text-zinc-700">{{ k }}</span> }
        </div>
        <p class="mt-1 text-[11.5px] text-zinc-500">Nicht im Formular abgebildet – im Advanced-Modus bearbeitbar, beim Umschalten unverändert.</p>
      </div>
    }
  `,
})
export class CxServiceForm {
  protected readonly draft = inject(CxDraft);
  protected readonly store = inject(CxStore);
  readonly svc = input.required<ServiceModel>();
  readonly sub = input.required<SubStep>();
  protected readonly inputCls = INPUT;

  protected readonly restarts = [
    { id: '', label: 'Keine (Docker-Standard)' },
    { id: 'unless-stopped', label: 'unless-stopped (empfohlen)' },
    { id: 'always', label: 'always' },
    { id: 'on-failure', label: 'on-failure' },
    { id: 'no', label: 'no' },
  ];

  protected readonly httpPort = computed(() => {
    const p = this.svc().ports.find((x) => PORT_PATTERN.test(x));
    if (!p) return '';
    return p.split('/')[0].split(':').pop() ?? '';
  });

  protected v(e: Event): string {
    return (e.target as HTMLInputElement | HTMLSelectElement).value;
  }

  protected portOk(p: string): boolean {
    return p.trim() !== '' && PORT_PATTERN.test(p.trim());
  }

  protected kind(m: string): string {
    const src = mountSource(m);
    if (!src) return m ? 'Anonym' : 'Neu';
    return src.startsWith('/') || src.startsWith('.') || src.startsWith('~') ? 'Bind-Mount' : 'Volume';
  }

  protected mountId(m: string): string | null {
    const src = mountSource(m);
    if (!src) return null;
    const stack = this.draft.model()?.name ?? '';
    const found = this.store.mounts().find(
      (x) => x.name === `${stack}_${src}` || x.source === src || (src.startsWith('./') && x.source.endsWith(src.slice(1))),
    );
    return found?.id ?? null;
  }

  protected setItem(field: 'ports' | 'volumes', i: number, value: string): void {
    const s = this.svc();
    const list = [...(field === 'ports' ? s.ports : s.volumes)];
    list[i] = value;
    this.draft.setList(s.key, field, list);
  }

  protected removeItem(field: 'ports' | 'volumes', i: number): void {
    const s = this.svc();
    const list = (field === 'ports' ? s.ports : s.volumes).filter((_, j) => j !== i);
    this.draft.setList(s.key, field, list);
  }

  protected addItem(field: 'ports' | 'volumes'): void {
    const s = this.svc();
    const list = [...(field === 'ports' ? s.ports : s.volumes), ''];
    this.draft.setList(s.key, field, list);
    this.focusLater(`f-${field}-${list.length - 1}`);
  }

  protected setEnvRow(i: number, part: keyof EnvRow, value: string): void {
    const s = this.svc();
    if (part === 'key' && s.env.some((r, j) => j !== i && r.key === value)) {
      this.store.notify(`Variable ${value} existiert bereits – doppelte Schlüssel wären ungültiges YAML.`);
      return;
    }
    const rows = s.env.map((r) => ({ ...r }));
    rows[i] = { ...rows[i], [part]: value };
    // Leere Namen kurzzeitig zulassen: Platzhalter, bis der Name eingegeben ist.
    this.draft.setEnv(s.key, rows.map((r, j) => (r.key ? r : { ...r, key: `VAR_${j + 1}` })), s.envStyle);
  }

  protected removeEnv(i: number): void {
    const s = this.svc();
    this.draft.setEnv(s.key, s.env.filter((_, j) => j !== i), s.envStyle);
  }

  protected addEnv(): void {
    const s = this.svc();
    const n = s.env.length + 1;
    this.draft.setEnv(s.key, [...s.env, { key: `VAR_${n}`, value: '' }], s.envStyle);
    this.focusLater(`f-env-${n - 1}`, true);
  }

  protected presetHttp(): void {
    const s = this.svc();
    this.draft.setHealth(s.key, 'test', `curl -fs http://localhost:${this.httpPort()}/ || exit 1`);
    if (!s.healthInterval) this.draft.setHealth(s.key, 'interval', '30s');
    if (!s.healthRetries) this.draft.setHealth(s.key, 'retries', '3');
  }

  protected clearHealth(): void {
    const s = this.svc();
    this.draft.setHealth(s.key, 'test', '');
    this.draft.setHealth(s.key, 'interval', '');
    this.draft.setHealth(s.key, 'retries', '');
  }

  private focusLater(id: string, select = false): void {
    setTimeout(() => {
      const el = document.getElementById(id) as HTMLInputElement | null;
      el?.focus();
      if (select) el?.select();
    });
  }
}
