// Docklet Design Lab – opus-compact · Einmaliger Import (docker run, GitHub, Docker Hub)
// Kein Git Sync, keine dauerhafte Verbindung, keine echten Requests. Ergebnis landet als Service im Entwurf.
import { ChangeDetectionStrategy, Component, computed, inject, input, output, signal } from '@angular/core';
import { stringify } from 'yaml';
import { ZardButtonComponent } from '../../shared/components/button';
import { dockerHubImport, dockerRunToService, githubImport, type ImportResult } from './compose';
import { CxDraft } from './draft';
import { CxIcon, type IconName } from './icon';
import { CxDialog } from './ui';

export type ImportSource = 'run' | 'github' | 'hub';

const SOURCES: { id: ImportSource; label: string; icon: IconName; placeholder: string; example: string }[] = [
  {
    id: 'run',
    label: 'docker run',
    icon: 'terminal',
    placeholder: 'docker run -d --name … image:tag',
    example: 'docker run -d --name uptime -p 3001:3001 -v uptime-data:/app/data -e TZ=Europe/Berlin --restart unless-stopped --label traefik.enable=true louislam/uptime-kuma:1',
  },
  { id: 'github', label: 'GitHub', icon: 'github', placeholder: 'https://github.com/owner/repo', example: 'https://github.com/example/whoami-stack' },
  { id: 'hub', label: 'Docker Hub', icon: 'box', placeholder: 'owner/image[:tag]', example: 'vaultwarden/server' },
];

@Component({
  selector: 'cx-import-dialog',
  imports: [ZardButtonComponent, CxIcon, CxDialog],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <cx-dialog
      [open]="open()"
      heading="Service importieren"
      description="Einmaliger Import in den aktuellen Entwurf. Vorhandene Werte werden übernommen, fehlende bleiben leer mit Hinweis."
      icon="upload"
      width="lg"
      (closed)="close()"
    >
      <div class="p-4">
        <div role="tablist" aria-label="Importquelle" class="mb-3 flex gap-1 rounded-md bg-zinc-100 p-0.5" (keydown)="onKey($event)">
          @for (s of sources; track s.id) {
            <button
              type="button"
              role="tab"
              [id]="'imp-tab-' + s.id"
              [attr.aria-selected]="source() === s.id"
              [attr.tabindex]="source() === s.id ? 0 : -1"
              class="inline-flex h-8 flex-1 items-center justify-center gap-1.5 rounded text-[12.5px] font-medium outline-none focus-visible:ring-2 focus-visible:ring-zinc-900"
              [class]="source() === s.id ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-600 hover:text-zinc-900'"
              (click)="select(s.id)"
            >
              <cx-icon [name]="s.icon" [size]="14" />{{ s.label }}
            </button>
          }
        </div>

        <div role="tabpanel" [attr.aria-labelledby]="'imp-tab-' + source()">
          <label class="block">
            <span class="mb-1 block text-[12px] font-medium text-zinc-700">{{ current().id === 'run' ? 'Befehl' : current().id === 'github' ? 'Repository-URL' : 'Image' }}</span>
            @if (current().id === 'run') {
              <textarea rows="4" class="w-full rounded-md border border-zinc-300 px-2 py-1.5 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" [placeholder]="current().placeholder" [value]="text()" (input)="setText($event)" autofocus></textarea>
            } @else {
              <input class="h-8 w-full rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" [placeholder]="current().placeholder" [value]="text()" (input)="setText($event)" (keydown.enter)="preview()" autofocus />
            }
          </label>
          <div class="mt-2 flex flex-wrap items-center gap-2">
            <button z-button zType="outline" zSize="sm" type="button" (click)="preview()"><cx-icon name="eye" [size]="13" />Vorschau</button>
            <button type="button" class="text-[12px] font-medium text-zinc-600 underline underline-offset-2 hover:text-zinc-900" (click)="useExample()">Beispiel einsetzen</button>
            @if (current().id !== 'run') {
              <span class="text-[11.5px] text-zinc-500">Simulierte Metadaten, keine Netzwerkabfrage.</span>
            }
          </div>

          @if (result(); as r) {
            @if (!r.ok) {
              <div class="mt-3 flex gap-2 rounded-md border border-red-200 bg-red-50 p-2.5 text-[12.5px] text-red-900" role="alert">
                <cx-icon name="xCircle" [size]="15" class="mt-0.5" />{{ r.error }}
              </div>
            } @else {
              <div class="mt-3 grid gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
                <div>
                  <div class="mb-1 text-[12px] font-semibold text-zinc-700">Ergebnis: Service <span class="font-mono">{{ r.key }}</span></div>
                  <pre class="max-h-64 overflow-auto rounded-md bg-[#0c0c0f] p-2.5 font-mono text-[11.5px] leading-5 text-[#e4e4e7]">{{ yamlPreview() }}</pre>
                </div>
                <div>
                  <div class="mb-1 text-[12px] font-semibold text-zinc-700">Hinweise</div>
                  <ul class="space-y-1 text-[12.5px] text-zinc-700">
                    @for (n of r.notes; track $index) {
                      <li class="flex gap-1.5"><cx-icon name="info" [size]="13" class="mt-0.5 text-sky-600" />{{ n }}</li>
                    } @empty {
                      <li class="flex gap-1.5"><cx-icon name="checkCircle" [size]="13" class="mt-0.5 text-emerald-600" />Alle Angaben übernommen.</li>
                    }
                  </ul>
                </div>
              </div>
            }
          }
        </div>
      </div>
      <div cx-footer class="flex gap-2">
        <button z-button zType="ghost" zSize="sm" type="button" (click)="close()">Abbrechen</button>
        <button z-button zSize="sm" type="button" [zDisabled]="!result()?.ok" (click)="apply()"><cx-icon name="plus" [size]="13" />Als Service übernehmen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxImportDialog {
  private readonly draft = inject(CxDraft);
  readonly open = input<boolean>(false);
  readonly initial = input<ImportSource>('run');
  readonly closed = output<void>();

  protected readonly sources = SOURCES;
  protected readonly picked = signal<ImportSource | null>(null);
  protected readonly text = signal('');
  protected readonly result = signal<ImportResult | null>(null);

  protected readonly source = computed<ImportSource>(() => this.picked() ?? this.initial());
  protected readonly current = computed(() => SOURCES.find((s) => s.id === this.source()) ?? SOURCES[0]);
  protected readonly yamlPreview = computed(() => {
    const r = this.result();
    return r?.ok ? stringify({ [r.key]: r.body }) : '';
  });

  protected select(id: ImportSource): void {
    this.picked.set(id);
    this.text.set('');
    this.result.set(null);
  }

  protected setText(e: Event): void {
    this.text.set((e.target as HTMLInputElement).value);
    this.result.set(null);
  }

  protected useExample(): void {
    this.text.set(this.current().example);
    this.preview();
  }

  protected preview(): void {
    const model = this.draft.model();
    const t = this.text();
    const id = this.source();
    this.result.set(id === 'run' ? dockerRunToService(t, model) : id === 'github' ? githubImport(t, model) : dockerHubImport(t, model));
  }

  protected apply(): void {
    const r = this.result();
    if (!r?.ok) return;
    this.draft.addService(r.key, r.body);
    this.close();
  }

  protected close(): void {
    this.picked.set(null);
    this.text.set('');
    this.result.set(null);
    this.closed.emit();
  }

  protected onKey(ev: KeyboardEvent): void {
    if (ev.key !== 'ArrowRight' && ev.key !== 'ArrowLeft') return;
    const i = SOURCES.findIndex((s) => s.id === this.source());
    const next = SOURCES[(i + (ev.key === 'ArrowRight' ? 1 : SOURCES.length - 1)) % SOURCES.length];
    this.select(next.id);
    setTimeout(() => document.getElementById('imp-tab-' + next.id)?.focus());
  }
}
