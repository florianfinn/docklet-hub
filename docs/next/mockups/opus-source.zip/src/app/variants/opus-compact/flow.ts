// Docklet Design Lab – opus-compact · Ablaufanzeige für Deployments und Aktionen
// Schritte (z. B. Prüfung, Image-Pull/Build, Erstellen/Austausch, Start, Zustandsprüfung), aktuelle Phase,
// Fortschritt, Ergebnis und betroffene Services.
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import type { ActionItem } from './data';
import { CxIcon } from './icon';
import { CxStatus } from './ui';

type StepState = 'done' | 'active' | 'error' | 'todo';

@Component({
  selector: 'cx-flow',
  imports: [CxIcon, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'block' },
  template: `
    @let a = action();
    @if (header()) {
      <div class="mb-2 flex flex-wrap items-center gap-2">
        <span class="font-medium">{{ a.title }}</span>
        <cx-status [kind]="a.status === 'running' ? 'active' : a.status" [label]="statusLabel()" />
        <span class="text-[11.5px] text-zinc-500">gestartet {{ a.startedAt }}</span>
        <span class="ml-auto font-mono text-[11.5px] tabular-nums text-zinc-600">{{ a.progress }}%</span>
      </div>
    }
    <ol class="grid gap-1" [style.grid-template-columns]="compact() ? '1fr' : gridCols()">
      @for (s of a.steps; track $index; let i = $index) {
        @let st = state(i);
        <li class="flex min-w-0 items-center gap-1.5 rounded-md border px-2 py-1.5 text-[12px]" [class]="boxCls(st)" [attr.aria-current]="st === 'active' ? 'step' : null">
          @switch (st) {
            @case ('done') { <cx-icon name="checkCircle" [size]="14" class="shrink-0 text-emerald-600" /> }
            @case ('active') { <span class="size-3.5 shrink-0 rounded-full border-2 border-sky-200 border-t-sky-600 motion-safe:animate-spin" aria-hidden="true"></span> }
            @case ('error') { <cx-icon name="xCircle" [size]="14" class="shrink-0 text-red-600" /> }
            @default { <span class="grid size-3.5 shrink-0 place-items-center rounded-full border border-zinc-300 font-mono text-[8.5px] text-zinc-500">{{ i + 1 }}</span> }
          }
          <span class="truncate" [class.font-medium]="st === 'active' || st === 'error'">{{ s }}</span>
          <span class="sr-only">({{ stateLabel(st) }})</span>
        </li>
      }
    </ol>
    @if (a.services?.length) {
      <div class="mt-2 flex flex-wrap items-center gap-1 text-[11.5px] text-zinc-600">
        <span>Betroffene Services:</span>
        @for (svc of a.services ?? []; track svc) {
          <span class="inline-flex items-center gap-1 rounded border border-zinc-200 bg-white px-1.5 font-mono text-[11px]">
            <span class="size-1.5 rounded-full" [class]="a.status === 'success' ? 'bg-emerald-500' : a.status === 'error' ? 'bg-red-500' : 'bg-sky-500'"></span>{{ svc }}
          </span>
        }
      </div>
    }
    @if (a.status === 'error') {
      <p class="mt-2 text-[12px] text-red-800">Ergebnis: fehlgeschlagen bei „{{ a.steps[a.step] }}“. {{ a.restorable ? 'Vorheriges Image und vorherige Konfiguration stehen zur manuellen Wiederherstellung bereit.' : '' }}</p>
    } @else if (a.status === 'success' && header()) {
      <p class="mt-2 text-[12px] text-emerald-800">Ergebnis: erfolgreich abgeschlossen.</p>
    }
  `,
})
export class CxFlow {
  readonly action = input.required<ActionItem>();
  readonly header = input<boolean>(true);
  readonly compact = input<boolean>(false);

  protected readonly gridCols = computed(() => `repeat(auto-fit, minmax(118px, 1fr))`);

  protected readonly statusLabel = computed(() => {
    const a = this.action();
    if (a.status === 'running') return `Phase: ${a.steps[a.step] ?? ''}`;
    return a.status === 'success' ? 'Erfolgreich' : a.status === 'error' ? 'Fehlgeschlagen' : 'Wartend';
  });

  protected state(i: number): StepState {
    const a = this.action();
    if (a.status === 'success' || i < a.step) return 'done';
    if (i === a.step) return a.status === 'error' ? 'error' : a.status === 'running' ? 'active' : 'todo';
    return 'todo';
  }

  protected stateLabel(s: StepState): string {
    return { done: 'erledigt', active: 'läuft', error: 'Fehler', todo: 'ausstehend' }[s];
  }

  protected boxCls(s: StepState): string {
    if (s === 'done') return 'border-emerald-500/25 bg-emerald-500/5';
    if (s === 'active') return 'border-sky-500/40 bg-sky-500/10';
    if (s === 'error') return 'border-red-500/40 bg-red-500/10';
    return 'border-zinc-200 text-zinc-500';
  }
}
