// Docklet Design Lab – opus-compact · Stack-Editor (Tab der Stack-Seite)
// Advanced = Arcane-Arbeitsbereich: Dateiliste (compose.yaml, .env) links, Tab-Leiste, Editor mit Zeilennummern,
// Speichern / Bereitstellen. Easy = synchronisierter, verschachtelter Wizard auf demselben Entwurf.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { LABEL_COLORS } from './data';
import { CxDraft, SUB_STEPS } from './draft';
import { CxServiceForm } from './editor-service';
import { CxIcon } from './icon';
import { CxImportDialog, type ImportSource } from './import-dialog';
import { CxStore, type EditorFile, type EditorMode } from './store';
import { CxHost, CxLabel } from './ui';

@Component({
  selector: 'cx-editor',
  imports: [ZardButtonComponent, CxIcon, CxHost, CxLabel, CxServiceForm, CxImportDialog],
  providers: [CxDraft],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let m = draft.model();
    @let host = store.host(store.draftHostId());
    <!-- Werkzeugleiste -->
    <div class="mb-3 flex flex-wrap items-center gap-x-3 gap-y-2">
      <div class="flex rounded-md border border-zinc-200 bg-zinc-100 p-0.5" role="group" aria-label="Bearbeitungsmodus">
        @for (md of modes; track md.id) {
          <button type="button" class="inline-flex h-7 items-center gap-1.5 rounded px-2.5 text-[12.5px] font-medium outline-none focus-visible:ring-2 focus-visible:ring-zinc-900" [class]="store.editorMode() === md.id ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-600 hover:text-zinc-900'" [attr.aria-pressed]="store.editorMode() === md.id" (click)="store.editorMode.set(md.id)">
            <cx-icon [name]="md.icon" [size]="13" />{{ md.label }}
          </button>
        }
      </div>
      @if (draft.valid()) {
        <span class="inline-flex items-center gap-1 rounded-md border border-emerald-500/25 bg-emerald-500/10 px-1.5 py-px text-[11.5px] font-medium text-emerald-700"><cx-icon name="check" [size]="12" />Easy und Advanced synchron</span>
      } @else {
        <span class="inline-flex items-center gap-1 rounded-md border border-red-500/25 bg-red-500/10 px-1.5 py-px text-[11.5px] font-medium text-red-700" role="status"><cx-icon name="alert" [size]="12" />YAML-Fehler{{ errorLine() ? ' · Zeile ' + errorLine() : '' }}</span>
      }
      @if (dirty()) { <span class="text-[11.5px] text-amber-700">Ungespeicherte Änderungen</span> }

      <div class="ml-auto flex flex-wrap items-center gap-2">
        <label class="flex items-center gap-1.5 text-[12px] text-zinc-600">
          <span>Zielhost</span>
          <select class="h-8 rounded-md border border-zinc-200 bg-white px-2 text-[12.5px] font-medium outline-none focus:ring-2 focus:ring-zinc-900/15 disabled:opacity-60" aria-label="Zielhost" [disabled]="!isNew()" [title]="isNew() ? '' : 'Host eines bestehenden Stacks wird hier nicht geändert'" (change)="setHost($event)">
            @for (h of store.hosts(); track h.id) {
              <option [value]="h.id" [selected]="h.id === store.draftHostId()" [disabled]="h.status === 'getrennt'">{{ h.name }}{{ h.status === 'getrennt' ? ' (getrennt)' : '' }}</option>
            }
          </select>
          <cx-host [name]="host.name" [color]="host.color" class="max-sm:hidden" />
        </label>
        <button z-button zType="outline" zSize="sm" type="button" [zDisabled]="!draft.valid()" (click)="save()"><cx-icon name="save" [size]="14" />Speichern</button>
        <button z-button zSize="sm" type="button" [zDisabled]="draft.blocking()" [attr.title]="draft.blocking() ? 'Pflichtangaben fehlen oder YAML ist ungültig' : null" (click)="deploy()">
          <cx-icon name="rocket" [size]="14" />Bereitstellen
        </button>
      </div>
    </div>

    @if (store.editorMode() === 'advanced') {
      <!-- Arcane-Arbeitsbereich -->
      <div class="grid items-start gap-3 lg:grid-cols-[208px_minmax(0,1fr)] 2xl:grid-cols-[208px_minmax(0,1fr)_272px]">
        <nav class="overflow-hidden rounded-lg border border-zinc-200 bg-white" aria-label="Projektdateien">
          <div class="flex items-center gap-1.5 border-b border-zinc-200 px-3 py-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-500"><cx-icon name="folder" [size]="13" />Dateien</div>
          <ul class="p-1">
            @for (f of files; track f.id) {
              <li>
                <button type="button" class="flex h-8 w-full items-center gap-2 rounded-md px-2 text-left font-mono text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-zinc-900" [class]="store.editorFile() === f.id ? 'bg-zinc-100 font-medium' : 'hover:bg-zinc-50'" [attr.aria-current]="store.editorFile() === f.id ? 'true' : null" (click)="store.editorFile.set(f.id)">
                  <cx-icon [name]="f.icon" [size]="14" [class]="f.cls" />{{ f.label }}
                  @if (f.id === 'compose' && !draft.valid()) { <span class="ml-auto size-1.5 rounded-full bg-red-500" title="Fehler"></span> }
                </button>
              </li>
            }
          </ul>
          <div class="border-t border-zinc-200 px-3 py-2 text-[11.5px] leading-4 text-zinc-500">
            <div class="mb-1 font-mono">{{ host.projectDir }}/{{ m?.name || '‹name›' }}/</div>
            Projektverzeichnis auf {{ host.name }}. Mounts öffnen im Easy-Modus den Dateibrowser.
          </div>
        </nav>

        <section class="min-w-0 overflow-hidden rounded-lg border border-[#27272a] bg-[#0c0c0f]" aria-label="Editor">
          <div class="flex items-center border-b border-[#27272a] bg-[#111114] text-[12px]" role="tablist" aria-label="Geöffnete Datei">
            @for (f of files; track f.id) {
              <button type="button" role="tab" class="flex h-9 items-center gap-1.5 border-r border-[#27272a] px-3 font-mono" [class]="store.editorFile() === f.id ? 'bg-[#0c0c0f] text-white' : 'text-[#a1a1aa] hover:text-white'" [attr.aria-selected]="store.editorFile() === f.id" (click)="store.editorFile.set(f.id)">
                <cx-icon [name]="f.icon" [size]="13" [class]="f.dark" />{{ f.label }}
              </button>
            }
            <span class="ml-auto hidden px-3 text-[11px] text-[#71717a] sm:inline">Tab rückt ein · Esc, dann Tab verlässt das Feld</span>
          </div>
          <div class="flex h-[min(64vh,600px)]">
            <pre #gutter class="w-11 shrink-0 select-none overflow-hidden border-r border-[#27272a] py-2.5 pr-2 text-right font-mono text-[12px] leading-5 text-[#52525b]" aria-hidden="true">@for (n of lineNumbers(); track n) {<span [class]="store.editorFile() === 'compose' && n === errorLine() ? 'font-bold text-[#f87171]' : ''">{{ n }}</span>
}</pre>
            <textarea
              class="min-w-0 flex-1 resize-none bg-transparent py-2.5 pl-3 pr-3 font-mono text-[12px] leading-5 text-[#e4e4e7] outline-none selection:bg-sky-700/60"
              spellcheck="false"
              autocapitalize="off"
              autocomplete="off"
              wrap="off"
              [attr.aria-label]="store.editorFile() === 'compose' ? 'compose.yaml bearbeiten' : '.env bearbeiten'"
              [attr.aria-invalid]="store.editorFile() === 'compose' && !draft.valid()"
              aria-describedby="cx-yaml-status"
              [value]="store.editorFile() === 'compose' ? draft.raw() : store.draftEnv()"
              (input)="onInput($event)"
              (scroll)="syncScroll(gutter, $event)"
              (keydown)="onEditorKey($event)"
            ></textarea>
          </div>
          <div id="cx-yaml-status" class="flex flex-wrap items-center gap-2 border-t border-[#27272a] bg-[#111114] px-3 py-1.5 text-[11.5px]" [class]="draft.valid() ? 'text-[#a1a1aa]' : 'text-[#fca5a5]'">
            @if (draft.valid()) {
              <cx-icon name="checkCircle" [size]="13" class="text-[#34d399]" />YAML gültig · {{ serviceKeys() || 'keine Services' }}
            } @else {
              <cx-icon name="xCircle" [size]="13" />
              @for (e of draft.parsed().errors; track $index) { <span>{{ e.line ? 'Zeile ' + e.line + ': ' : '' }}{{ e.message }}</span> }
            }
            <span class="ml-auto text-[#71717a]">{{ store.editorFile() === 'compose' ? 'YAML' : 'dotenv' }} · UTF-8</span>
          </div>
        </section>

        <aside class="space-y-3 lg:col-span-2 2xl:col-span-1">
          <div class="rounded-lg border border-zinc-200 bg-white p-3">
            <div class="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Erkannt</div>
            <dl class="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-[12.5px]">
              <dt class="text-zinc-500">Name</dt><dd class="font-mono">{{ m?.name || '–' }}</dd>
              <dt class="text-zinc-500">Services</dt><dd class="font-mono">{{ serviceKeys() || '–' }}</dd>
              <dt class="text-zinc-500">Weitere</dt><dd class="font-mono">{{ m?.topUnknown?.join(', ') || '–' }}</dd>
            </dl>
            <p class="mt-2 text-[11.5px] text-zinc-500">Unbekannte Felder und Kommentare bleiben beim Wechsel in den Easy-Modus erhalten.</p>
          </div>
          @if (draft.hints().length) {
            <div class="rounded-lg border border-zinc-200 bg-white p-3">
              <div class="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Hinweise</div>
              <ul class="space-y-1 text-[12.5px]">
                @for (h of draft.hints(); track $index) {
                  <li class="flex gap-1.5" [class]="h.level === 'pflicht' ? 'text-red-700' : 'text-amber-700'"><cx-icon [name]="h.level === 'pflicht' ? 'xCircle' : 'alert'" [size]="13" class="mt-0.5 shrink-0" />{{ h.text }}</li>
                }
              </ul>
            </div>
          }
        </aside>
      </div>
    } @else {
      <!-- Easy: verschachtelter Wizard -->
      <div class="grid items-start gap-3 lg:grid-cols-[236px_minmax(0,1fr)]">
        <nav class="rounded-lg border border-zinc-200 bg-white p-2 lg:sticky lg:top-16" aria-label="Wizard-Schritte">
          <ol class="space-y-0.5">
            <li>
              <button type="button" [class]="railCls(draft.step().kind === 'basics')" [attr.aria-current]="draft.step().kind === 'basics' ? 'step' : null" (click)="draft.go('basics')">
                <span class="grid size-5 place-items-center rounded-full text-[10.5px] font-semibold" [class]="m?.name ? 'bg-emerald-600 text-white' : 'bg-zinc-200 text-zinc-700'">@if (m?.name) { <cx-icon name="check" [size]="11" /> } @else { 1 }</span>
                Stack-Grundlagen
              </button>
            </li>
            <li class="pt-1">
              <div class="flex items-center gap-2 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500"><span class="grid size-5 place-items-center rounded-full bg-zinc-200 text-[10.5px] text-zinc-700">2</span>Services</div>
              <ul class="ml-[17px] space-y-0.5 border-l border-zinc-200 pl-2">
                @for (svc of m?.services ?? []; track $index; let i = $index) {
                  <li>
                    <button type="button" [class]="railCls(draft.step().kind === 'service' && draft.step().index === i)" (click)="draft.goService(i)" [attr.aria-expanded]="draft.step().kind === 'service' && draft.step().index === i">
                      <span class="size-2 shrink-0 rounded-full" [class]="svc.image ? 'bg-emerald-500' : 'bg-red-500'" [attr.title]="svc.image ? 'vollständig' : 'Image fehlt'"></span>
                      <span class="truncate font-mono text-[12.5px]">{{ svc.key }}</span>
                    </button>
                    @if (draft.step().kind === 'service' && draft.step().index === i) {
                      <ul class="mb-1 ml-3 mt-0.5 space-y-px">
                        @for (sub of subSteps; track sub.id) {
                          <li>
                            <button type="button" class="flex h-7 w-full items-center gap-2 rounded px-2 text-left text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-zinc-900" [class]="draft.step().sub === sub.id ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'" [attr.aria-current]="draft.step().sub === sub.id ? 'step' : null" (click)="draft.goService(i, sub.id)">
                              {{ sub.label }}
                              @if (sub.id === 'image' && !svc.image) { <span class="ml-auto text-[10.5px] font-semibold" [class]="draft.step().sub === sub.id ? 'text-red-300' : 'text-red-600'">Pflicht</span> }
                              @if (sub.id === 'ports' && svc.ports.length) { <span class="ml-auto font-mono text-[10.5px] opacity-70">{{ svc.ports.length }}</span> }
                              @if (sub.id === 'mounts' && svc.volumes.length) { <span class="ml-auto font-mono text-[10.5px] opacity-70">{{ svc.volumes.length }}</span> }
                              @if (sub.id === 'env' && svc.env.length) { <span class="ml-auto font-mono text-[10.5px] opacity-70">{{ svc.env.length }}</span> }
                              @if (sub.id === 'health' && svc.healthTest) { <cx-icon name="heart" [size]="12" class="ml-auto opacity-70" /> }
                            </button>
                          </li>
                        }
                      </ul>
                    }
                  </li>
                }
                <li>
                  <button type="button" class="flex h-8 w-full items-center gap-2 rounded-md px-2 text-left text-[12.5px] font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-40" [disabled]="!draft.valid()" (click)="addService()"><cx-icon name="plus" [size]="13" />Service hinzufügen</button>
                </li>
              </ul>
            </li>
            <li class="pt-1">
              <button type="button" [class]="railCls(draft.step().kind === 'review')" [attr.aria-current]="draft.step().kind === 'review' ? 'step' : null" (click)="draft.go('review')">
                <span class="grid size-5 place-items-center rounded-full bg-zinc-200 text-[10.5px] font-semibold text-zinc-700">3</span>
                Prüfen & Bereitstellen
                @if (pflicht() > 0) { <span class="ml-auto rounded bg-red-500/15 px-1 text-[10.5px] font-semibold text-red-700">{{ pflicht() }}</span> }
              </button>
            </li>
          </ol>
          <div class="mt-2 border-t border-zinc-100 pt-2">
            <div class="px-2 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Einmaliger Import</div>
            <div class="grid grid-cols-1 gap-1">
              <button z-button zType="outline" zSize="sm" type="button" [zDisabled]="!draft.valid()" (click)="openImport('run')"><cx-icon name="terminal" [size]="13" />docker run konvertieren</button>
              <button z-button zType="outline" zSize="sm" type="button" [zDisabled]="!draft.valid()" (click)="openImport('github')"><cx-icon name="github" [size]="13" />GitHub / Docker Hub</button>
            </div>
          </div>
        </nav>

        <section class="min-w-0 rounded-lg border border-zinc-200 bg-white" aria-labelledby="cx-step-title">
          @if (!draft.valid()) {
            <div class="flex gap-2 border-b border-red-500/25 bg-red-500/10 px-4 py-2.5 text-[12.5px] text-red-800" role="alert">
              <cx-icon name="alert" [size]="15" class="mt-0.5" />
              <div>Der Raw-Entwurf enthält ungültiges YAML. Das Formular zeigt den letzten gültigen Stand und ist gesperrt – es gehen keine Daten verloren.
                <button type="button" class="ml-1 font-semibold underline" (click)="store.editorMode.set('advanced')">Im Advanced-Modus korrigieren</button>
              </div>
            </div>
          }
          <header class="flex items-center gap-2 border-b border-zinc-100 px-4 py-2.5">
            <h2 id="cx-step-title" class="text-[14px] font-semibold">{{ stepTitle() }}</h2>
            <span class="ml-auto text-[11.5px] text-zinc-500">Schritt {{ stepIndex() + 1 }} von {{ draft.order().length }}</span>
          </header>
          <fieldset class="min-w-0 p-4 disabled:opacity-60" [disabled]="!draft.valid()">
            @switch (draft.step().kind) {
              @case ('basics') {
                <div class="grid gap-4 xl:grid-cols-2">
                  <div class="space-y-3">
                    <label class="block">
                      <span class="mb-1 block text-[12px] font-medium text-zinc-700">Stackname <span class="text-red-600" aria-hidden="true">*</span></span>
                      <input class="h-8 w-full rounded-md border bg-white px-2 font-mono text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/15" [class]="m?.name ? 'border-zinc-300' : 'border-red-400'" [value]="m?.name ?? ''" placeholder="z. B. media" required [attr.aria-invalid]="!m?.name" aria-describedby="cx-name-hint" (input)="draft.setName(v($event))" />
                      <span id="cx-name-hint" class="mt-1 block text-[11.5px]" [class]="m?.name ? 'text-zinc-500' : 'text-red-700'">{{ m?.name ? 'Wird als „name:“ in compose.yaml gespeichert.' : 'Pflichtfeld: Stackname angeben.' }}</span>
                    </label>
                    <div>
                      <span id="cx-lbl-title" class="mb-1 block text-[12px] font-medium text-zinc-700">Labels</span>
                      <div class="flex min-h-8 flex-wrap items-center gap-1 rounded-md border border-zinc-300 bg-white px-1.5 py-1" role="group" aria-labelledby="cx-lbl-title">
                        @for (l of store.draftLabels(); track l) {
                          <span class="inline-flex items-center gap-0.5"><cx-label [name]="l" /><button type="button" class="grid size-4 place-items-center rounded text-zinc-400 hover:text-red-700" [attr.aria-label]="'Label ' + l + ' entfernen'" (click)="removeLabel(l)"><cx-icon name="x" [size]="11" /></button></span>
                        }
                        <input class="h-6 min-w-[110px] flex-1 bg-transparent px-1 text-[12.5px] outline-none" list="cx-label-list" placeholder="Label + Enter" aria-label="Label hinzufügen" [value]="labelInput()" (input)="labelInput.set(v($event))" (keydown.enter)="addLabel(); $event.preventDefault()" />
                        <datalist id="cx-label-list">
                          @for (l of labelSuggestions(); track l) { <option [value]="l"></option> }
                        </datalist>
                      </div>
                      <div class="mt-1 flex flex-wrap gap-1">
                        @for (l of labelSuggestions(); track l) {
                          <button type="button" class="rounded-full opacity-70 hover:opacity-100" [attr.aria-label]="'Label ' + l + ' hinzufügen'" (click)="addLabel(l)"><cx-label [name]="l" /></button>
                        }
                      </div>
                      <span class="mt-1 block text-[11.5px] text-zinc-500">Docklet-Metadaten für Übersicht und Filter – nicht Teil der compose.yaml.</span>
                    </div>
                    <fieldset>
                      <legend class="mb-1 text-[12px] font-medium text-zinc-700">Zielhost</legend>
                      <div class="grid grid-cols-1 gap-1.5 sm:grid-cols-3">
                        @for (h of store.hosts(); track h.id) {
                          <label class="flex cursor-pointer items-center gap-2 rounded-md border px-2.5 py-2 has-[:disabled]:cursor-not-allowed has-[:disabled]:opacity-50 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-zinc-900" [class]="store.draftHostId() === h.id ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-200 hover:bg-zinc-50'">
                            <input type="radio" name="cx-host" class="sr-only" [value]="h.id" [checked]="store.draftHostId() === h.id" [disabled]="h.status === 'getrennt' || !isNew()" (change)="store.draftHostId.set(h.id)" />
                            <span class="size-2.5 rounded-sm" [style.background-color]="h.color"></span>
                            <span class="min-w-0"><span class="block font-medium">{{ h.name }}</span><span class="block text-[11px] text-zinc-500">{{ h.status === 'online' ? 'online · ' + h.cpu + '% CPU' : h.status }}</span></span>
                          </label>
                        }
                      </div>
                    </fieldset>
                  </div>
                  <div class="space-y-3">
                    <div>
                      <div class="mb-1 text-[12px] font-medium text-zinc-700">Projektverzeichnis</div>
                      <div class="flex items-center gap-2 rounded-md border border-zinc-200 bg-zinc-50 px-2 py-1.5 font-mono text-[12px]"><cx-icon name="folder" [size]="13" class="text-zinc-500" />{{ host.projectDir }}/{{ m?.name || '‹name›' }}</div>
                      <p class="mt-1 text-[11.5px] text-zinc-500">compose.yaml und .env liegen hier. Das Installationsverzeichnis des Agents ({{ host.installDir }}) ist davon getrennt.</p>
                    </div>
                    <label class="block">
                      <span class="mb-1 block text-[12px] font-medium text-zinc-700">Stack-.env</span>
                      <textarea rows="4" class="w-full rounded-md border border-zinc-300 bg-white px-2 py-1.5 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" placeholder="KEY=Wert" [value]="store.draftEnv()" (input)="store.draftEnv.set(v($event))"></textarea>
                      <span class="mt-1 block text-[11.5px] text-zinc-500">Dieselbe Datei wie „.env“ im Advanced-Arbeitsbereich. Kein zentraler Variableneditor.</span>
                    </label>
                    @if (m?.topUnknown?.length) {
                      <div class="rounded-md border border-dashed border-zinc-300 bg-zinc-50 p-2.5">
                        <div class="flex items-center gap-1.5 text-[12px] font-medium text-zinc-700"><cx-icon name="lock" [size]="13" />Weitere Top-Level-Schlüssel bleiben erhalten</div>
                        <div class="mt-1.5 flex flex-wrap gap-1">
                          @for (k of m?.topUnknown ?? []; track k) { <span class="rounded border border-zinc-200 bg-white px-1.5 py-0.5 font-mono text-[11.5px]">{{ k }}</span> }
                        </div>
                      </div>
                    }
                  </div>
                </div>
              }
              @case ('service') {
                @if (currentService(); as svc) {
                  <div class="mb-3 flex flex-wrap items-center gap-1">
                    @for (sub of subSteps; track sub.id; let j = $index) {
                      <button type="button" class="inline-flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-[12px] font-medium" [class]="draft.step().sub === sub.id ? 'border-zinc-900 bg-zinc-900 text-white' : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50'" [attr.aria-current]="draft.step().sub === sub.id ? 'step' : null" (click)="draft.goService(draft.step().index, sub.id)">
                        <span class="font-mono text-[10.5px] opacity-70">{{ j + 1 }}</span>{{ sub.label }}
                      </button>
                    }
                    <button z-button zType="ghost" zSize="sm" type="button" class="ml-auto text-red-700" (click)="draft.removeService(svc.key)"><cx-icon name="trash" [size]="13" />Service entfernen</button>
                  </div>
                  <cx-service-form [svc]="svc" [sub]="draft.step().sub" />
                }
              }
              @case ('review') {
                @if (draft.hints().length) {
                  <ul class="mb-3 space-y-1">
                    @for (h of draft.hints(); track $index) {
                      <li>
                        <button type="button" class="flex w-full items-center gap-2 rounded-md border px-2.5 py-1.5 text-left text-[12.5px]" [class]="h.level === 'pflicht' ? 'border-red-500/25 bg-red-500/10 text-red-800' : 'border-amber-500/30 bg-amber-500/10 text-amber-800'" (click)="jump(h.service)">
                          <cx-icon [name]="h.level === 'pflicht' ? 'xCircle' : 'alert'" [size]="14" />
                          <span class="flex-1">{{ h.text }}</span>
                          <span class="text-[11px] font-semibold uppercase">{{ h.level === 'pflicht' ? 'Pflicht' : 'Hinweis' }}</span>
                        </button>
                      </li>
                    }
                  </ul>
                } @else {
                  <div class="mb-3 flex items-center gap-2 rounded-md border border-emerald-500/25 bg-emerald-500/10 px-2.5 py-2 text-[12.5px] text-emerald-800"><cx-icon name="checkCircle" [size]="15" />Alle Pflichtangaben vorhanden.</div>
                }
                <div class="mb-3 overflow-x-auto rounded-md border border-zinc-200">
                  <table class="w-full min-w-[520px] text-left text-[12.5px]">
                    <thead class="bg-zinc-50 text-[11px] uppercase tracking-wide text-zinc-500">
                      <tr><th class="px-2.5 py-1.5 font-semibold">Service</th><th class="px-2.5 py-1.5 font-semibold">Image</th><th class="px-2.5 py-1.5 font-semibold">Ports</th><th class="px-2.5 py-1.5 font-semibold">Mounts</th><th class="px-2.5 py-1.5 font-semibold">Var.</th><th class="px-2.5 py-1.5 font-semibold">Health</th></tr>
                    </thead>
                    <tbody>
                      @for (svc of m?.services ?? []; track $index) {
                        <tr class="border-t border-zinc-100">
                          <td class="px-2.5 py-1.5 font-mono">{{ svc.key }}</td>
                          <td class="px-2.5 py-1.5 font-mono" [class]="svc.image ? '' : 'text-red-700'">{{ svc.image || 'fehlt' }}</td>
                          <td class="px-2.5 py-1.5 font-mono">{{ svc.ports.join(', ') || '–' }}</td>
                          <td class="px-2.5 py-1.5">{{ svc.volumes.length + svc.volumesExtra }}</td>
                          <td class="px-2.5 py-1.5">{{ svc.env.length }}</td>
                          <td class="px-2.5 py-1.5">{{ svc.healthTest ? 'ja' : '–' }}</td>
                        </tr>
                      }
                    </tbody>
                  </table>
                </div>
                <div class="flex flex-wrap items-center gap-2">
                  <button z-button type="button" [zDisabled]="draft.blocking()" (click)="deploy()"><cx-icon name="rocket" [size]="14" />Auf {{ host.name }} bereitstellen (Simulation)</button>
                  <button z-button zType="outline" type="button" [zDisabled]="!draft.valid()" (click)="save()"><cx-icon name="save" [size]="14" />Nur speichern</button>
                  <span class="text-[12px] text-zinc-600">Ablauf und Fortschritt erscheinen als Popup rechts oben.</span>
                </div>
              }
            }
          </fieldset>
          <footer class="flex items-center gap-2 border-t border-zinc-100 px-4 py-2.5">
            <button z-button zType="outline" zSize="sm" type="button" [zDisabled]="stepIndex() === 0" (click)="draft.move(-1)"><cx-icon name="chevronLeft" [size]="13" />Zurück</button>
            @if (stepIndex() < draft.order().length - 1) {
              <button z-button zSize="sm" type="button" class="ml-auto" (click)="draft.move(1)">Weiter<cx-icon name="chevronRight" [size]="13" /></button>
            }
          </footer>
        </section>
      </div>
    }

    <p class="mt-3 text-[12px] text-zinc-500">Kein Git Sync · kein Vorlagenkatalog · Compose-Subset im Formular, alles Weitere bleibt im Raw-Editor erhalten.</p>

    <cx-import-dialog [open]="importOpen()" [initial]="importSource()" (closed)="importOpen.set(false)" />
  `,
})
export class CxEditor {
  protected readonly store = inject(CxStore);
  protected readonly draft = inject(CxDraft);
  protected readonly subSteps = SUB_STEPS;
  protected readonly importOpen = signal(false);
  protected readonly importSource = signal<ImportSource>('run');
  protected readonly labelInput = signal('');
  private tabOut = false;

  protected readonly modes: { id: EditorMode; label: string; icon: 'wand' | 'code' }[] = [
    { id: 'easy', label: 'Easy', icon: 'wand' },
    { id: 'advanced', label: 'Advanced', icon: 'code' },
  ];

  protected readonly files: { id: EditorFile; label: string; icon: 'fileCode' | 'file'; cls: string; dark: string }[] = [
    { id: 'compose', label: 'compose.yaml', icon: 'fileCode', cls: 'text-sky-600', dark: 'text-[#38bdf8]' },
    { id: 'env', label: '.env', icon: 'file', cls: 'text-emerald-600', dark: 'text-[#34d399]' },
  ];

  protected readonly isNew = computed(() => this.store.draftStackId() === null);
  protected readonly original = computed(() => this.store.stacks().find((s) => s.id === this.store.draftStackId()) ?? null);
  protected readonly dirty = computed(() => {
    const o = this.original();
    if (!o) return true;
    return o.compose !== this.draft.raw() || o.env !== this.store.draftEnv() || o.labels.join(',') !== this.store.draftLabels().join(',');
  });

  protected readonly labelSuggestions = computed(() => {
    const taken = this.store.draftLabels();
    return [...new Set([...Object.keys(LABEL_COLORS), ...this.store.allLabels()])].filter((l) => !taken.includes(l));
  });

  protected readonly currentService = computed(() => {
    const st = this.draft.step();
    return st.kind === 'service' ? (this.draft.model()?.services[st.index] ?? null) : null;
  });

  protected readonly stepIndex = computed(() => Math.max(0, this.draft.order().indexOf(this.store.editorStep())));

  protected readonly stepTitle = computed(() => {
    const st = this.draft.step();
    if (st.kind === 'basics') return 'Stack-Grundlagen';
    if (st.kind === 'review') return 'Prüfen & Bereitstellen';
    const svc = this.currentService();
    const sub = SUB_STEPS.find((s) => s.id === st.sub)?.label ?? '';
    return `Service ${svc?.key ?? ''} · ${sub}`;
  });

  protected readonly pflicht = computed(() => this.draft.hints().filter((h) => h.level === 'pflicht').length);
  protected readonly errorLine = computed(() => this.draft.parsed().errors[0]?.line ?? 0);
  protected readonly lineNumbers = computed(() => {
    const text = this.store.editorFile() === 'compose' ? this.draft.raw() : this.store.draftEnv();
    return Array.from({ length: Math.max(1, text.split('\n').length) }, (_, i) => i + 1);
  });
  protected readonly serviceKeys = computed(() => (this.draft.model()?.services ?? []).map((s) => s.key).join(', '));

  protected railCls(active: boolean): string {
    return (
      'flex h-8 w-full items-center gap-2 rounded-md px-2 text-left text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-zinc-900 ' +
      (active ? 'bg-zinc-100 font-semibold text-zinc-900' : 'text-zinc-700 hover:bg-zinc-50')
    );
  }

  protected v(e: Event): string {
    return (e.target as HTMLInputElement | HTMLTextAreaElement).value;
  }

  protected setHost(e: Event): void {
    this.store.draftHostId.set((e.target as HTMLSelectElement).value);
  }

  protected onInput(e: Event): void {
    const value = this.v(e);
    if (this.store.editorFile() === 'compose') this.draft.raw.set(value);
    else this.store.draftEnv.set(value);
  }

  protected addLabel(value?: string): void {
    const l = (value ?? this.labelInput()).trim().toLowerCase().replace(/[^a-z0-9äöüß_-]+/g, '-');
    if (!l) return;
    this.store.draftLabels.update((list) => (list.includes(l) ? list : [...list, l]));
    this.labelInput.set('');
  }

  protected removeLabel(l: string): void {
    this.store.draftLabels.update((list) => list.filter((x) => x !== l));
  }

  protected addService(): void {
    const model = this.draft.model();
    const taken = new Set((model?.services ?? []).map((s) => s.key));
    let n = (model?.services.length ?? 0) + 1;
    while (taken.has(`service-${n}`)) n++;
    this.draft.addService(`service-${n}`, { image: '', restart: 'unless-stopped' });
  }

  protected openImport(src: ImportSource): void {
    this.importSource.set(src);
    this.importOpen.set(true);
  }

  protected jump(service: number | undefined): void {
    if (service === undefined) this.draft.go('basics');
    else this.draft.goService(service);
  }

  protected save(): void {
    const model = this.draft.model();
    if (!model || !this.draft.valid()) return;
    this.store.saveDraft(model, this.draft.raw());
  }

  protected deploy(): void {
    const model = this.draft.model();
    if (!model || this.draft.blocking()) return;
    this.store.deploy(model, this.draft.raw());
  }

  protected syncScroll(gutter: HTMLElement, e: Event): void {
    gutter.scrollTop = (e.target as HTMLTextAreaElement).scrollTop;
  }

  protected onEditorKey(e: KeyboardEvent): void {
    if (e.key === 'Escape') {
      this.tabOut = true;
      return;
    }
    if (e.key !== 'Tab' || e.shiftKey || this.tabOut) {
      this.tabOut = false;
      return;
    }
    e.preventDefault();
    const ta = e.target as HTMLTextAreaElement;
    ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end');
    if (this.store.editorFile() === 'compose') this.draft.raw.set(ta.value);
    else this.store.draftEnv.set(ta.value);
  }
}
