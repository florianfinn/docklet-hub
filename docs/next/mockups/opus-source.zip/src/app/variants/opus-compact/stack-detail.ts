// Docklet Design Lab – opus-compact
// Ungenutzt seit Überarbeitung 2: Stack-Details sind jetzt eine eigene Stack-Seite (stack-page.ts,
// stack-logs.ts). Datei bleibt leer, damit sie weiterhin kompiliert.
export {};
