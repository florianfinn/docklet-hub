// Docklet Design Lab – opus-compact · Hosts und „Host hinzufügen“
// Direkte Verbindung ist Standard, Edge wählbar. Projekt- und Installationsverzeichnis getrennt,
// UID/GID optional unter „Erweitert“, Socket-Gruppe automatisch. Prüfung nur simuliert, keine echten Schlüssel.
import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ZardButtonComponent } from '../../shared/components/button';
import { HOST_PALETTE, type ConnectionMode, type Host } from './data';
import { CxIcon } from './icon';
import { CxStore } from './store';
import { CxDialog, CxMeter, CxStatus, tint } from './ui';

type CheckState = 'idle' | 'running' | 'ok';

@Component({
  selector: 'cx-hosts',
  imports: [FormsModule, ZardButtonComponent, CxIcon, CxDialog, CxMeter, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-3 flex flex-wrap items-center gap-2">
      <p class="text-[13px] text-zinc-600">{{ store.hosts().length }} Hosts · {{ online() }} online. Alle Hosts erscheinen gemeinsam in Anwendungen – kein Umschalten nötig.</p>
      <button z-button zSize="sm" type="button" class="ml-auto" (click)="openAdd()"><cx-icon name="plus" [size]="14" />Host hinzufügen</button>
    </div>

    <div class="grid gap-3 md:grid-cols-2 2xl:grid-cols-3">
      @for (h of store.hosts(); track h.id) {
        <article class="overflow-hidden rounded-lg border border-zinc-200 bg-white" [attr.aria-labelledby]="'host-' + h.id">
          <div class="h-1" [style.background-color]="h.color"></div>
          <div class="p-3">
            <div class="flex items-start gap-2">
              <span class="grid size-9 place-items-center rounded-md" [style.background-color]="tintOf(h.color)" [style.color]="h.color"><cx-icon name="server" [size]="17" /></span>
              <div class="min-w-0 flex-1">
                <h2 [id]="'host-' + h.id" class="flex items-center gap-2 text-[14px] font-semibold">{{ h.name }} <cx-status [kind]="h.status" /></h2>
                <p class="truncate font-mono text-[11.5px] text-zinc-500">{{ h.address }}</p>
              </div>
              <span class="inline-flex items-center gap-1 rounded border border-zinc-200 px-1.5 py-0.5 text-[11px] font-medium text-zinc-700"><cx-icon [name]="h.mode === 'edge' ? 'cloud' : 'plug'" [size]="12" />{{ h.mode === 'edge' ? 'Edge' : 'Direkt' }}</span>
            </div>
            <div class="mt-3 grid grid-cols-[36px_1fr_38px] items-center gap-x-2 gap-y-1.5 text-[11.5px] text-zinc-500">
              <span>CPU</span><cx-meter [value]="h.cpu" [color]="h.color" [label]="'CPU ' + h.name" /><span class="text-right font-mono tabular-nums text-zinc-700">{{ h.status === 'online' ? h.cpu + '%' : '–' }}</span>
              <span>RAM</span><cx-meter [value]="h.mem" color="#71717a" [label]="'RAM ' + h.name" /><span class="text-right font-mono tabular-nums text-zinc-700">{{ h.status === 'online' ? h.mem + '%' : '–' }}</span>
              <span>Disk</span><cx-meter [value]="h.disk" color="#a1a1aa" [label]="'Speicher ' + h.name" /><span class="text-right font-mono tabular-nums text-zinc-700">{{ h.disk }}%</span>
            </div>
            <dl class="mt-3 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-[12px]">
              <dt class="text-zinc-500">Container</dt><dd class="font-medium">{{ containerCount(h.id) }}</dd>
              <dt class="text-zinc-500">Docker</dt><dd class="font-mono">{{ h.docker }}</dd>
              <dt class="text-zinc-500">Projekte</dt><dd class="truncate font-mono">{{ h.projectDir }}</dd>
              <dt class="text-zinc-500">Agent</dt><dd class="truncate font-mono">{{ h.installDir }}</dd>
              <dt class="text-zinc-500">Zuletzt</dt><dd>{{ h.lastSeen }}</dd>
            </dl>
            <div class="mt-3 flex flex-wrap gap-1.5">
              @if (h.status === 'getrennt') {
                <button z-button zType="outline" zSize="sm" type="button" (click)="reconnect(h)"><cx-icon name="restart" [size]="13" />Neu verbinden</button>
              } @else {
                <button z-button zType="outline" zSize="sm" type="button" (click)="check(h)"><cx-icon name="shield" [size]="13" />Verbindung prüfen</button>
              }
              <button z-button zType="ghost" zSize="sm" type="button" (click)="filterTo(h.id)"><cx-icon name="filter" [size]="13" />Nur diesen Host</button>
            </div>
          </div>
        </article>
      }
    </div>

    <cx-dialog [open]="addOpen()" heading="Host hinzufügen" description="Agent auf dem Zielhost installieren. Alle Prüfungen sind in dieser Demo simuliert." icon="server" width="xl" (closed)="addOpen.set(false)">
      <div class="grid gap-4 p-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <form id="cx-host-form" class="space-y-3" (ngSubmit)="create()">
          <div class="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
            <label class="block">
              <span class="mb-1 block text-[12px] font-medium text-zinc-700">Name <span class="text-red-600" aria-hidden="true">*</span></span>
              <input class="h-8 w-full rounded-md border px-2 text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/15" [class]="name().trim() ? 'border-zinc-300' : 'border-red-400'" name="name" required autofocus [ngModel]="name()" (ngModelChange)="name.set($event)" placeholder="z. B. Delta" />
              @if (!name().trim()) { <span class="mt-1 block text-[11.5px] text-red-700">Pflichtfeld.</span> }
            </label>
            <fieldset>
              <legend class="mb-1 text-[12px] font-medium text-zinc-700">Farbe</legend>
              <div class="flex gap-1">
                @for (p of palette; track p.color; let i = $index) {
                  <label class="grid size-8 cursor-pointer place-items-center rounded-md border has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-zinc-900" [class]="colorIdx() === i ? 'border-zinc-900' : 'border-zinc-200'" [title]="p.label">
                    <input type="radio" class="sr-only" name="color" [value]="i" [checked]="colorIdx() === i" (change)="colorIdx.set(i)" [attr.aria-label]="p.label" />
                    <span class="size-4 rounded-sm" [style.background-color]="p.color"></span>
                  </label>
                }
              </div>
            </fieldset>
          </div>

          <fieldset>
            <legend class="mb-1 text-[12px] font-medium text-zinc-700">Verbindungsart</legend>
            <div class="grid gap-1.5 sm:grid-cols-2">
              @for (o of modes; track o.id) {
                <label class="flex cursor-pointer gap-2 rounded-md border p-2.5 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-zinc-900" [class]="mode() === o.id ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-200 hover:bg-zinc-50'">
                  <input type="radio" class="mt-0.5 size-4 accent-zinc-900" name="mode" [value]="o.id" [checked]="mode() === o.id" (change)="mode.set(o.id)" />
                  <span><span class="block font-medium">{{ o.label }}</span><span class="block text-[12px] text-zinc-600">{{ o.hint }}</span></span>
                </label>
              }
            </div>
          </fieldset>

          @if (mode() === 'direkt') {
            <label class="block">
              <span class="mb-1 block text-[12px] font-medium text-zinc-700">Adresse des Agents <span class="text-red-600" aria-hidden="true">*</span></span>
              <input class="h-8 w-full rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" name="address" [ngModel]="address()" (ngModelChange)="address.set($event)" placeholder="delta.example.com:3553" />
              <span class="mt-1 block text-[11.5px] text-zinc-500">Der Hub verbindet sich zu diesem Port. Nur im lokalen Netz freigeben.</span>
            </label>
          } @else {
            <div class="rounded-md border border-zinc-200 bg-zinc-50 p-2.5 text-[12.5px]">
              <div class="flex items-center gap-1.5 font-medium"><cx-icon name="cloud" [size]="14" />Hub: https://hub.example.com</div>
              <p class="mt-0.5 text-zinc-600">Der Agent baut die Verbindung ausgehend auf – kein öffentlicher Agent-Port nötig. Token in der Demo: <span class="font-mono">&lt;DEMO-TOKEN&gt;</span></p>
            </div>
          }

          <div class="grid gap-3 sm:grid-cols-2">
            <label class="block">
              <span class="mb-1 block text-[12px] font-medium text-zinc-700">Projektverzeichnis</span>
              <input class="h-8 w-full rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" name="projectDir" [ngModel]="projectDir()" (ngModelChange)="projectDir.set($event)" />
              <span class="mt-1 block text-[11.5px] text-zinc-500">Hier liegen Ihre Stacks (compose.yaml, .env, Bind-Mounts).</span>
            </label>
            <label class="block">
              <span class="mb-1 block text-[12px] font-medium text-zinc-700">Installationsverzeichnis</span>
              <input class="h-8 w-full rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" name="installDir" [ngModel]="installDir()" (ngModelChange)="installDir.set($event)" />
              <span class="mt-1 block text-[11.5px] text-zinc-500">Nur Agent-Konfiguration und -Daten. Nicht mit dem Projektverzeichnis verwechseln.</span>
            </label>
          </div>

          <div class="rounded-md border border-zinc-200">
            <button type="button" class="flex w-full items-center gap-2 px-2.5 py-2 text-left text-[12.5px] font-medium" [attr.aria-expanded]="advanced()" aria-controls="cx-host-adv" (click)="advanced.set(!advanced())">
              <cx-icon [name]="advanced() ? 'chevronDown' : 'chevronRight'" [size]="14" />Erweitert: Dateirechte
            </button>
            @if (advanced()) {
              <div id="cx-host-adv" class="space-y-2 border-t border-zinc-100 p-2.5">
                <div class="grid grid-cols-2 gap-2">
                  <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">PUID (optional)</span><input class="h-8 w-full rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" inputmode="numeric" name="puid" [ngModel]="puid()" (ngModelChange)="puid.set($event)" placeholder="automatisch" /></label>
                  <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">PGID (optional)</span><input class="h-8 w-full rounded-md border border-zinc-300 px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" inputmode="numeric" name="pgid" [ngModel]="pgid()" (ngModelChange)="pgid.set($event)" placeholder="automatisch" /></label>
                </div>
                <p class="text-[11.5px] text-zinc-600">Ohne Angabe prüft der Installer die Verzeichnisrechte und schlägt UID/GID vor. Gilt nur für Dateien, auch im Compose-Download.</p>
                <p class="flex gap-1.5 text-[11.5px] text-zinc-600"><cx-icon name="info" [size]="13" class="mt-px" />Docker-Socket-Gruppe wird automatisch erkannt (group_add) und ist unabhängig von PUID/PGID.</p>
              </div>
            }
          </div>

          <div class="rounded-md border border-zinc-200 p-2.5">
            <div class="flex items-center gap-2">
              <span class="text-[12.5px] font-medium">Rechte & Verbindung</span>
              <button z-button zType="outline" zSize="xs" type="button" class="ml-auto" [zLoading]="checkState() === 'running'" (click)="runCheck()">Prüfen (simuliert)</button>
            </div>
            @if (checkState() !== 'idle') {
              <ul class="mt-2 space-y-1 text-[12.5px]" aria-live="polite">
                @for (c of checks(); track c.label; let i = $index) {
                  <li class="flex items-center gap-2">
                    @if (i < checkStep()) { <cx-icon name="checkCircle" [size]="14" class="text-emerald-600" /> } @else if (i === checkStep() && checkState() === 'running') { <span class="size-3.5 rounded-full border-2 border-zinc-300 border-t-zinc-800 motion-safe:animate-spin"></span> } @else { <span class="size-3.5 rounded-full border-2 border-zinc-200"></span> }
                    <span [class]="i < checkStep() ? 'text-zinc-900' : 'text-zinc-500'">{{ c.label }}</span>
                    @if (i < checkStep()) { <span class="ml-auto font-mono text-[11.5px] text-zinc-500">{{ c.result }}</span> }
                  </li>
                }
              </ul>
            }
          </div>
        </form>

        <div class="min-w-0">
          <div role="tablist" aria-label="Installationsart" class="mb-2 flex gap-1 rounded-md bg-zinc-100 p-0.5">
            @for (t of outTabs; track t.id) {
              <button type="button" role="tab" class="h-7 flex-1 rounded text-[12.5px] font-medium" [class]="outTab() === t.id ? 'bg-white shadow-sm' : 'text-zinc-600'" [attr.aria-selected]="outTab() === t.id" (click)="outTab.set(t.id)">{{ t.label }}</button>
            }
          </div>
          @if (outTab() === 'cmd') {
            <p class="mb-1.5 text-[12px] text-zinc-600">Auf dem Zielhost ausführen. Der Installer prüft Rechte und schreibt die Agent-Compose nach {{ installDir() }}.</p>
            <pre class="whitespace-pre-wrap break-all rounded-md bg-[#0c0c0f] p-3 font-mono text-[11.5px] leading-5 text-[#e4e4e7]">{{ installCmd() }}</pre>
            <div class="mt-2 flex gap-1.5">
              <button z-button zSize="sm" type="button" (click)="copy(installCmd())"><cx-icon name="copy" [size]="13" />Befehl kopieren</button>
            </div>
          } @else {
            <p class="mb-1.5 text-[12px] text-zinc-600">Alternative: Compose herunterladen und selbst starten.</p>
            <pre class="max-h-[420px] overflow-auto rounded-md bg-[#0c0c0f] p-3 font-mono text-[11.5px] leading-5 text-[#e4e4e7]">{{ composeText() }}</pre>
            <div class="mt-2 flex gap-1.5">
              <button z-button zSize="sm" type="button" (click)="download()"><cx-icon name="download" [size]="13" />compose.yaml herunterladen</button>
              <button z-button zType="outline" zSize="sm" type="button" (click)="copy(composeText())"><cx-icon name="copy" [size]="13" />Kopieren</button>
            </div>
          }
        </div>
      </div>
      <div cx-footer class="flex gap-2">
        <button z-button zType="ghost" zSize="sm" type="button" (click)="addOpen.set(false)">Abbrechen</button>
        <button z-button zSize="sm" type="submit" form="cx-host-form" [zDisabled]="!canCreate()"><cx-icon name="plus" [size]="13" />Host anlegen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxHosts {
  protected readonly store = inject(CxStore);
  private timer: ReturnType<typeof setInterval> | null = null;

  protected readonly palette = HOST_PALETTE;
  protected readonly addOpen = signal(false);
  protected readonly name = signal('');
  protected readonly colorIdx = signal(3);
  protected readonly mode = signal<ConnectionMode>('direkt');
  protected readonly address = signal('');
  protected readonly projectDir = signal('/opt/stacks');
  protected readonly installDir = signal('/opt/docklet-agent');
  protected readonly advanced = signal(false);
  protected readonly puid = signal('');
  protected readonly pgid = signal('');
  protected readonly checkState = signal<CheckState>('idle');
  protected readonly checkStep = signal(0);
  protected readonly outTab = signal<'cmd' | 'compose'>('cmd');

  protected readonly modes: { id: ConnectionMode; label: string; hint: string }[] = [
    { id: 'direkt', label: 'Direkt (Standard)', hint: 'Hub verbindet sich zum Agent im lokalen Netz.' },
    { id: 'edge', label: 'Edge', hint: 'Agent verbindet sich ausgehend zum Hub, ohne öffentlichen Port.' },
  ];
  protected readonly outTabs: { id: 'cmd' | 'compose'; label: string }[] = [
    { id: 'cmd', label: 'Installer-Befehl' },
    { id: 'compose', label: 'Compose-Vorschau' },
  ];

  constructor() {
    inject(DestroyRef).onDestroy(() => this.stopTimer());
  }

  protected readonly online = computed(() => this.store.hosts().filter((h) => h.status === 'online').length);

  protected readonly slug = computed(() => this.name().trim().toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-|-$/g, '') || 'neuer-host');

  protected readonly canCreate = computed(() => !!this.name().trim() && (this.mode() === 'edge' || !!this.address().trim()));

  protected readonly checks = computed(() => [
    { label: this.mode() === 'edge' ? 'Hub erreichbar (ausgehend)' : 'Agent-Port erreichbar', result: this.mode() === 'edge' ? 'hub.example.com:443' : this.address() || '–' },
    { label: 'Docker-Socket-Gruppe erkannt', result: 'GID 998' },
    { label: 'Projektverzeichnis beschreibbar', result: this.puid() ? `UID ${this.puid()}` : 'UID 1000 vorgeschlagen' },
    { label: 'Installationsverzeichnis anlegbar', result: this.installDir() },
  ]);

  protected readonly installCmd = computed(() => {
    const parts = [
      'curl -fsSL https://get.example.com/docklet-agent.sh | sudo sh -s --',
      `--name ${this.slug()}`,
      `--mode ${this.mode() === 'edge' ? 'edge' : 'direct'}`,
      `--install-dir ${this.installDir()}`,
      `--project-dir ${this.projectDir()}`,
    ];
    if (this.mode() === 'edge') parts.push('--hub https://hub.example.com', '--token <DEMO-TOKEN>');
    if (this.puid()) parts.push(`--puid ${this.puid()}`);
    if (this.pgid()) parts.push(`--pgid ${this.pgid()}`);
    return parts.join(' \\\n    ');
  });

  protected readonly composeText = computed(() => {
    const edge = this.mode() === 'edge';
    const lines = [
      '# Docklet-Agent – generiert im Design Lab (Demo)',
      'name: docklet-agent',
      'services:',
      '  agent:',
      '    image: docklet/agent:0.9.2',
      '    container_name: docklet-agent',
      '    restart: unless-stopped',
      '    environment:',
      `      AGENT_NAME: ${this.slug()}`,
      `      AGENT_MODE: ${edge ? 'edge' : 'direct'}`,
      `      PROJECT_DIR: ${this.projectDir()}`,
    ];
    if (edge) lines.push('      HUB_URL: https://hub.example.com', '      AGENT_TOKEN: "<DEMO-TOKEN>"');
    if (this.puid()) lines.push(`      PUID: "${this.puid()}"`);
    if (this.pgid()) lines.push(`      PGID: "${this.pgid()}"`);
    if (!edge) lines.push('    ports:', '      - "3553:3553"');
    lines.push(
      '    group_add:',
      '      - "${DOCKER_GID}"  # Socket-Gruppe, vom Installer erkannt',
      '    volumes:',
      '      - /var/run/docker.sock:/var/run/docker.sock',
      `      - ${this.installDir()}/data:/data`,
      `      - ${this.projectDir()}:${this.projectDir()}`,
    );
    return lines.join('\n') + '\n';
  });

  protected tintOf(color: string): string {
    return tint(color, 16);
  }

  protected containerCount(hostId: string): number {
    return this.store.allServices().filter((i) => i.hostId === hostId).length;
  }

  protected filterTo(id: string): void {
    this.store.hostFilter.set([id]);
    this.store.go('stacks');
  }

  protected check(h: Host): void {
    this.store.runAction({ title: `Verbindung ${h.name} prüfen`, hostId: h.id, steps: ['Handshake', 'Docker-API', 'Rechte Projektverzeichnis'] });
  }

  protected reconnect(h: Host): void {
    this.store.runAction({
      title: `${h.name} neu verbinden`,
      hostId: h.id,
      steps: ['Edge-Tunnel anfordern', 'Antwort des Agents abwarten', 'Status synchronisieren'],
      failAt: 2,
      failMessage: `Edge-Agent auf ${h.name} antwortet nicht (zuletzt ${h.lastSeen}). Bitte Host und Netzwerk prüfen.`,
    });
  }

  protected openAdd(): void {
    this.name.set('');
    this.address.set('');
    this.mode.set('direkt');
    this.checkState.set('idle');
    this.checkStep.set(0);
    this.addOpen.set(true);
  }

  protected runCheck(): void {
    this.stopTimer();
    this.checkState.set('running');
    this.checkStep.set(0);
    this.timer = setInterval(() => {
      this.checkStep.update((s) => s + 1);
      if (this.checkStep() >= this.checks().length) {
        this.checkState.set('ok');
        this.stopTimer();
      }
    }, 650);
  }

  private stopTimer(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  protected copy(text: string): void {
    const done = () => this.store.notify('In die Zwischenablage kopiert.');
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).then(done, () => this.store.notify('Kopieren nicht möglich – bitte Text markieren.'));
    } else {
      this.store.notify('Kopieren nicht möglich – bitte Text markieren.');
    }
  }

  protected download(): void {
    const blob = new Blob([this.composeText()], { type: 'application/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `docklet-agent-${this.slug()}.compose.yaml`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    this.store.notify('compose.yaml lokal erzeugt und heruntergeladen.');
  }

  protected create(): void {
    if (!this.canCreate()) return;
    const p = HOST_PALETTE[this.colorIdx()];
    const id = `${this.slug()}-${Date.now().toString(36)}`;
    const host: Host = {
      id,
      name: this.name().trim(),
      color: p.color,
      soft: p.soft,
      status: 'prüfung',
      cpu: 0,
      mem: 0,
      disk: 18,
      address: this.mode() === 'edge' ? 'Edge · hub.example.com' : this.address().trim(),
      mode: this.mode(),
      docker: '28.3.1',
      projectDir: this.projectDir(),
      installDir: this.installDir(),
      lastSeen: '–',
      cpuHistory: Array.from({ length: 24 }, () => 0),
      memGb: 16,
      cores: 4,
    };
    this.addOpen.set(false);
    this.store.addHost(host);
  }
}
