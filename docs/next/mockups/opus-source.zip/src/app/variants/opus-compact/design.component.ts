// Docklet Design Lab – Variante opus-compact (Richtung „compact“), Überarbeitung 2
// Docklets kompakte Dichte und klare Hostfarben; Dialoge, Icons, Statusbadges, Tabellen, Projektseite
// und Editor-Arbeitsbereich eng am Arcane-Original. Alle Daten synthetisch, alle Aktionen simuliert.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import type { PageId } from './data';
import { CxIcon, type IconName } from './icon';
import { CxStore } from './store';
import { CxHubSettings } from './settings-state';
import { CxActionCenter } from './action-center';
import { CxToasts } from './toasts';
import { CxUserMenu } from './user-menu';
import { CxDashboard } from './dashboard';
import { CxStacks } from './stacks';
import { CxStackPage } from './stack-page';
import { CxContainers } from './containers';
import { CxHosts } from './hosts';
import { CxNetworks } from './networks';
import { CxFiles, CxImages } from './resources';
import { CxSecurity } from './security';
import { CxSettings } from './settings';
import { CxProfile } from './profile';
import { CxPreview } from './preview';

interface NavItem {
  id: PageId;
  label: string;
  icon: IconName;
  hint?: string;
}

const NAV: { group: string; note?: string; items: NavItem[] }[] = [
  {
    group: 'Betrieb',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
      { id: 'stacks', label: 'Stacks', icon: 'layers' },
      { id: 'containers', label: 'Container', icon: 'box' },
      { id: 'hosts', label: 'Hosts', icon: 'server' },
      { id: 'security', label: 'Sicherheit', icon: 'shield' },
    ],
  },
  {
    group: 'Ressourcen',
    note: 'experimentell',
    items: [
      { id: 'networks', label: 'Netzwerke', icon: 'network' },
      { id: 'files', label: 'Volumes & Dateien', icon: 'database' },
      { id: 'images', label: 'Images', icon: 'archive' },
    ],
  },
  {
    group: 'Vorschau',
    items: [{ id: 'preview', label: 'Proxy & Games', icon: 'eye', hint: 'Vorschau' }],
  },
];

const TITLES: Record<PageId, string> = {
  dashboard: 'Dashboard',
  stacks: 'Stacks',
  stack: 'Stack',
  containers: 'Container',
  hosts: 'Hosts',
  networks: 'Netzwerke',
  files: 'Volumes & Dateien',
  images: 'Images',
  security: 'Sicherheit',
  settings: 'Hub-Einstellungen',
  profile: 'Profil',
  preview: 'Proxy & Games (Vorschau)',
};

@Component({
  selector: 'docklet-opus-compact',
  imports: [
    ZardButtonComponent, CxIcon, CxActionCenter, CxToasts, CxUserMenu, CxDashboard, CxStacks, CxStackPage, CxContainers,
    CxHosts, CxNetworks, CxFiles, CxImages, CxSecurity, CxSettings, CxProfile, CxPreview,
  ],
  providers: [CxStore, CxHubSettings],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: `
    :host { display: block; }
    .cx-root { background: oklch(.972 .003 286); }
    .cx-scroll { scrollbar-width: thin; }
    .cx-dark {
      color-scheme: dark; background: oklch(.165 .005 286);
      --color-white: oklch(.205 .006 286); --color-zinc-50: oklch(.232 .006 286); --color-zinc-100: oklch(.262 .006 286);
      --color-zinc-200: oklch(.31 .007 286); --color-zinc-300: oklch(.39 .008 286); --color-zinc-400: oklch(.52 .012 286);
      --color-zinc-500: oklch(.65 .014 286); --color-zinc-600: oklch(.74 .012 286); --color-zinc-700: oklch(.82 .008 286);
      --color-zinc-800: oklch(.88 .005 286); --color-zinc-900: oklch(.93 .003 286); --color-zinc-950: oklch(.97 .002 286);
      --color-emerald-50: oklch(.27 .04 163); --color-emerald-100: oklch(.31 .05 163); --color-emerald-200: oklch(.4 .07 163);
      --color-emerald-700: oklch(.78 .13 163); --color-emerald-800: oklch(.83 .11 163); --color-emerald-900: oklch(.88 .08 163);
      --color-red-50: oklch(.27 .05 25); --color-red-100: oklch(.31 .07 25); --color-red-200: oklch(.4 .1 25);
      --color-red-700: oklch(.74 .15 25); --color-red-800: oklch(.8 .12 25); --color-red-900: oklch(.86 .09 25);
      --color-amber-50: oklch(.28 .045 75); --color-amber-100: oklch(.32 .06 75); --color-amber-200: oklch(.41 .08 75);
      --color-amber-700: oklch(.8 .13 75); --color-amber-800: oklch(.85 .11 75); --color-amber-900: oklch(.89 .08 75); --color-amber-950: oklch(.93 .05 75);
      --color-sky-50: oklch(.27 .04 237); --color-sky-100: oklch(.31 .05 237); --color-sky-200: oklch(.4 .07 237);
      --color-sky-700: oklch(.78 .11 237); --color-sky-800: oklch(.84 .09 237); --color-sky-900: oklch(.88 .07 237); --color-sky-950: oklch(.92 .05 237);
      --color-indigo-50: oklch(.27 .05 277); --color-indigo-700: oklch(.78 .12 277); --color-indigo-800: oklch(.83 .1 277);
      --color-orange-50: oklch(.28 .05 47); --color-orange-700: oklch(.78 .13 47); --color-orange-800: oklch(.83 .11 47);
    }
    @media (prefers-reduced-motion: reduce) {
      .cx-root * { transition-duration: 0ms !important; animation-duration: 0ms !important; }
    }
  `,
  template: `
    <div class="cx-root flex min-h-dvh text-[13.5px] leading-5 text-zinc-900 antialiased" [class.dark]="store.isDark()" [class.cx-dark]="store.isDark()">
      <a href="#cx-main" class="sr-only z-50 rounded bg-white px-3 py-2 focus:not-sr-only focus:fixed focus:left-2 focus:top-2">Zum Inhalt springen</a>

      @if (menuOpen()) {
        <div class="fixed inset-0 z-40 bg-black/40 lg:hidden" (click)="menuOpen.set(false)" aria-hidden="true"></div>
      }
      <!-- Seitenleiste: bewusst in beiden Themes dunkel (Docklet-Kompaktstil) -->
      <aside
        class="fixed inset-y-0 left-0 z-40 w-60 flex-col border-r border-[#27272a] bg-[#0b0b0e] text-[#d4d4d8] lg:sticky lg:top-0 lg:flex lg:h-dvh"
        [class]="menuOpen() ? 'flex' : 'hidden'"
        aria-label="Hauptnavigation"
        (keydown.escape)="menuOpen.set(false)"
      >
        <div class="flex h-12 items-center gap-2 border-b border-[#27272a] px-3">
          <span class="grid size-7 place-items-center rounded-md bg-white text-[#0b0b0e]">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M3 13h18l-2 6H5z" /><path d="M6 13V9h4v4" /><path d="M10 13V6h4v7" /><path d="M14 13V9h4v4" />
            </svg>
          </span>
          <div class="min-w-0 leading-tight">
            <div class="text-[13.5px] font-semibold text-white">Docklet</div>
            <div class="text-[11px] text-[#a1a1aa]">Design Lab · compact</div>
          </div>
          <button type="button" class="ml-auto grid size-8 place-items-center rounded-md text-[#a1a1aa] hover:bg-[#27272a] hover:text-white lg:hidden" aria-label="Navigation schließen" (click)="menuOpen.set(false)">
            <cx-icon name="x" />
          </button>
        </div>

        <nav class="cx-scroll flex-1 overflow-y-auto px-2 py-3">
          @for (g of nav; track g.group) {
            <div class="mb-3.5">
              <div class="mb-1 flex items-baseline justify-between px-2">
                <span class="text-[10.5px] font-semibold uppercase tracking-wider text-[#71717a]">{{ g.group }}</span>
                @if (g.note) { <span class="text-[10px] text-[#71717a]">{{ g.note }}</span> }
              </div>
              <ul class="space-y-0.5">
                @for (item of g.items; track item.id) {
                  <li>
                    <button
                      type="button"
                      class="flex h-8 w-full items-center gap-2.5 rounded-md px-2 text-left text-[13px] outline-none transition-colors focus-visible:ring-2 focus-visible:ring-sky-400"
                      [class]="isActive(item.id) ? 'bg-[#27272a] font-medium text-white' : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-[#f4f4f5]'"
                      [attr.aria-current]="isActive(item.id) ? 'page' : null"
                      (click)="go(item.id)"
                    >
                      <cx-icon [name]="item.icon" [size]="15" />
                      <span class="flex-1 truncate">{{ item.label }}</span>
                      @if (item.id === 'stacks' && store.kpis().problems > 0) {
                        <span class="rounded bg-red-500/20 px-1.5 text-[10.5px] font-semibold text-[#fca5a5]">{{ store.kpis().problems }}</span>
                      }
                      @if (item.hint) { <span class="rounded border border-[#3f3f46] px-1 text-[10px] text-[#a1a1aa]">{{ item.hint }}</span> }
                    </button>
                  </li>
                }
              </ul>
            </div>
          }

          <!-- Globaler Hostfilter -->
          <div class="mb-1 flex items-baseline justify-between px-2">
            <span id="cx-hf-label" class="text-[10.5px] font-semibold uppercase tracking-wider text-[#71717a]">Hostfilter</span>
            <span class="text-[10px] text-[#71717a]">gilt überall</span>
          </div>
          <ul class="space-y-0.5" aria-labelledby="cx-hf-label">
            <li>
              <button type="button" class="flex h-8 w-full items-center gap-2.5 rounded-md px-2 text-left text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-sky-400" [class]="store.filterActive() ? 'text-[#a1a1aa] hover:bg-[#18181b]' : 'bg-[#18181b] font-medium text-white'" [attr.aria-pressed]="!store.filterActive()" (click)="store.clearFilter()">
                <span class="grid size-3.5 place-items-center rounded-[3px] border" [class]="store.filterActive() ? 'border-[#52525b]' : 'border-white bg-white text-[#0b0b0e]'">@if (!store.filterActive()) { <cx-icon name="check" [size]="10" [stroke]="3" /> }</span>
                <span class="flex-1">Alle Hosts</span>
                <span class="font-mono text-[11px] text-[#71717a]">{{ store.hosts().length }}</span>
              </button>
            </li>
            @for (h of store.hosts(); track h.id) {
              @let on = store.hostFilter().includes(h.id);
              <li>
                <button type="button" class="flex h-8 w-full items-center gap-2.5 rounded-md px-2 text-left text-[13px] text-[#d4d4d8] outline-none hover:bg-[#18181b] focus-visible:ring-2 focus-visible:ring-sky-400" [attr.aria-pressed]="on" [title]="(on ? 'Aus Filter entfernen: ' : 'Zum Filter hinzufügen: ') + h.name" (click)="store.toggleHost(h.id)">
                  <span class="grid size-3.5 place-items-center rounded-[3px] border-2" [style.border-color]="h.color" [style.background-color]="on ? h.color : 'transparent'">@if (on) { <cx-icon name="check" [size]="9" [stroke]="3.5" class="text-white" /> }</span>
                  <span class="flex-1 truncate" [class.font-medium]="on">{{ h.name }}</span>
                  @if (h.status === 'online') {
                    <span class="font-mono text-[11px] tabular-nums text-[#71717a]">{{ h.cpu }}%</span>
                  } @else {
                    <span class="text-[11px] text-[#71717a]">{{ h.status }}</span>
                  }
                </button>
              </li>
            }
          </ul>
        </nav>

        <div class="border-t border-[#27272a] p-2">
          <cx-user-menu (navigate)="go($event)" />
        </div>
      </aside>

      <!-- Hauptbereich -->
      <div class="flex min-w-0 flex-1 flex-col">
        <header class="sticky top-0 z-30 flex h-12 items-center gap-2 border-b border-zinc-200 bg-white/95 px-3 backdrop-blur sm:px-4">
          <button type="button" class="grid size-8 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100 lg:hidden" aria-label="Navigation öffnen" (click)="menuOpen.set(true)">
            <cx-icon name="menu" />
          </button>
          <nav aria-label="Brotkrumen" class="flex min-w-0 items-center gap-1.5">
            @if (store.page() === 'stack') {
              <button type="button" class="hidden text-[13px] text-zinc-500 hover:text-zinc-900 sm:inline" (click)="go('stacks')">Stacks</button>
              <cx-icon name="chevronRight" [size]="13" class="hidden text-zinc-400 sm:inline-flex" />
            }
            <h1 class="truncate text-[15px] font-semibold">{{ title() }}</h1>
          </nav>

          @if (store.filterActive()) {
            <div class="ml-2 hidden min-w-0 items-center gap-1 md:flex" aria-label="Aktiver Hostfilter">
              <span class="text-[11.5px] text-zinc-500">Filter:</span>
              @for (id of store.hostFilter(); track id) {
                @let h = store.host(id);
                <button type="button" class="inline-flex h-6 items-center gap-1 rounded-md border border-zinc-200 px-1.5 text-[11.5px] font-medium hover:bg-zinc-50" [attr.aria-label]="h.name + ' aus Filter entfernen'" (click)="store.toggleHost(id)">
                  <span class="size-2 rounded-sm" [style.background-color]="h.color"></span>{{ h.name }}<cx-icon name="x" [size]="11" class="text-zinc-400" />
                </button>
              }
              <button type="button" class="text-[11.5px] font-medium text-zinc-600 underline underline-offset-2 hover:text-zinc-900" (click)="store.clearFilter()">Alle Hosts</button>
            </div>
          }

          <div class="ml-auto flex items-center gap-1.5">
            <button
              type="button"
              class="relative inline-flex h-8 items-center gap-1.5 rounded-md border border-zinc-200 bg-white px-2 text-[12.5px] font-medium text-zinc-700 outline-none hover:bg-zinc-50 focus-visible:ring-2 focus-visible:ring-zinc-900"
              aria-haspopup="dialog"
              [attr.aria-expanded]="store.actionCenterOpen()"
              title="Aktionszentrum: Details und Verlauf"
              (click)="store.showActionDetails(null)"
            >
              <cx-icon name="activity" [size]="15" />
              <span class="hidden sm:inline">Aktivität</span>
              @if (store.runningActions() > 0) {
                <span class="grid h-4 min-w-4 place-items-center rounded-full bg-sky-600 px-1 text-[10px] font-semibold text-white">{{ store.runningActions() }}</span>
              }
            </button>
            <button z-button zSize="sm" type="button" (click)="newStack()">
              <cx-icon name="plus" [size]="14" />
              <span class="hidden sm:inline">Neuer Stack</span>
            </button>
          </div>
        </header>

        @if (store.filterActive()) {
          <div class="flex items-center gap-1.5 overflow-x-auto border-b border-zinc-200 bg-white px-3 py-1.5 text-[11.5px] md:hidden">
            <span class="text-zinc-500">Filter:</span>
            @for (id of store.hostFilter(); track id) {
              <span class="inline-flex items-center gap-1 rounded-md border border-zinc-200 px-1.5 font-medium"><span class="size-2 rounded-sm" [style.background-color]="store.host(id).color"></span>{{ store.host(id).name }}</span>
            }
            <button type="button" class="ml-auto shrink-0 font-medium underline" (click)="store.clearFilter()">Zurücksetzen</button>
          </div>
        }

        <main id="cx-main" class="min-w-0 flex-1 p-3 sm:p-4 lg:p-5" tabindex="-1">
          @switch (store.page()) {
            @case ('dashboard') { <cx-dashboard /> }
            @case ('stacks') { <cx-stacks /> }
            @case ('stack') { <cx-stack-page /> }
            @case ('containers') { <cx-containers /> }
            @case ('hosts') { <cx-hosts /> }
            @case ('networks') { <cx-networks /> }
            @case ('files') { <cx-files /> }
            @case ('images') { <cx-images /> }
            @case ('security') { <cx-security /> }
            @case ('settings') { <cx-settings /> }
            @case ('profile') { <cx-profile /> }
            @case ('preview') { <cx-preview /> }
          }
        </main>
      </div>

      <cx-action-center />
      <cx-toasts />
    </div>
  `,
})
export class DesignComponent {
  protected readonly store = inject(CxStore);
  protected readonly nav = NAV;
  protected readonly menuOpen = signal(false);

  protected readonly title = computed(() => {
    const p = this.store.page();
    if (p === 'stack') return this.store.currentStack()?.name ?? 'Neuer Stack (Entwurf)';
    return TITLES[p];
  });

  protected isActive(id: PageId): boolean {
    const p = this.store.page();
    return p === id || (id === 'stacks' && p === 'stack');
  }

  protected go(id: PageId): void {
    this.store.go(id);
    this.menuOpen.set(false);
  }

  protected newStack(): void {
    this.store.newStack();
    this.menuOpen.set(false);
  }
}
