// Docklet Design Lab – opus-compact · Dashboard
// Getrennt von Stacks: dynamische Ressourcenanzeigen je Host (nach Arcane metric-ring/stat-card, mehrere Hosts
// gemeinsam), darunter wählbare und sortierbare Widgets in einheitlicher Größe. Live-Werte sind simuliert.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { WIDGETS, type EventLevel, type Host, type WidgetDef, type WidgetId } from './data';
import { CxIcon, type IconName } from './icon';
import { CxStore } from './store';
import { CxDialog, CxHost, CxMeter, CxRing, CxStatus } from './ui';

const LEVEL_ICON: Record<EventLevel, { icon: IconName; cls: string }> = {
  info: { icon: 'info', cls: 'text-sky-600' },
  'warnung': { icon: 'alert', cls: 'text-amber-600' },
  'fehler': { icon: 'xCircle', cls: 'text-red-600' },
  erfolg: { icon: 'checkCircle', cls: 'text-emerald-600' },
};

@Component({
  selector: 'cx-dashboard',
  imports: [ZardButtonComponent, CxIcon, CxDialog, CxHost, CxMeter, CxRing, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Hosts: dynamische Ressourcenanzeigen -->
    <section class="mb-4" aria-labelledby="dh-title">
      <div class="mb-2 flex flex-wrap items-center gap-2">
        <h2 id="dh-title" class="text-[13px] font-semibold">Hosts</h2>
        <span class="text-[12px] text-zinc-500">{{ store.filterActive() ? 'gefiltert' : 'alle Hosts gemeinsam' }}</span>
        <button type="button" class="ml-auto inline-flex h-7 items-center gap-1.5 rounded-md border border-zinc-200 bg-white px-2 text-[12px] font-medium" [attr.aria-pressed]="store.live()" (click)="store.live.set(!store.live())">
          <span class="size-2 rounded-full" [class]="store.live() ? 'bg-emerald-500 motion-safe:animate-pulse' : 'bg-zinc-300'"></span>{{ store.live() ? 'Live (simuliert)' : 'Pausiert' }}
        </button>
      </div>
      <div class="grid gap-3 md:grid-cols-2 2xl:grid-cols-3">
        @for (h of hosts(); track h.id) {
          @let off = h.status !== 'online';
          <article class="overflow-hidden rounded-lg border border-zinc-200 bg-white" [attr.aria-labelledby]="'dh-' + h.id">
            <div class="h-1" [style.background-color]="h.color"></div>
            <div class="p-3">
              <div class="flex items-center gap-2">
                <h3 [id]="'dh-' + h.id" class="text-[14px] font-semibold">{{ h.name }}</h3>
                <cx-status [kind]="h.status" />
                <span class="text-[11.5px] text-zinc-500">{{ h.mode === 'edge' ? 'Edge' : 'Direkt' }} · Docker {{ h.docker }}</span>
                <button type="button" class="ml-auto text-[11.5px] font-medium text-zinc-600 underline-offset-2 hover:underline" (click)="store.hostFilter.set([h.id]); store.go('stacks')">Stacks</button>
              </div>
              <div class="mt-2 flex items-center justify-between gap-2">
                <cx-ring [value]="h.cpu" label="CPU" [color]="h.color" [disabled]="off" />
                <cx-ring [value]="h.mem" label="RAM" [color]="h.color" [disabled]="off" />
                <cx-ring [value]="h.disk" label="Speicher" color="#71717a" />
                <div class="min-w-0 flex-1 pl-1">
                  <svg viewBox="0 0 120 40" class="h-10 w-full" preserveAspectRatio="none" role="img" [attr.aria-label]="'CPU-Verlauf ' + h.name">
                    <polyline [attr.points]="spark(h.cpuHistory)" fill="none" [attr.stroke]="h.color" stroke-width="1.6" stroke-linejoin="round" vector-effect="non-scaling-stroke" [attr.stroke-dasharray]="off ? '3 3' : null" />
                  </svg>
                  <div class="mt-0.5 grid grid-cols-2 gap-x-2 text-[11px] text-zinc-500">
                    <span>{{ containers(h.id) }} Container</span><span class="text-right">{{ h.cores }} Kerne</span>
                    <span>{{ off ? 'zuletzt ' + h.lastSeen : ramUsed(h) }}</span><span class="text-right">{{ h.memGb }} GB RAM</span>
                  </div>
                </div>
              </div>
            </div>
          </article>
        } @empty {
          <p class="rounded-lg border border-dashed border-zinc-300 bg-white p-4 text-zinc-600">Keine Hosts im Filter.</p>
        }
      </div>
    </section>

    <div class="mb-2 flex flex-wrap items-center gap-2">
      <h2 class="text-[13px] font-semibold">Widgets</h2>
      <p class="text-[12px] text-zinc-500">Bedienung in <button type="button" class="font-medium text-zinc-800 underline underline-offset-2" (click)="store.go('stacks')">Stacks</button>.</p>
      <button z-button zType="outline" zSize="sm" class="ml-auto" type="button" (click)="customize.set(true)"><cx-icon name="sliders" [size]="14" />Widgets anpassen</button>
    </div>

    @if (active().length === 0) {
      <div class="grid place-items-center rounded-lg border border-dashed border-zinc-300 bg-white p-10 text-center text-zinc-600">
        Keine Widgets ausgewählt.
        <button type="button" class="mt-2 font-medium text-zinc-900 underline" (click)="customize.set(true)">Widgets auswählen</button>
      </div>
    }

    <div class="grid grid-cols-1 gap-3 md:grid-cols-2 2xl:grid-cols-3">
      @for (w of active(); track w.id) {
        <section class="flex h-[264px] flex-col rounded-lg border border-zinc-200 bg-white" [attr.aria-labelledby]="'w-' + w.id">
          <header class="flex h-10 shrink-0 items-center gap-2 border-b border-zinc-100 px-3">
            <h2 [id]="'w-' + w.id" class="text-[13px] font-semibold">{{ w.title }}</h2>
            @switch (w.id) {
              @case ('problems') { @if (store.problems().length) { <span class="rounded-md border border-red-500/25 bg-red-500/10 px-1.5 text-[11px] font-semibold text-red-700">{{ store.problems().length }}</span> } }
              @case ('updates') { @if (store.updates().length) { <span class="rounded-md border border-indigo-500/25 bg-indigo-500/10 px-1.5 text-[11px] font-semibold text-indigo-700">{{ store.updates().length }}</span> } }
            }
          </header>
          <div class="min-h-0 flex-1 overflow-y-auto p-3">
            @switch (w.id) {
              @case ('kpis') {
                <div class="grid h-full grid-cols-2 gap-2">
                  <button type="button" class="rounded-md border border-zinc-200 p-3 text-left hover:bg-zinc-50" (click)="store.go('containers')">
                    <div class="flex items-center gap-1.5 text-[12px] text-zinc-600"><cx-icon name="play" [size]="13" class="text-emerald-600" />Laufende Container</div>
                    <div class="mt-1 text-[26px] font-semibold tabular-nums leading-8">{{ store.kpis().running }}<span class="text-[14px] font-normal text-zinc-500"> / {{ store.kpis().total }}</span></div>
                  </button>
                  <button type="button" class="rounded-md border border-zinc-200 p-3 text-left hover:bg-zinc-50" (click)="store.go('stacks')">
                    <div class="flex items-center gap-1.5 text-[12px] text-zinc-600"><cx-icon name="update" [size]="13" class="text-indigo-600" />Updates</div>
                    <div class="mt-1 text-[26px] font-semibold tabular-nums leading-8">{{ store.kpis().updates }}</div>
                  </button>
                  <button type="button" class="rounded-md border p-3 text-left" [class]="store.kpis().problems ? 'border-red-500/30 bg-red-500/5 hover:bg-red-500/10' : 'border-zinc-200 hover:bg-zinc-50'" (click)="store.go('stacks')">
                    <div class="flex items-center gap-1.5 text-[12px] text-zinc-600"><cx-icon name="alert" [size]="13" class="text-red-600" />Probleme</div>
                    <div class="mt-1 text-[26px] font-semibold tabular-nums leading-8" [class]="store.kpis().problems ? 'text-red-700' : ''">{{ store.kpis().problems }}</div>
                  </button>
                  <button type="button" class="rounded-md border border-zinc-200 p-3 text-left hover:bg-zinc-50" (click)="store.go('hosts')">
                    <div class="flex items-center gap-1.5 text-[12px] text-zinc-600"><cx-icon name="server" [size]="13" />Hosts online</div>
                    <div class="mt-1 text-[26px] font-semibold tabular-nums leading-8">{{ store.kpis().hostsOnline }}<span class="text-[14px] font-normal text-zinc-500"> / {{ store.kpis().hostsTotal }}</span></div>
                  </button>
                </div>
              }
              @case ('problems') {
                @if (store.problems().length === 0 && offlineHosts().length === 0) {
                  <div class="grid h-full place-items-center text-center text-zinc-600"><div><cx-icon name="checkCircle" [size]="22" class="text-emerald-600" /><p class="mt-1">Keine Probleme.</p></div></div>
                }
                <ul class="space-y-2">
                  @for (p of store.problems(); track p.svc.id) {
                    <li class="rounded-md border border-red-500/25 bg-red-500/5 p-2.5">
                      <div class="flex flex-wrap items-center gap-2">
                        <span class="font-semibold">{{ stackName(p.stackId) }}/{{ p.svc.name }}</span>
                        <cx-host [name]="store.host(p.hostId).name" [color]="store.host(p.hostId).color" />
                        <cx-status [kind]="p.svc.state === 'exited' ? 'exited' : 'unhealthy'" />
                      </div>
                      <p class="mt-1 text-[12.5px] text-zinc-700">Healthcheck 3× fehlgeschlagen. Auto Heal: 2 von 3 Neustarts genutzt.</p>
                      <div class="mt-2 flex gap-1.5">
                        @if (p.stackId) {
                          <button z-button zType="outline" zSize="xs" type="button" (click)="store.openStack(p.stackId, 'logs')"><cx-icon name="terminal" [size]="12" />Logs</button>
                        }
                        <button z-button zType="outline" zSize="xs" type="button" (click)="store.restartService(p.stackId, p.svc.id, p.svc.name, p.hostId)"><cx-icon name="restart" [size]="12" />Neu starten</button>
                      </div>
                    </li>
                  }
                  @for (h of offlineHosts(); track h.id) {
                    <li class="flex items-center gap-2 rounded-md border border-zinc-200 p-2.5 text-[12.5px] text-zinc-700">
                      <cx-icon name="plug" [size]="14" class="text-zinc-500" />
                      <span><b>{{ h.name }}</b> ist getrennt (zuletzt {{ h.lastSeen }}). Zählt nicht als Containerproblem.</span>
                    </li>
                  }
                </ul>
              }
              @case ('hosts') {
                <ul class="divide-y divide-zinc-100">
                  @for (h of hosts(); track h.id) {
                    <li class="grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1 py-2 first:pt-0">
                      <cx-host [name]="h.name" [color]="h.color" />
                      <cx-status [kind]="h.status" />
                      <div class="col-span-2 grid grid-cols-[34px_1fr_38px] items-center gap-2 text-[11.5px] text-zinc-500">
                        <span>CPU</span><cx-meter [value]="h.cpu" [color]="h.color" [label]="'CPU ' + h.name" /><span class="text-right font-mono tabular-nums text-zinc-700">{{ h.status === 'online' ? h.cpu + '%' : '–' }}</span>
                      </div>
                    </li>
                  }
                </ul>
              }
              @case ('updates') {
                <ul class="space-y-1.5">
                  @for (u of store.updates(); track u.svc.id) {
                    <li class="flex items-center gap-2 rounded-md border border-zinc-200 px-2.5 py-1.5">
                      <cx-icon name="box" [size]="14" class="text-zinc-500" />
                      <div class="min-w-0 flex-1">
                        <div class="truncate font-medium">{{ u.svc.image }}</div>
                        <div class="font-mono text-[11.5px] text-zinc-600">{{ u.svc.tag }} → <span class="text-indigo-700">{{ u.svc.newTag }}</span></div>
                      </div>
                      <cx-host [name]="store.host(u.hostId).name" [color]="store.host(u.hostId).color" />
                    </li>
                  } @empty {
                    <li class="py-8 text-center text-zinc-600">Alle Images aktuell.</li>
                  }
                </ul>
                @if (updateStacks().length) {
                  <div class="mt-2 flex flex-wrap gap-1.5">
                    @for (s of updateStacks(); track s) {
                      <button z-button zSize="xs" type="button" (click)="store.installUpdates(s)"><cx-icon name="download" [size]="12" />{{ stackName(s) }} aktualisieren</button>
                    }
                  </div>
                }
              }
              @case ('cpu') {
                <svg viewBox="0 0 320 170" class="h-[176px] w-full" role="img" [attr.aria-label]="chartLabel()">
                  @for (g of grid; track g) {
                    <svg:line x1="28" [attr.y1]="150 - g * 1.3" x2="316" [attr.y2]="150 - g * 1.3" class="stroke-zinc-200" stroke-width="1" />
                    <svg:text x="22" [attr.y]="154 - g * 1.3" text-anchor="end" font-size="9" class="fill-zinc-500">{{ g }}</svg:text>
                  }
                  @for (h of hosts(); track h.id) {
                    <svg:polyline [attr.points]="line(h.cpuHistory)" fill="none" [attr.stroke]="h.color" stroke-width="2" stroke-linejoin="round" [attr.stroke-dasharray]="h.status === 'online' ? null : '4 3'" />
                  }
                  <text x="28" y="166" font-size="9" class="fill-zinc-500">älter</text>
                  <text x="316" y="166" font-size="9" class="fill-zinc-500" text-anchor="end">jetzt</text>
                </svg>
                <div class="flex flex-wrap gap-3 text-[11.5px] text-zinc-600">
                  @for (h of hosts(); track h.id) {
                    <span class="inline-flex items-center gap-1.5"><span class="h-0.5 w-3 rounded" [style.background-color]="h.color"></span>{{ h.name }} {{ h.status === 'online' ? h.cpu + '%' : '(getrennt)' }}</span>
                  }
                </div>
              }
              @case ('events') {
                <ul class="space-y-1.5">
                  @for (e of events(); track e.id) {
                    <li class="flex items-start gap-2 text-[12.5px]">
                      <cx-icon [name]="levelIcon[e.level].icon" [size]="14" [class]="'mt-0.5 ' + levelIcon[e.level].cls" />
                      <span class="w-10 shrink-0 font-mono text-[11.5px] text-zinc-500">{{ e.time }}</span>
                      <span class="mt-1.5 size-2 shrink-0 rounded-sm" [style.background-color]="store.host(e.hostId).color" [title]="store.host(e.hostId).name"></span>
                      <span class="min-w-0 flex-1 text-zinc-800">{{ e.text }}</span>
                    </li>
                  }
                </ul>
                <button type="button" class="mt-2 text-[12px] font-medium text-zinc-700 underline underline-offset-2" (click)="store.showActionDetails(null)">Verlauf im Aktionszentrum</button>
              }
              @case ('backups') {
                <ul class="divide-y divide-zinc-100">
                  @for (s of store.visibleStacks(); track s.id) {
                    <li class="flex items-center gap-2 py-2 first:pt-0">
                      <cx-icon name="archive" [size]="14" class="text-zinc-500" />
                      <div class="min-w-0 flex-1">
                        <div class="font-medium">{{ s.name }} <span class="font-normal text-zinc-500">· {{ s.backup.last }}</span></div>
                        <div class="truncate text-[11.5px] text-zinc-600">{{ s.backup.target }} · {{ s.backup.schedule }}</div>
                      </div>
                      <button z-button zType="ghost" zSize="xs" type="button" (click)="store.backupNow(s.id)">Jetzt</button>
                    </li>
                  }
                </ul>
              }
              @case ('scan') {
                @if (!store.scanEnabled()) {
                  <div class="flex h-full flex-col justify-center gap-2 text-zinc-700">
                    <p class="text-[12.5px]">Schwachstellenscans sind optional und getrennt von der Update-Erkennung.</p>
                    <button z-button zType="outline" zSize="sm" type="button" class="self-start" (click)="store.go('settings')"><cx-icon name="shield" [size]="14" />In Hub-Einstellungen aktivieren</button>
                  </div>
                } @else {
                  <div class="mb-2 grid grid-cols-4 gap-1.5 text-center">
                    @for (sv of sev(); track sv.label) {
                      <div class="rounded-md border p-1.5" [class]="sv.cls"><div class="text-[17px] font-semibold tabular-nums">{{ sv.n }}</div><div class="text-[10.5px]">{{ sv.label }}</div></div>
                    }
                  </div>
                  <p class="text-[12px] text-zinc-600">Letzter Scan {{ store.lastScan() }} · Zeitplan {{ store.scanSchedule() }}</p>
                  <div class="mt-2 flex gap-1.5">
                    <button z-button zType="outline" zSize="xs" type="button" (click)="store.runScan()"><cx-icon name="scan" [size]="12" />Jetzt scannen</button>
                    <button z-button zType="ghost" zSize="xs" type="button" (click)="store.go('security')">Zur Sicherheit</button>
                  </div>
                }
              }
              @case ('links') {
                <ul class="grid grid-cols-2 gap-2">
                  @for (l of links; track l.name) {
                    <li>
                      <button type="button" class="flex w-full items-center gap-2 rounded-md border border-zinc-200 p-2 text-left hover:bg-zinc-50" (click)="store.notify('Würde ' + l.url + ' öffnen (in der Demo deaktiviert)')">
                        <span class="grid size-8 place-items-center rounded-md text-white" [style.background-color]="store.host(l.host).color"><cx-icon [name]="l.icon" [size]="15" /></span>
                        <span class="min-w-0"><span class="block font-medium">{{ l.name }}</span><span class="block truncate text-[11.5px] text-zinc-500">{{ l.url }}</span></span>
                      </button>
                    </li>
                  }
                </ul>
              }
            }
          </div>
        </section>
      }
    </div>

    <cx-dialog [open]="customize()" heading="Dashboard anpassen" description="Widgets ein- oder ausblenden und Reihenfolge festlegen. Alle Widgets haben dieselbe Größe." icon="sliders" (closed)="customize.set(false)">
      <ol class="divide-y divide-zinc-100" aria-label="Widgets">
        @for (w of ordered(); track w.id) {
          <li class="flex items-center gap-3 px-4 py-2.5">
            <input type="checkbox" class="size-4 accent-zinc-900" [id]="'wc-' + w.id" [checked]="isActive(w.id)" (change)="store.toggleWidget(w.id)" />
            <label [for]="'wc-' + w.id" class="min-w-0 flex-1 cursor-pointer">
              <span class="block font-medium">{{ w.title }}</span>
              <span class="block text-[12px] text-zinc-600">{{ w.description }}</span>
            </label>
            @if (isActive(w.id)) {
              <span class="w-5 text-right font-mono text-[11.5px] text-zinc-500">{{ position(w.id) }}</span>
              <div class="flex gap-0.5">
                <button type="button" class="grid size-7 place-items-center rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-100 disabled:opacity-35" [disabled]="position(w.id) === 1" [attr.aria-label]="w.title + ' nach oben'" (click)="store.moveWidget(w.id, -1)"><cx-icon name="arrowUp" [size]="13" /></button>
                <button type="button" class="grid size-7 place-items-center rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-100 disabled:opacity-35" [disabled]="position(w.id) === store.widgets().length" [attr.aria-label]="w.title + ' nach unten'" (click)="store.moveWidget(w.id, 1)"><cx-icon name="arrowDown" [size]="13" /></button>
              </div>
            } @else {
              <span class="text-[11.5px] text-zinc-500">ausgeblendet</span>
            }
          </li>
        }
      </ol>
      <div cx-footer class="flex w-full items-center gap-2">
        <button z-button zType="ghost" zSize="sm" type="button" (click)="store.resetWidgets()">Standard wiederherstellen</button>
        <button z-button zSize="sm" type="button" class="ml-auto" (click)="customize.set(false)">Fertig</button>
      </div>
    </cx-dialog>
  `,
})
export class CxDashboard {
  protected readonly store = inject(CxStore);
  protected readonly customize = signal(false);
  protected readonly levelIcon = LEVEL_ICON;
  protected readonly grid = [0, 25, 50, 75, 100];

  protected readonly active = computed<WidgetDef[]>(() =>
    this.store.widgets().map((id) => WIDGETS.find((w) => w.id === id)).filter((w): w is WidgetDef => !!w),
  );

  protected readonly ordered = computed<WidgetDef[]>(() => [...this.active(), ...WIDGETS.filter((w) => !this.store.widgets().includes(w.id))]);

  protected readonly hosts = computed(() => this.store.visibleHosts());
  protected readonly offlineHosts = computed(() => this.hosts().filter((h) => h.status === 'getrennt'));
  protected readonly events = computed(() => this.store.events().filter((e) => this.store.visible(e.hostId)).slice(0, 6));
  protected readonly updateStacks = computed(() => [...new Set(this.store.updates().map((u) => u.stackId).filter((s): s is string => !!s))]);

  protected readonly sev = computed(() => {
    const f = this.store.findings();
    const sum = (k: 'kritisch' | 'hoch' | 'mittel' | 'niedrig') => f.reduce((a, x) => a + x[k], 0);
    return [
      { label: 'Kritisch', n: sum('kritisch'), cls: 'border-red-500/25 bg-red-500/10 text-red-700' },
      { label: 'Hoch', n: sum('hoch'), cls: 'border-orange-500/25 bg-orange-500/10 text-orange-700' },
      { label: 'Mittel', n: sum('mittel'), cls: 'border-amber-500/30 bg-amber-500/10 text-amber-700' },
      { label: 'Niedrig', n: sum('niedrig'), cls: 'border-lime-500/30 bg-lime-500/10 text-zinc-700' },
    ];
  });

  protected readonly links: { name: string; url: string; host: string; icon: IconName }[] = [
    { name: 'Jellyfin', url: 'https://media.example.com', host: 'atlas', icon: 'play' },
    { name: 'Nextcloud', url: 'https://cloud.example.com', host: 'boreal', icon: 'cloud' },
    { name: 'Craft', url: 'mc.example.com:25565', host: 'boreal', icon: 'gamepad' },
    { name: 'whoami', url: 'https://whoami.example.com', host: 'boreal', icon: 'globe' },
  ];

  protected readonly chartLabel = computed(
    () => 'CPU-Verlauf: ' + this.hosts().map((h) => `${h.name} aktuell ${h.status === 'online' ? h.cpu + ' Prozent' : 'getrennt'}`).join(', '),
  );

  protected isActive(id: WidgetId): boolean {
    return this.store.widgets().includes(id);
  }

  protected position(id: WidgetId): number {
    return this.store.widgets().indexOf(id) + 1;
  }

  protected containers(hostId: string): number {
    return this.store.allServices().filter((i) => i.hostId === hostId && i.svc.state === 'running').length;
  }

  protected ramUsed(h: Host): string {
    return `${((h.memGb * h.mem) / 100).toFixed(1)} GB belegt`;
  }

  protected stackName(id: string | null): string {
    if (!id) return 'Einzelcontainer';
    return this.store.stacks().find((s) => s.id === id)?.name ?? id;
  }

  protected spark(values: number[]): string {
    const step = 120 / (values.length - 1);
    return values.map((v, i) => `${(i * step).toFixed(1)},${(38 - v * 0.36).toFixed(1)}`).join(' ');
  }

  protected line(values: number[]): string {
    const step = 288 / (values.length - 1);
    return values.map((v, i) => `${(28 + i * step).toFixed(1)},${(150 - v * 1.3).toFixed(1)}`).join(' ');
  }
}
