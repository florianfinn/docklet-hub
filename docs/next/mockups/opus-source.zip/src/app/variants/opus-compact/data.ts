// Docklet Design Lab – opus-compact
// Synthetische Beispieldaten. Keine realen Betriebsdaten, nur example.com-Domains.

export type PageId =
  | 'dashboard'
  | 'stacks'
  | 'stack'
  | 'containers'
  | 'hosts'
  | 'networks'
  | 'files'
  | 'images'
  | 'security'
  | 'settings'
  | 'profile'
  | 'preview';

export type ThemePref = 'hell' | 'dunkel' | 'system';

export type HostStatus = 'online' | 'getrennt' | 'prüfung';
export type ConnectionMode = 'direkt' | 'edge';

export interface Host {
  id: string;
  name: string;
  color: string;
  soft: string;
  status: HostStatus;
  cpu: number;
  mem: number;
  disk: number;
  address: string;
  mode: ConnectionMode;
  docker: string;
  projectDir: string;
  installDir: string;
  lastSeen: string;
  cpuHistory: number[];
  memGb: number;
  cores: number;
}

export type RunState = 'running' | 'exited' | 'restarting';
export type Health = 'healthy' | 'unhealthy' | 'starting' | 'none';

export interface Service {
  id: string;
  name: string;
  image: string;
  tag: string;
  newTag?: string;
  state: RunState;
  health: Health;
  cpu: number;
  memMb: number;
  ports: string[];
  networks: string[];
}

export type MountKind = 'volume' | 'bind';

export interface MountRef {
  id: string;
  kind: MountKind;
  name: string;
  source: string;
  hostId: string;
  sizeMb: number;
  usedBy: string[];
}

export type AutoUpdate = 'pruefen' | 'taeglich' | 'woechentlich';

export interface Stack {
  id: string;
  name: string;
  hostId: string;
  description: string;
  path: string;
  domain?: string;
  labels: string[];
  services: Service[];
  mounts: string[];
  autoUpdate: AutoUpdate;
  autoHeal: boolean;
  backup: { last: string; schedule: string; target: string; retention: string };
  compose: string;
  env: string;
  deployed: boolean;
}

export type Origin = 'docklet' | 'standalone' | 'unraid' | 'unklar';

export interface StandaloneContainer extends Service {
  hostId: string;
  origin: Origin;
  note: string;
}

export interface NetworkDef {
  id: string;
  name: string;
  hostId: string;
  driver: 'bridge' | 'host' | 'macvlan';
  subnet: string;
  gateway: string;
  isInternal: boolean;
  members: string[]; // Service-IDs
}

/** Beobachtete Kommunikation zwischen Services (Demo). Bewusst ohne Durchsatzwerte. */
export interface ObservedLink {
  from: string;
  to: string;
  note: string;
}

export type WidgetId = 'kpis' | 'problems' | 'hosts' | 'updates' | 'cpu' | 'events' | 'backups' | 'scan' | 'links';

export interface WidgetDef {
  id: WidgetId;
  title: string;
  description: string;
}

export const WIDGETS: WidgetDef[] = [
  { id: 'kpis', title: 'Kennzahlen', description: 'Laufende Container, Updates, Probleme, Hosts' },
  { id: 'problems', title: 'Probleme', description: 'Unhealthy Container und Auto-Heal-Status' },
  { id: 'hosts', title: 'Hoststatus', description: 'Verbindung je Host (kompakt)' },
  { id: 'updates', title: 'Updates', description: 'Verfügbare Image-Updates, manuell installieren' },
  { id: 'cpu', title: 'CPU-Verlauf', description: 'Liniendiagramm je Host' },
  { id: 'events', title: 'Letzte Ereignisse', description: 'Auszug aus dem Ereignisverlauf' },
  { id: 'backups', title: 'Backups', description: 'Letzte Sicherungen und Ziele' },
  { id: 'scan', title: 'Schwachstellen', description: 'Optionaler Scan, getrennt von Updates' },
  { id: 'links', title: 'Anwendungslinks', description: 'Schnellzugriff im Homepage-Stil' },
];

export const DEFAULT_WIDGETS: WidgetId[] = ['kpis', 'problems', 'updates', 'cpu', 'events'];

export type ActionStatus = 'running' | 'success' | 'error' | 'queued';

export interface ActionItem {
  id: string;
  title: string;
  hostId: string;
  status: ActionStatus;
  progress: number;
  steps: string[];
  step: number;
  output: string[];
  startedAt: string;
  restorable?: boolean;
  stackId?: string;
  services?: string[];
}

export type EventLevel = 'info' | 'warnung' | 'fehler' | 'erfolg';

export interface EventItem {
  id: string;
  time: string;
  level: EventLevel;
  hostId: string;
  text: string;
}

export interface FileNode {
  name: string;
  kind: 'dir' | 'file';
  size?: string;
  modified?: string;
  content?: string;
  children?: FileNode[];
}

export interface LogLine {
  t: string;
  svc: string;
  text: string;
  level?: 'warn' | 'error';
}

export type Severity = 'kritisch' | 'hoch' | 'mittel' | 'niedrig';

export interface ImageFindings {
  image: string;
  kritisch: number;
  hoch: number;
  mittel: number;
  niedrig: number;
}

export interface Finding {
  id: string;
  severity: Severity;
  pkg: string;
  installed: string;
  fixed: string;
  image: string;
}

/** Deployment-Ablauf nach Docklet-Vorbild. Konkrete Schrittfolge je Aktion bleibt technisch zu präzisieren. */
export const DEPLOY_STEPS = ['Prüfung', 'Image-Pull/Build', 'Erstellen/Austausch', 'Start', 'Zustandsprüfung'];

export const HOST_PALETTE: { color: string; soft: string; label: string }[] = [
  { color: '#2563eb', soft: '#dbeafe', label: 'Blau' },
  { color: '#7c3aed', soft: '#ede9fe', label: 'Violett' },
  { color: '#ea580c', soft: '#ffedd5', label: 'Orange' },
  { color: '#0d9488', soft: '#ccfbf1', label: 'Petrol' },
  { color: '#db2777', soft: '#fce7f3', label: 'Pink' },
  { color: '#65a30d', soft: '#ecfccb', label: 'Grün' },
];

/** Farben der Stack-Labels (Chips). Unbekannte Labels erhalten Grau. */
export const LABEL_COLORS: Record<string, string> = {
  media: '#c026d3',
  produktiv: '#16a34a',
  'spiele': '#d97706',
  intern: '#0891b2',
  datenbank: '#4f46e5',
  test: '#71717a',
};

export function labelColor(label: string): string {
  return LABEL_COLORS[label] ?? '#71717a';
}

export const SEED_HOSTS: Host[] = [
  {
    id: 'atlas',
    name: 'Atlas',
    color: '#2563eb',
    soft: '#dbeafe',
    status: 'online',
    cpu: 28,
    mem: 41,
    disk: 63,
    address: 'atlas.example.com:3553',
    mode: 'direkt',
    docker: '28.3.1',
    projectDir: '/mnt/user/appdata/stacks',
    installDir: '/opt/docklet-agent',
    lastSeen: 'gerade eben',
    cpuHistory: [22, 24, 19, 21, 30, 34, 27, 25, 31, 38, 33, 29, 26, 24, 28, 35, 41, 37, 30, 27, 25, 29, 31, 28],
    memGb: 32,
    cores: 8,
  },
  {
    id: 'boreal',
    name: 'Boreal',
    color: '#7c3aed',
    soft: '#ede9fe',
    status: 'online',
    cpu: 46,
    mem: 58,
    disk: 47,
    address: 'boreal.example.com:3553',
    mode: 'direkt',
    docker: '28.2.2',
    projectDir: '/srv/stacks',
    installDir: '/opt/docklet-agent',
    lastSeen: 'gerade eben',
    cpuHistory: [38, 41, 44, 40, 39, 52, 58, 61, 55, 49, 47, 45, 50, 54, 48, 43, 46, 51, 57, 53, 48, 44, 45, 46],
    memGb: 16,
    cores: 6,
  },
  {
    id: 'cedar',
    name: 'Cedar',
    color: '#ea580c',
    soft: '#ffedd5',
    status: 'getrennt',
    cpu: 0,
    mem: 0,
    disk: 71,
    address: 'Edge · hub.example.com',
    mode: 'edge',
    docker: '27.5.1',
    projectDir: '/home/docker/stacks',
    installDir: '/opt/docklet-agent',
    lastSeen: 'vor 3 Std.',
    cpuHistory: [12, 14, 11, 13, 15, 12, 10, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    memGb: 8,
    cores: 4,
  },
];

const MEDIA_COMPOSE = `# Media-Stack auf Atlas
name: media
services:
  jellyfin:
    image: jellyfin/jellyfin:10.10.3
    container_name: jellyfin
    restart: unless-stopped
    ports:
      - "8096:8096"
    volumes:
      - jellyfin-config:/config
      - /mnt/user/media:/media:ro
    environment:
      TZ: Europe/Berlin
      JELLYFIN_PublishedServerUrl: https://media.example.com
    healthcheck:
      test: ["CMD-SHELL", "curl -fs http://localhost:8096/health || exit 1"]
      interval: 30s
      retries: 3
    labels:
      docklet.group: media
    deploy:
      resources:
        limits:
          memory: 2g
  redis:
    image: redis:7.2.5
    restart: unless-stopped
    volumes:
      - redis-data:/data
volumes:
  jellyfin-config:
  redis-data:
`;

const CLOUD_COMPOSE = `name: cloud
services:
  nextcloud:
    image: nextcloud:30.0.4
    restart: unless-stopped
    ports:
      - "8443:443"
    volumes:
      - nextcloud-data:/var/www/html
    environment:
      POSTGRES_HOST: postgres
      NEXTCLOUD_TRUSTED_DOMAINS: cloud.example.com
    networks: [cloud_backend, proxy]
  postgres:
    image: postgres:16.6
    restart: unless-stopped
    volumes:
      - postgres-data:/var/lib/postgresql/data
    environment:
      POSTGRES_DB: nextcloud
      POSTGRES_USER: nextcloud
      POSTGRES_PASSWORD: \${POSTGRES_PASSWORD}
    networks: [cloud_backend]
networks:
  cloud_backend:
  proxy:
    external: true
volumes:
  nextcloud-data:
  postgres-data:
`;

const CRAFT_COMPOSE = `name: craft
services:
  minecraft:
    image: itzg/minecraft-server:2025.9.0
    restart: unless-stopped
    tty: true
    stdin_open: true
    ports:
      - "25565:25565"
    volumes:
      - ./data:/data
    environment:
      EULA: "TRUE"
      MEMORY: 4G
    healthcheck:
      test: ["CMD", "mc-health"]
      interval: 60s
      retries: 3
`;

export const SEED_STACKS: Stack[] = [
  {
    id: 'media',
    name: 'Media',
    hostId: 'atlas',
    description: 'Jellyfin mit Redis-Cache',
    path: '/mnt/user/appdata/stacks/media',
    domain: 'media.example.com',
    labels: ['media', 'produktiv'],
    services: [
      { id: 'jellyfin', name: 'jellyfin', image: 'jellyfin/jellyfin', tag: '10.10.3', newTag: '10.10.7', state: 'running', health: 'healthy', cpu: 9.4, memMb: 812, ports: ['8096:8096'], networks: ['media_default'] },
      { id: 'redis', name: 'redis', image: 'redis', tag: '7.2.5', newTag: '7.4.1', state: 'running', health: 'none', cpu: 0.6, memMb: 24, ports: [], networks: ['media_default'] },
    ],
    mounts: ['v-jellyfin-config', 'b-media', 'v-redis-data'],
    autoUpdate: 'pruefen',
    autoHeal: true,
    backup: { last: 'heute 03:00', schedule: 'täglich 03:00', target: 'Lokal · /mnt/backups', retention: '7 Tage' },
    compose: MEDIA_COMPOSE,
    env: 'TZ=Europe/Berlin\n',
    deployed: true,
  },
  {
    id: 'cloud',
    name: 'Cloud',
    hostId: 'boreal',
    description: 'Nextcloud mit Postgres',
    path: '/srv/stacks/cloud',
    domain: 'cloud.example.com',
    labels: ['produktiv', 'datenbank'],
    services: [
      { id: 'nextcloud', name: 'nextcloud', image: 'nextcloud', tag: '30.0.4', state: 'running', health: 'healthy', cpu: 4.1, memMb: 356, ports: ['8443:443'], networks: ['cloud_backend', 'proxy'] },
      { id: 'postgres', name: 'postgres', image: 'postgres', tag: '16.6', state: 'running', health: 'healthy', cpu: 1.8, memMb: 142, ports: [], networks: ['cloud_backend'] },
    ],
    mounts: ['v-nextcloud-data', 'v-postgres-data'],
    autoUpdate: 'woechentlich',
    autoHeal: true,
    backup: { last: 'gestern 02:30', schedule: 'täglich 02:30', target: 'SMB · //nas.example.com/backup', retention: '14 Tage' },
    compose: CLOUD_COMPOSE,
    env: 'POSTGRES_PASSWORD=<geheim – nur Demo>\n',
    deployed: true,
  },
  {
    id: 'craft',
    name: 'Craft',
    hostId: 'boreal',
    description: 'Minecraft-Server (Java)',
    path: '/srv/stacks/craft',
    labels: ['spiele', 'intern'],
    services: [
      { id: 'minecraft', name: 'minecraft', image: 'itzg/minecraft-server', tag: '2025.9.0', state: 'running', health: 'unhealthy', cpu: 31.2, memMb: 3480, ports: ['25565:25565'], networks: ['craft_default'] },
    ],
    mounts: ['b-craft-data'],
    autoUpdate: 'pruefen',
    autoHeal: true,
    backup: { last: 'vor 2 Tagen', schedule: 'wöchentlich So 04:00', target: 'NFS · nfs.example.com:/backup', retention: '4 Wochen' },
    compose: CRAFT_COMPOSE,
    env: '',
    deployed: true,
  },
];

export const SEED_STANDALONE: StandaloneContainer[] = [
  { id: 'legacy', name: 'Legacy', image: 'linuxserver/legacy-app', tag: 'latest', state: 'running', health: 'none', cpu: 1.2, memMb: 210, ports: ['8080:80'], networks: ['bridge'], hostId: 'atlas', origin: 'unraid', note: 'Über Unraid-Template erstellt. Eingeschränkt: Status, Logs, Shell, Auslastung, Start/Stop/Neustart.' },
  { id: 'whoami', name: 'whoami', image: 'traefik/whoami', tag: 'v1.10', state: 'running', health: 'none', cpu: 0.1, memMb: 6, ports: ['8000:80'], networks: ['proxy'], hostId: 'boreal', origin: 'standalone', note: 'Normaler Einzelcontainer ohne Compose. Bearbeiten und neu erstellen möglich.' },
  { id: 'agent-atlas', name: 'docklet-agent', image: 'docklet/agent', tag: '0.9.2', state: 'running', health: 'healthy', cpu: 0.4, memMb: 38, ports: ['3553:3553'], networks: ['bridge'], hostId: 'atlas', origin: 'docklet', note: 'Docklet-Agent dieses Hosts.' },
];

export const SEED_MOUNTS: MountRef[] = [
  { id: 'v-jellyfin-config', kind: 'volume', name: 'media_jellyfin-config', source: '/var/lib/docker/volumes/media_jellyfin-config/_data', hostId: 'atlas', sizeMb: 1840, usedBy: ['jellyfin'] },
  { id: 'b-media', kind: 'bind', name: '/mnt/user/media', source: '/mnt/user/media', hostId: 'atlas', sizeMb: 912000, usedBy: ['jellyfin'] },
  { id: 'v-redis-data', kind: 'volume', name: 'media_redis-data', source: '/var/lib/docker/volumes/media_redis-data/_data', hostId: 'atlas', sizeMb: 12, usedBy: ['redis'] },
  { id: 'v-nextcloud-data', kind: 'volume', name: 'cloud_nextcloud-data', source: '/var/lib/docker/volumes/cloud_nextcloud-data/_data', hostId: 'boreal', sizeMb: 48200, usedBy: ['nextcloud'] },
  { id: 'v-postgres-data', kind: 'volume', name: 'cloud_postgres-data', source: '/var/lib/docker/volumes/cloud_postgres-data/_data', hostId: 'boreal', sizeMb: 620, usedBy: ['postgres'] },
  { id: 'b-craft-data', kind: 'bind', name: './data (craft)', source: '/srv/stacks/craft/data', hostId: 'boreal', sizeMb: 2310, usedBy: ['minecraft'] },
];

export const SEED_NETWORKS: NetworkDef[] = [
  { id: 'media_default', name: 'media_default', hostId: 'atlas', driver: 'bridge', subnet: '192.0.2.32/27', gateway: '192.0.2.33', isInternal: false, members: ['jellyfin', 'redis'] },
  { id: 'bridge-atlas', name: 'bridge', hostId: 'atlas', driver: 'bridge', subnet: '192.0.2.0/27', gateway: '192.0.2.1', isInternal: false, members: ['legacy', 'agent-atlas'] },
  { id: 'cloud_backend', name: 'cloud_backend', hostId: 'boreal', driver: 'bridge', subnet: '192.0.2.64/27', gateway: '192.0.2.65', isInternal: true, members: ['nextcloud', 'postgres'] },
  { id: 'proxy', name: 'proxy', hostId: 'boreal', driver: 'bridge', subnet: '198.51.100.0/27', gateway: '198.51.100.1', isInternal: false, members: ['nextcloud', 'whoami'] },
  { id: 'craft_default', name: 'craft_default', hostId: 'boreal', driver: 'bridge', subnet: '198.51.100.32/27', gateway: '198.51.100.33', isInternal: false, members: ['minecraft'] },
];

export const OBSERVED_LINKS: ObservedLink[] = [
  { from: 'jellyfin', to: 'redis', note: 'TCP 6379, zuletzt vor 2 s gesehen' },
  { from: 'nextcloud', to: 'postgres', note: 'TCP 5432, zuletzt vor 1 s gesehen' },
  { from: 'whoami', to: 'nextcloud', note: 'HTTP 443, zuletzt vor 4 min gesehen' },
];

export const SEED_ACTIONS: ActionItem[] = [
  {
    id: 'a-seed-1',
    title: 'Backup Cloud',
    hostId: 'boreal',
    status: 'success',
    progress: 100,
    steps: ['Stack anhalten', 'Volumes sichern', 'Stack starten'],
    step: 3,
    output: ['cloud_nextcloud-data → //nas.example.com/backup (47,1 GB)', 'cloud_postgres-data → //nas.example.com/backup (612 MB)', 'Aufbewahrung: 14 Sicherungen, 1 alte entfernt'],
    startedAt: '02:30',
    stackId: 'cloud',
    services: ['nextcloud', 'postgres'],
  },
  {
    id: 'a-seed-2',
    title: 'Update whoami v1.10 → v1.11',
    hostId: 'boreal',
    status: 'error',
    progress: 80,
    steps: DEPLOY_STEPS,
    step: 4,
    output: ['Prüfung … ok', 'v1.11: pull complete', 'recreate whoami … ok', 'start whoami … ok', 'Fehler: Container beendet sich mit Code 1 (Demo)', 'Vorheriges Image traefik/whoami:v1.10 und Konfiguration sind gesichert.'],
    startedAt: 'gestern 22:14',
    restorable: true,
    services: ['whoami'],
  },
];

export const SEED_EVENTS: EventItem[] = [
  { id: 'e1', time: '09:41', level: 'fehler', hostId: 'boreal', text: 'craft/minecraft ist unhealthy (Healthcheck 3× fehlgeschlagen)' },
  { id: 'e2', time: '09:42', level: 'warnung', hostId: 'boreal', text: 'Auto-Heal: craft/minecraft neu gestartet (2 von 3 Versuchen)' },
  { id: 'e3', time: '08:15', level: 'info', hostId: 'atlas', text: 'Update gefunden: jellyfin/jellyfin 10.10.7, redis 7.4.1' },
  { id: 'e4', time: '06:58', level: 'warnung', hostId: 'cedar', text: 'Edge-Verbindung zu Cedar getrennt' },
  { id: 'e5', time: '03:00', level: 'erfolg', hostId: 'atlas', text: 'Backup Media abgeschlossen (1,9 GB, lokal)' },
  { id: 'e6', time: '02:31', level: 'erfolg', hostId: 'boreal', text: 'Backup Cloud abgeschlossen (SMB)' },
];

/** Logzeilen je Service, mit Zeitstempel für den gemeinsamen Stack-Logstream. */
export const LOGS: Record<string, LogLine[]> = {
  jellyfin: [
    { t: '09:40:02', svc: 'jellyfin', text: '[INF] Main: Jellyfin version: 10.10.3' },
    { t: '09:40:03', svc: 'jellyfin', text: '[INF] Startup complete 0:00:04.8' },
    { t: '09:41:12', svc: 'jellyfin', text: '[INF] Session: user "demo" verbunden von 203.0.113.24' },
    { t: '09:43:55', svc: 'jellyfin', text: '[INF] Transcoding: hevc → h264, 1080p' },
  ],
  redis: [
    { t: '09:40:01', svc: 'redis', text: '* Ready to accept connections tcp' },
    { t: '09:42:30', svc: 'redis', text: '* DB loaded from disk: 0.012 seconds' },
    { t: '09:55:01', svc: 'redis', text: '* 100 changes in 300 seconds. Saving...' },
  ],
  nextcloud: [
    { t: '09:30:11', svc: 'nextcloud', text: 'AH00558: apache2: Server name set to cloud.example.com' },
    { t: '09:35:00', svc: 'nextcloud', text: '[core] Cron-Job erfolgreich (2,1 s)' },
    { t: '09:36:40', svc: 'nextcloud', text: '[files] Scan abgeschlossen: 18 204 Dateien' },
  ],
  postgres: [
    { t: '09:30:02', svc: 'postgres', text: 'LOG:  database system is ready to accept connections' },
    { t: '09:35:12', svc: 'postgres', text: 'LOG:  checkpoint complete: wrote 412 buffers (2.5%)' },
  ],
  minecraft: [
    { t: '09:38:10', svc: 'minecraft', text: '[Server thread/INFO]: Done (18.402s)! For help, type "help"' },
    { t: '09:39:44', svc: 'minecraft', text: "[Server thread/WARN]: Can't keep up! Running 5214ms behind", level: 'warn' },
    { t: '09:41:02', svc: 'minecraft', text: '[mc-health] Fehler: keine Antwort auf Status-Ping (Timeout 5 s)', level: 'error' },
    { t: '09:41:02', svc: 'minecraft', text: '[docker] health_status: unhealthy', level: 'error' },
  ],
  legacy: [
    { t: '08:00:00', svc: 'legacy', text: '[s6-init] starting services' },
    { t: '08:00:02', svc: 'legacy', text: '[app] listening on :80' },
  ],
  whoami: [{ t: '07:12:00', svc: 'whoami', text: 'Starting up on port 80' }],
  'agent-atlas': [
    { t: '06:00:00', svc: 'docklet-agent', text: 'agent 0.9.2 verbunden (direkt)' },
    { t: '06:00:01', svc: 'docklet-agent', text: 'Socket-Gruppe 998 erkannt' },
  ],
};

/** Synthetische Scanbefunde je Image (keine echten CVE-Kennungen). */
export const SEED_FINDINGS: ImageFindings[] = [
  { image: 'jellyfin/jellyfin', kritisch: 0, hoch: 1, mittel: 4, niedrig: 9 },
  { image: 'redis', kritisch: 0, hoch: 0, mittel: 1, niedrig: 3 },
  { image: 'nextcloud', kritisch: 1, hoch: 2, mittel: 5, niedrig: 12 },
  { image: 'postgres', kritisch: 0, hoch: 0, mittel: 2, niedrig: 6 },
  { image: 'itzg/minecraft-server', kritisch: 0, hoch: 1, mittel: 3, niedrig: 4 },
  { image: 'linuxserver/legacy-app', kritisch: 1, hoch: 3, mittel: 6, niedrig: 10 },
  { image: 'traefik/whoami', kritisch: 0, hoch: 0, mittel: 0, niedrig: 1 },
  { image: 'docklet/agent', kritisch: 0, hoch: 0, mittel: 0, niedrig: 0 },
];

export const SEED_FINDING_LIST: Finding[] = [
  { id: 'DEMO-2026-0142', severity: 'kritisch', pkg: 'libdemo-ssl', installed: '3.0.11', fixed: '3.0.15', image: 'nextcloud' },
  { id: 'DEMO-2026-0219', severity: 'kritisch', pkg: 'demo-zlib', installed: '1.2.11', fixed: '1.3.1', image: 'linuxserver/legacy-app' },
  { id: 'DEMO-2026-0087', severity: 'hoch', pkg: 'demo-curl', installed: '8.4.0', fixed: '8.9.1', image: 'jellyfin/jellyfin' },
  { id: 'DEMO-2026-0301', severity: 'hoch', pkg: 'demo-xml', installed: '2.9.14', fixed: '2.12.7', image: 'nextcloud' },
  { id: 'DEMO-2026-0333', severity: 'hoch', pkg: 'demo-java-log', installed: '2.17.1', fixed: '2.24.0', image: 'itzg/minecraft-server' },
  { id: 'DEMO-2026-0402', severity: 'mittel', pkg: 'demo-glibc', installed: '2.36', fixed: '2.36-9', image: 'postgres' },
  { id: 'DEMO-2026-0415', severity: 'mittel', pkg: 'demo-tar', installed: '1.34', fixed: '–', image: 'redis' },
];

/** Scanzeitpunkte der letzten 7 Tage (Befunde gesamt je Scan), synthetisch. */
export const SEED_SCAN_HISTORY: { day: string; time: string; total: number; manual: boolean }[] = [
  { day: 'Sa', time: '04:00', total: 92, manual: false },
  { day: 'So', time: '04:00', total: 90, manual: false },
  { day: 'Mo', time: '04:00', total: 91, manual: false },
  { day: 'Di', time: '04:00', total: 88, manual: false },
  { day: 'Mi', time: '04:00', total: 86, manual: false },
  { day: 'Do', time: '16:20', total: 85, manual: true },
  { day: 'Fr', time: '04:00', total: 84, manual: false },
];

export const FILE_TREES: Record<string, FileNode[]> = {
  'v-jellyfin-config': [
    { name: 'config', kind: 'dir', children: [
      { name: 'system.xml', kind: 'file', size: '4 KB', modified: 'heute 09:40', content: '<ServerConfiguration>\n  <ServerName>Atlas Media</ServerName>\n  <EnableMetrics>false</EnableMetrics>\n</ServerConfiguration>' },
      { name: 'network.xml', kind: 'file', size: '2 KB', modified: 'vor 3 Tagen', content: '<NetworkConfiguration>\n  <PublishedServerUrl>https://media.example.com</PublishedServerUrl>\n</NetworkConfiguration>' },
    ] },
    { name: 'data', kind: 'dir', children: [{ name: 'library.db', kind: 'file', size: '182 MB', modified: 'heute 09:43' }] },
    { name: 'log', kind: 'dir', children: [{ name: 'log_20261010.log', kind: 'file', size: '88 KB', modified: 'heute 09:43', content: '[09:40:02] [INF] Main: Jellyfin version: 10.10.3' }] },
  ],
  'b-media': [
    { name: 'filme', kind: 'dir', children: [{ name: 'Beispielfilm (2024).mkv', kind: 'file', size: '4,2 GB', modified: '02.09.2026' }] },
    { name: 'serien', kind: 'dir', children: [{ name: 'Beispielserie', kind: 'dir', children: [] }] },
    { name: 'musik', kind: 'dir', children: [] },
  ],
  'v-redis-data': [{ name: 'dump.rdb', kind: 'file', size: '11 MB', modified: 'heute 09:55' }],
  'v-nextcloud-data': [
    { name: 'config', kind: 'dir', children: [{ name: 'config.php', kind: 'file', size: '2 KB', modified: 'vor 5 Tagen', content: "<?php\n$CONFIG = array (\n  'trusted_domains' => ['cloud.example.com'],\n  'dbtype' => 'pgsql',\n);" }] },
    { name: 'data', kind: 'dir', children: [{ name: 'demo', kind: 'dir', children: [] }] },
  ],
  'v-postgres-data': [{ name: 'PG_VERSION', kind: 'file', size: '1 KB', modified: 'vor 30 Tagen', content: '16' }, { name: 'base', kind: 'dir', children: [] }],
  'b-craft-data': [
    { name: 'world', kind: 'dir', children: [{ name: 'level.dat', kind: 'file', size: '6 KB', modified: 'heute 09:38' }] },
    { name: 'server.properties', kind: 'file', size: '1 KB', modified: 'heute 09:30', content: 'motd=Craft Demo\nmax-players=12\nview-distance=10\nonline-mode=true' },
    { name: 'logs', kind: 'dir', children: [{ name: 'latest.log', kind: 'file', size: '64 KB', modified: 'heute 09:41', content: "[09:39:44] Can't keep up! Running 5214ms behind" }] },
  ],
};

export const EMPTY_COMPOSE = `name: neuer-stack
services:
  app:
    image: ""
    restart: unless-stopped
`;
