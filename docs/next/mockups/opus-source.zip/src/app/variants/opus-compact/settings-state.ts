// Docklet Design Lab – opus-compact · Zustand der Hub-Einstellungen (lokal, simuliert)
import { Injectable, signal } from '@angular/core';

export type AuthMode = 'none' | 'local' | 'proxy';
export type Access = 'voll' | 'eingeschraenkt';
export type BackupTargetType = 'lokal' | 'hostmount' | 'smb' | 'nfs';

export interface HubUser {
  id: string;
  name: string;
  email: string;
  admin: boolean;
  access: Access;
  stacks: string[];
}

export interface Channel {
  id: string;
  type: string;
  name: string;
  target: string;
  events: string[];
  enabled: boolean;
}

export interface BackupTarget {
  id: string;
  type: BackupTargetType;
  name: string;
  path: string;
  hostId?: string;
}

/** Bestehende Arcane-Kanäle. Angezeigt werden nur eingerichtete; der Typ wird beim Hinzufügen gewählt. */
export const CHANNEL_TYPES: { id: string; label: string; field: string; placeholder: string }[] = [
  { id: 'email', label: 'E-Mail', field: 'Empfänger', placeholder: 'ops@example.com' },
  { id: 'discord', label: 'Discord', field: 'Webhook-URL', placeholder: 'https://discord.example.com/api/webhooks/…' },
  { id: 'telegram', label: 'Telegram', field: 'Chat-ID', placeholder: '-100123456' },
  { id: 'signal', label: 'Signal', field: 'Nummer / Gruppe', placeholder: '+49 000 000000' },
  { id: 'slack', label: 'Slack', field: 'Webhook-URL', placeholder: 'https://hooks.example.com/services/…' },
  { id: 'ntfy', label: 'ntfy', field: 'Topic-URL', placeholder: 'https://ntfy.example.com/docklet' },
  { id: 'pushover', label: 'Pushover', field: 'User-Key', placeholder: '<DEMO-KEY>' },
  { id: 'gotify', label: 'Gotify', field: 'Server-URL', placeholder: 'https://gotify.example.com' },
  { id: 'matrix', label: 'Matrix', field: 'Raum', placeholder: '!raum:example.com' },
  { id: 'gchat', label: 'Google Chat', field: 'Webhook-URL', placeholder: 'https://chat.example.com/v1/spaces/…' },
  { id: 'generic', label: 'Generisch (Webhook)', field: 'URL', placeholder: 'https://hooks.example.com/docklet' },
];

export const EVENT_TYPES = ['Updates verfügbar', 'Aktion fehlgeschlagen', 'Container unhealthy', 'Host getrennt', 'Backup', 'Schwachstellen (hoch/kritisch)'];

export const TARGET_TYPES: { id: BackupTargetType; label: string; hint: string; placeholder: string }[] = [
  { id: 'lokal', label: 'Lokales Verzeichnis', hint: 'Verzeichnis auf dem Host des Stacks', placeholder: '/mnt/backups' },
  { id: 'hostmount', label: 'Vorhandener Host-Mount', hint: 'Bereits eingehängtes Laufwerk oder Share', placeholder: '/mnt/user/backup' },
  { id: 'smb', label: 'SMB-Freigabe', hint: 'Eigene Anbindung durch Docklet', placeholder: '//nas.example.com/backup' },
  { id: 'nfs', label: 'NFS-Export', hint: 'Eigene Anbindung durch Docklet', placeholder: 'nfs.example.com:/backup' },
];

@Injectable()
export class CxHubSettings {
  private seq = 100;

  readonly authMode = signal<AuthMode>('local');
  readonly proxyHeader = signal('Remote-User');
  readonly trustedProxies = signal('10.0.0.0/8');

  readonly users = signal<HubUser[]>([
    { id: 'u1', name: 'Demo Admin', email: 'admin@example.com', admin: true, access: 'voll', stacks: [] },
    { id: 'u2', name: 'Mara (Gast)', email: 'mara@example.com', admin: false, access: 'eingeschraenkt', stacks: ['craft'] },
  ]);

  readonly channels = signal<Channel[]>([
    { id: 'c1', type: 'ntfy', name: 'ntfy Homelab', target: 'https://ntfy.example.com/docklet', events: ['Aktion fehlgeschlagen', 'Container unhealthy', 'Host getrennt'], enabled: true },
    { id: 'c2', type: 'email', name: 'E-Mail Admin', target: 'admin@example.com', events: ['Updates verfügbar', 'Backup'], enabled: true },
  ]);

  readonly checkInterval = signal('6h');
  readonly defaultPolicy = signal<'pruefen' | 'auto'>('pruefen');
  readonly maintenanceWindow = signal('04:00');

  readonly targets = signal<BackupTarget[]>([
    { id: 'b1', type: 'lokal', name: 'Lokal Atlas', path: '/mnt/backups', hostId: 'atlas' },
    { id: 'b2', type: 'smb', name: 'NAS (SMB)', path: '//nas.example.com/backup' },
    { id: 'b3', type: 'nfs', name: 'NFS Archiv', path: 'nfs.example.com:/backup' },
  ]);

  readonly healEnabled = signal(true);
  readonly healMax = signal(3);
  readonly healWindow = signal('1 h');
  readonly healExceptions = signal<string[]>(['legacy']);

  nextId(prefix: string): string {
    return `${prefix}${++this.seq}`;
  }
}
