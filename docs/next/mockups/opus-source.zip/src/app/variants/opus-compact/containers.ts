// Docklet Design Lab – opus-compact · Container-Seite
// Einzelcontainer ohne Compose (normal: bearbeiten/recreate; Unraid/unklar: eingeschränkt, manuelle Zuordnung).
// Umschaltbar auf alle Container; Stack-Container führen zur Stack-Seite.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ZardButtonComponent } from '../../shared/components/button';
import { LOGS, type Origin, type Service, type StandaloneContainer } from './data';
import { CxIcon } from './icon';
import { CxStore, splitImage } from './store';
import { CxDialog, CxHost, CxStatus } from './ui';

type Scope = 'einzeln' | 'alle';

const ORIGIN_LABEL: Record<Origin, string> = {
  docklet: 'Docklet-System',
  standalone: 'Einzelcontainer',
  unraid: 'Unraid (fremdverwaltet)',
  unklar: 'Herkunft unklar',
};

interface Row {
  svc: Service;
  hostId: string;
  stackId: string | null;
  origin: Origin | null;
}

@Component({
  selector: 'cx-containers',
  imports: [FormsModule, ZardButtonComponent, CxIcon, CxDialog, CxHost, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-2 flex flex-wrap items-center gap-2">
      <div class="flex rounded-md border border-zinc-200 bg-white p-0.5" role="group" aria-label="Umfang">
        <button type="button" class="h-7 rounded px-2.5 text-[12px] font-medium" [class]="scope() === 'einzeln' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'" [attr.aria-pressed]="scope() === 'einzeln'" (click)="scope.set('einzeln')">Einzelcontainer</button>
        <button type="button" class="h-7 rounded px-2.5 text-[12px] font-medium" [class]="scope() === 'alle' ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'" [attr.aria-pressed]="scope() === 'alle'" (click)="scope.set('alle')">Alle Container</button>
      </div>
      <div class="relative min-w-[180px] flex-1 sm:max-w-xs">
        <cx-icon name="search" [size]="14" class="pointer-events-none absolute left-2.5 top-2 text-zinc-400" />
        <input type="search" class="h-8 w-full rounded-md border border-zinc-200 bg-white pl-8 pr-2 text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="Name oder Image" aria-label="Container durchsuchen" [ngModel]="query()" (ngModelChange)="query.set($event)" />
      </div>
      <span class="ml-auto text-[12px] text-zinc-500">{{ rows().length }} Container</span>
    </div>

    <div class="grid items-start gap-3" [class]="selected() ? 'xl:grid-cols-[minmax(0,1fr)_400px]' : ''">
      <section class="min-w-0 overflow-x-auto rounded-lg border border-zinc-200 bg-white" aria-label="Containerliste">
        <table class="w-full min-w-[720px] text-left text-[12.5px]">
          <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500">
            <tr><th class="px-3 py-2 font-semibold">Name</th><th class="px-3 py-2 font-semibold">Status</th><th class="px-3 py-2 font-semibold">Host</th><th class="px-3 py-2 font-semibold">Herkunft</th><th class="px-3 py-2 font-semibold">Image</th><th class="px-3 py-2 font-semibold">Ports</th><th class="px-3 py-2 text-right font-semibold">CPU · RAM</th></tr>
          </thead>
          <tbody>
            @for (r of rows(); track r.svc.id) {
              @let h = store.host(r.hostId);
              <tr class="cursor-pointer border-b border-zinc-100 last:border-0 hover:bg-zinc-50/70" [class]="selectedId() === r.svc.id ? 'bg-zinc-50' : ''" [style.box-shadow]="'inset 3px 0 0 ' + h.color" (click)="pick(r)">
                <td class="px-3 py-2"><button type="button" class="flex items-center gap-2 font-semibold hover:underline" (click)="pick(r); $event.stopPropagation()"><cx-icon name="box" [size]="14" class="text-zinc-500" />{{ r.svc.name }}</button></td>
                <td class="px-3 py-2"><span class="flex gap-1"><cx-status [kind]="r.svc.health === 'unhealthy' ? 'unhealthy' : r.svc.state" />@if (r.origin === 'unraid' || r.origin === 'unklar') { <cx-status kind="limited" /> }</span></td>
                <td class="px-3 py-2"><cx-host [name]="h.name" [color]="h.color" /></td>
                <td class="px-3 py-2 text-zinc-600">
                  @if (r.stackId) { <span class="inline-flex items-center gap-1"><cx-icon name="layers" [size]="12" />Stack {{ stackName(r.stackId) }}</span> } @else { {{ originLabel(r.origin) }} }
                </td>
                <td class="px-3 py-2 font-mono text-[11.5px] text-zinc-600">{{ r.svc.image }}:{{ r.svc.tag }}</td>
                <td class="px-3 py-2 font-mono text-[11.5px]">{{ r.svc.ports.join(', ') || '–' }}</td>
                <td class="px-3 py-2 text-right font-mono text-[11.5px] tabular-nums text-zinc-600">{{ r.svc.cpu.toFixed(1) }}% · {{ r.svc.memMb }} MB</td>
              </tr>
            } @empty {
              <tr><td colspan="7" class="px-3 py-8 text-center text-zinc-600">Keine Container für diesen Filter.</td></tr>
            }
          </tbody>
        </table>
      </section>

      @if (selected(); as c) {
        @let h = store.host(c.hostId);
        <aside class="min-w-0 overflow-hidden rounded-lg border border-zinc-200 bg-white xl:sticky xl:top-16" aria-label="Container-Details">
          <header class="flex items-start gap-2 border-b border-zinc-200 p-3">
            <div class="min-w-0 flex-1">
              <div class="flex flex-wrap items-center gap-2">
                <h2 class="text-[16px] font-semibold">{{ c.name }}</h2>
                <cx-host [name]="h.name" [color]="h.color" />
                <cx-status [kind]="c.state" />
              </div>
              <p class="font-mono text-[11.5px] text-zinc-500">{{ c.image }}:{{ c.tag }} · {{ c.ports.join(', ') || 'keine Ports' }}</p>
            </div>
            <button type="button" class="grid size-8 shrink-0 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100" aria-label="Details schließen" (click)="selectedId.set(null)"><cx-icon name="x" /></button>
          </header>
          <div class="space-y-3 p-3">
            <div class="rounded-md border p-2.5 text-[12.5px]" [class]="limited(c) ? 'border-amber-500/30 bg-amber-500/10 text-amber-800' : 'border-zinc-200 text-zinc-700'">
              <div class="flex items-center gap-1.5 font-medium"><cx-icon [name]="limited(c) ? 'lock' : 'info'" [size]="14" />{{ originLabel(c.origin) }}</div>
              <p class="mt-0.5">{{ limited(c) ? 'Eingeschränkt: Status, Logs, Shell, Auslastung, Start/Stop/Neustart. Kein Editor und kein Recreate.' : c.note }}</p>
            </div>
            <label class="block">
              <span class="mb-1 block text-[12px] font-medium text-zinc-700">Zuordnung (manuell)</span>
              <select class="h-8 w-full rounded-md border border-zinc-200 bg-white px-2 text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/10" [ngModel]="c.origin" (ngModelChange)="store.setOrigin(c.id, $event)">
                @for (o of origins; track o) { <option [value]="o">{{ originLabel(o) }}</option> }
              </select>
              <span class="mt-1 block text-[11.5px] text-zinc-500">Automatisch erkannt: {{ c.id === 'legacy' ? 'Unraid-Template-Labels' : 'keine fremde Verwaltung' }}.</span>
            </label>
            <div class="flex flex-wrap gap-1.5">
              @if (c.state === 'running') {
                <button z-button zType="outline" zSize="sm" type="button" (click)="store.setServiceState(null, c.id, c.name, c.hostId, false)"><cx-icon name="stop" [size]="13" />Stoppen</button>
              } @else {
                <button z-button zType="outline" zSize="sm" type="button" (click)="store.setServiceState(null, c.id, c.name, c.hostId, true)"><cx-icon name="play" [size]="13" />Starten</button>
              }
              <button z-button zType="outline" zSize="sm" type="button" (click)="store.restartService(null, c.id, c.name, c.hostId)"><cx-icon name="restart" [size]="13" />Neustart</button>
              <button z-button zType="outline" zSize="sm" type="button" (click)="store.notify('Shell für ' + c.name + ' würde sich öffnen (Demo).')"><cx-icon name="terminal" [size]="13" />Shell</button>
              <button z-button zSize="sm" type="button" [zDisabled]="limited(c)" [attr.title]="limited(c) ? 'Für fremdverwaltete Container nicht verfügbar' : null" (click)="startEdit(c)"><cx-icon name="pencil" [size]="13" />Bearbeiten & neu erstellen</button>
            </div>
            <div>
              <h3 class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Logs</h3>
              <pre class="max-h-44 overflow-auto rounded-md bg-[#0c0c0f] p-2.5 font-mono text-[11.5px] leading-5 text-[#e4e4e7]">{{ logText(c.id) }}</pre>
            </div>
          </div>
        </aside>
      }
    </div>

    <cx-dialog [open]="editOpen()" [heading]="'Container bearbeiten: ' + (editing()?.name ?? '')" description="Änderungen werden durch Neu-Erstellen des Containers angewendet." icon="pencil" (closed)="editOpen.set(false)">
      <form class="space-y-3 px-4 pb-4" id="cx-edit-form" (ngSubmit)="saveEdit()">
        <label class="block">
          <span class="mb-1 block text-[12px] font-medium">Image <span class="text-red-600">*</span></span>
          <input class="h-8 w-full rounded-md border border-zinc-300 bg-white px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" name="image" required [(ngModel)]="editImage" autofocus />
          @if (!editImage.trim()) { <span class="mt-1 block text-[11.5px] text-red-700">Pflichtfeld: Image angeben.</span> }
        </label>
        <label class="block">
          <span class="mb-1 block text-[12px] font-medium">Ports (Host:Container, kommagetrennt)</span>
          <input class="h-8 w-full rounded-md border border-zinc-300 bg-white px-2 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" name="ports" [(ngModel)]="editPorts" />
        </label>
        <label class="block">
          <span class="mb-1 block text-[12px] font-medium">Variablen (KEY=Wert je Zeile)</span>
          <textarea rows="3" class="w-full rounded-md border border-zinc-300 bg-white px-2 py-1.5 font-mono text-[12.5px] outline-none focus:ring-2 focus:ring-zinc-900/15" name="env" [(ngModel)]="editEnv"></textarea>
        </label>
        <div class="flex gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 p-2.5 text-[12.5px] text-amber-800">
          <cx-icon name="alert" [size]="15" class="mt-0.5 shrink-0" />
          <p>Neu erstellen ersetzt den Container. Daten in Volumes und Bind-Mounts bleiben erhalten; das vorherige Image wird für eine manuelle Wiederherstellung gesichert.</p>
        </div>
      </form>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="editOpen.set(false)">Abbrechen</button>
        <button z-button zSize="sm" type="submit" form="cx-edit-form" [zDisabled]="!editImage.trim()"><cx-icon name="restart" [size]="13" />Neu erstellen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxContainers {
  protected readonly store = inject(CxStore);
  protected readonly scope = signal<Scope>('einzeln');
  protected readonly query = signal('');
  protected readonly selectedId = signal<string | null>(null);
  protected readonly editOpen = signal(false);
  protected readonly editingId = signal<string | null>(null);
  protected readonly origins: Origin[] = ['standalone', 'unraid', 'unklar', 'docklet'];
  protected editImage = '';
  protected editPorts = '';
  protected editEnv = '';

  protected readonly rows = computed<Row[]>(() => {
    const q = this.query().trim().toLowerCase();
    const list: Row[] = this.store.visibleStandalone().map((c) => ({ svc: c, hostId: c.hostId, stackId: null, origin: c.origin }));
    if (this.scope() === 'alle') {
      for (const s of this.store.visibleStacks()) for (const svc of s.services) list.push({ svc, hostId: s.hostId, stackId: s.id, origin: null });
    }
    return list.filter((r) => !q || `${r.svc.name} ${r.svc.image}`.toLowerCase().includes(q));
  });

  protected readonly selected = computed(() => this.store.standalone().find((c) => c.id === this.selectedId()) ?? null);
  protected readonly editing = computed(() => this.store.standalone().find((c) => c.id === this.editingId()) ?? null);

  protected originLabel(o: Origin | null): string {
    return o ? ORIGIN_LABEL[o] : '–';
  }

  protected stackName(id: string): string {
    return this.store.stacks().find((s) => s.id === id)?.name ?? id;
  }

  protected logText(id: string): string {
    return (LOGS[id] ?? []).map((l) => `[${l.t}] ${l.text}`).join('\n') || '(keine Logs in der Demo)';
  }

  protected pick(r: Row): void {
    if (r.stackId) {
      this.store.openStack(r.stackId);
      return;
    }
    this.selectedId.set(r.svc.id);
  }

  protected limited(c: StandaloneContainer): boolean {
    return c.origin === 'unraid' || c.origin === 'unklar';
  }

  protected startEdit(c: StandaloneContainer): void {
    if (this.limited(c)) return;
    this.editingId.set(c.id);
    this.editImage = `${c.image}:${c.tag}`;
    this.editPorts = c.ports.join(', ');
    this.editEnv = 'TZ=Europe/Berlin';
    this.editOpen.set(true);
  }

  protected saveEdit(): void {
    const c = this.editing();
    if (!c || !this.editImage.trim()) return;
    const [image, tag] = splitImage(this.editImage.trim());
    const ports = this.editPorts.split(',').map((p) => p.trim()).filter(Boolean);
    this.editOpen.set(false);
    this.store.runAction({
      title: `Recreate ${c.name}`,
      hostId: c.hostId,
      steps: ['Prüfung', 'Image-Pull/Build', 'Erstellen/Austausch', 'Start', 'Zustandsprüfung'],
      services: [c.name],
      onDone: () => this.store.standalone.update((list) => list.map((x) => (x.id === c.id ? { ...x, image, tag, ports } : x))),
    });
  }
}
