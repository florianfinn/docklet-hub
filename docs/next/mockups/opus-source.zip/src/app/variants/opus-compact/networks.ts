// Docklet Design Lab – opus-compact · Netzwerktopologie
// Live-Status und Auslastung je Service (simuliert), Netzwerkzuordnung (durchgezogen) und beobachtete Kommunikation
// (gestrichelte Bögen) getrennt schaltbar. KEINE Durchsatzzahlen. Zoom, Verschieben, Filter, Detailauswahl.
// Die optionale Animation ist rein dekorativ und zeigt keinen gemessenen Datenverkehr.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { OBSERVED_LINKS, type NetworkDef, type Service } from './data';
import { CxIcon } from './icon';
import { CxStore } from './store';
import { CxHost, CxMeter, CxStatus } from './ui';

interface TNode {
  id: string;
  kind: 'net' | 'svc';
  label: string;
  sub: string;
  x: number;
  y: number;
  hostId: string;
  color: string;
  svc: Service | null;
  match: boolean;
}

interface TEdge {
  id: string;
  from: string;
  to: string;
  d: string;
  color: string;
  kind: 'member' | 'observed';
  isInternal: boolean;
}

const W = 780;
const BAND = 184;

@Component({
  selector: 'cx-networks',
  imports: [ZardButtonComponent, CxIcon, CxHost, CxMeter, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: `
    .node { cursor: pointer; outline: none; }
    .node:focus-visible .ring { stroke-width: 3; stroke-dasharray: 3 2; }
    .deco { animation: deco 2.4s ease-in-out infinite; transform-box: fill-box; transform-origin: center; }
    @keyframes deco { 50% { opacity: .25; transform: scale(1.18); } }
    .pan { cursor: grab; touch-action: none; }
    .pan:active { cursor: grabbing; }
    @media (prefers-reduced-motion: reduce) { .deco { animation: none; } }
  `,
  template: `
    <div class="grid items-start gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
      <section class="min-w-0 rounded-lg border border-zinc-200 bg-white" aria-labelledby="topo-title">
        <header class="flex flex-wrap items-center gap-2 border-b border-zinc-100 px-3 py-2">
          <h2 id="topo-title" class="text-[13px] font-semibold">Topologie</h2>
          <span class="text-[12px] text-zinc-500">{{ nets().length }} Netzwerke · {{ svcCount() }} Services</span>
          <div class="relative ml-auto">
            <cx-icon name="search" [size]="13" class="pointer-events-none absolute left-2 top-2 text-zinc-400" />
            <input type="search" class="h-7 w-40 rounded-md border border-zinc-200 bg-white pl-7 pr-2 text-[12px] outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="Knoten suchen" aria-label="Knoten suchen" [value]="query()" (input)="query.set(v($event))" />
          </div>
          <div class="flex rounded-md border border-zinc-200 p-0.5" role="group" aria-label="Zoom">
            <button type="button" class="grid size-6 place-items-center rounded text-zinc-600 hover:bg-zinc-100" aria-label="Verkleinern" (click)="zoomBy(-0.2)"><cx-icon name="zoomOut" [size]="14" /></button>
            <span class="grid w-10 place-items-center font-mono text-[11px] tabular-nums text-zinc-600" aria-live="polite">{{ round(zoom() * 100) }}%</span>
            <button type="button" class="grid size-6 place-items-center rounded text-zinc-600 hover:bg-zinc-100" aria-label="Vergrößern" (click)="zoomBy(0.2)"><cx-icon name="zoomIn" [size]="14" /></button>
            <button type="button" class="grid size-6 place-items-center rounded text-zinc-600 hover:bg-zinc-100" aria-label="Ansicht zurücksetzen" (click)="resetView()"><cx-icon name="maximize" [size]="13" /></button>
          </div>
        </header>
        <div class="flex flex-wrap items-center gap-x-4 gap-y-1.5 border-b border-zinc-100 px-3 py-1.5 text-[12px]" role="group" aria-label="Ebenen und Filter">
          <label class="flex items-center gap-1.5"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="showMember()" (change)="showMember.set(!showMember())" /><span class="h-0 w-4 border-t-2 border-zinc-500"></span>Netzwerkzuordnung</label>
          <label class="flex items-center gap-1.5"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="showObserved()" (change)="showObserved.set(!showObserved())" /><span class="h-0 w-4 border-t-2 border-dashed border-fuchsia-500"></span>Beobachtete Kommunikation</label>
          <label class="flex items-center gap-1.5"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="onlyProblems()" (change)="onlyProblems.set(!onlyProblems())" />Nur Probleme hervorheben</label>
          <label class="ml-auto flex items-center gap-1.5 text-zinc-600" title="Rein gestalterisch, kein Messwert"><input type="checkbox" class="size-3.5 accent-zinc-900" [checked]="deco()" (change)="deco.set(!deco())" />Dekorative Animation <span class="rounded border border-zinc-200 px-1 text-[10.5px]">kein Traffic-Indikator</span></label>
        </div>
        <div class="overflow-hidden" (keydown)="onKey($event)">
          <svg
            [attr.viewBox]="viewBox()"
            class="pan block select-none"
            [attr.height]="height()"
            width="100%"
            role="group"
            aria-label="Netzwerktopologie. Knoten mit Tab erreichbar, Enter zeigt Details, Plus/Minus zoomt, Ziehen verschiebt."
            (pointerdown)="panStart($event)"
            (pointermove)="panMove($event)"
            (pointerup)="panEnd($event)"
            (pointercancel)="panEnd($event)"
          >
            @for (b of bands(); track b.hostId) {
              <svg:rect x="6" [attr.y]="b.y + 6" [attr.width]="width - 12" [attr.height]="band - 12" rx="10" [attr.fill]="b.color" fill-opacity="0.05" [attr.stroke]="b.color" stroke-opacity="0.3" />
              <svg:rect x="16" [attr.y]="b.y + 16" width="5" height="16" rx="2" [attr.fill]="b.color" />
              <svg:text x="27" [attr.y]="b.y + 29" font-size="12" font-weight="600" class="fill-zinc-800">{{ b.name }}</svg:text>
              <svg:text [attr.x]="width - 18" [attr.y]="b.y + 29" font-size="10" text-anchor="end" class="fill-zinc-500">{{ b.status }}</svg:text>
            }
            @for (e of edges(); track e.id) {
              <svg:path
                [attr.d]="e.d"
                fill="none"
                [attr.stroke]="e.kind === 'observed' ? '#c026d3' : e.color"
                [attr.stroke-width]="isLit(e) ? 2.6 : e.kind === 'observed' ? 1.8 : 1.4"
                [attr.stroke-opacity]="edgeOpacity(e)"
                [attr.stroke-dasharray]="e.kind === 'observed' ? '6 4' : e.isInternal ? '3 3' : null"
              />
            }
            @for (n of nodes(); track n.id) {
              <svg:g
                class="node"
                tabindex="0"
                role="button"
                [attr.aria-label]="ariaFor(n)"
                [attr.aria-pressed]="selected() === n.id"
                [attr.opacity]="nodeOpacity(n)"
                (click)="select(n.id)"
                (pointerdown)="$event.stopPropagation()"
                (keydown.enter)="select(n.id)"
                (keydown.space)="select(n.id); $event.preventDefault()"
              >
                @if (n.kind === 'net') {
                  <svg:rect class="ring fill-white" [attr.x]="n.x - 62" [attr.y]="n.y - 17" width="124" height="34" rx="6" [attr.stroke]="selected() === n.id ? 'currentColor' : n.color" [attr.stroke-width]="selected() === n.id ? 2.2 : 1.25" />
                  <svg:text [attr.x]="n.x" [attr.y]="n.y - 1" text-anchor="middle" font-size="11.5" font-weight="600" class="fill-zinc-900" font-family="ui-monospace, monospace">{{ n.label }}</svg:text>
                  <svg:text [attr.x]="n.x" [attr.y]="n.y + 11" text-anchor="middle" font-size="9.5" class="fill-zinc-500">{{ n.sub }}</svg:text>
                } @else {
                  @if (deco() && n.svc?.state === 'running') {
                    <svg:circle class="deco" [attr.cx]="n.x" [attr.cy]="n.y" r="21" fill="none" [attr.stroke]="n.color" stroke-opacity="0.35" stroke-width="2" />
                  }
                  <svg:circle class="ring fill-white" [attr.cx]="n.x" [attr.cy]="n.y" r="17" [attr.stroke]="statusColor(n)" [attr.stroke-width]="selected() === n.id ? 3 : 1.5" [attr.stroke-dasharray]="n.svc?.state === 'exited' ? '3 3' : null" />
                  <svg:circle [attr.cx]="n.x" [attr.cy]="n.y" r="17" fill="none" [attr.stroke]="n.color" stroke-width="3" pathLength="100" [attr.stroke-dasharray]="load(n) + ' 100'" [attr.transform]="'rotate(-90 ' + n.x + ' ' + n.y + ')'" stroke-linecap="round" />
                  <svg:path [attr.d]="boxPath(n.x, n.y)" fill="none" [attr.stroke]="statusColor(n)" stroke-width="1.4" stroke-linejoin="round" />
                  @if (n.svc?.health === 'unhealthy') { <svg:circle [attr.cx]="n.x + 13" [attr.cy]="n.y - 13" r="4.5" fill="#dc2626" /> }
                  <svg:text [attr.x]="n.x" [attr.y]="n.y + 31" text-anchor="middle" font-size="11" font-weight="600" class="fill-zinc-900">{{ n.label }}</svg:text>
                  <svg:text [attr.x]="n.x" [attr.y]="n.y + 43" text-anchor="middle" font-size="9.5" [attr.class]="n.svc?.health === 'unhealthy' ? 'fill-red-700' : 'fill-zinc-500'">{{ n.sub }}</svg:text>
                }
              </svg:g>
            }
            @if (bands().length === 0) {
              <svg:text [attr.x]="width / 2" y="60" text-anchor="middle" font-size="12" class="fill-zinc-500">Keine Netzwerke für den aktuellen Hostfilter.</svg:text>
            }
          </svg>
        </div>
        <footer class="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-zinc-100 px-3 py-1.5 text-[11.5px] text-zinc-600">
          <span class="inline-flex items-center gap-1.5"><span class="size-3 rounded-full border-2 border-zinc-400"></span>Service, Bogen = CPU-Anteil</span>
          <span class="inline-flex items-center gap-1.5"><span class="size-2.5 rounded-full bg-red-600"></span>unhealthy</span>
          <span class="inline-flex items-center gap-1.5"><span class="h-0 w-4 border-t border-dashed border-zinc-500"></span>internes Netz / gestoppt</span>
          <span class="ml-auto">Live-Status simuliert · keine Durchsatzwerte</span>
        </footer>
      </section>

      <aside class="rounded-lg border border-zinc-200 bg-white xl:sticky xl:top-16" aria-live="polite" aria-label="Details">
        @if (selNet(); as n) {
          @let h = store.host(n.hostId);
          <div class="border-b border-zinc-100 p-3">
            <div class="flex items-center gap-2"><cx-icon name="network" [size]="16" /><h2 class="font-mono text-[14px] font-semibold">{{ n.name }}</h2></div>
            <div class="mt-1 flex flex-wrap gap-1.5"><cx-host [name]="h.name" [color]="h.color" />@if (n.isInternal) { <span class="rounded-md border border-zinc-300 px-1.5 text-[11px] text-zinc-700">intern</span> }</div>
          </div>
          <dl class="grid grid-cols-[90px_1fr] gap-x-3 gap-y-1 p-3 text-[12.5px]">
            <dt class="text-zinc-500">Treiber</dt><dd class="font-mono">{{ n.driver }}</dd>
            <dt class="text-zinc-500">Subnetz</dt><dd class="font-mono">{{ n.subnet }}</dd>
            <dt class="text-zinc-500">Gateway</dt><dd class="font-mono">{{ n.gateway }}</dd>
            <dt class="text-zinc-500">Internet</dt><dd>{{ n.isInternal ? 'kein Zugriff (internal)' : 'erlaubt' }}</dd>
          </dl>
          <div class="px-3 pb-3">
            <h3 class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Zugeordnete Services</h3>
            <ul class="space-y-1">
              @for (m of n.members; track m; let i = $index) {
                <li><button type="button" class="flex w-full items-center gap-2 rounded-md border border-zinc-200 px-2 py-1.5 text-left hover:bg-zinc-50" (click)="select('svc:' + m)"><span class="size-2 rounded-full" [class]="dotFor(m)"></span><span class="flex-1">{{ svcName(m) }}</span><span class="font-mono text-[11px] text-zinc-500">{{ ip(n, i) }}</span></button></li>
              }
            </ul>
            <p class="mt-2 text-[11.5px] text-zinc-500">Zuordnung heißt: Container sind am Netz angeschlossen – nicht, dass sie kommunizieren.</p>
          </div>
        } @else if (selSvc(); as s) {
          @let h = store.host(s.hostId);
          <div class="border-b border-zinc-100 p-3">
            <div class="flex items-center gap-2"><cx-icon name="box" [size]="16" /><h2 class="text-[14px] font-semibold">{{ s.svc.name }}</h2></div>
            <div class="mt-1 flex flex-wrap gap-1.5"><cx-host [name]="h.name" [color]="h.color" /><cx-status [kind]="s.svc.health === 'unhealthy' ? 'unhealthy' : s.svc.state" /></div>
          </div>
          <div class="space-y-1.5 p-3 text-[12px]">
            <div class="grid grid-cols-[40px_1fr_64px] items-center gap-2"><span class="text-zinc-500">CPU</span><cx-meter [value]="clampPct(s.svc.cpu)" [color]="h.color" label="CPU" /><span class="text-right font-mono tabular-nums">{{ s.svc.cpu.toFixed(1) }}%</span></div>
            <div class="grid grid-cols-[40px_1fr_64px] items-center gap-2"><span class="text-zinc-500">RAM</span><cx-meter [value]="clampPct(s.svc.memMb / 40)" color="#71717a" label="RAM" /><span class="text-right font-mono tabular-nums">{{ s.svc.memMb }} MB</span></div>
          </div>
          <dl class="grid grid-cols-[90px_1fr] gap-x-3 gap-y-1 px-3 pb-3 text-[12.5px]">
            <dt class="text-zinc-500">Image</dt><dd class="break-all font-mono">{{ s.svc.image }}:{{ s.svc.tag }}</dd>
            <dt class="text-zinc-500">Stack</dt><dd>{{ stackName(s.stackId) }}</dd>
            <dt class="text-zinc-500">Ports</dt><dd class="font-mono">{{ s.svc.ports.join(', ') || '–' }}</dd>
          </dl>
          <div class="px-3 pb-3">
            <h3 class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Beobachtete Kommunikation</h3>
            <ul class="space-y-1 text-[12px]">
              @for (l of observedFor(s.svc.id); track l.other) {
                <li class="flex items-center gap-1.5"><span class="h-0 w-3 border-t-2 border-dashed border-fuchsia-500"></span><button type="button" class="font-medium hover:underline" (click)="select('svc:' + l.other)">{{ svcName(l.other) }}</button><span class="text-zinc-500">· {{ l.note }}</span></li>
              } @empty {
                <li class="text-zinc-500">Keine beobachtet.</li>
              }
            </ul>
            <p class="mt-1.5 text-[11px] text-zinc-500">Nur „gesehen / nicht gesehen“ – Container-Metriken liefern keinen Traffic pro Verbindung.</p>
          </div>
          <div class="flex flex-wrap gap-1.5 px-3 pb-3">
            @if (s.stackId) {
              <button z-button zSize="sm" type="button" (click)="store.openStack(s.stackId)"><cx-icon name="layers" [size]="13" />Stack öffnen</button>
            }
            @for (net of s.svc.networks; track net) {
              <button z-button zType="outline" zSize="sm" type="button" (click)="selectNet(net, s.hostId)"><cx-icon name="network" [size]="13" />{{ net }}</button>
            }
          </div>
        } @else {
          <div class="p-4 text-[12.5px] text-zinc-600">
            <cx-icon name="info" [size]="16" class="text-zinc-400" />
            <p class="mt-1">Knoten anklicken oder per Tab fokussieren und Enter drücken. Verbindungen des gewählten Knotens werden hervorgehoben. Ziehen verschiebt die Ansicht, Plus/Minus zoomt.</p>
          </div>
        }
      </aside>
    </div>

    <section class="mt-3 overflow-x-auto rounded-lg border border-zinc-200 bg-white" aria-label="Netzwerkliste">
      <table class="w-full min-w-[560px] text-left text-[12.5px]">
        <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500">
          <tr><th class="px-3 py-2 font-semibold">Netzwerk</th><th class="px-3 py-2 font-semibold">Host</th><th class="px-3 py-2 font-semibold">Treiber</th><th class="px-3 py-2 font-semibold">Subnetz</th><th class="px-3 py-2 font-semibold">Services</th></tr>
        </thead>
        <tbody>
          @for (n of nets(); track n.id) {
            @let h = store.host(n.hostId);
            <tr class="border-b border-zinc-100 last:border-0 hover:bg-zinc-50" [class]="selected() === 'net:' + n.id ? 'bg-zinc-50' : ''">
              <td class="px-3 py-1.5"><button type="button" class="font-mono font-medium hover:underline" (click)="select('net:' + n.id)">{{ n.name }}</button></td>
              <td class="px-3 py-1.5"><cx-host [name]="h.name" [color]="h.color" /></td>
              <td class="px-3 py-1.5 font-mono">{{ n.driver }}{{ n.isInternal ? ' · intern' : '' }}</td>
              <td class="px-3 py-1.5 font-mono">{{ n.subnet }}</td>
              <td class="px-3 py-1.5">{{ n.members.length }}</td>
            </tr>
          }
        </tbody>
      </table>
    </section>
  `,
})
export class CxNetworks {
  protected readonly store = inject(CxStore);
  protected readonly width = W;
  protected readonly band = BAND;
  protected readonly selected = signal<string | null>(null);
  protected readonly query = signal('');
  protected readonly showMember = signal(true);
  protected readonly showObserved = signal(true);
  protected readonly onlyProblems = signal(false);
  protected readonly deco = signal(false);
  protected readonly zoom = signal(1);
  protected readonly pan = signal({ x: 0, y: 0 });
  private drag: { x: number; y: number; px: number; py: number; w: number } | null = null;

  protected readonly nets = computed(() => this.store.networks().filter((n) => this.store.visible(n.hostId)));

  private readonly svcIndex = computed(() => {
    const map = new Map<string, { svc: Service; hostId: string; stackId: string | null }>();
    for (const i of this.store.allServices()) map.set(i.svc.id, i);
    return map;
  });

  protected readonly bands = computed(() => {
    const hostIds = [...new Set(this.nets().map((n) => n.hostId))];
    return hostIds.map((id, i) => {
      const h = this.store.host(id);
      return { hostId: id, name: h.name, color: h.color, y: i * BAND, status: h.status === 'online' ? `online · ${h.cpu}% CPU` : h.status };
    });
  });

  protected readonly height = computed(() => Math.max(1, this.bands().length) * BAND);
  protected readonly viewBox = computed(() => {
    const z = this.zoom();
    const p = this.pan();
    return `${p.x.toFixed(1)} ${p.y.toFixed(1)} ${(W / z).toFixed(1)} ${(this.height() / z).toFixed(1)}`;
  });

  private readonly layout = computed(() => {
    const nodes: TNode[] = [];
    const edges: TEdge[] = [];
    const q = this.query().trim().toLowerCase();
    const pos = new Map<string, { x: number; y: number }>();
    for (const b of this.bands()) {
      const nets = this.nets().filter((n) => n.hostId === b.hostId);
      const members = [...new Set(nets.flatMap((n) => n.members))];
      const netY = b.y + 64;
      const svcY = b.y + 122;
      const netPos = new Map<string, number>();
      nets.forEach((n, i) => {
        const x = 110 + ((W - 220) * (i + 0.5)) / nets.length;
        netPos.set(n.id, x);
        nodes.push({ id: 'net:' + n.id, kind: 'net', label: n.name, sub: n.subnet, x, y: netY, hostId: b.hostId, color: b.color, svc: null, match: !q || n.name.includes(q) });
      });
      members.forEach((m, i) => {
        const x = 70 + ((W - 140) * (i + 0.5)) / members.length;
        const info = this.svcIndex().get(m);
        const svc = info?.svc ?? null;
        pos.set(m, { x, y: svcY });
        const sub = svc?.health === 'unhealthy' ? 'unhealthy' : svc?.state === 'exited' ? 'gestoppt' : `${(svc?.cpu ?? 0).toFixed(1)}% CPU`;
        nodes.push({ id: 'svc:' + m, kind: 'svc', label: svc?.name ?? m, sub, x, y: svcY, hostId: b.hostId, color: b.color, svc, match: !q || (svc?.name ?? m).toLowerCase().includes(q) });
        for (const n of nets.filter((nn) => nn.members.includes(m))) {
          const nx = netPos.get(n.id) ?? x;
          edges.push({ id: `${m}->${n.id}`, from: 'svc:' + m, to: 'net:' + n.id, d: `M${x} ${svcY - 17} L${nx} ${netY + 17}`, color: b.color, kind: 'member', isInternal: n.isInternal });
        }
      });
    }
    for (const l of OBSERVED_LINKS) {
      const a = pos.get(l.from);
      const c = pos.get(l.to);
      if (!a || !c) continue;
      const mx = (a.x + c.x) / 2;
      const my = Math.max(a.y, c.y) + 34 + Math.abs(a.x - c.x) * 0.06;
      edges.push({ id: `obs:${l.from}->${l.to}`, from: 'svc:' + l.from, to: 'svc:' + l.to, d: `M${a.x} ${a.y + 17} Q${mx} ${my} ${c.x} ${c.y + 17}`, color: '#c026d3', kind: 'observed', isInternal: false });
    }
    return { nodes, edges };
  });

  protected readonly nodes = computed(() => this.layout().nodes);
  protected readonly edges = computed(() =>
    this.layout().edges.filter((e) => (e.kind === 'member' ? this.showMember() : this.showObserved())),
  );
  protected readonly svcCount = computed(() => this.nodes().filter((n) => n.kind === 'svc').length);

  protected readonly selNet = computed<NetworkDef | null>(() => {
    const s = this.selected();
    return s?.startsWith('net:') ? (this.store.networks().find((n) => n.id === s.slice(4)) ?? null) : null;
  });

  protected readonly selSvc = computed(() => {
    const s = this.selected();
    return s?.startsWith('svc:') ? (this.svcIndex().get(s.slice(4)) ?? null) : null;
  });

  protected v(e: Event): string {
    return (e.target as HTMLInputElement).value;
  }

  protected round(n: number): number {
    return Math.round(n);
  }

  protected clampPct(n: number): number {
    return Math.max(0, Math.min(100, Math.round(n)));
  }

  protected select(id: string): void {
    this.selected.set(this.selected() === id ? null : id);
  }

  protected selectNet(name: string, hostId: string): void {
    const n = this.store.networks().find((x) => x.name === name && x.hostId === hostId);
    if (n) this.selected.set('net:' + n.id);
  }

  protected isLit(e: TEdge): boolean {
    const s = this.selected();
    return !!s && (e.from === s || e.to === s);
  }

  private related(id: string): boolean {
    const s = this.selected();
    if (!s || s === id) return true;
    return this.edges().some((e) => (e.from === s && e.to === id) || (e.to === s && e.from === id));
  }

  private problem(n: TNode): boolean {
    return n.kind === 'svc' && (n.svc?.health === 'unhealthy' || n.svc?.state === 'exited');
  }

  protected nodeOpacity(n: TNode): number {
    if (!n.match) return 0.2;
    if (this.onlyProblems() && !this.problem(n)) return 0.3;
    if (this.selected() && !this.related(n.id)) return 0.35;
    return 1;
  }

  protected edgeOpacity(e: TEdge): number {
    if (this.selected()) return this.isLit(e) ? 0.95 : 0.12;
    if (this.onlyProblems()) return 0.2;
    return e.kind === 'observed' ? 0.7 : 0.55;
  }

  protected statusColor(n: TNode): string {
    const s = n.svc;
    if (!s) return n.color;
    if (s.health === 'unhealthy') return '#dc2626';
    if (s.state === 'restarting') return '#d97706';
    if (s.state === 'exited') return '#a1a1aa';
    return '#059669';
  }

  protected load(n: TNode): number {
    return Math.max(2, Math.min(100, Math.round(n.svc?.cpu ?? 0)));
  }

  protected ariaFor(n: TNode): string {
    if (n.kind === 'net') return `Netzwerk ${n.label}, ${n.sub}`;
    return `Service ${n.label}, ${n.sub}`;
  }

  protected dotFor(id: string): string {
    const s = this.svcIndex().get(id)?.svc;
    if (s?.health === 'unhealthy') return 'bg-red-500';
    return s?.state === 'running' ? 'bg-emerald-500' : 'bg-zinc-300';
  }

  protected observedFor(id: string): { other: string; note: string }[] {
    return OBSERVED_LINKS.filter((l) => l.from === id || l.to === id).map((l) => ({ other: l.from === id ? l.to : l.from, note: l.note }));
  }

  protected svcName(id: string): string {
    return this.svcIndex().get(id)?.svc.name ?? id;
  }

  protected stackName(id: string | null): string {
    return id ? (this.store.stacks().find((s) => s.id === id)?.name ?? id) : 'Einzelcontainer';
  }

  protected ip(n: NetworkDef, i: number): string {
    const base = n.subnet.split('/')[0].split('.').slice(0, 3).join('.');
    return `${base}.${i + 2}`;
  }

  protected boxPath(x: number, y: number): string {
    return `M${x - 6} ${y - 3}l6 -3.5 6 3.5v6.5l-6 3.5 -6 -3.5z M${x - 6} ${y - 3}l6 3.5 6 -3.5 M${x} ${y + 0.5}v6.5`;
  }

  /* ---------------------------------------------------------- Zoom und Pan */

  protected zoomBy(d: number): void {
    const z = Math.min(2.4, Math.max(0.6, Math.round((this.zoom() + d) * 10) / 10));
    const cw = W / this.zoom();
    const ch = this.height() / this.zoom();
    const p = this.pan();
    const nw = W / z;
    const nh = this.height() / z;
    this.pan.set({ x: p.x + (cw - nw) / 2, y: p.y + (ch - nh) / 2 });
    this.zoom.set(z);
  }

  protected resetView(): void {
    this.zoom.set(1);
    this.pan.set({ x: 0, y: 0 });
  }

  protected onKey(e: KeyboardEvent): void {
    if (e.key === '+' || e.key === '=') this.zoomBy(0.2);
    else if (e.key === '-') this.zoomBy(-0.2);
    else if (e.key === '0') this.resetView();
  }

  protected panStart(e: PointerEvent): void {
    const el = e.currentTarget as SVGSVGElement;
    this.drag = { x: e.clientX, y: e.clientY, px: this.pan().x, py: this.pan().y, w: el.clientWidth || W };
    el.setPointerCapture(e.pointerId);
  }

  protected panMove(e: PointerEvent): void {
    if (!this.drag) return;
    const scale = W / this.zoom() / this.drag.w;
    this.pan.set({ x: this.drag.px - (e.clientX - this.drag.x) * scale, y: this.drag.py - (e.clientY - this.drag.y) * scale });
  }

  protected panEnd(e: PointerEvent): void {
    if (!this.drag) return;
    (e.currentTarget as SVGSVGElement).releasePointerCapture(e.pointerId);
    this.drag = null;
  }
}
