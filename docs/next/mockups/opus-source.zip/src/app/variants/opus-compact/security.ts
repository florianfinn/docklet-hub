// Docklet Design Lab – opus-compact · Sicherheit (nach Arcane security-overview)
// Risiko-Gauge, Verlauf der Scanzeitpunkte, Schweregrad- und Exposure-Anteile (Share-Bars), Kennzahlen-Leiste,
// Top-Befunde, Befunde je Stack und Image-Tabelle. Scans optional, manuell oder geplant, getrennt von Updates.
// Alle Befunde synthetisch (DEMO-Kennungen, keine echten CVEs).
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import { SEED_FINDING_LIST, type ImageFindings, type Severity } from './data';
import { CxIcon } from './icon';
import { CxStore } from './store';
import { CxDialog, CxHost } from './ui';

const SEV: { id: Severity; label: string; bar: string; badge: string }[] = [
  { id: 'kritisch', label: 'Kritisch', bar: 'bg-red-600', badge: 'border-red-500/25 bg-red-500/10 text-red-700' },
  { id: 'hoch', label: 'Hoch', bar: 'bg-orange-500', badge: 'border-orange-500/25 bg-orange-500/10 text-orange-700' },
  { id: 'mittel', label: 'Mittel', bar: 'bg-amber-400', badge: 'border-amber-500/30 bg-amber-500/10 text-amber-700' },
  { id: 'niedrig', label: 'Niedrig', bar: 'bg-lime-500', badge: 'border-lime-500/30 bg-lime-500/10 text-zinc-700' },
];

interface ImgRow extends ImageFindings {
  hosts: string[];
  running: number;
  total: number;
}

@Component({
  selector: 'cx-security',
  imports: [ZardButtonComponent, CxIcon, CxDialog, CxHost],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mb-3 flex flex-wrap items-center gap-2">
      <p class="text-[12.5px] text-zinc-600">
        @if (store.scanEnabled()) { Letzter Scan {{ store.lastScan() }} · Zeitplan {{ store.scanSchedule() }} · {{ rows().length }} Images im Filter }
        @else { Schwachstellenscans sind deaktiviert. }
      </p>
      <div class="ml-auto flex gap-1.5">
        <button z-button zType="outline" zSize="sm" type="button" (click)="store.go('settings')"><cx-icon name="settings" [size]="13" />Scan-Einstellungen</button>
        @if (store.scanEnabled()) {
          <button z-button zSize="sm" type="button" (click)="store.runScan()"><cx-icon name="scan" [size]="13" />Jetzt scannen</button>
        }
      </div>
    </div>

    @if (!store.scanEnabled()) {
      <div class="flex flex-col items-center gap-3 rounded-lg border border-zinc-200 bg-white py-16 text-center">
        <cx-icon name="scan" [size]="40" class="text-zinc-300" />
        <p class="max-w-md text-[13px] text-zinc-600">Scans sind optional und unabhängig von der Update-Erkennung. Aktiviert laufen sie nach Zeitplan und jederzeit manuell.</p>
        <button z-button zSize="sm" type="button" (click)="enable()"><cx-icon name="shield" [size]="13" />Scans aktivieren</button>
      </div>
    } @else {
      <!-- Übersicht: Gauge + Verlauf + Anteile -->
      <section class="mb-3 grid items-center gap-6 rounded-lg border border-zinc-200 bg-white p-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        <div class="flex flex-col items-center gap-1 lg:border-r lg:border-zinc-200 lg:pr-6">
          <svg viewBox="0 0 120 70" class="w-full max-w-[260px]" role="meter" aria-valuemin="0" aria-valuemax="100" [attr.aria-valuenow]="risk()" [attr.aria-label]="'Risikowert ' + risk() + ' von 100, ' + band().label">
            <path d="M10 62 A50 50 0 0 1 110 62" fill="none" class="stroke-zinc-200" stroke-width="10" stroke-linecap="round" />
            <path d="M10 62 A50 50 0 0 1 110 62" fill="none" [attr.stroke]="band().color" stroke-width="10" stroke-linecap="round" pathLength="100" [attr.stroke-dasharray]="risk() + ' 100'" class="motion-safe:transition-[stroke-dasharray] motion-safe:duration-700" />
            <text x="60" y="54" text-anchor="middle" font-size="22" font-weight="700" class="fill-zinc-900">{{ risk() }}</text>
            <text x="60" y="67" text-anchor="middle" font-size="7.5" class="fill-zinc-500">von 100</text>
          </svg>
          <span class="rounded-md border px-2 py-px text-[12px] font-medium" [class]="band().badge">Risiko {{ band().label }}</span>
          <p class="max-w-xs text-center text-[11.5px] text-zinc-500">Gewichtet nach Schweregrad und ob das Image in laufenden Containern steckt (Demo-Formel).</p>
        </div>
        <div class="min-w-0 space-y-5">
          <div>
            <div class="mb-1 flex items-end justify-between">
              <h3 class="text-[13px] font-medium">Befunde je Scan (7 Tage)</h3>
              <span class="text-[11.5px] text-zinc-500">● geplant · ◆ manuell</span>
            </div>
            <svg viewBox="0 0 300 92" class="h-[100px] w-full" role="img" [attr.aria-label]="trendLabel()">
              @for (g of [0, 1, 2]; track g) { <svg:line x1="8" x2="292" [attr.y1]="12 + g * 30" [attr.y2]="12 + g * 30" class="stroke-zinc-200" stroke-width="1" /> }
              <polyline [attr.points]="trendPoints()" fill="none" stroke="#6366f1" stroke-width="2" stroke-linejoin="round" />
              @for (p of trend(); track $index) {
                @if (p.manual) {
                  <svg:rect [attr.x]="p.x - 3.5" [attr.y]="p.y - 3.5" width="7" height="7" fill="#6366f1" [attr.transform]="'rotate(45 ' + p.x + ' ' + p.y + ')'"><svg:title>{{ p.day }} {{ p.time }} (manuell): {{ p.total }} Befunde</svg:title></svg:rect>
                } @else {
                  <svg:circle [attr.cx]="p.x" [attr.cy]="p.y" r="3" fill="#6366f1"><svg:title>{{ p.day }} {{ p.time }}: {{ p.total }} Befunde</svg:title></svg:circle>
                }
                <svg:text [attr.x]="p.x" y="90" text-anchor="middle" font-size="8" class="fill-zinc-500">{{ p.day }} {{ p.time }}</svg:text>
              }
            </svg>
          </div>
          <div class="grid gap-5 sm:grid-cols-2">
            <div class="min-w-0">
              <h4 class="mb-2 text-[12.5px] text-zinc-600">Schweregrade</h4>
              <div class="flex h-2 gap-0.5">
                @for (s of sevTotals(); track s.id) {
                  @if (s.n > 0) { <div class="h-full rounded-full" [class]="s.bar" [style.flex-grow]="s.n" [title]="s.label + ': ' + s.n"></div> }
                }
              </div>
              <ul class="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-zinc-600">
                @for (s of sevTotals(); track s.id) { <li class="flex items-center gap-1.5"><span class="size-2 rounded-full" [class]="s.bar"></span>{{ s.label }} <b class="tabular-nums text-zinc-900">{{ s.n }}</b></li> }
              </ul>
            </div>
            <div class="min-w-0">
              <h4 class="mb-2 text-[12.5px] text-zinc-600">Exposition (hoch + kritisch)</h4>
              <div class="flex h-2 gap-0.5">
                @for (e of exposure(); track e.label) {
                  @if (e.n > 0) { <div class="h-full rounded-full" [class]="e.bar" [style.flex-grow]="e.n" [title]="e.label + ': ' + e.n"></div> }
                }
              </div>
              <ul class="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-zinc-600">
                @for (e of exposure(); track e.label) { <li class="flex items-center gap-1.5"><span class="size-2 rounded-full" [class]="e.bar"></span>{{ e.label }} <b class="tabular-nums text-zinc-900">{{ e.n }}</b></li> }
              </ul>
            </div>
          </div>
        </div>
      </section>

      <!-- Kennzahlenleiste -->
      <div class="mb-3 grid grid-cols-2 divide-zinc-200 overflow-hidden rounded-lg border border-zinc-200 bg-white sm:grid-cols-5 sm:divide-x">
        @for (s of sevTotals(); track s.id) {
          <div class="px-3 py-2.5"><div class="flex items-center gap-1.5 text-[11.5px] text-zinc-500"><span class="size-2 rounded-full" [class]="s.bar"></span>{{ s.label }}</div><div class="text-[20px] font-semibold tabular-nums">{{ s.n }}</div></div>
        }
        <div class="px-3 py-2.5"><div class="text-[11.5px] text-zinc-500">Images gescannt</div><div class="text-[20px] font-semibold tabular-nums">{{ rows().length }}</div></div>
      </div>

      <div class="mb-3 grid gap-3 lg:grid-cols-2">
        <section class="rounded-lg border border-zinc-200 bg-white p-3" aria-labelledby="sec-top">
          <h3 id="sec-top" class="mb-1 text-[13px] font-medium">Wichtigste Befunde</h3>
          <ol class="divide-y divide-zinc-100">
            @for (f of topFindings(); track f.id; let i = $index) {
              <li>
                <button type="button" class="grid w-full grid-cols-[18px_minmax(0,1fr)_auto] items-center gap-2 rounded-md px-1 py-2 text-left hover:bg-zinc-50" (click)="openImage(f.image)">
                  <span class="text-[11px] tabular-nums text-zinc-500">{{ i + 1 }}</span>
                  <span class="min-w-0">
                    <span class="flex items-center gap-1.5"><span class="size-2 rounded-full" [class]="sevMeta(f.severity).bar"></span><span class="font-mono text-[12.5px]">{{ f.id }}</span></span>
                    <span class="block truncate font-mono text-[11px] text-zinc-500">{{ f.pkg }} {{ f.installed }} → {{ f.fixed }} · {{ f.image }}</span>
                  </span>
                  <span class="rounded-md border px-1.5 text-[11px] font-medium" [class]="sevMeta(f.severity).badge">{{ sevMeta(f.severity).label }}</span>
                </button>
              </li>
            } @empty { <li class="py-6 text-center text-zinc-500">Keine Befunde im Filter.</li> }
          </ol>
        </section>
        <section class="rounded-lg border border-zinc-200 bg-white p-3" aria-labelledby="sec-stack">
          <h3 id="sec-stack" class="mb-2 text-[13px] font-medium">Befunde je Stack</h3>
          <ul class="space-y-2.5">
            @for (s of perStack(); track s.name) {
              <li>
                <div class="mb-1 flex items-center gap-2 text-[12.5px]"><span class="size-2 rounded-sm" [style.background-color]="s.color"></span><span class="font-medium">{{ s.name }}</span><span class="ml-auto tabular-nums text-zinc-600">{{ s.total }}</span></div>
                <div class="flex h-2 gap-0.5 rounded-full bg-zinc-100" [attr.aria-label]="s.name + ': ' + s.total + ' Befunde'">
                  @for (p of s.parts; track p.id) {
                    @if (p.n > 0) { <div class="h-full rounded-full" [class]="p.bar" [style.width.%]="(p.n / maxStack()) * 100" [title]="p.label + ': ' + p.n"></div> }
                  }
                </div>
              </li>
            }
          </ul>
        </section>
      </div>

      <section class="overflow-x-auto rounded-lg border border-zinc-200 bg-white" aria-label="Images">
        <table class="w-full min-w-[680px] text-left text-[12.5px]">
          <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500">
            <tr><th class="px-3 py-2 font-semibold">Image</th><th class="px-3 py-2 font-semibold">Host</th><th class="px-3 py-2 font-semibold">Nutzung</th><th class="px-3 py-2 font-semibold">Schweregrade</th><th class="px-3 py-2 text-right font-semibold">Gesamt</th></tr>
          </thead>
          <tbody>
            @for (r of rows(); track r.image) {
              <tr class="cursor-pointer border-b border-zinc-100 last:border-0 hover:bg-zinc-50" (click)="openImage(r.image)">
                <td class="px-3 py-2"><button type="button" class="font-mono font-medium hover:underline" (click)="openImage(r.image); $event.stopPropagation()">{{ r.image }}</button></td>
                <td class="px-3 py-2"><span class="flex flex-wrap gap-1">@for (h of r.hosts; track h) { <cx-host [name]="store.host(h).name" [color]="store.host(h).color" /> }</span></td>
                <td class="px-3 py-2 text-zinc-600">{{ r.running ? r.running + ' laufend' : 'gestoppt' }}</td>
                <td class="px-3 py-2"><span class="flex gap-1">
                  @for (s of sev; track s.id) {
                    @if (r[s.id] > 0) { <span class="min-w-7 rounded-md border px-1.5 text-center text-[11px] font-medium tabular-nums" [class]="s.badge" [title]="s.label">{{ r[s.id] }}</span> }
                  }
                  @if (r.total === 0) { <span class="text-[11.5px] text-emerald-700">keine</span> }
                </span></td>
                <td class="px-3 py-2 text-right font-semibold tabular-nums">{{ r.total }}</td>
              </tr>
            }
          </tbody>
        </table>
      </section>
    }

    <cx-dialog [open]="image() !== null" [heading]="'Befunde: ' + (image() ?? '')" description="Synthetische Beispielbefunde. Behebung über ein Image-Update im Stack." icon="shield" width="lg" (closed)="image.set(null)">
      <div class="px-4 pb-4">
        <table class="w-full text-left text-[12.5px]">
          <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500"><tr><th class="py-1.5 pr-2 font-semibold">Kennung</th><th class="py-1.5 pr-2 font-semibold">Schweregrad</th><th class="py-1.5 pr-2 font-semibold">Paket</th><th class="py-1.5 font-semibold">Behoben in</th></tr></thead>
          <tbody>
            @for (f of imageFindings(); track f.id) {
              <tr class="border-b border-zinc-100 last:border-0">
                <td class="py-1.5 pr-2 font-mono">{{ f.id }}</td>
                <td class="py-1.5 pr-2"><span class="rounded-md border px-1.5 text-[11px] font-medium" [class]="sevMeta(f.severity).badge">{{ sevMeta(f.severity).label }}</span></td>
                <td class="py-1.5 pr-2 font-mono">{{ f.pkg }} {{ f.installed }}</td>
                <td class="py-1.5 font-mono">{{ f.fixed }}</td>
              </tr>
            } @empty {
              <tr><td colspan="4" class="py-4 text-zinc-600">Nur Zählwerte vorhanden (niedrige/mittlere Befunde werden in der Demo nicht einzeln gelistet).</td></tr>
            }
          </tbody>
        </table>
      </div>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="image.set(null)">Schließen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxSecurity {
  protected readonly store = inject(CxStore);
  protected readonly sev = SEV;
  protected readonly image = signal<string | null>(null);

  protected readonly rows = computed<ImgRow[]>(() => {
    const visible = this.store.allServices().filter((i) => this.store.visible(i.hostId));
    return this.store
      .findings()
      .map((f) => {
        const uses = visible.filter((i) => i.svc.image === f.image);
        return {
          ...f,
          hosts: [...new Set(uses.map((u) => u.hostId))],
          running: uses.filter((u) => u.svc.state === 'running').length,
          total: f.kritisch + f.hoch + f.mittel + f.niedrig,
        };
      })
      .filter((r) => r.hosts.length > 0)
      .sort((a, b) => b.kritisch - a.kritisch || b.hoch - a.hoch || b.total - a.total);
  });

  protected readonly sevTotals = computed(() =>
    SEV.map((s) => ({ ...s, n: this.rows().reduce((a, r) => a + r[s.id], 0) })),
  );

  protected readonly exposure = computed(() => {
    const crit = (r: ImgRow) => r.kritisch + r.hoch;
    return [
      { label: 'Laufend', n: this.rows().filter((r) => r.running > 0).reduce((a, r) => a + crit(r), 0), bar: 'bg-indigo-500' },
      { label: 'Gestoppt', n: this.rows().filter((r) => r.running === 0).reduce((a, r) => a + crit(r), 0), bar: 'bg-indigo-300' },
    ];
  });

  protected readonly risk = computed(() => {
    const score = this.rows().reduce((a, r) => a + (r.kritisch * 14 + r.hoch * 5 + r.mittel * 1 + r.niedrig * 0.2) * (r.running ? 1 : 0.4), 0);
    return Math.min(100, Math.round(score));
  });

  protected readonly band = computed(() => {
    const r = this.risk();
    if (r >= 60) return { label: 'hoch', color: '#dc2626', badge: 'border-red-500/25 bg-red-500/10 text-red-700' };
    if (r >= 30) return { label: 'mittel', color: '#d97706', badge: 'border-amber-500/30 bg-amber-500/10 text-amber-700' };
    return { label: 'niedrig', color: '#16a34a', badge: 'border-emerald-500/25 bg-emerald-500/10 text-emerald-700' };
  });

  protected readonly trend = computed(() => {
    const h = this.store.scanHistory();
    const max = Math.max(...h.map((x) => x.total)) + 4;
    const min = Math.min(...h.map((x) => x.total)) - 4;
    return h.map((x, i) => ({ ...x, x: 14 + (i * 272) / Math.max(1, h.length - 1), y: 12 + ((max - x.total) / Math.max(1, max - min)) * 60 }));
  });
  protected readonly trendPoints = computed(() => this.trend().map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' '));
  protected readonly trendLabel = computed(() => 'Befunde je Scan: ' + this.store.scanHistory().map((x) => `${x.day} ${x.time} ${x.total}${x.manual ? ' manuell' : ''}`).join(', '));

  protected readonly topFindings = computed(() => {
    const imgs = new Set(this.rows().map((r) => r.image));
    const order: Severity[] = ['kritisch', 'hoch', 'mittel', 'niedrig'];
    return SEED_FINDING_LIST.filter((f) => imgs.has(f.image)).sort((a, b) => order.indexOf(a.severity) - order.indexOf(b.severity)).slice(0, 6);
  });

  protected readonly perStack = computed(() => {
    const out: { name: string; color: string; total: number; parts: { id: Severity; label: string; bar: string; n: number }[] }[] = [];
    const byImage = new Map(this.store.findings().map((f) => [f.image, f]));
    const build = (name: string, color: string, images: string[]) => {
      const parts = SEV.map((s) => ({ id: s.id, label: s.label, bar: s.bar, n: images.reduce((a, img) => a + (byImage.get(img)?.[s.id] ?? 0), 0) }));
      out.push({ name, color, total: parts.reduce((a, p) => a + p.n, 0), parts });
    };
    for (const s of this.store.visibleStacks()) build(s.name, this.store.host(s.hostId).color, [...new Set(s.services.map((x) => x.image))]);
    const single = this.store.visibleStandalone();
    if (single.length) build('Einzelcontainer', '#71717a', [...new Set(single.map((c) => c.image))]);
    return out.sort((a, b) => b.total - a.total);
  });
  protected readonly maxStack = computed(() => Math.max(1, ...this.perStack().map((s) => s.total)));

  protected readonly imageFindings = computed(() => SEED_FINDING_LIST.filter((f) => f.image === this.image()));

  protected sevMeta(id: Severity) {
    return SEV.find((s) => s.id === id) ?? SEV[3];
  }

  protected openImage(img: string): void {
    this.image.set(img);
  }

  protected enable(): void {
    this.store.scanEnabled.set(true);
    this.store.notify('Schwachstellenscans aktiviert (Demo). Zeitplan: ' + this.store.scanSchedule());
  }
}
