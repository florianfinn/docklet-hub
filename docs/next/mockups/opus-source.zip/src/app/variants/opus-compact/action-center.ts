// Docklet Design Lab – opus-compact · Aktionszentrum (Drawer)
// Bewusst aufrufbar (Kopfzeile „Aktivität“ oder „Details“ im Popup), öffnet sich nie automatisch.
// Aktionen mit Ablaufanzeige, Ausgaben und Fehlern sowie Ereignisverlauf mit Filtern.
import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import type { ActionItem, EventLevel } from './data';
import { CxFlow } from './flow';
import { CxIcon, type IconName } from './icon';
import { CxStore } from './store';
import { CxDialog } from './ui';

type Filter = 'alle' | 'aktionen' | 'ereignisse' | 'fehler';

const LEVEL: Record<EventLevel, { icon: IconName; cls: string; label: string }> = {
  info: { icon: 'info', cls: 'text-sky-600', label: 'Info' },
  'warnung': { icon: 'alert', cls: 'text-amber-600', label: 'Warnung' },
  'fehler': { icon: 'xCircle', cls: 'text-red-600', label: 'Fehler' },
  erfolg: { icon: 'checkCircle', cls: 'text-emerald-600', label: 'Erfolg' },
};

@Component({
  selector: 'cx-action-center',
  imports: [ZardButtonComponent, CxIcon, CxDialog, CxFlow],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <cx-dialog
      [open]="store.actionCenterOpen()"
      variant="drawer"
      heading="Aktionszentrum"
      description="Details, Ausgaben und Verlauf aller Hosts. Alles simuliert."
      icon="activity"
      (closed)="close()"
    >
      <div class="sticky top-0 z-10 flex gap-1 border-b border-zinc-100 bg-white px-4 py-2" role="group" aria-label="Filter">
        @for (f of filters; track f.id) {
          <button type="button" class="h-7 rounded-md px-2 text-[12px] font-medium" [class]="filter() === f.id ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'" [attr.aria-pressed]="filter() === f.id" (click)="filter.set(f.id)">
            {{ f.label }}
            @if (f.id === 'fehler' && errorCount()) { <span class="ml-0.5 rounded bg-red-500/20 px-1 text-[10.5px]">{{ errorCount() }}</span> }
          </button>
        }
      </div>

      @if (showActions()) {
        <section class="px-4 pt-3" aria-label="Aktionen">
          <h3 class="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Aktionen</h3>
          <ul class="space-y-2">
            @for (a of actions(); track a.id) {
              @let h = store.host(a.hostId);
              <li [id]="'ac-' + a.id" class="rounded-lg border p-2.5" [class]="itemCls(a)" [style.box-shadow]="'inset 3px 0 0 ' + h.color">
                <cx-flow [action]="a" [compact]="true" />
                <div class="mt-1.5 text-[11.5px] text-zinc-500">{{ h.name }}{{ a.stackId ? ' · Stack ' + stackName(a.stackId) : '' }}</div>
                <details class="mt-1.5" [open]="a.status !== 'success' || store.focusActionId() === a.id">
                  <summary class="cursor-pointer text-[12px] font-medium text-zinc-600">Ausgabe ({{ a.output.length }} Zeilen)</summary>
                  <pre class="mt-1 max-h-40 overflow-auto rounded bg-[#0c0c0f] p-2 font-mono text-[11px] leading-[18px] text-[#e4e4e7]">@for (l of a.output; track $index) {<span [class]="l.startsWith('Fehler') ? 'text-[#fca5a5]' : ''">{{ l }}</span>
}</pre>
                </details>
                <div class="mt-2 flex flex-wrap items-center gap-2">
                  @if (a.stackId) {
                    <button z-button zType="ghost" zSize="xs" type="button" (click)="openStack(a.stackId)"><cx-icon name="layers" [size]="12" />Stack öffnen</button>
                  }
                  @if (a.restorable) {
                    <button z-button zType="outline" zSize="xs" type="button" (click)="store.restoreAction(a.id)"><cx-icon name="history" [size]="12" />Vorherige Version wiederherstellen</button>
                    <span class="text-[11px] text-zinc-500">Nur manuell – keine automatische Rückkehr.</span>
                  }
                </div>
              </li>
            } @empty {
              <li class="rounded-md border border-dashed border-zinc-300 p-3 text-center text-zinc-600">Keine Aktionen.</li>
            }
          </ul>
        </section>
      }

      @if (showEvents()) {
        <section class="px-4 pb-4 pt-3" aria-label="Ereignisse">
          <h3 class="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Ereignisse</h3>
          <ol class="relative space-y-2 border-l border-zinc-200 pl-4">
            @for (e of events(); track e.id) {
              @let h = store.host(e.hostId);
              <li class="relative">
                <span class="absolute -left-[22.5px] top-0.5 grid size-[13px] place-items-center rounded-full bg-white"><cx-icon [name]="level[e.level].icon" [size]="13" [class]="level[e.level].cls" /></span>
                <div class="text-[12.5px] text-zinc-800">{{ e.text }}</div>
                <div class="flex items-center gap-1.5 text-[11px] text-zinc-500"><span class="size-1.5 rounded-sm" [style.background-color]="h.color"></span>{{ h.name }} · {{ e.time }} · {{ level[e.level].label }}</div>
              </li>
            } @empty {
              <li class="text-zinc-600">Keine Ereignisse.</li>
            }
          </ol>
        </section>
      }

      <div cx-footer class="flex w-full flex-wrap items-center gap-2">
        <span class="text-[11.5px] text-zinc-500">Benachrichtigungen: nur eingerichtete Kanäle (Hub-Einstellungen)</span>
        <button z-button zType="ghost" zSize="sm" type="button" class="ml-auto" (click)="store.clearFinished()">Abgeschlossene entfernen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxActionCenter {
  protected readonly store = inject(CxStore);
  protected readonly filter = signal<Filter>('alle');
  protected readonly level = LEVEL;

  protected readonly filters: { id: Filter; label: string }[] = [
    { id: 'alle', label: 'Alle' },
    { id: 'aktionen', label: 'Aktionen' },
    { id: 'ereignisse', label: 'Ereignisse' },
    { id: 'fehler', label: 'Fehler' },
  ];

  constructor() {
    effect(() => {
      const id = this.store.focusActionId();
      if (id && this.store.actionCenterOpen()) {
        this.filter.set('alle');
        setTimeout(() => document.getElementById('ac-' + id)?.scrollIntoView({ block: 'nearest' }), 220);
      }
    });
  }

  protected readonly showActions = computed(() => this.filter() !== 'ereignisse');
  protected readonly showEvents = computed(() => this.filter() !== 'aktionen');

  protected readonly actions = computed(() => {
    const list = this.store.actions().filter((a) => this.store.visible(a.hostId) || a.id === this.store.focusActionId());
    const f = this.filter() === 'fehler' ? list.filter((a) => a.status === 'error') : list;
    return [...f].sort((a, b) => Number(b.status === 'running') - Number(a.status === 'running'));
  });

  protected readonly events = computed(() => {
    const list = this.store.events().filter((e) => this.store.visible(e.hostId));
    return this.filter() === 'fehler' ? list.filter((e) => e.level === 'fehler') : list;
  });

  protected readonly errorCount = computed(
    () => this.store.actions().filter((a) => a.status === 'error').length + this.store.events().filter((e) => e.level === 'fehler').length,
  );

  protected itemCls(a: ActionItem): string {
    if (this.store.focusActionId() === a.id) return 'border-sky-500/50 ring-2 ring-sky-500/20';
    return a.status === 'error' ? 'border-red-500/30' : 'border-zinc-200';
  }

  protected stackName(id: string): string {
    return this.store.stacks().find((s) => s.id === id)?.name ?? id;
  }

  protected openStack(id: string): void {
    this.close();
    this.store.openStack(id);
  }

  protected close(): void {
    this.store.actionCenterOpen.set(false);
    this.store.focusActionId.set(null);
  }
}
