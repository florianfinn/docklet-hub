// Docklet Design Lab – opus-compact · Profil (Name, Sprache, Theme)
// Theme wirkt sofort auf die ganze Variante (Hell / Dunkel / System).
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import type { ThemePref } from './data';
import { CxIcon, type IconName } from './icon';
import { CxStore } from './store';

@Component({
  selector: 'cx-profile',
  imports: [ZardButtonComponent, CxIcon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mx-auto max-w-2xl space-y-3">
      <section class="rounded-lg border border-zinc-200 bg-white" aria-labelledby="pf-acc">
        <header class="flex items-center gap-3 border-b border-zinc-200 px-4 py-3">
          <span class="grid size-10 place-items-center rounded-full bg-zinc-200 text-[15px] font-semibold">{{ (store.profileName().trim().charAt(0) || '?').toUpperCase() }}</span>
          <div><h2 id="pf-acc" class="text-[15px] font-semibold">Konto</h2><p class="text-[12px] text-zinc-500">Lokaler Admin · angemeldet seit heute 08:02 (Demo)</p></div>
        </header>
        <div class="grid gap-3 p-4 sm:grid-cols-2">
          <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Anzeigename</span>
            <input class="h-8 w-full rounded-md border border-zinc-300 bg-white px-2 text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/15" [value]="store.profileName()" (input)="store.profileName.set(v($event))" />
          </label>
          <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">E-Mail</span>
            <input type="email" class="h-8 w-full rounded-md border border-zinc-300 bg-white px-2 text-[13px] outline-none focus:ring-2 focus:ring-zinc-900/15" [value]="store.profileEmail()" (input)="store.profileEmail.set(v($event))" />
          </label>
          <label class="block"><span class="mb-1 block text-[12px] font-medium text-zinc-700">Sprache</span>
            <select class="h-8 w-full rounded-md border border-zinc-300 bg-white px-2 text-[13px]" (change)="setLang($event)">
              <option value="de" [selected]="store.language() === 'de'">Deutsch</option>
              <option value="en" [selected]="store.language() === 'en'">English (Vorschau)</option>
            </select>
          </label>
          <div class="flex items-end"><button z-button zType="outline" zSize="sm" type="button" (click)="store.notify('Passwortänderung würde einen Dialog öffnen (Demo).')"><cx-icon name="key" [size]="13" />Passwort ändern</button></div>
        </div>
      </section>

      <section class="rounded-lg border border-zinc-200 bg-white" aria-labelledby="pf-theme">
        <header class="border-b border-zinc-200 px-4 py-3"><h2 id="pf-theme" class="text-[15px] font-semibold">Darstellung</h2></header>
        <fieldset class="p-4">
          <legend class="sr-only">Theme</legend>
          <div class="grid gap-2 sm:grid-cols-3">
            @for (t of themes; track t.id) {
              <label class="cursor-pointer overflow-hidden rounded-lg border has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-zinc-900" [class]="store.theme() === t.id ? 'border-zinc-900 ring-1 ring-zinc-900' : 'border-zinc-200 hover:border-zinc-300'">
                <input type="radio" name="theme" class="sr-only" [checked]="store.theme() === t.id" (change)="store.theme.set(t.id)" />
                <span class="flex h-16 gap-1 p-2" [style.background]="t.bg">
                  <span class="w-5 rounded-sm" [style.background]="'#0b0b0e'"></span>
                  <span class="flex flex-1 flex-col gap-1">
                    <span class="h-2.5 rounded-sm" [style.background]="t.card"></span>
                    <span class="h-6 rounded-sm" [style.background]="t.card"></span>
                  </span>
                </span>
                <span class="flex items-center gap-1.5 border-t border-zinc-200 px-2.5 py-1.5 text-[12.5px] font-medium"><cx-icon [name]="t.icon" [size]="14" />{{ t.label }}</span>
              </label>
            }
          </div>
          <p class="mt-2 text-[12px] text-zinc-500">Die Seitenleiste bleibt in beiden Themes dunkel (kompakter Docklet-Stil). Hostfarben bleiben gleich.</p>
        </fieldset>
      </section>
    </div>
  `,
})
export class CxProfile {
  protected readonly store = inject(CxStore);

  protected readonly themes: { id: ThemePref; label: string; icon: IconName; bg: string; card: string }[] = [
    { id: 'hell', label: 'Hell', icon: 'sun', bg: '#f4f4f5', card: '#ffffff' },
    { id: 'dunkel', label: 'Dunkel', icon: 'moon', bg: '#18181b', card: '#27272a' },
    { id: 'system', label: 'System', icon: 'monitor', bg: 'linear-gradient(90deg,#f4f4f5 50%,#18181b 50%)', card: 'linear-gradient(90deg,#ffffff 50%,#27272a 50%)' },
  ];

  protected v(e: Event): string {
    return (e.target as HTMLInputElement).value;
  }

  protected setLang(e: Event): void {
    const val = (e.target as HTMLSelectElement).value;
    this.store.language.set(val === 'en' ? 'en' : 'de');
    if (val === 'en') this.store.notify('Englisch ist in dieser Demo nur eine Vorschau – Texte bleiben deutsch.');
  }
}
