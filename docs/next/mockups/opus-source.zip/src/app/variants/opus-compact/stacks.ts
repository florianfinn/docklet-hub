// Docklet Design Lab – opus-compact · Stacks-Übersicht
// Arcanes Tabellenstruktur (Name, Tags, Status, Updates, Services), Stacks als klar abgesetzte Zeilen mit
// Hostfarbe (Docklet). Nur Stacks – Einzelcontainer stehen auf der Container-Seite. Klick öffnet die Stack-Seite.
// Kein Erstellungsdatum, kein Arbeitsverzeichnis. Easy-Ansicht Standard, Full-Ansicht umschaltbar.
// Mehrfachauswahl standardmäßig aus (Button), in der Full-Ansicht automatisch eingeblendet.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import type { Stack } from './data';
import { CxIcon } from './icon';
import { CxStore, type StackOp, type StacksView } from './store';
import { CxDialog, CxHost, CxLabel, CxStatus } from './ui';

type StatusFilter = 'alle' | 'probleme' | 'updates' | 'gestoppt';

const AUTO_LABEL = { 'pruefen': 'nur prüfen', 'taeglich': 'täglich', 'woechentlich': 'wöchentlich' } as const;

@Component({
  selector: 'cx-stacks',
  imports: [ZardButtonComponent, CxIcon, CxDialog, CxHost, CxLabel, CxStatus],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <!-- Kennzahlen (Arcane: Stat-Karten über der Tabelle) -->
    <div class="mb-3 grid grid-cols-2 gap-2 md:grid-cols-4">
      @for (k of stats(); track k.label) {
        <button type="button" class="flex items-center gap-2.5 rounded-lg border border-zinc-200 bg-white px-3 py-2 text-left hover:bg-zinc-50" [attr.aria-pressed]="status() === k.filter" (click)="status.set(status() === k.filter ? 'alle' : k.filter)">
          <span class="grid size-8 place-items-center rounded-md border" [class]="k.cls"><cx-icon [name]="k.icon" [size]="15" /></span>
          <span><span class="block text-[18px] font-semibold leading-6 tabular-nums">{{ k.value }}</span><span class="block text-[11.5px] text-zinc-500">{{ k.label }}</span></span>
        </button>
      }
    </div>

    <!-- Werkzeugleiste -->
    <div class="mb-2 flex flex-wrap items-center gap-2">
      <div class="relative min-w-[180px] flex-1 sm:max-w-xs">
        <cx-icon name="search" [size]="14" class="pointer-events-none absolute left-2.5 top-2 text-zinc-400" />
        <input type="search" class="h-8 w-full rounded-md border border-zinc-200 bg-white pl-8 pr-2 text-[13px] outline-none focus:border-zinc-400 focus:ring-2 focus:ring-zinc-900/10" placeholder="Stack, Service oder Image" aria-label="Stacks durchsuchen" [value]="query()" (input)="query.set(v($event))" />
      </div>
      <div class="flex rounded-md border border-zinc-200 bg-white p-0.5" role="group" aria-label="Statusfilter">
        @for (f of filters; track f.id) {
          <button type="button" class="h-7 rounded px-2 text-[12px] font-medium" [class]="status() === f.id ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'" [attr.aria-pressed]="status() === f.id" (click)="status.set(f.id)">{{ f.label }}</button>
        }
      </div>
      <div class="ml-auto flex items-center gap-1.5">
        <button type="button" class="inline-flex h-8 items-center gap-1.5 rounded-md border px-2 text-[12px] font-medium" [class]="showSelect() ? 'border-zinc-900 bg-zinc-900 text-white' : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'" [attr.aria-pressed]="showSelect()" (click)="toggleSelect()">
          <cx-icon name="checkSquare" [size]="14" />Mehrfachauswahl
        </button>
        <div class="flex rounded-md border border-zinc-200 bg-white p-0.5" role="group" aria-label="Ansicht">
          @for (vw of views; track vw.id) {
            <button type="button" class="inline-flex h-7 items-center gap-1 rounded px-2 text-[12px] font-medium" [class]="store.stacksView() === vw.id ? 'bg-zinc-900 text-white' : 'text-zinc-600 hover:bg-zinc-100'" [attr.aria-pressed]="store.stacksView() === vw.id" [title]="vw.hint" (click)="setView(vw.id)">
              <cx-icon [name]="vw.id === 'easy' ? 'rows' : 'table'" [size]="13" />{{ vw.label }}
            </button>
          }
        </div>
      </div>
    </div>

    <!-- Labelfilter -->
    @if (store.allLabels().length) {
      <div class="mb-2 flex flex-wrap items-center gap-1.5" role="group" aria-label="Nach Label filtern">
        <cx-icon name="tag" [size]="13" class="text-zinc-400" />
        @for (l of store.allLabels(); track l) {
          <button type="button" class="rounded-full outline-none ring-offset-1 focus-visible:ring-2 focus-visible:ring-zinc-900" [class]="labelOn(l) ? 'ring-2 ring-zinc-900/70' : store.labelFilter().length ? 'opacity-50 hover:opacity-100' : ''" [attr.aria-pressed]="labelOn(l)" (click)="store.toggleLabel(l)"><cx-label [name]="l" /></button>
        }
        @if (store.labelFilter().length) {
          <button type="button" class="text-[11.5px] font-medium text-zinc-600 underline underline-offset-2" (click)="store.labelFilter.set([])">Labels zurücksetzen</button>
        }
      </div>
    }

    <!-- Sammelaktionen -->
    @if (showSelect() && selected().size > 0) {
      <div class="mb-2 flex flex-wrap items-center gap-1.5 rounded-lg border border-sky-500/30 bg-sky-500/10 px-3 py-1.5" role="region" aria-label="Sammelaktionen">
        <span class="mr-1 text-[12.5px] font-medium">{{ selected().size }} ausgewählt</span>
        <button z-button zType="outline" zSize="xs" type="button" (click)="bulk('start')"><cx-icon name="play" [size]="12" />Starten</button>
        <button z-button zType="outline" zSize="xs" type="button" (click)="stopSelected()"><cx-icon name="stop" [size]="12" />Stoppen</button>
        <button z-button zType="outline" zSize="xs" type="button" (click)="bulk('restart')"><cx-icon name="restart" [size]="12" />Neu starten</button>
        <button z-button zType="outline" zSize="xs" type="button" (click)="bulkUpdate()"><cx-icon name="download" [size]="12" />Updates installieren</button>
        <button type="button" class="ml-auto text-[12px] font-medium text-zinc-600 underline" (click)="selected.set(emptySet())">Auswahl aufheben</button>
      </div>
    }

    <!-- Tabelle -->
    <div role="table" aria-label="Stacks" [attr.aria-rowcount]="rows().length + 1">
      <div role="row" class="hidden items-center gap-3 px-3 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 md:grid md:grid-cols-(--cols)" [style.--cols]="cols()">
        @if (showSelect()) {
          <span role="columnheader"><input type="checkbox" class="size-3.5 accent-zinc-900" aria-label="Alle sichtbaren Stacks auswählen" [checked]="allSelected()" (change)="toggleAll()" /></span>
        }
        <span role="columnheader">Name</span>
        <span role="columnheader">Status</span>
        <span role="columnheader">Host</span>
        <span role="columnheader">Services</span>
        <span role="columnheader">Updates</span>
        @if (full()) {
          <span role="columnheader" class="text-right">CPU · RAM</span>
          <span role="columnheader">Auto-Update</span>
          <span role="columnheader">Backup</span>
        }
        <span role="columnheader" class="text-right">Aktionen</span>
      </div>

      <div class="space-y-1.5" role="rowgroup">
        @for (s of rows(); track s.id) {
          @let h = store.host(s.hostId);
          @let ups = updates(s);
          <div
            role="row"
            class="grid cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-1.5 rounded-lg border bg-white px-3 py-2 transition-colors hover:border-zinc-300 hover:bg-zinc-50/60 md:grid-cols-(--cols)"
            [class]="isSel(s.id) ? 'border-sky-500/50 bg-sky-500/5' : 'border-zinc-200'"
            [style.--cols]="cols()"
            [style.box-shadow]="'inset 3px 0 0 ' + h.color"
            (click)="open(s)"
          >
            @if (showSelect()) {
              <span role="cell" class="max-md:hidden" (click)="$event.stopPropagation()"><input type="checkbox" class="size-3.5 accent-zinc-900" [attr.aria-label]="s.name + ' auswählen'" [checked]="isSel(s.id)" (change)="toggleSel(s.id)" /></span>
            }
            <div role="cell" class="min-w-0">
              <div class="flex min-w-0 items-center gap-2">
                <button type="button" class="truncate text-[13.5px] font-semibold outline-none hover:underline focus-visible:underline" (click)="open(s); $event.stopPropagation()">{{ s.name }}</button>
                @if (full() && s.domain) { <span class="hidden truncate font-mono text-[11px] text-zinc-500 xl:inline">{{ s.domain }}</span> }
              </div>
              @if (s.labels.length) {
                <div class="mt-0.5 flex flex-wrap gap-1">
                  @for (l of s.labels; track l) { <cx-label [name]="l" /> }
                </div>
              }
            </div>
            <div role="cell" class="max-md:hidden"><cx-status [kind]="store.stackStatus(s)" /></div>
            <div role="cell" class="max-md:hidden"><cx-host [name]="h.name" [color]="h.color" /></div>

            <!-- Services mit Hover-/Fokus-Details -->
            <div role="cell" class="group relative max-md:hidden" (click)="$event.stopPropagation()">
              <button type="button" class="inline-flex items-center gap-1.5 rounded-md px-1 py-0.5 text-[12.5px] outline-none hover:bg-zinc-100 focus-visible:ring-2 focus-visible:ring-zinc-900" [attr.aria-describedby]="'tip-svc-' + s.id" (click)="open(s)">
                <span class="font-semibold tabular-nums">{{ running(s) }}/{{ s.services.length }}</span>
                <span class="flex gap-0.5" aria-hidden="true">
                  @for (svc of s.services; track svc.id) { <span class="size-2 rounded-full" [class]="dot(svc.state, svc.health)"></span> }
                </span>
              </button>
              <div role="tooltip" [id]="'tip-svc-' + s.id" class="invisible absolute left-0 top-full z-20 mt-1 w-72 rounded-lg border border-zinc-200 bg-white p-2 text-[12px] opacity-0 shadow-lg transition-opacity group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                <div class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Services</div>
                @for (svc of s.services; track svc.id) {
                  <div class="flex items-center gap-2 py-0.5">
                    <span class="size-2 shrink-0 rounded-full" [class]="dot(svc.state, svc.health)"></span>
                    <span class="font-medium">{{ svc.name }}</span>
                    <span class="truncate font-mono text-[11px] text-zinc-500">{{ svc.image }}:{{ svc.tag }}</span>
                    <span class="ml-auto shrink-0 text-[11px] text-zinc-600">{{ svcLabel(svc.state, svc.health) }}</span>
                  </div>
                }
              </div>
            </div>

            <!-- Updates mit Hover-/Fokus-Details -->
            <div role="cell" class="group relative max-md:hidden" (click)="$event.stopPropagation()">
              @if (ups.length) {
                <button type="button" class="outline-none focus-visible:ring-2 focus-visible:ring-zinc-900 rounded-md" [attr.aria-describedby]="'tip-up-' + s.id" (click)="store.openStack(s.id, 'updates')">
                  <cx-status kind="update" [label]="ups.length + (ups.length === 1 ? ' Update' : ' Updates')" />
                </button>
                <div role="tooltip" [id]="'tip-up-' + s.id" class="invisible absolute left-0 top-full z-20 mt-1 w-72 rounded-lg border border-zinc-200 bg-white p-2 text-[12px] opacity-0 shadow-lg transition-opacity group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                  <div class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Verfügbare Updates</div>
                  @for (u of ups; track u.id) {
                    <div class="flex items-center gap-1.5 py-0.5 font-mono text-[11.5px]"><span class="font-sans font-medium">{{ u.name }}</span><span class="text-zinc-500">{{ u.tag }}</span><cx-icon name="chevronRight" [size]="11" class="text-zinc-400" /><span class="text-indigo-700">{{ u.newTag }}</span></div>
                  }
                  <div class="mt-1.5 flex items-center gap-2 border-t border-zinc-100 pt-1.5">
                    <button z-button zSize="xs" type="button" (click)="store.installUpdates(s.id)"><cx-icon name="download" [size]="11" />Installieren</button>
                    <span class="text-[11px] text-zinc-500">Richtlinie: {{ autoLabel[s.autoUpdate] }}</span>
                  </div>
                </div>
              } @else {
                <span class="inline-flex items-center gap-1 text-[12px] text-zinc-500"><cx-icon name="check" [size]="12" />aktuell</span>
              }
            </div>

            @if (full()) {
              <div role="cell" class="text-right font-mono text-[11.5px] tabular-nums text-zinc-600 max-md:hidden">{{ cpu(s) }}% · {{ mem(s) }}</div>
              <div role="cell" class="text-[12px] text-zinc-600 max-md:hidden">{{ autoLabel[s.autoUpdate] }}</div>
              <div role="cell" class="truncate text-[12px] text-zinc-600 max-md:hidden" [title]="s.backup.target">{{ s.backup.last }}</div>
            }

            <!-- Aktionen -->
            <div role="cell" class="flex items-center justify-end gap-0.5" (click)="$event.stopPropagation()">
              @if (store.stackStatus(s) === 'exited' || store.stackStatus(s) === 'entwurf') {
                <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100 hover:text-emerald-700" [attr.aria-label]="s.name + ' starten'" title="Starten" (click)="store.stackOp(s.id, 'start')"><cx-icon name="play" [size]="14" /></button>
              } @else {
                <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100 hover:text-red-700" [attr.aria-label]="s.name + ' stoppen'" title="Stoppen" (click)="confirmStop([s.id])"><cx-icon name="stop" [size]="14" /></button>
              }
              <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100" [attr.aria-label]="s.name + ' neu starten'" title="Neu starten" (click)="store.stackOp(s.id, 'restart')"><cx-icon name="restart" [size]="14" /></button>
              <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100" [attr.aria-label]="s.name + ' im Editor öffnen'" title="Editor" (click)="store.openStack(s.id, 'editor')"><cx-icon name="fileCode" [size]="14" /></button>
            </div>

            <!-- Mobile Zusammenfassung -->
            <div class="col-span-2 flex flex-wrap items-center gap-1.5 md:hidden">
              <cx-status [kind]="store.stackStatus(s)" />
              <cx-host [name]="h.name" [color]="h.color" />
              <span class="text-[12px] text-zinc-600">{{ running(s) }}/{{ s.services.length }} Services</span>
              @if (ups.length) { <cx-status kind="update" [label]="ups.length + ' Update' + (ups.length > 1 ? 's' : '')" /> }
            </div>
          </div>
        } @empty {
          <div class="rounded-lg border border-dashed border-zinc-300 bg-white px-3 py-8 text-center text-zinc-600">
            Keine Stacks für diesen Filter.
            <button type="button" class="ml-1 font-medium text-zinc-900 underline" (click)="reset()">Filter zurücksetzen</button>
          </div>
        }
      </div>
    </div>

    <p class="mt-3 flex flex-wrap items-center gap-1 text-[12px] text-zinc-500">
      <cx-icon name="info" [size]="13" />Einzelcontainer ohne Compose (inkl. Unraid/Legacy) stehen unter
      <button type="button" class="font-medium text-zinc-800 underline underline-offset-2" (click)="store.go('containers')">Container</button>.
      Hover oder Fokus auf „Services“ und „Updates“ zeigt Details.
    </p>

    <cx-dialog [open]="stopIds().length > 0" heading="Stacks stoppen?" [description]="stopText()" icon="stop" tone="danger" width="sm" (closed)="stopIds.set([])">
      <ul class="space-y-1 px-4 pb-3">
        @for (id of stopIds(); track id) {
          <li class="flex items-center gap-2 text-[12.5px]"><span class="size-2 rounded-sm" [style.background-color]="store.host(stackOf(id)?.hostId ?? '').color"></span>{{ stackOf(id)?.name }}<span class="text-zinc-500">· {{ stackOf(id)?.services?.length }} Services</span></li>
        }
      </ul>
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="stopIds.set([])">Abbrechen</button>
        <button z-button zType="destructive" zSize="sm" type="button" (click)="doStop()"><cx-icon name="stop" [size]="13" />Stoppen</button>
      </div>
    </cx-dialog>
  `,
})
export class CxStacks {
  protected readonly store = inject(CxStore);
  protected readonly query = signal('');
  protected readonly status = signal<StatusFilter>('alle');
  protected readonly selected = signal<Set<string>>(new Set());
  protected readonly stopIds = signal<string[]>([]);
  protected readonly autoLabel = AUTO_LABEL;

  protected readonly filters: { id: StatusFilter; label: string }[] = [
    { id: 'alle', label: 'Alle' },
    { id: 'probleme', label: 'Probleme' },
    { id: 'updates', label: 'Updates' },
    { id: 'gestoppt', label: 'Gestoppt' },
  ];

  protected readonly views: { id: StacksView; label: string; hint: string }[] = [
    { id: 'easy', label: 'Easy', hint: 'Kompakte Standardansicht' },
    { id: 'full', label: 'Full', hint: 'Ausführlich: Auslastung, Auto-Update, Backup, Mehrfachauswahl' },
  ];

  protected readonly full = computed(() => this.store.stacksView() === 'full');
  protected readonly showSelect = computed(() => this.store.selectMode());

  protected readonly cols = computed(() => {
    const parts: string[] = [];
    if (this.showSelect()) parts.push('20px');
    parts.push('minmax(0,1.6fr)', '128px', '96px', '96px', '112px');
    if (this.full()) parts.push('96px', '92px', '104px');
    parts.push('96px');
    return parts.join(' ');
  });

  protected readonly stats = computed(() => {
    const list = this.store.visibleStacks();
    return [
      { label: 'Stacks gesamt', value: list.length, icon: 'layers' as const, cls: 'border-zinc-200 bg-zinc-50 text-zinc-700', filter: 'alle' as StatusFilter },
      { label: 'Probleme', value: list.filter((s) => this.store.stackStatus(s) === 'unhealthy').length, icon: 'alert' as const, cls: 'border-red-500/25 bg-red-500/10 text-red-700', filter: 'probleme' as StatusFilter },
      { label: 'Mit Updates', value: list.filter((s) => s.services.some((x) => x.newTag)).length, icon: 'update' as const, cls: 'border-indigo-500/25 bg-indigo-500/10 text-indigo-700', filter: 'updates' as StatusFilter },
      { label: 'Gestoppt / Entwurf', value: list.filter((s) => ['exited', 'entwurf'].includes(this.store.stackStatus(s))).length, icon: 'stop' as const, cls: 'border-zinc-500/20 bg-zinc-500/10 text-zinc-600', filter: 'gestoppt' as StatusFilter },
    ];
  });

  protected readonly rows = computed(() => {
    const q = this.query().trim().toLowerCase();
    const labels = this.store.labelFilter();
    return this.store.visibleStacks().filter((s) => {
      const text = [s.name, s.description, s.domain ?? '', ...s.labels, ...s.services.map((x) => `${x.name} ${x.image}`)].join(' ').toLowerCase();
      if (q && !text.includes(q)) return false;
      if (labels.length && !labels.every((l) => s.labels.includes(l))) return false;
      const st = this.store.stackStatus(s);
      if (this.status() === 'probleme') return st === 'unhealthy';
      if (this.status() === 'updates') return s.services.some((x) => x.newTag);
      if (this.status() === 'gestoppt') return st === 'exited' || st === 'entwurf';
      return true;
    });
  });

  protected readonly allSelected = computed(() => this.rows().length > 0 && this.rows().every((s) => this.selected().has(s.id)));
  protected readonly stopText = computed(() =>
    this.stopIds().length === 1 ? 'Alle Container dieses Stacks werden gestoppt (Simulation).' : `${this.stopIds().length} Stacks werden gestoppt (Simulation).`,
  );

  protected v(e: Event): string {
    return (e.target as HTMLInputElement).value;
  }

  protected emptySet(): Set<string> {
    return new Set<string>();
  }

  protected labelOn(l: string): boolean {
    return this.store.labelFilter().includes(l);
  }

  protected setView(id: StacksView): void {
    this.store.stacksView.set(id);
    this.store.selectMode.set(id === 'full');
    if (id === 'easy') this.selected.set(new Set());
  }

  protected toggleSelect(): void {
    this.store.selectMode.update((x) => !x);
    if (!this.store.selectMode()) this.selected.set(new Set());
  }

  protected isSel(id: string): boolean {
    return this.showSelect() && this.selected().has(id);
  }

  protected toggleSel(id: string): void {
    this.selected.update((set) => {
      const next = new Set(set);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  protected toggleAll(): void {
    this.selected.set(this.allSelected() ? new Set() : new Set(this.rows().map((s) => s.id)));
  }

  protected bulk(op: StackOp): void {
    for (const id of this.selected()) this.store.stackOp(id, op);
    this.selected.set(new Set());
  }

  protected bulkUpdate(): void {
    let n = 0;
    for (const id of this.selected()) {
      const s = this.stackOf(id);
      if (s?.services.some((x) => x.newTag)) {
        this.store.installUpdates(id);
        n++;
      }
    }
    if (n === 0) this.store.notify('Für die Auswahl sind keine Updates verfügbar.');
    this.selected.set(new Set());
  }

  protected stopSelected(): void {
    this.stopIds.set(Array.from(this.selected()));
  }

  protected confirmStop(ids: string[]): void {
    this.stopIds.set(ids);
  }

  protected doStop(): void {
    for (const id of this.stopIds()) this.store.stackOp(id, 'stop');
    this.stopIds.set([]);
    this.selected.set(new Set());
  }

  protected stackOf(id: string): Stack | undefined {
    return this.store.stacks().find((s) => s.id === id);
  }

  protected open(s: Stack): void {
    this.store.openStack(s.id);
  }

  protected reset(): void {
    this.query.set('');
    this.status.set('alle');
    this.store.labelFilter.set([]);
  }

  protected updates(s: Stack) {
    return s.services.filter((x) => x.newTag);
  }

  protected running(s: Stack): number {
    return s.services.filter((x) => x.state === 'running').length;
  }

  protected dot(state: string, health: string): string {
    if (health === 'unhealthy') return 'bg-red-500';
    if (state === 'restarting') return 'bg-amber-500';
    if (state === 'running') return 'bg-emerald-500';
    return 'bg-zinc-300';
  }

  protected svcLabel(state: string, health: string): string {
    if (health === 'unhealthy') return 'unhealthy';
    if (state === 'restarting') return 'Neustart';
    if (state === 'running') return health === 'healthy' ? 'läuft · healthy' : 'läuft';
    return 'gestoppt';
  }

  protected cpu(s: Stack): string {
    return s.services.reduce((a, x) => a + x.cpu, 0).toFixed(1);
  }

  protected mem(s: Stack): string {
    const mb = s.services.reduce((a, x) => a + x.memMb, 0);
    return mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${mb} MB`;
  }
}
