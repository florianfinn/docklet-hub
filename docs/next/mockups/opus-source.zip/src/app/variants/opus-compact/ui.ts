// Docklet Design Lab – opus-compact
// Kleine lokale UI-Bausteine: Dialog/Drawer, Statusbadge (Arcane-Stil: Tönung /10, Rand /20),
// Host-Chip, Label-Chip, Meter und Metrik-Ring. Farben funktionieren in hellem und dunklem Theme.
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  computed,
  effect,
  input,
  output,
  viewChild,
} from '@angular/core';
import { labelColor } from './data';
import { CxIcon, type IconName } from './icon';

let uid = 0;

export function darken(hex: string, f = 0.62): string {
  const n = parseInt(hex.replace('#', ''), 16);
  const r = Math.round(((n >> 16) & 255) * f);
  const g = Math.round(((n >> 8) & 255) * f);
  const b = Math.round((n & 255) * f);
  return `rgb(${r}, ${g}, ${b})`;
}

/** Hintergrund-Tönung einer Farbe, unabhängig vom Theme. */
export function tint(hex: string, pct = 14): string {
  return `color-mix(in srgb, ${hex} ${pct}%, transparent)`;
}

/** Lesbare Textfarbe: im hellen Theme abgedunkelt, im dunklen aufgehellt (zinc-950 wird im Dark-Theme hell). */
export function ink(hex: string): string {
  return `color-mix(in srgb, ${hex} 62%, var(--color-zinc-950, #09090b))`;
}

const FOCUSABLE = 'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

@Component({
  selector: 'cx-dialog',
  imports: [CxIcon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: `
    .cx-fade { animation: cx-fade 160ms ease-out; }
    .cx-pop { animation: cx-pop 180ms cubic-bezier(.2,.8,.2,1); }
    .cx-slide { animation: cx-slide 200ms cubic-bezier(.2,.8,.2,1); }
    @keyframes cx-fade { from { opacity: 0; } }
    @keyframes cx-pop { from { opacity: 0; transform: translateY(8px) scale(.985); } }
    @keyframes cx-slide { from { transform: translateX(24px); opacity: 0; } }
    @media (prefers-reduced-motion: reduce) {
      .cx-fade, .cx-pop, .cx-slide { animation: none; }
    }
  `,
  template: `
    @if (open()) {
      <div class="fixed inset-0 z-50 flex" [class]="containerClass()">
        <div class="cx-fade absolute inset-0 bg-black/50 backdrop-blur-[1px]" (click)="close()" aria-hidden="true"></div>
        <div
          #panel
          role="dialog"
          aria-modal="true"
          tabindex="-1"
          [attr.aria-labelledby]="titleId"
          [attr.aria-describedby]="description() ? descId : null"
          (keydown)="onKey($event)"
          class="relative flex flex-col border-zinc-200 bg-white text-zinc-900 shadow-2xl outline-none"
          [class]="panelClass()"
        >
          <header class="flex items-start gap-3 px-4 pb-2 pt-4">
            @if (icon(); as ic) {
              <span class="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg border" [class]="tone() === 'danger' ? 'border-red-500/25 bg-red-500/10 text-red-700' : 'border-zinc-200 bg-zinc-50 text-zinc-700'"><cx-icon [name]="ic" [size]="16" /></span>
            }
            <div class="min-w-0 flex-1">
              <h2 [id]="titleId" class="text-[15px] font-semibold leading-6">{{ heading() }}</h2>
              @if (description()) {
                <p [id]="descId" class="text-[13px] leading-5 text-zinc-600">{{ description() }}</p>
              }
            </div>
            <button
              type="button"
              class="grid size-8 place-items-center rounded-md text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
              aria-label="Dialog schließen"
              (click)="close()"
            >
              <cx-icon name="x" [size]="16" />
            </button>
          </header>
          <div class="min-h-0 flex-1 overflow-y-auto" data-cx-body>
            <ng-content />
          </div>
          <footer class="flex flex-wrap items-center justify-end gap-2 border-t border-zinc-200 px-4 py-3 empty:hidden">
            <ng-content select="[cx-footer]" />
          </footer>
        </div>
      </div>
    }
  `,
})
export class CxDialog {
  readonly open = input<boolean>(false);
  readonly heading = input.required<string>();
  readonly description = input<string>('');
  readonly icon = input<IconName | null>(null);
  readonly tone = input<'default' | 'danger'>('default');
  readonly variant = input<'center' | 'drawer'>('center');
  readonly width = input<'sm' | 'md' | 'lg' | 'xl'>('md');
  readonly closed = output<void>();

  protected readonly titleId = `cx-dlg-title-${++uid}`;
  protected readonly descId = `cx-dlg-desc-${uid}`;
  private readonly panel = viewChild<ElementRef<HTMLElement>>('panel');
  private lastFocus: HTMLElement | null = null;

  protected readonly containerClass = computed(() =>
    this.variant() === 'drawer' ? 'justify-end' : 'items-end justify-center sm:items-center sm:p-4',
  );

  protected readonly panelClass = computed(() => {
    if (this.variant() === 'drawer') return 'cx-slide h-full w-full max-w-[460px] border-l';
    const w = { sm: 'sm:max-w-md', md: 'sm:max-w-xl', lg: 'sm:max-w-3xl', xl: 'sm:max-w-5xl' }[this.width()];
    return `cx-pop max-h-[92vh] w-full rounded-t-xl border sm:rounded-xl ${w}`;
  });

  constructor() {
    effect(() => {
      const el = this.panel();
      if (this.open() && el) {
        this.lastFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        setTimeout(() => {
          const root = el.nativeElement;
          const first =
            root.querySelector<HTMLElement>('[autofocus]') ??
            root.querySelector<HTMLElement>('[data-cx-body] :is(' + FOCUSABLE + ')') ??
            root.querySelector<HTMLElement>(FOCUSABLE);
          (first ?? root).focus();
        });
      } else if (!this.open() && this.lastFocus) {
        const target = this.lastFocus;
        this.lastFocus = null;
        setTimeout(() => target.focus());
      }
    });
  }

  close(): void {
    this.closed.emit();
  }

  protected onKey(ev: KeyboardEvent): void {
    if (ev.key === 'Escape') {
      ev.stopPropagation();
      this.close();
      return;
    }
    if (ev.key !== 'Tab') return;
    const root = this.panel()?.nativeElement;
    if (!root) return;
    const items = Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((e) => e.offsetParent !== null);
    if (items.length === 0) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (ev.shiftKey && document.activeElement === first) {
      ev.preventDefault();
      last.focus();
    } else if (!ev.shiftKey && document.activeElement === last) {
      ev.preventDefault();
      first.focus();
    }
  }
}

export type StatusKind =
  | 'running'
  | 'healthy'
  | 'unhealthy'
  | 'starting'
  | 'exited'
  | 'restarting'
  | 'online'
  | 'getrennt'
  | 'prüfung'
  | 'success'
  | 'error'
  | 'queued'
  | 'active'
  | 'update'
  | 'partial'
  | 'limited'
  | 'entwurf'
  | 'none';

const GREEN = 'border-emerald-500/25 bg-emerald-500/10 text-emerald-700';
const RED = 'border-red-500/25 bg-red-500/10 text-red-700';
const AMBER = 'border-amber-500/30 bg-amber-500/10 text-amber-700';
const GRAY = 'border-zinc-500/20 bg-zinc-500/10 text-zinc-600';
const BLUE = 'border-sky-500/25 bg-sky-500/10 text-sky-700';
const INDIGO = 'border-indigo-500/25 bg-indigo-500/10 text-indigo-700';

const STATUS: Record<StatusKind, { label: string; pill: string; dot: string; pulse?: boolean }> = {
  running: { label: 'Läuft', pill: GREEN, dot: 'bg-emerald-500' },
  healthy: { label: 'Healthy', pill: GREEN, dot: 'bg-emerald-500' },
  online: { label: 'Online', pill: GREEN, dot: 'bg-emerald-500' },
  success: { label: 'Erfolgreich', pill: GREEN, dot: 'bg-emerald-500' },
  unhealthy: { label: 'Unhealthy', pill: RED, dot: 'bg-red-500', pulse: true },
  error: { label: 'Fehler', pill: RED, dot: 'bg-red-500' },
  'getrennt': { label: 'Getrennt', pill: GRAY, dot: 'bg-zinc-400' },
  exited: { label: 'Gestoppt', pill: GRAY, dot: 'bg-zinc-400' },
  restarting: { label: 'Neustart', pill: AMBER, dot: 'bg-amber-500', pulse: true },
  starting: { label: 'Startet', pill: AMBER, dot: 'bg-amber-500', pulse: true },
  'prüfung': { label: 'Prüfung', pill: AMBER, dot: 'bg-amber-500', pulse: true },
  queued: { label: 'Wartend', pill: GRAY, dot: 'bg-zinc-400' },
  active: { label: 'Läuft', pill: BLUE, dot: 'bg-sky-500', pulse: true },
  update: { label: 'Update', pill: INDIGO, dot: 'bg-indigo-500' },
  partial: { label: 'Teilweise', pill: AMBER, dot: 'bg-amber-500' },
  limited: { label: 'Eingeschränkt', pill: GRAY, dot: 'bg-zinc-500' },
  entwurf: { label: 'Nicht bereitgestellt', pill: GRAY, dot: 'bg-zinc-300' },
  none: { label: 'Kein Healthcheck', pill: GRAY, dot: 'bg-zinc-300' },
};

@Component({
  selector: 'cx-status',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'inline-flex' },
  template: `
    <span class="inline-flex items-center gap-1.5 whitespace-nowrap rounded-md border px-1.5 py-px text-[11.5px] font-medium" [class]="meta().pill">
      <span class="size-1.5 rounded-full" [class]="meta().dot + (meta().pulse ? ' motion-safe:animate-pulse' : '')"></span>
      {{ label() || meta().label }}
    </span>
  `,
})
export class CxStatus {
  readonly kind = input.required<StatusKind>();
  readonly label = input<string>('');
  protected readonly meta = computed(() => STATUS[this.kind()]);
}

@Component({
  selector: 'cx-host',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'inline-flex' },
  template: `
    <span
      class="inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-1.5 py-px text-[11.5px] font-semibold"
      [style.background-color]="bg()"
      [style.color]="fg()"
    >
      <span class="size-2 rounded-sm" [style.background-color]="color()"></span>{{ name() }}
    </span>
  `,
})
export class CxHost {
  readonly name = input.required<string>();
  readonly color = input.required<string>();
  /** Bleibt aus Kompatibilitätsgründen; die Tönung wird themeunabhängig berechnet. */
  readonly soft = input<string>('');
  protected readonly bg = computed(() => tint(this.color(), 15));
  protected readonly fg = computed(() => ink(this.color()));
}

@Component({
  selector: 'cx-label',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'inline-flex' },
  template: `
    <span class="inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-1.5 text-[11px] font-medium leading-[18px]" [style.border-color]="border()" [style.background-color]="bg()" [style.color]="fg()">
      <span class="size-1.5 rounded-full" [style.background-color]="c()"></span>{{ name() }}
    </span>
  `,
})
export class CxLabel {
  readonly name = input.required<string>();
  protected readonly c = computed(() => labelColor(this.name()));
  protected readonly bg = computed(() => tint(this.c(), 10));
  protected readonly border = computed(() => tint(this.c(), 30));
  protected readonly fg = computed(() => ink(this.c()));
}

@Component({
  selector: 'cx-meter',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'block' },
  template: `
    <div
      class="h-1.5 w-full overflow-hidden rounded-full bg-zinc-200"
      role="meter"
      aria-valuemin="0"
      aria-valuemax="100"
      [attr.aria-valuenow]="value()"
      [attr.aria-label]="label()"
    >
      <div class="h-full rounded-full motion-safe:transition-[width] motion-safe:duration-700" [style.width.%]="value()" [style.background-color]="color()"></div>
    </div>
  `,
})
export class CxMeter {
  readonly value = input.required<number>();
  readonly color = input<string>('#71717a');
  readonly label = input<string>('Auslastung');
}

/** Metrik-Ring nach Arcane-Vorbild (metric-ring): Wert in der Mitte, Farbe nach Schwelle. */
@Component({
  selector: 'cx-ring',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'inline-flex flex-col items-center' },
  template: `
    <svg [attr.width]="size()" [attr.height]="size()" viewBox="0 0 44 44" role="meter" aria-valuemin="0" aria-valuemax="100" [attr.aria-valuenow]="value()" [attr.aria-label]="label() + ' ' + (disabled() ? 'nicht verfügbar' : value() + ' Prozent')">
      <circle cx="22" cy="22" r="18" fill="none" class="stroke-zinc-200" stroke-width="4.5" />
      @if (!disabled()) {
        <svg:circle cx="22" cy="22" r="18" fill="none" [attr.stroke]="stroke()" stroke-width="4.5" stroke-linecap="round" pathLength="100" [attr.stroke-dasharray]="value() + ' 100'" transform="rotate(-90 22 22)" class="motion-safe:transition-[stroke-dasharray] motion-safe:duration-700" />
      }
      <text x="22" y="25.5" text-anchor="middle" font-size="10.5" font-weight="600" class="fill-zinc-900">{{ disabled() ? '–' : value() + '%' }}</text>
    </svg>
    <span class="mt-0.5 text-[11px] text-zinc-500">{{ label() }}</span>
  `,
})
export class CxRing {
  readonly value = input.required<number>();
  readonly label = input<string>('');
  readonly color = input<string>('#71717a');
  readonly size = input<number>(56);
  readonly disabled = input<boolean>(false);
  protected readonly stroke = computed(() => (this.value() >= 85 ? '#dc2626' : this.value() >= 70 ? '#d97706' : this.color()));
}
