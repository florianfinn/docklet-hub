// Docklet Design Lab – opus-compact · Stack-Seite (nach Arcane projects/[projectId])
// Kopf mit Status, Host, Labels und Aktionen; Tabs Übersicht/Services, Editor, Logs, Dateien, Updates, Backups.
// „Neuer Stack“ öffnet dieselbe Seite im Entwurfsmodus mit Editor.
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ZardButtonComponent } from '../../shared/components/button';
import type { AutoUpdate, Stack } from './data';
import { CxEditor } from './editor';
import { CxFlow } from './flow';
import { CxIcon, type IconName } from './icon';
import { CxStackLogs } from './stack-logs';
import { CxStore, type StackTab } from './store';
import { CxDialog, CxHost, CxLabel, CxStatus } from './ui';

const TABS: { id: StackTab; label: string; icon: IconName }[] = [
  { id: 'overview', label: 'Services', icon: 'layers' },
  { id: 'editor', label: 'Editor', icon: 'fileCode' },
  { id: 'logs', label: 'Logs', icon: 'terminal' },
  { id: 'files', label: 'Dateien', icon: 'folder' },
  { id: 'updates', label: 'Updates', icon: 'update' },
  { id: 'backups', label: 'Backups', icon: 'archive' },
];

@Component({
  selector: 'cx-stack-page',
  imports: [ZardButtonComponent, CxIcon, CxDialog, CxHost, CxLabel, CxStatus, CxEditor, CxFlow, CxStackLogs],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let s = store.currentStack();
    @let h = store.host(s?.hostId ?? store.draftHostId());
    <!-- Kopf -->
    <header class="mb-3 rounded-lg border border-zinc-200 bg-white" [style.box-shadow]="'inset 3px 0 0 ' + h.color">
      <div class="flex flex-wrap items-start gap-3 px-4 py-3">
        <button type="button" class="grid size-8 shrink-0 place-items-center rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50" aria-label="Zurück zu Stacks" (click)="store.go('stacks')"><cx-icon name="arrowLeft" [size]="15" /></button>
        <div class="min-w-0 flex-1">
          <div class="flex flex-wrap items-center gap-2">
            <h2 class="text-[18px] font-semibold leading-7">{{ s?.name ?? 'Neuer Stack' }}</h2>
            @if (s) { <cx-status [kind]="store.stackStatus(s)" /> } @else { <cx-status kind="entwurf" label="Entwurf" /> }
            <cx-host [name]="h.name" [color]="h.color" />
            @for (l of s?.labels ?? store.draftLabels(); track l) { <cx-label [name]="l" /> }
            <button type="button" class="inline-flex items-center gap-1 rounded px-1 text-[11.5px] text-zinc-500 hover:text-zinc-900" (click)="editLabels()"><cx-icon name="tag" [size]="12" />Labels bearbeiten</button>
          </div>
          <p class="mt-0.5 text-[12px] text-zinc-500">
            @if (s) {
              {{ s.description }} · {{ s.services.length }} Services@if (s.domain) { · <span class="font-mono">{{ s.domain }}</span> }
            } @else {
              Entwurf – noch nicht gespeichert. Erst Editor ausfüllen, dann speichern oder bereitstellen.
            }
          </p>
        </div>
        @if (s) {
          <div class="flex flex-wrap items-center gap-1.5">
            @if (store.stackStatus(s) === 'exited' || store.stackStatus(s) === 'entwurf') {
              <button z-button zSize="sm" type="button" (click)="store.stackOp(s.id, 'start')"><cx-icon name="play" [size]="14" />{{ s.deployed ? 'Starten' : 'Bereitstellen' }}</button>
            } @else {
              <button z-button zType="outline" zSize="sm" type="button" (click)="confirm.set('stop')"><cx-icon name="stop" [size]="14" />Stoppen</button>
            }
            <button z-button zType="outline" zSize="sm" type="button" [zDisabled]="!s.deployed" (click)="store.stackOp(s.id, 'restart')"><cx-icon name="restart" [size]="14" />Neu starten</button>
            <button z-button zType="outline" zSize="sm" type="button" [zDisabled]="!s.deployed" (click)="store.stackOp(s.id, 'redeploy')"><cx-icon name="rocket" [size]="14" />Neu bereitstellen</button>
            @if (updates().length) {
              <button z-button zType="secondary" zSize="sm" type="button" (click)="store.setStackTab('updates')"><cx-icon name="update" [size]="14" />{{ updates().length }} Updates</button>
            }
            <button z-button zType="ghost" zSize="icon-sm" type="button" aria-label="Stack entfernen" title="Stack entfernen" (click)="confirm.set('remove')"><cx-icon name="trash" [size]="14" /></button>
          </div>
        }
      </div>

      <div role="tablist" aria-label="Stack-Bereiche" class="flex gap-0.5 overflow-x-auto border-t border-zinc-200 px-2" (keydown)="onTabKey($event)">
        @for (t of tabs; track t.id) {
          <button
            type="button"
            role="tab"
            class="relative inline-flex h-9 shrink-0 items-center gap-1.5 px-2.5 text-[12.5px] font-medium outline-none focus-visible:bg-zinc-100 disabled:cursor-not-allowed disabled:opacity-40"
            [id]="'st-tab-' + t.id"
            [attr.aria-selected]="store.stackTab() === t.id"
            aria-controls="st-panel"
            [attr.tabindex]="store.stackTab() === t.id ? 0 : -1"
            [disabled]="!s && t.id !== 'editor'"
            [class]="store.stackTab() === t.id ? 'text-zinc-900 after:absolute after:inset-x-1 after:bottom-0 after:h-0.5 after:rounded after:bg-zinc-900' : 'text-zinc-500 hover:text-zinc-800'"
            (click)="selectTab(t.id)"
          >
            <cx-icon [name]="t.icon" [size]="13" />{{ t.label }}
            @if (t.id === 'updates' && updates().length) { <span class="rounded bg-indigo-500/15 px-1 text-[10.5px] text-indigo-700">{{ updates().length }}</span> }
            @if (t.id === 'overview' && s && store.stackStatus(s) === 'unhealthy') { <span class="size-1.5 rounded-full bg-red-500"></span> }
          </button>
        }
      </div>
    </header>

    <div id="st-panel" role="tabpanel" [attr.aria-labelledby]="'st-tab-' + store.stackTab()">
      @if (store.stackTab() === 'editor') {
        <cx-editor />
      } @else if (s) {
        @switch (store.stackTab()) {
          @case ('overview') {
            @if (lastAction(); as a) {
              <section class="mb-3 rounded-lg border border-zinc-200 bg-white p-3" aria-label="Letzter Ablauf">
                <div class="mb-1 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Letzter Ablauf
                  <button type="button" class="ml-auto text-[11.5px] font-medium normal-case tracking-normal text-zinc-600 underline" (click)="store.showActionDetails(a.id)">Ausgabe im Aktionszentrum</button>
                </div>
                <cx-flow [action]="a" />
              </section>
            }
            @if (!s.deployed) {
              <div class="mb-3 flex items-center gap-2 rounded-lg border border-zinc-200 bg-white p-3 text-[12.5px]">
                <cx-icon name="info" [size]="15" class="text-sky-600" />Gespeichert, aber noch nicht bereitgestellt.
                <button z-button zSize="xs" type="button" class="ml-auto" (click)="store.stackOp(s.id, 'start')"><cx-icon name="rocket" [size]="12" />Jetzt bereitstellen</button>
              </div>
            }
            <div class="grid items-start gap-3 xl:grid-cols-[minmax(0,1fr)_300px]">
              <section class="min-w-0 overflow-x-auto rounded-lg border border-zinc-200 bg-white" aria-label="Services">
                <table class="w-full min-w-[640px] text-left text-[12.5px]">
                  <thead class="border-b border-zinc-200 text-[11px] uppercase tracking-wide text-zinc-500">
                    <tr><th class="px-3 py-2 font-semibold">Service</th><th class="px-3 py-2 font-semibold">Image</th><th class="px-3 py-2 font-semibold">Status</th><th class="px-3 py-2 font-semibold">Ports</th><th class="px-3 py-2 text-right font-semibold">CPU · RAM</th><th class="px-3 py-2 text-right font-semibold"><span class="sr-only">Aktionen</span></th></tr>
                  </thead>
                  <tbody>
                    @for (svc of s.services; track svc.id) {
                      <tr class="border-b border-zinc-100 last:border-0 hover:bg-zinc-50/60">
                        <td class="px-3 py-2 font-medium">{{ svc.name }}</td>
                        <td class="px-3 py-2 font-mono text-[11.5px] text-zinc-600">{{ svc.image }}:{{ svc.tag }}@if (svc.newTag) { <span class="ml-1 rounded border border-indigo-500/25 bg-indigo-500/10 px-1 text-[10.5px] text-indigo-700">→ {{ svc.newTag }}</span> }</td>
                        <td class="px-3 py-2"><span class="flex flex-wrap gap-1"><cx-status [kind]="svc.state" />@if (svc.health !== 'none') { <cx-status [kind]="svc.health" /> }</span></td>
                        <td class="px-3 py-2 font-mono text-[11.5px]">{{ svc.ports.join(', ') || '–' }}</td>
                        <td class="px-3 py-2 text-right font-mono text-[11.5px] tabular-nums text-zinc-600">{{ svc.cpu.toFixed(1) }}% · {{ svc.memMb }} MB</td>
                        <td class="px-2 py-1 text-right">
                          <span class="inline-flex gap-0.5">
                            <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100" [attr.aria-label]="'Logs von ' + svc.name" title="Logs" (click)="showLogs(svc.name)"><cx-icon name="terminal" [size]="14" /></button>
                            <button type="button" class="grid size-7 place-items-center rounded-md text-zinc-600 hover:bg-zinc-100" [attr.aria-label]="svc.name + ' neu starten'" title="Neu starten" [disabled]="!s.deployed" (click)="store.restartService(s.id, svc.id, svc.name, s.hostId)"><cx-icon name="restart" [size]="14" /></button>
                          </span>
                        </td>
                      </tr>
                    }
                  </tbody>
                </table>
                @if (unhealthy()) {
                  <div class="flex gap-2 border-t border-red-500/25 bg-red-500/10 px-3 py-2 text-[12.5px] text-red-800">
                    <cx-icon name="alert" [size]="15" class="mt-0.5" />
                    <div><b>{{ unhealthy() }}</b> ist unhealthy. Letzter Fehler: keine Antwort auf Status-Ping. <button type="button" class="ml-1 font-medium underline" (click)="showLogs(unhealthy())">Logs ansehen</button></div>
                  </div>
                }
              </section>
              <aside class="space-y-3">
                <div class="rounded-lg border border-zinc-200 bg-white p-3">
                  <h3 class="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Netzwerke</h3>
                  <div class="flex flex-wrap gap-1">
                    @for (n of networks(); track n) { <button type="button" class="rounded border border-zinc-200 px-1.5 font-mono text-[11.5px] hover:bg-zinc-50" (click)="store.go('networks')">{{ n }}</button> }
                  </div>
                  <h3 class="mb-1.5 mt-3 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Mounts</h3>
                  <ul class="space-y-1">
                    @for (m of mounts(); track m.id) {
                      <li><button type="button" class="flex w-full items-center gap-1.5 rounded px-1 py-0.5 text-left text-[12px] hover:bg-zinc-50" (click)="store.openFiles(m.id)"><cx-icon [name]="m.kind === 'volume' ? 'database' : 'drive'" [size]="13" class="text-zinc-500" /><span class="truncate font-mono">{{ m.name }}</span></button></li>
                    } @empty { <li class="text-[12px] text-zinc-500">Keine Mounts.</li> }
                  </ul>
                </div>
                <div class="rounded-lg border border-zinc-200 bg-white p-3">
                  <label class="flex items-center gap-2.5">
                    <input type="checkbox" class="size-4 accent-zinc-900" [checked]="s.autoHeal" (change)="store.setAutoHeal(s.id, checked($event))" />
                    <span class="font-medium">Auto Heal</span>
                  </label>
                  <p class="mt-1 text-[12px] text-zinc-600">Unhealthy Container begrenzt neu starten (max. 3/h, Hub-Einstellungen). Unerwartete Stopps regeln Docker-Neustartregeln.</p>
                  <dl class="mt-2 grid grid-cols-[96px_1fr] gap-y-1 border-t border-zinc-100 pt-2 text-[12px]">
                    <dt class="text-zinc-500">Updates</dt><dd>{{ autoLabel(s.autoUpdate) }}</dd>
                    <dt class="text-zinc-500">Backup</dt><dd>{{ s.backup.last }}</dd>
                  </dl>
                </div>
              </aside>
            </div>
          }
          @case ('logs') {
            <section class="rounded-lg border border-zinc-200 bg-white p-3"><cx-stack-logs [stack]="s" [only]="logOnly()" /></section>
          }
          @case ('files') {
            <div class="grid gap-3 lg:grid-cols-2">
              <section class="rounded-lg border border-zinc-200 bg-white p-3">
                <h3 class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Projektdateien</h3>
                <p class="mb-2 font-mono text-[11.5px] text-zinc-500">{{ s.path }}</p>
                <ul class="overflow-hidden rounded-md border border-zinc-200">
                  @for (f of projectFiles(); track f.name) {
                    <li>
                      <button type="button" class="flex w-full items-center gap-2 border-b border-zinc-100 px-2.5 py-2 text-left last:border-0 hover:bg-zinc-50" [attr.aria-expanded]="openFile() === f.name" (click)="openFile.set(openFile() === f.name ? null : f.name)">
                        <cx-icon [name]="f.name === '.env' ? 'file' : 'fileCode'" [size]="14" [class]="f.name === '.env' ? 'text-emerald-600' : 'text-sky-600'" />
                        <span class="flex-1 font-mono text-[12px]">{{ f.name }}</span>
                        <span class="text-[11.5px] text-zinc-500">{{ f.size }}</span>
                        <cx-icon [name]="openFile() === f.name ? 'chevronDown' : 'chevronRight'" [size]="14" class="text-zinc-400" />
                      </button>
                      @if (openFile() === f.name) {
                        <pre class="max-h-56 overflow-auto bg-[#0c0c0f] px-3 py-2 font-mono text-[11.5px] leading-5 text-[#e4e4e7]">{{ f.content }}</pre>
                      }
                    </li>
                  }
                </ul>
                <button z-button zType="outline" zSize="sm" type="button" class="mt-2" (click)="store.setStackTab('editor')"><cx-icon name="pencil" [size]="13" />Im Editor bearbeiten</button>
              </section>
              <section class="rounded-lg border border-zinc-200 bg-white p-3">
                <h3 class="mb-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Volumes & Bind-Mounts</h3>
                <ul class="overflow-hidden rounded-md border border-zinc-200">
                  @for (m of mounts(); track m.id) {
                    <li class="flex items-center gap-2 border-b border-zinc-100 px-2.5 py-2 last:border-0">
                      <cx-icon [name]="m.kind === 'volume' ? 'database' : 'drive'" [size]="14" class="text-zinc-500" />
                      <div class="min-w-0 flex-1">
                        <div class="truncate font-mono text-[12px]">{{ m.name }}</div>
                        <div class="text-[11.5px] text-zinc-500">{{ m.kind === 'volume' ? 'Volume' : 'Bind-Mount' }} · {{ m.usedBy.join(', ') }}</div>
                      </div>
                      <button z-button zType="outline" zSize="xs" type="button" (click)="store.openFiles(m.id)"><cx-icon name="folder" [size]="12" />Durchsuchen</button>
                    </li>
                  } @empty {
                    <li class="px-2.5 py-3 text-zinc-600">Keine Mounts.</li>
                  }
                </ul>
              </section>
            </div>
          }
          @case ('updates') {
            <div class="grid items-start gap-3 lg:grid-cols-[minmax(0,1fr)_340px]">
              <section class="rounded-lg border border-zinc-200 bg-white p-3">
                <ul class="mb-3 overflow-hidden rounded-md border border-zinc-200">
                  @for (svc of s.services; track svc.id) {
                    <li class="flex items-center gap-2 border-b border-zinc-100 px-2.5 py-2 last:border-0">
                      <div class="min-w-0 flex-1">
                        <div class="font-medium">{{ svc.name }}</div>
                        <div class="font-mono text-[11.5px] text-zinc-600">{{ svc.image }}:{{ svc.tag }}@if (svc.newTag) { <span class="text-indigo-700"> → {{ svc.newTag }}</span> }</div>
                      </div>
                      @if (svc.newTag) { <cx-status kind="update" label="Update verfügbar" /> } @else { <span class="text-[11.5px] text-zinc-500">aktuell</span> }
                    </li>
                  }
                </ul>
                <div class="flex flex-wrap gap-1.5">
                  <button z-button zSize="sm" type="button" [zDisabled]="updates().length === 0" (click)="store.installUpdates(s.id)"><cx-icon name="download" [size]="14" />Updates installieren</button>
                  @if (hasRestore()) {
                    <button z-button zType="outline" zSize="sm" type="button" (click)="store.restorePrevious(s.id)"><cx-icon name="history" [size]="14" />Vorherige Version wiederherstellen</button>
                  }
                </div>
                <p class="mt-1.5 text-[11.5px] text-zinc-600">Vor jedem Update werden vorheriges Image und Konfiguration gesichert. Wiederherstellung nur manuell; keine automatische Rückkehr, Anwendungsdaten werden nicht zurückgesetzt.</p>
              </section>
              <fieldset class="rounded-lg border border-zinc-200 bg-white p-3">
                <legend class="px-1 text-[12px] font-semibold">Automatische Updates</legend>
                @for (o of autoOptions; track o.id) {
                  <label class="flex items-start gap-2 py-1">
                    <input type="radio" class="mt-0.5 size-4 accent-zinc-900" [name]="'au-' + s.id" [checked]="s.autoUpdate === o.id" (change)="store.setAutoUpdate(s.id, o.id)" />
                    <span><span class="font-medium">{{ o.label }}</span><span class="block text-[12px] text-zinc-600">{{ o.hint }}</span></span>
                  </label>
                }
              </fieldset>
            </div>
          }
          @case ('backups') {
            <div class="grid items-start gap-3 lg:grid-cols-2">
              <section class="rounded-lg border border-zinc-200 bg-white p-3">
                <dl class="grid grid-cols-[110px_1fr] gap-x-3 gap-y-1.5 text-[12.5px]">
                  <dt class="text-zinc-500">Letztes Backup</dt><dd class="font-medium">{{ s.backup.last }}</dd>
                  <dt class="text-zinc-500">Zeitplan</dt><dd>{{ s.backup.schedule }}</dd>
                  <dt class="text-zinc-500">Ziel</dt><dd>{{ s.backup.target }}</dd>
                  <dt class="text-zinc-500">Aufbewahrung</dt><dd>{{ s.backup.retention }}</dd>
                </dl>
                <div class="mt-3 flex flex-wrap gap-1.5">
                  <button z-button zSize="sm" type="button" (click)="store.backupNow(s.id)"><cx-icon name="archive" [size]="14" />Backup jetzt</button>
                  <button z-button zType="outline" zSize="sm" type="button" (click)="store.notify('Wiederherstellung aus Sicherung ' + s.backup.last + ' vorbereitet (Demo).')"><cx-icon name="history" [size]="14" />Aus Sicherung wiederherstellen</button>
                </div>
                <p class="mt-2 text-[11.5px] text-zinc-600">Ziele: lokale Verzeichnisse, vorhandene Host-Mounts oder eigene SMB-/NFS-Freigaben (Hub-Einstellungen). Kein S3.</p>
              </section>
              <section class="rounded-lg border border-zinc-200 bg-white p-3">
                <h3 class="mb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Enthalten</h3>
                <ul class="space-y-1">
                  @for (m of mounts(); track m.id) {
                    <li class="flex items-center gap-2 text-[12.5px]"><input type="checkbox" class="size-4 accent-zinc-900" checked [attr.aria-label]="m.name + ' sichern'" /><span class="font-mono">{{ m.name }}</span><span class="text-zinc-500">({{ m.kind === 'volume' ? 'Volume' : 'Bind-Mount' }})</span></li>
                  }
                  <li class="flex items-center gap-2 text-[12.5px]"><input type="checkbox" class="size-4 accent-zinc-900" checked aria-label="Projektdateien sichern" /><span>compose.yaml + .env</span></li>
                </ul>
              </section>
            </div>
          }
        }
      }
    </div>

    <cx-dialog [open]="confirm() !== null" [heading]="confirm() === 'remove' ? 'Stack entfernen?' : 'Stack stoppen?'" [description]="confirm() === 'remove' ? 'Container und Stack-Netzwerke werden entfernt. Volumes und Projektdateien bleiben erhalten (Simulation).' : 'Alle Container dieses Stacks werden gestoppt (Simulation).'" [icon]="confirm() === 'remove' ? 'trash' : 'stop'" tone="danger" width="sm" (closed)="confirm.set(null)">
      <div cx-footer class="flex gap-2">
        <button z-button zType="outline" zSize="sm" type="button" (click)="confirm.set(null)">Abbrechen</button>
        <button z-button zType="destructive" zSize="sm" type="button" (click)="doConfirm()">{{ confirm() === 'remove' ? 'Entfernen' : 'Stoppen' }}</button>
      </div>
    </cx-dialog>
  `,
})
export class CxStackPage {
  protected readonly store = inject(CxStore);
  protected readonly tabs = TABS;
  protected readonly openFile = signal<string | null>('compose.yaml');
  protected readonly logOnly = signal<string | null>(null);
  protected readonly confirm = signal<'stop' | 'remove' | null>(null);

  protected readonly autoOptions: { id: AutoUpdate; label: string; hint: string }[] = [
    { id: 'pruefen', label: 'Nur prüfen (Standard)', hint: 'Updates werden erkannt und angezeigt, aber nicht installiert.' },
    { id: 'taeglich', label: 'Automatisch täglich 04:00', hint: 'Installiert verfügbare Updates nach Zeitplan.' },
    { id: 'woechentlich', label: 'Automatisch wöchentlich So 04:00', hint: 'Installiert verfügbare Updates einmal pro Woche.' },
  ];

  private readonly stack = computed<Stack | null>(() => this.store.currentStack());
  protected readonly updates = computed(() => this.stack()?.services.filter((x) => x.newTag) ?? []);
  protected readonly hasRestore = computed(() => {
    const s = this.stack();
    return !!s && !!this.store.restorePoints()[s.id];
  });
  protected readonly unhealthy = computed(() => this.stack()?.services.find((x) => x.health === 'unhealthy')?.name ?? '');
  protected readonly mounts = computed(() => {
    const s = this.stack();
    return s ? this.store.mounts().filter((m) => s.mounts.includes(m.id)) : [];
  });
  protected readonly networks = computed(() => [...new Set((this.stack()?.services ?? []).flatMap((x) => x.networks))]);
  protected readonly lastAction = computed(() => {
    const s = this.stack();
    return s ? (this.store.actions().find((a) => a.stackId === s.id) ?? null) : null;
  });
  protected readonly projectFiles = computed(() => {
    const s = this.stack();
    if (!s) return [];
    return [
      { name: 'compose.yaml', size: `${(s.compose.length / 1024).toFixed(1)} KB`, content: s.compose },
      { name: '.env', size: `${s.env.length} B`, content: s.env || '# leer' },
    ];
  });

  protected checked(e: Event): boolean {
    return (e.target as HTMLInputElement).checked;
  }

  protected autoLabel(v: AutoUpdate): string {
    return v === 'pruefen' ? 'nur prüfen' : v === 'taeglich' ? 'automatisch täglich' : 'automatisch wöchentlich';
  }

  protected selectTab(id: StackTab): void {
    this.logOnly.set(null);
    this.store.setStackTab(id);
  }

  protected showLogs(svc: string): void {
    this.logOnly.set(svc);
    this.store.setStackTab('logs');
  }

  protected editLabels(): void {
    this.store.setStackTab('editor');
    this.store.editorMode.set('easy');
    this.store.editorStep.set('basics');
  }

  protected doConfirm(): void {
    const s = this.stack();
    const what = this.confirm();
    this.confirm.set(null);
    if (!s) return;
    if (what === 'stop') this.store.stackOp(s.id, 'stop');
    if (what === 'remove') this.store.removeStack(s.id);
  }

  protected onTabKey(ev: KeyboardEvent): void {
    if (ev.key !== 'ArrowRight' && ev.key !== 'ArrowLeft' && ev.key !== 'Home' && ev.key !== 'End') return;
    if (!this.stack()) return;
    ev.preventDefault();
    const i = TABS.findIndex((t) => t.id === this.store.stackTab());
    let next = i;
    if (ev.key === 'ArrowRight') next = (i + 1) % TABS.length;
    if (ev.key === 'ArrowLeft') next = (i - 1 + TABS.length) % TABS.length;
    if (ev.key === 'Home') next = 0;
    if (ev.key === 'End') next = TABS.length - 1;
    if (TABS[next].id !== 'logs') this.logOnly.set(null);
    this.store.setStackTab(TABS[next].id);
    setTimeout(() => document.getElementById('st-tab-' + TABS[next].id)?.focus());
  }
}
