// Docklet Design Lab – opus-compact · Kompakte Popups rechts oben
// Aktionen zeigen Ablauf (Schritte, Phase, Fortschritt, Ergebnis, betroffene Services). Das Aktionszentrum
// öffnet sich nicht automatisch, ist aber über „Details“ erreichbar.
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import type { ActionItem } from './data';
import { CxIcon } from './icon';
import { CxStore, type Toast } from './store';

interface ToastView {
  t: Toast;
  a: ActionItem | null;
}

@Component({
  selector: 'cx-toasts',
  imports: [CxIcon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: `
    .cx-in { animation: cx-in 200ms cubic-bezier(.2,.8,.2,1); }
    @keyframes cx-in { from { opacity: 0; transform: translateY(-6px); } }
    @media (prefers-reduced-motion: reduce) { .cx-in { animation: none; } }
  `,
  template: `
    <section class="pointer-events-none fixed right-3 top-14 z-[60] flex w-[min(360px,calc(100vw-1.5rem))] flex-col gap-2" aria-label="Benachrichtigungen" aria-live="polite">
      @for (v of views(); track v.t.id) {
        @if (v.a; as a) {
          @let h = store.host(a.hostId);
          <div class="cx-in pointer-events-auto overflow-hidden rounded-lg border border-zinc-200 bg-white shadow-lg" role="status">
            <div class="h-0.5" [style.background-color]="h.color"></div>
            <div class="flex items-start gap-2 p-2.5">
              <span class="mt-0.5 grid size-5 shrink-0 place-items-center">
                @switch (a.status) {
                  @case ('running') { <span class="size-4 rounded-full border-2 border-zinc-300 border-t-sky-600 motion-safe:animate-spin" aria-hidden="true"></span> }
                  @case ('success') { <cx-icon name="checkCircle" [size]="17" class="text-emerald-600" /> }
                  @case ('error') { <cx-icon name="xCircle" [size]="17" class="text-red-600" /> }
                  @default { <cx-icon name="clock" [size]="16" class="text-zinc-500" /> }
                }
              </span>
              <div class="min-w-0 flex-1">
                <div class="truncate text-[13px] font-medium">{{ a.title }}</div>
                <div class="truncate text-[11.5px] text-zinc-500">
                  {{ h.name }} ·
                  @if (a.status === 'running') { Schritt {{ a.step + 1 }}/{{ a.steps.length }}: {{ a.steps[a.step] }} }
                  @else if (a.status === 'success') { Abgeschlossen }
                  @else if (a.status === 'error') { Fehlgeschlagen bei „{{ a.steps[a.step] }}“ }
                </div>
                <ol class="mt-1.5 flex gap-0.5" [attr.aria-label]="'Ablauf ' + a.title">
                  @for (s of a.steps; track $index; let i = $index) {
                    <li class="h-1 flex-1 rounded-full" [class]="segCls(a, i)" [title]="s"><span class="sr-only">{{ s }}: {{ segLabel(a, i) }}</span></li>
                  }
                </ol>
                @if (a.services?.length) {
                  <div class="mt-1.5 flex flex-wrap gap-1">
                    @for (svc of (a.services ?? []).slice(0, 4); track svc) {
                      <span class="rounded border border-zinc-200 px-1 font-mono text-[10.5px] text-zinc-600">{{ svc }}</span>
                    }
                  </div>
                }
              </div>
              <div class="flex shrink-0 flex-col items-end gap-1">
                <button type="button" class="grid size-6 place-items-center rounded text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700" aria-label="Popup schließen" (click)="store.dismissToast(v.t.id)"><cx-icon name="x" [size]="13" /></button>
                <button type="button" class="rounded px-1 text-[11.5px] font-medium text-zinc-600 underline-offset-2 hover:text-zinc-900 hover:underline" (click)="store.showActionDetails(a.id)">Details</button>
              </div>
            </div>
          </div>
        } @else {
          <div class="cx-in pointer-events-auto flex items-start gap-2 rounded-lg border p-2.5 text-[12.5px] shadow-lg" [class]="v.t.kind === 'error' ? 'border-red-500/30 bg-white text-red-800' : 'border-zinc-200 bg-white text-zinc-800'" role="status">
            <cx-icon [name]="v.t.kind === 'error' ? 'alert' : 'info'" [size]="15" class="mt-px shrink-0" [class]="v.t.kind === 'error' ? 'text-red-600' : 'text-sky-600'" />
            <span class="min-w-0 flex-1">{{ v.t.text }}</span>
            <button type="button" class="grid size-5 shrink-0 place-items-center rounded text-zinc-400 hover:text-zinc-700" aria-label="Popup schließen" (click)="store.dismissToast(v.t.id)"><cx-icon name="x" [size]="12" /></button>
          </div>
        }
      }
    </section>
  `,
})
export class CxToasts {
  protected readonly store = inject(CxStore);

  protected readonly views = computed<ToastView[]>(() => {
    const actions = this.store.actions();
    return this.store.toasts().map((t) => ({ t, a: t.actionId ? (actions.find((x) => x.id === t.actionId) ?? null) : null }));
  });

  protected segCls(a: ActionItem, i: number): string {
    if (i < a.step) return 'bg-emerald-500';
    if (i === a.step && a.status === 'running') return 'bg-sky-500 motion-safe:animate-pulse';
    if (i === a.step && a.status === 'error') return 'bg-red-500';
    if (a.status === 'success') return 'bg-emerald-500';
    return 'bg-zinc-200';
  }

  protected segLabel(a: ActionItem, i: number): string {
    if (i < a.step || a.status === 'success') return 'erledigt';
    if (i === a.step && a.status === 'running') return 'läuft';
    if (i === a.step && a.status === 'error') return 'Fehler';
    return 'ausstehend';
  }
}
