// Docklet Design Lab – opus-compact · Editor-Entwurf
// Ein Entwurf, zwei Sichten: Easy (Formular) und Advanced (Raw Compose) arbeiten auf demselben Raw-Text.
import { Injectable, computed, inject } from '@angular/core';
import type { Document } from 'yaml';
import {
  addService,
  collectHints,
  editCompose,
  parseCompose,
  removeService,
  renameService,
  setEnv,
  setHealthField,
  setScalarField,
  setStackName,
  setStringList,
  type ComposeModel,
  type EnvRow,
  type HealthField,
  type ListField,
  type ScalarField,
} from './compose';
import { CxStore } from './store';

export type SubStep = 'image' | 'ports' | 'mounts' | 'env' | 'health';
export const SUB_STEPS: { id: SubStep; label: string }[] = [
  { id: 'image', label: 'Image' },
  { id: 'ports', label: 'Ports' },
  { id: 'mounts', label: 'Mounts' },
  { id: 'env', label: 'Variablen' },
  { id: 'health', label: 'Healthcheck' },
];

export interface StepRef {
  kind: 'basics' | 'service' | 'review';
  index: number;
  sub: SubStep;
}

@Injectable()
export class CxDraft {
  private readonly store = inject(CxStore);
  readonly raw = this.store.draftRaw;
  private lastGood: ComposeModel | null = null;

  readonly parsed = computed(() => parseCompose(this.raw()));
  readonly valid = computed(() => this.parsed().ok);

  /** Letzter gültiger Stand – bei YAML-Fehlern bleibt das Formular lesbar, aber gesperrt. */
  readonly model = computed<ComposeModel | null>(() => {
    const p = this.parsed();
    if (p.ok) this.lastGood = p.model;
    return p.ok ? p.model : this.lastGood;
  });

  readonly hints = computed(() => (this.valid() ? collectHints(this.model()) : []));
  readonly blocking = computed(() => !this.valid() || this.hints().some((h) => h.level === 'pflicht'));

  readonly step = computed<StepRef>(() => {
    const raw = this.store.editorStep();
    const m = /^svc-(\d+)-(\w+)$/.exec(raw);
    const count = this.model()?.services.length ?? 0;
    if (m) {
      const index = Math.min(Number(m[1]), Math.max(0, count - 1));
      if (count === 0) return { kind: 'basics', index: 0, sub: 'image' };
      return { kind: 'service', index, sub: (SUB_STEPS.some((s) => s.id === m[2]) ? m[2] : 'image') as SubStep };
    }
    return { kind: raw === 'review' ? 'review' : 'basics', index: 0, sub: 'image' };
  });

  /** Lineare Schrittfolge für Zurück/Weiter. */
  readonly order = computed<string[]>(() => {
    const n = this.model()?.services.length ?? 0;
    const list = ['basics'];
    for (let i = 0; i < n; i++) for (const s of SUB_STEPS) list.push(`svc-${i}-${s.id}`);
    list.push('review');
    return list;
  });

  go(step: string): void {
    this.store.editorStep.set(step);
  }

  goService(index: number, sub: SubStep = 'image'): void {
    this.go(`svc-${index}-${sub}`);
  }

  move(dir: -1 | 1): void {
    const order = this.order();
    const cur = this.store.editorStep();
    const i = Math.max(0, order.indexOf(cur));
    const next = order[Math.min(order.length - 1, Math.max(0, i + dir))];
    this.go(next);
  }

  apply(fn: (doc: Document) => void): void {
    if (!this.valid()) return;
    this.raw.set(editCompose(this.raw(), fn));
  }

  setName(name: string): void {
    this.apply((d) => setStackName(d, name));
  }

  setField(key: string, field: ScalarField, value: string): void {
    this.apply((d) => setScalarField(d, key, field, value));
  }

  setList(key: string, field: ListField, values: string[]): void {
    this.apply((d) => setStringList(d, key, field, values));
  }

  setEnv(key: string, rows: EnvRow[], style: 'map' | 'list'): void {
    this.apply((d) => setEnv(d, key, rows, style));
  }

  setHealth(key: string, field: HealthField, value: string): void {
    this.apply((d) => setHealthField(d, key, field, value));
  }

  addService(key: string, body: Record<string, unknown>): void {
    this.apply((d) => addService(d, key, body));
    const idx = (this.model()?.services.findIndex((s) => s.key === key) ?? -1);
    if (idx >= 0) this.goService(idx);
  }

  removeService(key: string): void {
    this.apply((d) => removeService(d, key));
    this.go('basics');
  }

  renameService(oldKey: string, newKey: string): void {
    const clean = newKey.trim().toLowerCase().replace(/[^a-z0-9_.-]+/g, '-');
    if (!clean) return;
    this.apply((d) => renameService(d, oldKey, clean));
  }
}
