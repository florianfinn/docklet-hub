import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';

/*
 * Leere Style-Hosts mit globalen, präfixierten Primitiven (oa-*).
 * Farben und Radien folgen den Arcane-Tokens (routes/layout.css, Standard-Dark):
 * neutrale Grautöne, Violett als Primärfarbe, success/warning/destructive/info.
 * Aufgeteilt, damit jedes Komponenten-Stylesheet unter 4 kB bleibt.
 */

@Component({
  selector: 'oa-primitives-base',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-root{--oa-bg:oklch(.145 0 0);--oa-side:oklch(.205 0 0);--oa-card:oklch(.205 0 0);--oa-pop:oklch(.205 0 0);--oa-mbg:oklch(.269 0 0);--oa-code:oklch(.17 0 0);--oa-line:oklch(1 0 0/10%);--oa-line2:oklch(1 0 0/15%);--oa-fg:oklch(.985 0 0);--oa-muted:oklch(.708 0 0);--oa-dim:oklch(.556 0 0);--oa-accent:oklch(.541 .281 293.009);--oa-accent-fg:oklch(.702 .183 293.541);--oa-accent-soft:color-mix(in oklch,var(--oa-accent) 15%,transparent);--oa-ok:oklch(.765 .177 163.223);--oa-warn:oklch(.828 .189 84.429);--oa-err:oklch(.704 .191 22.216);--oa-info:oklch(.707 .165 254.624);--oa-orange:oklch(.75 .183 55.934);--oa-lime:oklch(.841 .238 128.85);--oa-sky:oklch(.746 .16 232.661);--oa-violet:oklch(.702 .183 293.541);--oa-pink:oklch(.718 .202 349.761);--oa-cyan:oklch(.789 .154 211.53);--oa-r:14px;
      --primary:var(--oa-accent);--primary-foreground:oklch(.969 .016 293.756);--ring:var(--oa-accent);--background:var(--oa-bg);--foreground:var(--oa-fg);--border:var(--oa-line);--input:var(--oa-line2);--muted:var(--oa-mbg);--secondary:oklch(.274 .006 286);--secondary-foreground:var(--oa-fg);--destructive:var(--oa-err);--card:var(--oa-card);
      font-family:'Inter','Segoe UI',system-ui,sans-serif;font-size:14px;line-height:1.5;color:var(--oa-fg);-webkit-font-smoothing:antialiased;color-scheme:dark}
    .oa-root *:focus-visible{outline:2px solid var(--oa-accent);outline-offset:2px}
    .oa-card{position:relative;background:var(--oa-card);border:1px solid var(--oa-line);border-radius:var(--oa-r);padding:16px;box-shadow:0 1px 2px rgb(0 0 0/.18)}
    .oa-card-head{display:flex;align-items:center;gap:10px;margin-bottom:12px}
    .oa-card-head h3{font-size:14px;font-weight:600;margin:0}
    .oa-card-ico{display:grid;place-items:center;width:30px;height:30px;border-radius:10px;flex-shrink:0;color:var(--t,var(--oa-accent-fg));background:color-mix(in oklch,var(--t,var(--oa-accent)) 14%,transparent)}
    .oa-pill{--c:var(--t,var(--oa-muted));display:inline-flex;align-items:center;justify-content:center;gap:5px;height:22px;padding:0 9px;border-radius:9px;font-size:12px;font-weight:500;white-space:nowrap;border:1px solid color-mix(in oklch,var(--c) 28%,transparent);color:var(--c);background:color-mix(in oklch,var(--c) 11%,transparent)}
    .oa-pill--status{min-width:80px}
    .oa-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--t,var(--oa-dim));flex-shrink:0}
    .oa-dot[data-tone=err]{animation:oa-pulse 1.8s infinite}
    @keyframes oa-pulse{50%{box-shadow:0 0 0 5px color-mix(in oklch,var(--oa-err) 0%,transparent)}0%{box-shadow:0 0 0 0 color-mix(in oklch,var(--oa-err) 45%,transparent)}}
    .oa-ibtn{display:inline-grid;place-items:center;width:32px;height:32px;border-radius:10px;border:1px solid transparent;color:var(--oa-muted);background:transparent;cursor:pointer;transition:background .15s,color .15s}
    .oa-ibtn:hover{background:var(--oa-mbg);color:var(--oa-fg)}
    .oa-ibtn:disabled{opacity:.4;cursor:not-allowed}
    .oa-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .oa-sp{flex:1}
    .oa-muted{color:var(--oa-muted)}
    .oa-dim{color:var(--oa-dim)}
    .oa-small{font-size:12px}
    .oa-mono{font-family:'JetBrains Mono','Cascadia Code',ui-monospace,monospace;font-size:12.5px}
    .oa-host{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--oa-muted);white-space:nowrap}
    .oa-host i{width:8px;height:8px;border-radius:3px;background:var(--hc,#888)}
    .oa-bar{height:6px;border-radius:99px;background:color-mix(in oklch,var(--oa-mbg) 70%,transparent);overflow:hidden}
    .oa-bar>span{display:block;height:100%;border-radius:inherit;background:var(--bc,var(--oa-accent));transition:width .6s ease}
    .oa-kv{display:grid;grid-template-columns:minmax(110px,auto) 1fr;gap:6px 14px;font-size:13px;margin:0}
    .oa-kv dt{color:var(--oa-muted)}
    .oa-kv dd{margin:0;min-width:0;overflow-wrap:anywhere}
    .oa-sr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
  `,
})
export class PrimitivesBaseComponent {}

@Component({
  selector: 'oa-primitives-theme',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-root.oa-light{--oa-bg:oklch(1 0 0);--oa-side:oklch(.985 0 0);--oa-card:oklch(1 0 0);--oa-pop:oklch(1 0 0);--oa-mbg:oklch(.96 0 0);--oa-code:oklch(.975 0 0);--oa-line:oklch(.905 0 0);--oa-line2:oklch(.87 0 0);--oa-fg:oklch(.145 0 0);--oa-muted:oklch(.52 0 0);--oa-dim:oklch(.6 0 0);--oa-accent:oklch(.606 .25 292.717);--oa-accent-fg:oklch(.541 .281 293.009);--oa-ok:oklch(.596 .145 163.225);--oa-warn:oklch(.666 .179 58.318);--oa-err:oklch(.577 .245 27.325);--oa-info:oklch(.546 .245 262.881);--oa-orange:oklch(.646 .222 41.116);--oa-lime:oklch(.648 .2 131.684);--oa-sky:oklch(.588 .158 241.966);--oa-violet:oklch(.541 .281 293.009);--oa-pink:oklch(.592 .249 .584);--oa-cyan:oklch(.609 .126 221.723);--secondary:oklch(.967 .001 286);color-scheme:light}
    [data-tone]{--t:var(--oa-muted)}
    [data-tone=ok]{--t:var(--oa-ok)}
    [data-tone=warn]{--t:var(--oa-warn)}
    [data-tone=err]{--t:var(--oa-err)}
    [data-tone=info]{--t:var(--oa-info)}
    [data-tone=accent]{--t:var(--oa-accent-fg)}
    [data-tone=orange]{--t:var(--oa-orange)}
    [data-tone=violet]{--t:var(--oa-violet)}
    [data-tone=sky]{--t:var(--oa-sky)}
    [data-tone=lime]{--t:var(--oa-lime)}
    [data-tone=pink]{--t:var(--oa-pink)}
    [data-tone=cyan]{--t:var(--oa-cyan)}
  `,
})
export class PrimitivesThemeComponent {}

@Component({
  selector: 'oa-primitives-forms',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-field{display:flex;flex-direction:column;gap:6px;min-width:0}
    .oa-label{font-size:13px;font-weight:500;color:var(--oa-fg);display:flex;align-items:center;gap:6px}
    .oa-req{color:var(--oa-err)}
    .oa-help{font-size:12px;color:var(--oa-dim);line-height:1.4}
    .oa-errtxt{font-size:12px;color:var(--oa-err);display:flex;gap:5px;align-items:center}
    .oa-warntxt{font-size:12px;color:var(--oa-warn);display:flex;gap:5px;align-items:center}
    .oa-input,.oa-select,.oa-textarea{width:100%;min-width:0;height:36px;padding:0 11px;border-radius:10px;border:1px solid var(--oa-line2);background:color-mix(in oklch,var(--oa-line2) 30%,transparent);color:var(--oa-fg);font:inherit;font-size:13.5px;transition:border-color .15s,box-shadow .15s}
    .oa-textarea{height:auto;padding:10px 11px;resize:vertical;line-height:1.5}
    .oa-input::placeholder,.oa-textarea::placeholder{color:var(--oa-dim)}
    .oa-input:focus,.oa-select:focus,.oa-textarea:focus{outline:none;border-color:var(--oa-accent);box-shadow:0 0 0 3px color-mix(in oklch,var(--oa-accent) 35%,transparent)}
    .oa-input[aria-invalid=true]{border-color:var(--oa-err)}
    .oa-input[readonly]{color:var(--oa-muted)}
    .oa-select{appearance:none;background-image:linear-gradient(45deg,transparent 50%,var(--oa-muted) 50%),linear-gradient(135deg,var(--oa-muted) 50%,transparent 50%);background-position:calc(100% - 15px) 15px,calc(100% - 10px) 15px;background-size:5px 5px;background-repeat:no-repeat;padding-right:28px}
    .oa-select option{background:var(--oa-pop);color:var(--oa-fg)}
    .oa-switch{position:relative;width:36px;height:20px;border-radius:99px;border:1px solid transparent;background:var(--oa-line2);cursor:pointer;flex-shrink:0;transition:background .18s}
    .oa-switch::after{content:'';position:absolute;top:1px;left:1px;width:16px;height:16px;border-radius:50%;background:var(--oa-fg);transition:transform .18s}
    .oa-switch[aria-checked=true]{background:var(--oa-accent)}
    .oa-switch[aria-checked=true]::after{transform:translateX(16px);background:#fff}
    .oa-check{display:inline-flex;align-items:center;gap:8px;font-size:13px;cursor:pointer}
    .oa-check input{width:16px;height:16px;accent-color:var(--oa-accent)}
    .oa-callout{--c:var(--t,var(--oa-muted));display:flex;gap:10px;align-items:flex-start;padding:11px 13px;border-radius:12px;border:1px solid color-mix(in oklch,var(--c) 30%,transparent);background:color-mix(in oklch,var(--c) 8%,transparent);font-size:13px;line-height:1.45}
    .oa-callout>oa-icon{margin-top:2px;color:var(--c)}
    .oa-code{margin:0;padding:12px 14px;border-radius:12px;border:1px solid var(--oa-line);background:var(--oa-code);color:var(--oa-fg);font-family:'JetBrains Mono','Cascadia Code',ui-monospace,monospace;font-size:12.5px;line-height:1.6;overflow:auto;white-space:pre}
    .oa-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}
    .oa-list>li{display:flex;align-items:center;gap:10px;padding:10px 0;border-top:1px solid color-mix(in oklch,var(--oa-line) 60%,transparent)}
    .oa-list>li:first-child{border-top:0}
    .oa-tag{display:inline-flex;align-items:center;gap:4px;height:22px;padding:0 8px;border-radius:9px;font-size:12px;font-weight:500;color:var(--t);background:color-mix(in oklch,var(--t) 12%,transparent);border:1px solid color-mix(in oklch,var(--t) 25%,transparent)}
    .oa-tag button{border:0;background:none;color:inherit;padding:0;cursor:pointer;display:inline-grid}
  `,
})
export class PrimitivesFormsComponent {}

@Component({
  selector: 'oa-primitives-controls',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-btn{display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 11px;border-radius:10px;border:1px solid var(--oa-line2);background:color-mix(in oklch,var(--oa-line2) 30%,transparent);color:var(--oa-fg);font-size:13px;font-weight:500;cursor:pointer;white-space:nowrap;transition:background .15s,border-color .15s}
    .oa-btn:hover{background:var(--oa-mbg)}
    .oa-btn:disabled{opacity:.45;cursor:not-allowed}
    .oa-btn[data-tone]{color:var(--t);border-color:color-mix(in oklch,var(--t) 30%,transparent);background:color-mix(in oklch,var(--t) 10%,transparent)}
    .oa-chip{display:inline-flex;align-items:center;gap:7px;height:30px;padding:0 11px;border-radius:10px;border:1px dashed var(--oa-line2);background:transparent;color:var(--oa-muted);font-size:12.5px;cursor:pointer;transition:all .15s}
    .oa-chip:hover{color:var(--oa-fg);background:var(--oa-mbg)}
    .oa-chip[aria-pressed=true]{color:var(--oa-fg);border-style:solid;background:var(--oa-accent-soft);border-color:color-mix(in oklch,var(--oa-accent) 50%,transparent)}
    .oa-tabs{display:inline-flex;gap:2px;padding:3px;border-radius:12px;background:var(--oa-mbg);overflow-x:auto;scrollbar-width:none;max-width:100%}
    .oa-tab{display:inline-flex;align-items:center;gap:7px;height:30px;padding:0 12px;border:0;border-radius:9px;background:none;color:var(--oa-muted);font-size:13px;font-weight:500;cursor:pointer;white-space:nowrap}
    .oa-tab:hover{color:var(--oa-fg)}
    .oa-tab:disabled{opacity:.4;cursor:not-allowed}
    .oa-tab[aria-selected=true]{color:var(--oa-fg);background:var(--oa-bg);box-shadow:0 1px 3px rgb(0 0 0/.3)}
    .oa-seg{display:inline-flex;padding:3px;border-radius:11px;background:var(--oa-mbg)}
    .oa-seg button{display:inline-flex;align-items:center;gap:6px;height:28px;padding:0 12px;border:0;border-radius:8px;background:none;color:var(--oa-muted);font-size:12.5px;font-weight:500;cursor:pointer}
    .oa-seg button[aria-pressed=true],.oa-seg button[aria-checked=true]{background:var(--oa-bg);color:var(--oa-fg);box-shadow:0 1px 3px rgb(0 0 0/.3)}
    .oa-table{width:100%;border-collapse:collapse;font-size:13.5px}
    .oa-table th{text-align:left;font-weight:500;font-size:13px;color:var(--oa-muted);height:40px;padding:0 12px;border-bottom:1px solid var(--oa-line);white-space:nowrap}
    .oa-table td{padding:10px 12px;border-bottom:1px solid var(--oa-line);vertical-align:middle}
    .oa-table tr:last-child td{border-bottom:0}
    .oa-table tbody tr:hover{background:color-mix(in oklch,var(--oa-mbg) 50%,transparent)}
    .oa-scroll-x{overflow-x:auto}
    .oa-grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    .oa-grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
    @media (max-width:720px){.oa-grid2,.oa-grid3{grid-template-columns:1fr}}
    .oa-page-head{display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap;margin-bottom:20px}
    .oa-page-head h1{font-size:24px;font-weight:600;letter-spacing:-.02em;margin:0}
    .oa-page-head p{margin:2px 0 0;color:var(--oa-muted);font-size:14px}
    .oa-section-title{font-size:13px;font-weight:500;color:var(--oa-muted);margin:22px 0 10px}
    .oa-spin{animation:oa-spin 1s linear infinite}
    @keyframes oa-spin{to{transform:rotate(360deg)}}
    @media (prefers-reduced-motion:reduce){.oa-root *,.oa-root *::before,.oa-root *::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important}}
  `,
})
export class PrimitivesControlsComponent {}

@Component({
  selector: 'oa-primitives-shell',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-tipwrap{position:relative;display:inline-flex}
    .oa-tip{position:absolute;z-index:40;left:50%;top:calc(100% + 6px);transform:translateX(-50%);min-width:220px;max-width:300px;padding:10px 12px;border-radius:12px;background:var(--oa-pop);border:1px solid var(--oa-line);box-shadow:0 12px 32px -8px rgb(0 0 0/.6);font-size:12.5px;color:var(--oa-fg);opacity:0;visibility:hidden;transition:opacity .12s;pointer-events:none;text-align:left;white-space:normal}
    .oa-tipwrap:hover>.oa-tip,.oa-tipwrap:focus-within>.oa-tip{opacity:1;visibility:visible}
    .oa-tip ul{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:4px}
    .oa-tip li{display:flex;align-items:center;gap:7px}
    .oa-tip strong{font-size:12.5px}
    .oa-menu{position:absolute;z-index:45;min-width:220px;padding:4px;border-radius:12px;background:var(--oa-pop);border:1px solid var(--oa-line);box-shadow:0 16px 40px -10px rgb(0 0 0/.7);animation:oa-menu .12s ease-out}
    @keyframes oa-menu{from{opacity:0;transform:translateY(4px)}}
    .oa-menu-item{display:flex;align-items:center;gap:10px;width:100%;height:34px;padding:0 9px;border:0;border-radius:8px;background:none;color:var(--oa-fg);font-size:13.5px;text-align:left;cursor:pointer}
    .oa-menu-item oa-icon{color:var(--oa-muted)}
    .oa-menu-item:hover,.oa-menu-item:focus-visible{background:var(--oa-mbg);outline:none}
    .oa-menu-item[data-tone=err],.oa-menu-item[data-tone=err] oa-icon{color:var(--oa-err)}
    .oa-menu-item:disabled{opacity:.45;cursor:not-allowed}
    .oa-menu-sep{height:1px;margin:4px -4px;background:var(--oa-line)}
    .oa-strip{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));border-block:1px solid color-mix(in oklch,var(--oa-line) 60%,transparent);padding:18px 0;margin:0 0 20px}
    .oa-strip>div{display:flex;flex-direction:column;align-items:center;gap:6px;padding:0 12px;text-align:center}
    .oa-strip>div+div{border-left:1px solid color-mix(in oklch,var(--oa-line) 60%,transparent)}
    .oa-strip dt{font-size:13.5px;color:var(--oa-muted);display:flex;align-items:center;gap:6px}
    .oa-strip dd{margin:0;font-size:28px;font-weight:600;font-variant-numeric:tabular-nums;line-height:1.1}
    .oa-strip small{display:block;font-size:12px;color:var(--oa-muted);font-weight:400}
    @media (max-width:720px){.oa-strip{grid-template-columns:1fr 1fr;row-gap:16px}.oa-strip>div:nth-child(3){border-left:0}}
    @media (max-width:960px){
      .oa-root{grid-template-columns:minmax(0,1fr)!important}
      .oa-side{position:fixed!important;inset:0 auto 0 0;z-index:70;width:min(290px,86vw);margin:0!important;border-radius:0 16px 16px 0!important;height:100dvh!important;transform:translateX(-102%);transition:transform .22s ease}
      .oa-nav-open .oa-side{transform:none;box-shadow:20px 0 60px rgb(0 0 0/.6)}
      .oa-nav-open .oa-side-backdrop{display:block;position:fixed;inset:0;z-index:65;border:0;background:rgb(0 0 0/.55)}
      .oa-side-close,.oa-top{display:flex!important}
      .oa-content{padding:18px 14px!important}
    }
  `,
})
export class PrimitivesShellComponent {}
