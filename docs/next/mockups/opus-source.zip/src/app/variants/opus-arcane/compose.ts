/*
 * Compose-Synchronisation für den Stack-Editor.
 * Quelle der Wahrheit ist immer der Rohtext. Das Easy-Formular liest ein daraus
 * abgeleitetes Modell und schreibt Änderungen gezielt per yaml-Dokument-API
 * (parseDocument/setIn/deleteIn) zurück. Unbekannte Felder, Kommentare und
 * Reihenfolge bleiben dadurch erhalten. Bewusst begrenzter Subset:
 * name, image, container_name, restart, ports, volumes, environment, healthcheck.
 */
import { Document, isMap, isScalar, isSeq, parseDocument, Scalar } from 'yaml';

export interface PortRow {
  index: number;
  host: string;
  container: string;
  editable: boolean;
  raw: string;
}

export interface MountRow {
  index: number;
  source: string;
  target: string;
  ro: boolean;
  editable: boolean;
  raw: string;
}

export interface EnvRow {
  index: number;
  key: string;
  value: string;
}

export interface HealthModel {
  enabled: boolean;
  test: string;
  interval: string;
  retries: string;
}

export interface ServiceModel {
  key: string;
  image: string;
  containerName: string;
  restart: string;
  ports: PortRow[];
  mounts: MountRow[];
  env: EnvRow[];
  health: HealthModel;
  extras: string[];
}

export interface ComposeModel {
  name: string;
  services: ServiceModel[];
  extras: string[];
}

export interface ParseResult {
  model: ComposeModel | null;
  errors: string[];
}

export interface Issue {
  level: 'error' | 'warn';
  msg: string;
  service?: string;
  field?: 'image' | 'ports' | 'mounts' | 'env' | 'health' | 'name';
}

type Obj = Record<string, unknown>;

const KNOWN_SERVICE_KEYS = ['image', 'container_name', 'restart', 'ports', 'volumes', 'environment', 'healthcheck'];
const KNOWN_ROOT_KEYS = ['name', 'services'];

function isObj(v: unknown): v is Obj {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function str(v: unknown): string {
  if (v === null || v === undefined) return '';
  return typeof v === 'string' ? v : String(v);
}

/* ---------- Lesen ---------- */

export function parseCompose(text: string): ParseResult {
  let doc: Document.Parsed;
  try {
    doc = parseDocument(text);
  } catch (e) {
    return { model: null, errors: [String(e)] };
  }
  if (doc.errors.length) {
    return {
      model: null,
      errors: doc.errors.map((e) => {
        const pos = e.linePos?.[0];
        const first = e.message.split('\n')[0];
        return pos ? `Zeile ${pos.line}, Spalte ${pos.col}: ${first}` : first;
      }),
    };
  }
  let js: unknown;
  try {
    js = doc.toJS();
  } catch (e) {
    return { model: null, errors: [String(e)] };
  }
  if (js === null || js === undefined) js = {};
  if (!isObj(js)) return { model: null, errors: ['Die oberste Ebene muss eine Zuordnung (key: value) sein.'] };
  const rawServices = js['services'];
  if (rawServices !== null && rawServices !== undefined && !isObj(rawServices)) {
    return { model: null, errors: ['„services“ muss eine Zuordnung von Servicenamen sein.'] };
  }
  const services: ServiceModel[] = [];
  if (isObj(rawServices)) {
    for (const key of Object.keys(rawServices)) {
      const s = rawServices[key];
      services.push(readService(key, isObj(s) ? s : {}));
    }
  }
  return {
    model: {
      name: str(js['name']),
      services,
      extras: Object.keys(js).filter((k) => !KNOWN_ROOT_KEYS.includes(k)),
    },
    errors: [],
  };
}

function readService(key: string, s: Obj): ServiceModel {
  const ports: PortRow[] = [];
  const rawPorts = s['ports'];
  if (Array.isArray(rawPorts)) {
    rawPorts.forEach((p, index) => {
      if (typeof p === 'string' || typeof p === 'number') {
        const parts = String(p).split(':');
        const container = parts[parts.length - 1] ?? '';
        const host = parts.length > 1 ? parts.slice(0, -1).join(':') : '';
        ports.push({ index, host, container, editable: true, raw: String(p) });
      } else {
        ports.push({ index, host: '', container: '', editable: false, raw: JSON.stringify(p) });
      }
    });
  }
  const mounts: MountRow[] = [];
  const rawVols = s['volumes'];
  if (Array.isArray(rawVols)) {
    rawVols.forEach((v, index) => {
      if (typeof v === 'string') {
        const parts = v.split(':');
        if (parts.length === 1) {
          mounts.push({ index, source: '', target: parts[0], ro: false, editable: true, raw: v });
        } else {
          mounts.push({
            index,
            source: parts[0],
            target: parts[1] ?? '',
            ro: (parts[2] ?? '').split(',').includes('ro'),
            editable: true,
            raw: v,
          });
        }
      } else {
        mounts.push({ index, source: '', target: '', ro: false, editable: false, raw: JSON.stringify(v) });
      }
    });
  }
  const env: EnvRow[] = [];
  const rawEnv = s['environment'];
  if (Array.isArray(rawEnv)) {
    rawEnv.forEach((e, index) => {
      const t = str(e);
      const eq = t.indexOf('=');
      env.push({ index, key: eq < 0 ? t : t.slice(0, eq), value: eq < 0 ? '' : t.slice(eq + 1) });
    });
  } else if (isObj(rawEnv)) {
    Object.keys(rawEnv).forEach((k, index) => env.push({ index, key: k, value: str(rawEnv[k]) }));
  }
  const hc = s['healthcheck'];
  let health: HealthModel = { enabled: false, test: '', interval: '', retries: '' };
  if (isObj(hc) && hc['disable'] !== true) {
    const t = hc['test'];
    let test: string;
    if (Array.isArray(t)) {
      const arr = t.map(str);
      test = arr[0] === 'CMD-SHELL' || arr[0] === 'CMD' ? arr.slice(1).join(' ') : arr.join(' ');
    } else {
      test = str(t);
    }
    health = { enabled: true, test, interval: str(hc['interval']), retries: str(hc['retries']) };
  }
  return {
    key,
    image: str(s['image']),
    containerName: str(s['container_name']),
    restart: str(s['restart']),
    ports,
    mounts,
    env,
    health,
    extras: Object.keys(s).filter((k) => !KNOWN_SERVICE_KEYS.includes(k)),
  };
}

/* ---------- Prüfen ---------- */

export function validateModel(m: ComposeModel): Issue[] {
  const out: Issue[] = [];
  if (!m.name.trim()) out.push({ level: 'error', msg: 'Stackname fehlt', field: 'name' });
  else if (!/^[a-z0-9][a-z0-9_-]*$/.test(m.name)) {
    out.push({ level: 'warn', msg: 'Stackname sollte nur Kleinbuchstaben, Ziffern, - und _ enthalten', field: 'name' });
  }
  if (!m.services.length) out.push({ level: 'error', msg: 'Mindestens ein Service ist erforderlich' });
  for (const s of m.services) {
    if (!s.image.trim()) out.push({ level: 'error', msg: 'Image fehlt', service: s.key, field: 'image' });
    for (const p of s.ports) {
      if (!p.editable) continue;
      if (!p.container.trim()) out.push({ level: 'error', msg: `Port ${p.index + 1}: Container-Port fehlt`, service: s.key, field: 'ports' });
      else if (!/^\d+(-\d+)?(\/(tcp|udp))?$/.test(p.container.trim())) {
        out.push({ level: 'warn', msg: `Port ${p.index + 1}: ungewöhnlicher Container-Port`, service: s.key, field: 'ports' });
      }
      if (p.host && !/^(\d{1,3}(\.\d{1,3}){3}:)?\d+(-\d+)?$/.test(p.host.trim())) {
        out.push({ level: 'warn', msg: `Port ${p.index + 1}: Host-Port prüfen`, service: s.key, field: 'ports' });
      }
    }
    for (const v of s.mounts) {
      if (!v.editable) continue;
      if (!v.target.trim()) out.push({ level: 'error', msg: `Mount ${v.index + 1}: Zielpfad fehlt`, service: s.key, field: 'mounts' });
      else if (!v.target.startsWith('/')) out.push({ level: 'warn', msg: `Mount ${v.index + 1}: Zielpfad sollte absolut sein`, service: s.key, field: 'mounts' });
    }
    for (const e of s.env) {
      if (!e.key.trim()) out.push({ level: 'error', msg: `Variable ${e.index + 1}: Name fehlt`, service: s.key, field: 'env' });
      else if (!e.value.trim()) out.push({ level: 'warn', msg: `${e.key}: Wert leer`, service: s.key, field: 'env' });
    }
    if (s.health.enabled && !s.health.test.trim()) {
      out.push({ level: 'error', msg: 'Healthcheck aktiv, aber Testbefehl fehlt', service: s.key, field: 'health' });
    }
  }
  return out;
}

/* ---------- Schreiben ---------- */

export type Mutator = (doc: Document.Parsed) => void;

/** Wendet eine Änderung auf den Rohtext an. Wirft bei ungültigem YAML, damit nichts verloren geht. */
export function mutate(text: string, fn: Mutator): string {
  const doc = parseDocument(text);
  if (doc.errors.length) throw new Error('YAML ist ungültig – Änderung im Formular nicht möglich.');
  if (doc.contents === null) doc.contents = doc.createNode({}) as never;
  fn(doc);
  return doc.toString({ lineWidth: 0 });
}

const svcPath = (key: string, ...rest: (string | number)[]) => ['services', key, ...rest];

function quoted(doc: Document.Parsed, value: string): Scalar {
  const node = doc.createNode(value) as unknown as Scalar;
  node.type = Scalar.QUOTE_DOUBLE;
  return node;
}

function ensureSeq(doc: Document.Parsed, path: (string | number)[]): void {
  const node = doc.getIn(path, true);
  if (!isSeq(node)) doc.setIn(path, doc.createNode([]));
}

function ensureServices(doc: Document.Parsed): void {
  const node = doc.get('services', true);
  if (!isMap(node)) doc.set('services', doc.createNode({}));
}

export const ops = {
  setName: (v: string): Mutator => (doc) => doc.set('name', v),

  setField: (key: string, field: 'image' | 'container_name' | 'restart', v: string): Mutator => (doc) => {
    if (!v && field !== 'image') doc.deleteIn(svcPath(key, field));
    else doc.setIn(svcPath(key, field), v);
  },

  renameService: (oldKey: string, newKey: string): Mutator => (doc) => {
    const services = doc.get('services', true);
    if (!isMap(services)) return;
    if (services.items.some((p) => isScalar(p.key) && p.key.value === newKey)) {
      throw new Error(`Service „${newKey}“ existiert bereits.`);
    }
    const pair = services.items.find((p) => isScalar(p.key) && p.key.value === oldKey);
    if (pair && isScalar(pair.key)) pair.key.value = newKey;
  },

  addService: (key: string, body: Obj): Mutator => (doc) => {
    ensureServices(doc);
    doc.setIn(['services', key], doc.createNode(body));
  },

  removeService: (key: string): Mutator => (doc) => {
    doc.deleteIn(['services', key]);
  },

  addPort: (key: string): Mutator => (doc) => {
    ensureSeq(doc, svcPath(key, 'ports'));
    doc.addIn(svcPath(key, 'ports'), quoted(doc, ''));
  },

  setPort: (key: string, index: number, host: string, container: string): Mutator => (doc) => {
    const value = host.trim() ? `${host.trim()}:${container.trim()}` : container.trim();
    doc.setIn(svcPath(key, 'ports', index), value);
  },

  removePort: (key: string, index: number): Mutator => (doc) => {
    doc.deleteIn(svcPath(key, 'ports', index));
    const seq = doc.getIn(svcPath(key, 'ports'), true);
    if (isSeq(seq) && seq.items.length === 0) doc.deleteIn(svcPath(key, 'ports'));
  },

  addMount: (key: string): Mutator => (doc) => {
    ensureSeq(doc, svcPath(key, 'volumes'));
    doc.addIn(svcPath(key, 'volumes'), ':/data');
  },

  setMount: (key: string, index: number, source: string, target: string, ro: boolean): Mutator => (doc) => {
    const base = source.trim() ? `${source.trim()}:${target.trim()}` : target.trim();
    doc.setIn(svcPath(key, 'volumes', index), ro && source.trim() ? `${base}:ro` : base);
  },

  removeMount: (key: string, index: number): Mutator => (doc) => {
    doc.deleteIn(svcPath(key, 'volumes', index));
    const seq = doc.getIn(svcPath(key, 'volumes'), true);
    if (isSeq(seq) && seq.items.length === 0) doc.deleteIn(svcPath(key, 'volumes'));
  },

  addEnv: (key: string): Mutator => (doc) => {
    const path = svcPath(key, 'environment');
    const env = doc.getIn(path, true);
    if (isSeq(env)) {
      doc.addIn(path, `VARIABLE_${env.items.length + 1}=`);
    } else if (isMap(env)) {
      let n = env.items.length + 1;
      while (env.has(`VARIABLE_${n}`)) n++;
      env.set(`VARIABLE_${n}`, '');
    } else {
      doc.setIn(path, doc.createNode({ VARIABLE_1: '' }));
    }
  },

  setEnv: (key: string, index: number, name: string, value: string): Mutator => (doc) => {
    const env = doc.getIn(svcPath(key, 'environment'), true);
    if (isSeq(env)) {
      env.set(index, `${name}=${value}`);
    } else if (isMap(env)) {
      const pair = env.items[index];
      if (!pair) return;
      if (isScalar(pair.key)) pair.key.value = name;
      else pair.key = doc.createNode(name);
      if (isScalar(pair.value)) pair.value.value = value;
      else pair.value = doc.createNode(value);
    }
  },

  removeEnv: (key: string, index: number): Mutator => (doc) => {
    const path = svcPath(key, 'environment');
    const env = doc.getIn(path, true);
    if (isSeq(env)) env.delete(index);
    else if (isMap(env)) env.items.splice(index, 1);
    const after = doc.getIn(path, true);
    if ((isSeq(after) || isMap(after)) && after.items.length === 0) doc.deleteIn(path);
  },

  setHealthEnabled: (key: string, on: boolean): Mutator => (doc) => {
    const path = svcPath(key, 'healthcheck');
    if (!on) {
      doc.deleteIn(path);
      return;
    }
    const hc = doc.getIn(path, true);
    if (isMap(hc)) {
      hc.delete('disable');
      return;
    }
    doc.setIn(path, doc.createNode({ test: doc.createNode(['CMD-SHELL', ''], { flow: true }), interval: '30s', retries: 3 }));
  },

  setHealthTest: (key: string, cmd: string): Mutator => (doc) => {
    doc.setIn(svcPath(key, 'healthcheck', 'test'), doc.createNode(['CMD-SHELL', cmd], { flow: true }));
  },

  setHealthField: (key: string, field: 'interval' | 'retries', v: string): Mutator => (doc) => {
    const path = svcPath(key, 'healthcheck', field);
    if (!v.trim()) doc.deleteIn(path);
    else doc.setIn(path, field === 'retries' && /^\d+$/.test(v) ? Number(v) : v);
  },
};

export function uniqueKey(existing: string[], base: string): string {
  const clean = (base || 'service').toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'service';
  if (!existing.includes(clean)) return clean;
  let n = 2;
  while (existing.includes(`${clean}-${n}`)) n++;
  return `${clean}-${n}`;
}

/* ---------- docker run → Compose ---------- */

export interface Conversion {
  key: string;
  body: Obj;
  hints: string[];
}

function tokenize(input: string): string[] {
  const src = input.replace(/\\\r?\n/g, ' ').trim();
  const out: string[] = [];
  let cur = '';
  let quote: string | null = null;
  let has = false;
  for (const ch of src) {
    if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
      has = true;
    } else if (/\s/.test(ch)) {
      if (has || cur) out.push(cur);
      cur = '';
      has = false;
    } else {
      cur += ch;
      has = true;
    }
  }
  if (has || cur) out.push(cur);
  return out;
}

const VALUE_FLAGS: Record<string, string> = {
  '--name': 'name',
  '-p': 'port',
  '--publish': 'port',
  '-v': 'volume',
  '--volume': 'volume',
  '-e': 'env',
  '--env': 'env',
  '--restart': 'restart',
  '--network': 'network',
  '--net': 'network',
  '-l': 'label',
  '--label': 'label',
  '--health-cmd': 'hcmd',
  '--health-interval': 'hint',
  '--health-retries': 'hretries',
  '-u': 'user',
  '--user': 'user',
  '-h': 'hostname',
  '--hostname': 'hostname',
  '-w': 'workdir',
  '--workdir': 'workdir',
  '--env-file': 'envfile',
  '-m': 'memory',
  '--memory': 'memory',
};
const BOOL_FLAGS = ['-d', '--detach', '--rm', '-i', '-t', '-it', '-ti', '--init', '--privileged', '--interactive', '--tty'];

export function convertDockerRun(input: string, existing: string[]): Conversion {
  const t = tokenize(input);
  if (t[0] === 'sudo') t.shift();
  if (t[0] === 'docker') t.shift();
  if (t[0] === 'container') t.shift();
  if (t[0] !== 'run') throw new Error('Befehl muss mit „docker run“ beginnen.');
  t.shift();

  const hints: string[] = [];
  const ports: string[] = [];
  const vols: string[] = [];
  const env: Obj = {};
  const labels: string[] = [];
  const hc: Obj = {};
  let name = '';
  let restart = '';
  let image = '';
  const extra: Obj = {};
  let i = 0;
  while (i < t.length) {
    let tok = t[i];
    if (!tok.startsWith('-') || image) break;
    let val: string | undefined;
    if (tok.startsWith('--') && tok.includes('=')) {
      val = tok.slice(tok.indexOf('=') + 1);
      tok = tok.slice(0, tok.indexOf('='));
    }
    const kind = VALUE_FLAGS[tok];
    if (kind) {
      if (val === undefined) {
        i++;
        val = t[i] ?? '';
      }
      switch (kind) {
        case 'name': name = val; break;
        case 'port': ports.push(val); break;
        case 'volume': vols.push(val); break;
        case 'env': {
          const eq = val.indexOf('=');
          env[eq < 0 ? val : val.slice(0, eq)] = eq < 0 ? '' : val.slice(eq + 1);
          if (eq < 0) hints.push(`Variable ${val} ohne Wert – bitte ergänzen`);
          break;
        }
        case 'restart': restart = val; break;
        case 'network':
          if (val === 'host') extra['network_mode'] = 'host';
          else {
            extra['networks'] = [val];
            hints.push(`Netzwerk „${val}“ muss im Stack definiert oder als external markiert werden`);
          }
          break;
        case 'label': labels.push(val); break;
        case 'hcmd': hc['test'] = ['CMD-SHELL', val]; break;
        case 'hint': hc['interval'] = val; break;
        case 'hretries': hc['retries'] = Number(val) || val; break;
        case 'user': extra['user'] = val; break;
        case 'hostname': extra['hostname'] = val; break;
        case 'workdir': extra['working_dir'] = val; break;
        case 'memory': extra['mem_limit'] = val; break;
        case 'envfile':
          extra['env_file'] = [val];
          hints.push('env_file übernommen – Datei muss im Projektverzeichnis liegen');
          break;
      }
    } else if (BOOL_FLAGS.includes(tok) || /^-[dit]+$/.test(tok)) {
      if (tok === '--rm') hints.push('--rm wird in Compose ignoriert');
      if (tok === '--privileged') {
        extra['privileged'] = true;
        hints.push('privileged übernommen – bitte bewusst prüfen');
      }
    } else {
      hints.push(`Nicht übernommen: ${tok}`);
    }
    i++;
  }
  image = t[i] ?? '';
  const command = t.slice(i + 1);
  if (!image) hints.push('Kein Image erkannt – Pflichtfeld bitte ausfüllen');
  if (!restart) hints.push('Kein Neustartverhalten angegeben – „unless-stopped“ empfohlen');
  if (!ports.length) hints.push('Keine Ports veröffentlicht');

  const body: Obj = { image };
  if (name) body['container_name'] = name;
  if (restart) body['restart'] = restart;
  if (ports.length) body['ports'] = ports;
  if (vols.length) body['volumes'] = vols;
  if (Object.keys(env).length) body['environment'] = env;
  if (labels.length) body['labels'] = labels;
  if (Object.keys(hc).length) body['healthcheck'] = hc;
  if (command.length) body['command'] = command.join(' ');
  Object.assign(body, extra);

  const base = name || (image.split('/').pop() ?? '').split(':')[0] || 'service';
  return { key: uniqueKey(existing, base), body, hints };
}

/* ---------- Einmaliger Import (simuliert, keine Netzwerkanfrage) ---------- */

export interface ImportResult {
  title: string;
  found: string[];
  missing: string[];
  services: { key: string; body: Obj }[];
}

export function simulateImport(kind: 'dockerhub' | 'github', ref: string): ImportResult {
  const r = ref.trim().replace(/^https?:\/\//, '').replace(/\/+$/, '');
  if (!r) throw new Error(kind === 'github' ? 'Repository angeben, z. B. github.com/example/notes-app' : 'Image angeben, z. B. traefik/whoami');
  if (kind === 'github') {
    const repo = r.replace(/^github\.com\//, '');
    if (repo === 'example/notes-app') {
      return {
        title: `${repo} · deploy/compose.yaml`,
        found: ['Compose-Datei unter deploy/compose.yaml', '2 Services: app, db', 'Port 3000 veröffentlicht'],
        missing: ['DATABASE_URL hat keinen Wert', 'POSTGRES_PASSWORD hat keinen Wert', 'Volume-Quelle für db prüfen'],
        services: [
          {
            key: 'app',
            body: {
              image: 'ghcr.io/example/notes-app:1.4.0',
              restart: 'unless-stopped',
              ports: ['3000:3000'],
              environment: { APP_URL: 'https://notes.example.com', DATABASE_URL: '' },
              depends_on: ['db'],
            },
          },
          {
            key: 'db',
            body: {
              image: 'postgres:16-alpine',
              restart: 'unless-stopped',
              volumes: ['notes_db:/var/lib/postgresql/data'],
              environment: { POSTGRES_PASSWORD: '' },
            },
          },
        ],
      };
    }
    const short = repo.split('/').pop() ?? 'app';
    return {
      title: `${repo} · keine Compose-Datei`,
      found: ['README gefunden', 'Dockerfile gefunden (eigenständige Builds sind nicht Teil von Docklet)'],
      missing: ['Image fehlt – bitte ein veröffentlichtes Image angeben', 'Ports unbekannt'],
      services: [{ key: short, body: { image: '', restart: 'unless-stopped' } }],
    };
  }
  const image = r.replace(/^hub\.docker\.com\/(r\/)?/, '');
  if (image.startsWith('traefik/whoami')) {
    return {
      title: 'traefik/whoami · Docker Hub',
      found: ['Neuester Tag: v1.10', 'EXPOSE 80/tcp'],
      missing: ['Host-Port für 80/tcp festlegen'],
      services: [{ key: 'whoami', body: { image: 'traefik/whoami:v1.10', restart: 'unless-stopped', ports: ['80'] } }],
    };
  }
  if (image.includes('syncthing')) {
    return {
      title: 'linuxserver/syncthing · Docker Hub',
      found: ['Tag: latest', 'EXPOSE 8384, 22000/tcp, 22000/udp', 'VOLUME /config'],
      missing: ['Quelle für /config wählen', 'PUID/PGID passend zu Dateirechten setzen'],
      services: [
        {
          key: 'syncthing',
          body: {
            image: 'lscr.io/linuxserver/syncthing:latest',
            restart: 'unless-stopped',
            ports: ['8384:8384', '22000:22000'],
            volumes: ['/config'],
            environment: { PUID: '', PGID: '', TZ: 'Europe/Berlin' },
          },
        },
      ],
    };
  }
  const base = (image.split('/').pop() ?? 'app').split(':')[0];
  return {
    title: `${image} · Docker Hub`,
    found: [`Image-Referenz: ${image.includes(':') ? image : image + ':latest'}`],
    missing: ['Keine Metadaten zu Ports oder Volumes gefunden (simuliert)'],
    services: [{ key: base, body: { image: image.includes(':') ? image : `${image}:latest`, restart: 'unless-stopped' } }],
  };
}
