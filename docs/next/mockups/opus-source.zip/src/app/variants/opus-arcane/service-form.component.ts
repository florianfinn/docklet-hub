import { ChangeDetectionStrategy, Component, computed, inject, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { Issue, MountRow, ops, PortRow, ServiceModel, uniqueKey, validateModel } from './compose';
import { IconComponent, IconName } from './icon.component';
import { ArcaneStore, SubStep } from './store';

const SUBS: { id: SubStep; label: string; icon: IconName; field: Issue['field'] }[] = [
  { id: 'image', label: 'Image', icon: 'package', field: 'image' },
  { id: 'ports', label: 'Ports', icon: 'plug', field: 'ports' },
  { id: 'mounts', label: 'Mounts', icon: 'database', field: 'mounts' },
  { id: 'env', label: 'Variablen', icon: 'key', field: 'env' },
  { id: 'health', label: 'Healthcheck', icon: 'heart', field: 'health' },
];

/** Schritt 2 des Easy-Wizards: Services mit verschachtelten Unterschritten. */
@Component({
  selector: 'oa-service-form',
  imports: [ZardButtonComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    @let m = store.model();
    @if (m) {
      <div class="oa-svcf">
        <aside class="oa-svcf-list" aria-label="Services">
          @for (s of m.services; track s.key) {
            <button type="button" class="oa-svcf-item" [attr.aria-current]="current()?.key === s.key ? 'true' : null" (click)="select(s.key)">
              <span class="oa-svcf-ico"><oa-icon name="box" [size]="15" /></span>
              <span class="oa-sp" style="min-width:0">
                <strong>{{ s.key }}</strong>
                <small class="oa-mono">{{ s.image || 'Image fehlt' }}</small>
              </span>
              @if (errorCount(s.key); as n) {
                <span class="oa-pill" data-tone="err" [attr.aria-label]="n + ' Fehler'">{{ n }}</span>
              }
            </button>
          }
          <button type="button" class="oa-svcf-add" (click)="addService()"><oa-icon name="plus" [size]="15" /> Service hinzufügen</button>
        </aside>

        @if (current(); as s) {
          <section class="oa-card oa-svcf-panel" aria-label="Service bearbeiten">
            <header class="oa-row oa-svcf-head">
              <div class="oa-field oa-sp">
                <label class="oa-label" for="svc-name">Servicename</label>
                <input id="svc-name" class="oa-input oa-mono" [value]="s.key" (change)="rename(s.key, $any($event.target).value)" />
              </div>
              <button type="button" class="oa-btn" data-tone="err" (click)="remove(s.key)" [disabled]="m.services.length < 2">
                <oa-icon name="trash" [size]="14" /> Entfernen
              </button>
            </header>

            <ol class="oa-substeps" aria-label="Service-Schritte">
              @for (sub of subs; track sub.id; let i = $index) {
                <li>
                  <button type="button" [attr.aria-current]="store.editorSub() === sub.id ? 'step' : null" (click)="store.editorSub.set(sub.id)">
                    <span class="oa-substep-n" [attr.data-state]="subState(s.key, sub.field)">
                      @if (subState(s.key, sub.field) === 'err') {
                        <oa-icon name="alert" [size]="12" />
                      } @else {
                        {{ i + 1 }}
                      }
                    </span>
                    {{ sub.label }}
                  </button>
                </li>
              }
            </ol>

            <div class="oa-svcf-body">
              @switch (store.editorSub()) {
                @case ('image') {
                  <div class="oa-field">
                    <label class="oa-label" for="svc-image">Image <span class="oa-req" aria-hidden="true">*</span></label>
                    <input id="svc-image" class="oa-input oa-mono" placeholder="z. B. nginx:1.27-alpine" required [attr.aria-invalid]="!s.image.trim()" aria-describedby="svc-image-h" [value]="s.image" (input)="store.edit(ops.setField(s.key, 'image', $any($event.target).value))" />
                    @if (!s.image.trim()) {
                      <span class="oa-errtxt" id="svc-image-h"><oa-icon name="alert" [size]="13" /> Pflichtfeld: Image mit Tag angeben</span>
                    } @else {
                      <span class="oa-help" id="svc-image-h">Wird live mit dem Advanced-Editor synchronisiert.</span>
                    }
                  </div>
                  <div class="oa-grid2" style="margin-top:12px">
                    <div class="oa-field">
                      <label class="oa-label" for="svc-cname">Containername</label>
                      <input id="svc-cname" class="oa-input oa-mono" placeholder="optional" [value]="s.containerName" (input)="store.edit(ops.setField(s.key, 'container_name', $any($event.target).value))" />
                    </div>
                    <div class="oa-field">
                      <label class="oa-label" for="svc-restart">Neustartverhalten</label>
                      <select id="svc-restart" class="oa-select" [value]="s.restart" (change)="store.edit(ops.setField(s.key, 'restart', $any($event.target).value))">
                        <option value="">nicht gesetzt</option>
                        <option value="no">no</option>
                        <option value="always">always</option>
                        <option value="unless-stopped">unless-stopped</option>
                        <option value="on-failure">on-failure</option>
                      </select>
                    </div>
                  </div>
                }
                @case ('ports') {
                  <p class="oa-help">Host-Port links, Container-Port rechts. Leerer Host-Port veröffentlicht nur intern.</p>
                  @for (p of s.ports; track $index) {
                    <div class="oa-rowedit">
                      @if (p.editable) {
                        <input class="oa-input oa-mono" placeholder="Host" [attr.aria-label]="'Host-Port ' + (p.index + 1)" [value]="p.host" (input)="setPort(s.key, p, $any($event.target).value, p.container)" />
                        <oa-icon name="chevronRight" class="oa-dim" />
                        <input class="oa-input oa-mono" placeholder="Container *" [attr.aria-label]="'Container-Port ' + (p.index + 1)" [attr.aria-invalid]="!p.container" [value]="p.container" (input)="setPort(s.key, p, p.host, $any($event.target).value)" />
                      } @else {
                        <span class="oa-mono oa-small oa-sp">{{ p.raw }}</span>
                        <span class="oa-pill"><oa-icon name="lock" [size]="11" /> Langform · Advanced</span>
                      }
                      <button type="button" class="oa-ibtn" (click)="store.edit(ops.removePort(s.key, p.index))" [attr.aria-label]="'Port ' + (p.index + 1) + ' entfernen'"><oa-icon name="trash" [size]="15" /></button>
                    </div>
                  } @empty {
                    <p class="oa-small oa-muted">Keine Ports veröffentlicht.</p>
                  }
                  <button type="button" class="oa-btn" (click)="store.edit(ops.addPort(s.key))"><oa-icon name="plus" [size]="14" /> Port hinzufügen</button>
                }
                @case ('mounts') {
                  <p class="oa-help">Volume-Name oder Hostpfad (Bind-Mount) links, Pfad im Container rechts.</p>
                  @for (v of s.mounts; track $index) {
                    <div class="oa-rowedit">
                      @if (v.editable) {
                        <input class="oa-input oa-mono" placeholder="Volume oder /pfad" [attr.aria-label]="'Quelle ' + (v.index + 1)" [value]="v.source" (input)="setMount(s.key, v, $any($event.target).value, v.target, v.ro)" />
                        <oa-icon name="chevronRight" class="oa-dim" />
                        <input class="oa-input oa-mono" placeholder="/ziel *" [attr.aria-label]="'Ziel ' + (v.index + 1)" [attr.aria-invalid]="!v.target" [value]="v.target" (input)="setMount(s.key, v, v.source, $any($event.target).value, v.ro)" />
                        <label class="oa-check oa-small" [title]="'Nur lesen'"><input type="checkbox" [checked]="v.ro" (change)="setMount(s.key, v, v.source, v.target, $any($event.target).checked)" /> ro</label>
                        <button type="button" class="oa-ibtn" [disabled]="!v.source" (click)="store.openFiles(v.source)" [attr.aria-label]="'Quelle ' + v.source + ' im Dateibrowser öffnen'" title="Im Dateibrowser öffnen"><oa-icon name="folder" [size]="15" /></button>
                      } @else {
                        <span class="oa-mono oa-small oa-sp">{{ v.raw }}</span>
                        <span class="oa-pill"><oa-icon name="lock" [size]="11" /> Langform · Advanced</span>
                      }
                      <button type="button" class="oa-ibtn" (click)="store.edit(ops.removeMount(s.key, v.index))" [attr.aria-label]="'Mount ' + (v.index + 1) + ' entfernen'"><oa-icon name="trash" [size]="15" /></button>
                    </div>
                  } @empty {
                    <p class="oa-small oa-muted">Keine Mounts.</p>
                  }
                  <button type="button" class="oa-btn" (click)="store.edit(ops.addMount(s.key))"><oa-icon name="plus" [size]="14" /> Mount hinzufügen</button>
                }
                @case ('env') {
                  <p class="oa-help">Service-Variablen. Werte wie <span class="oa-mono">\${{ '{' }}DB_PASSWORD{{ '}' }}</span> kommen aus der Stack-.env (Schritt 1).</p>
                  @for (e of s.env; track $index) {
                    <div class="oa-rowedit">
                      <input class="oa-input oa-mono" placeholder="NAME *" [attr.aria-label]="'Variablenname ' + (e.index + 1)" [attr.aria-invalid]="!e.key" [value]="e.key" (input)="store.edit(ops.setEnv(s.key, e.index, $any($event.target).value, e.value))" />
                      <span class="oa-dim">=</span>
                      <input class="oa-input oa-mono" placeholder="Wert" [attr.aria-label]="'Wert ' + (e.key || e.index + 1)" [value]="e.value" (input)="store.edit(ops.setEnv(s.key, e.index, e.key, $any($event.target).value))" />
                      <button type="button" class="oa-ibtn" (click)="store.edit(ops.removeEnv(s.key, e.index))" [attr.aria-label]="'Variable ' + e.key + ' entfernen'"><oa-icon name="trash" [size]="15" /></button>
                    </div>
                  } @empty {
                    <p class="oa-small oa-muted">Keine Variablen.</p>
                  }
                  <button type="button" class="oa-btn" (click)="store.edit(ops.addEnv(s.key))"><oa-icon name="plus" [size]="14" /> Variable hinzufügen</button>
                }
                @case ('health') {
                  <div class="oa-row" style="margin-bottom:12px">
                    <button type="button" class="oa-switch" role="switch" [attr.aria-checked]="s.health.enabled" aria-labelledby="hc-l" (click)="store.edit(ops.setHealthEnabled(s.key, !s.health.enabled))"></button>
                    <span id="hc-l">Healthcheck aktiv</span>
                  </div>
                  @if (s.health.enabled) {
                    <div class="oa-field">
                      <label class="oa-label" for="hc-test">Testbefehl <span class="oa-req" aria-hidden="true">*</span></label>
                      <input id="hc-test" class="oa-input oa-mono" placeholder="curl -fs http://localhost/health || exit 1" [attr.aria-invalid]="!s.health.test" [value]="s.health.test" (input)="store.edit(ops.setHealthTest(s.key, $any($event.target).value))" />
                      <span class="oa-help">Wird als CMD-SHELL gespeichert. Unbekannte Felder wie start_period bleiben erhalten.</span>
                    </div>
                    <div class="oa-grid2" style="margin-top:12px">
                      <div class="oa-field">
                        <label class="oa-label" for="hc-int">Intervall</label>
                        <input id="hc-int" class="oa-input oa-mono" placeholder="30s" [value]="s.health.interval" (input)="store.edit(ops.setHealthField(s.key, 'interval', $any($event.target).value))" />
                      </div>
                      <div class="oa-field">
                        <label class="oa-label" for="hc-ret">Wiederholungen</label>
                        <input id="hc-ret" class="oa-input oa-mono" inputmode="numeric" placeholder="3" [value]="s.health.retries" (input)="store.edit(ops.setHealthField(s.key, 'retries', $any($event.target).value))" />
                      </div>
                    </div>
                    <p class="oa-help" style="margin-top:10px">Auto Heal startet unhealthy-Container begrenzt neu, sofern global aktiviert.</p>
                  } @else {
                    <p class="oa-small oa-muted">Ohne Healthcheck kann Docklet nur „läuft/gestoppt“ erkennen.</p>
                  }
                }
              }

              @for (i of currentIssues(); track $index) {
                <p [class]="i.level === 'error' ? 'oa-errtxt' : 'oa-warntxt'"><oa-icon [name]="i.level === 'error' ? 'alert' : 'info'" [size]="13" /> {{ i.msg }}</p>
              }
            </div>

            @if (s.extras.length) {
              <div class="oa-extras">
                <oa-icon name="lock" [size]="13" />
                <span>Bleiben unverändert erhalten:</span>
                @for (x of s.extras; track x) {
                  <span class="oa-pill oa-mono">{{ x }}</span>
                }
              </div>
            }

            <footer class="oa-row oa-svcf-foot">
              <button z-button zType="ghost" zSize="sm" type="button" (click)="prev()"><oa-icon name="chevronLeft" [size]="14" /> Zurück</button>
              <span class="oa-sp"></span>
              <button z-button zSize="sm" type="button" (click)="next()">
                {{ store.editorSub() === 'health' ? (isLastService(s.key) ? 'Zur Prüfung' : 'Nächster Service') : 'Weiter' }}
                <oa-icon name="chevronRight" [size]="14" />
              </button>
            </footer>
          </section>
        } @else {
          <div class="oa-card">
            <p class="oa-muted">Noch kein Service. Füge einen hinzu, konvertiere einen docker-run-Befehl oder importiere einmalig.</p>
          </div>
        }
      </div>
    }
  `,
  styles: `
    .oa-svcf{display:grid;grid-template-columns:230px minmax(0,1fr);gap:14px;align-items:start}
    @media (max-width:820px){.oa-svcf{grid-template-columns:1fr}}
    .oa-svcf-list{display:flex;flex-direction:column;gap:6px}
    .oa-svcf-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:11px;border:1px solid var(--oa-line);background:rgb(255 255 255/.02);color:var(--oa-fg);text-align:left;cursor:pointer;transition:all .15s}
    .oa-svcf-item:hover{border-color:var(--oa-line2)}
    .oa-svcf-item[aria-current=true]{border-color:rgb(139 124 246/.5);background:var(--oa-accent-soft)}
    .oa-svcf-item strong{display:block;font-size:13px}
    .oa-svcf-item small{display:block;font-size:11px;color:var(--oa-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-svcf-ico{display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:rgb(255 255 255/.05);color:var(--oa-muted)}
    .oa-svcf-add{display:flex;align-items:center;justify-content:center;gap:6px;height:38px;border-radius:11px;border:1px dashed var(--oa-line2);background:none;color:var(--oa-muted);cursor:pointer;font-size:13px}
    .oa-svcf-add:hover{color:var(--oa-fg);border-color:var(--oa-accent)}
    .oa-svcf-head{align-items:flex-end;margin-bottom:14px}
    .oa-substeps{list-style:none;margin:0 0 14px;padding:0;display:flex;gap:4px;overflow-x:auto;border-bottom:1px solid var(--oa-line)}
    .oa-substeps button{display:flex;align-items:center;gap:7px;padding:8px 10px;border:0;border-bottom:2px solid transparent;margin-bottom:-1px;background:none;color:var(--oa-muted);font-size:13px;cursor:pointer;white-space:nowrap}
    .oa-substeps button:hover{color:var(--oa-fg)}
    .oa-substeps button[aria-current=step]{color:var(--oa-fg);border-bottom-color:var(--oa-accent)}
    .oa-substep-n{display:grid;place-items:center;width:20px;height:20px;border-radius:50%;font-size:11px;background:rgb(255 255 255/.07)}
    .oa-substeps button[aria-current=step] .oa-substep-n{background:var(--oa-accent);color:#fff}
    .oa-substep-n[data-state=err]{background:rgb(239 68 68/.2);color:#f87171}
    .oa-substep-n[data-state=warn]{box-shadow:inset 0 0 0 1px rgb(245 158 11/.6)}
    .oa-svcf-body{display:flex;flex-direction:column;gap:8px;min-height:180px}
    .oa-svcf-body>p{margin:0}
    .oa-rowedit{display:flex;align-items:center;gap:8px}
    .oa-rowedit .oa-input{flex:1}
    .oa-rowedit>.oa-btn,.oa-svcf-body>.oa-btn{align-self:flex-start}
    .oa-extras{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:14px;padding:10px 12px;border-radius:10px;background:rgb(0 0 0/.2);font-size:12px;color:var(--oa-muted)}
    .oa-svcf-foot{margin-top:14px;padding-top:12px;border-top:1px solid var(--oa-line)}
  `,
})
export class ServiceFormComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly ops = ops;
  protected readonly subs = SUBS;

  protected readonly issues = computed(() => {
    const m = this.store.model();
    return m ? validateModel(m) : [];
  });

  protected readonly current = computed<ServiceModel | null>(() => {
    const m = this.store.model();
    if (!m || !m.services.length) return null;
    return m.services.find((s) => s.key === this.store.editorService()) ?? m.services[0];
  });

  protected readonly currentIssues = computed(() => {
    const s = this.current();
    const field = SUBS.find((x) => x.id === this.store.editorSub())?.field;
    return s ? this.issues().filter((i) => i.service === s.key && i.field === field) : [];
  });

  protected errorCount(key: string): number {
    return this.issues().filter((i) => i.service === key && i.level === 'error').length;
  }

  protected subState(key: string, field: Issue['field']): 'err' | 'warn' | 'ok' {
    const list = this.issues().filter((i) => i.service === key && i.field === field);
    return list.some((i) => i.level === 'error') ? 'err' : list.length ? 'warn' : 'ok';
  }

  protected select(key: string): void {
    this.store.editorService.set(key);
    this.store.editorSub.set('image');
  }

  protected addService(): void {
    const m = this.store.model();
    if (!m) return;
    const key = uniqueKey(m.services.map((s) => s.key), `service-${m.services.length + 1}`);
    if (this.store.edit(ops.addService(key, { image: '', restart: 'unless-stopped' }))) {
      this.select(key);
      this.store.showToast(`Service „${key}“ hinzugefügt – Image ergänzen`);
    }
  }

  protected rename(oldKey: string, value: string): void {
    const next = value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-');
    if (!next || next === oldKey) return;
    if (this.store.edit(ops.renameService(oldKey, next))) this.store.editorService.set(next);
  }

  protected remove(key: string): void {
    if (this.store.edit(ops.removeService(key))) {
      this.store.editorService.set(null);
      this.store.showToast(`Service „${key}“ entfernt`);
    }
  }

  protected setPort(key: string, p: PortRow, host: string, container: string): void {
    this.store.edit(ops.setPort(key, p.index, host, container));
  }

  protected setMount(key: string, v: MountRow, source: string, target: string, ro: boolean): void {
    this.store.edit(ops.setMount(key, v.index, source, target, ro));
  }

  protected isLastService(key: string): boolean {
    const list = this.store.model()?.services ?? [];
    return list[list.length - 1]?.key === key;
  }

  protected next(): void {
    const i = SUBS.findIndex((x) => x.id === this.store.editorSub());
    if (i < SUBS.length - 1) {
      this.store.editorSub.set(SUBS[i + 1].id);
      return;
    }
    const list = this.store.model()?.services ?? [];
    const cur = this.current();
    const idx = list.findIndex((s) => s.key === cur?.key);
    if (idx >= 0 && idx < list.length - 1) this.select(list[idx + 1].key);
    else this.store.editorStep.set(3);
  }

  protected prev(): void {
    const i = SUBS.findIndex((x) => x.id === this.store.editorSub());
    if (i > 0) this.store.editorSub.set(SUBS[i - 1].id);
    else this.store.editorStep.set(1);
  }
}
