import { ChangeDetectionStrategy, Component, computed, ElementRef, inject, signal, viewChild, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { AccountComponent } from './account.component';
import { ActionCenterComponent } from './action-center.component';
import { StacksComponent } from './apps.component';
import { ContainersComponent } from './containers.component';
import { DashboardComponent } from './dashboard.component';
import { PageId } from './data';
import { overlayState } from './dialog.component';
import { HostsComponent } from './hosts.component';
import { IconComponent, IconName } from './icon.component';
import { NetworkComponent } from './network.component';
import { PreviewComponent } from './preview.component';
import {
  PrimitivesBaseComponent,
  PrimitivesControlsComponent,
  PrimitivesFormsComponent,
  PrimitivesShellComponent,
  PrimitivesThemeComponent,
} from './primitives.component';
import { ResourcesComponent } from './resources.component';
import { SecurityComponent } from './security.component';
import { SettingsComponent } from './settings.component';
import { StackPageComponent } from './stack-detail.component';
import { ArcaneStore } from './store';
import { ToastsComponent } from './toasts.component';
import { UserMenuComponent } from './user-menu.component';

interface NavItem {
  id: PageId;
  label: string;
  icon: IconName;
}

interface NavGroup {
  label: string;
  items: NavItem[];
}

/* Vereinfachte Arcane-Navigation: Verwaltung, Ressourcen, Administration. */
const NAV: NavGroup[] = [
  {
    label: 'Verwaltung',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
      { id: 'stacks', label: 'Stacks', icon: 'layers' },
      { id: 'containers', label: 'Container', icon: 'box' },
      { id: 'security', label: 'Sicherheit', icon: 'shield' },
      { id: 'hosts', label: 'Hosts', icon: 'server' },
    ],
  },
  {
    label: 'Ressourcen',
    items: [
      { id: 'networks', label: 'Netzwerke', icon: 'network' },
      { id: 'resources', label: 'Images & Volumes', icon: 'database' },
    ],
  },
  {
    label: 'Administration',
    items: [
      { id: 'settings', label: 'Einstellungen', icon: 'settings' },
      { id: 'preview', label: 'Proxy & Games', icon: 'globe' },
    ],
  },
];

const TITLES: Record<PageId, string> = {
  dashboard: 'Dashboard',
  stacks: 'Stacks',
  stack: 'Stack',
  containers: 'Container',
  hosts: 'Hosts',
  networks: 'Netzwerke',
  resources: 'Images & Volumes',
  security: 'Sicherheit',
  settings: 'Hub-Einstellungen',
  account: 'Profil',
  preview: 'Proxy & Games',
};

/**
 * Docklet – Richtung „arcane“ (Claude Opus 5.5), Überarbeitung 2.
 * Shell nach Arcanes App-Rahmen: schwebende Seitenleiste mit Gruppen, Hostfilter statt
 * Environment-Switcher, Aktivitäten-Eintrag, Benutzer unten links.
 */
@Component({
  selector: 'oa-design-root',
  imports: [
    ZardButtonComponent,
    IconComponent,
    PrimitivesBaseComponent,
    PrimitivesThemeComponent,
    PrimitivesFormsComponent,
    PrimitivesControlsComponent,
    PrimitivesShellComponent,
    DashboardComponent,
    StacksComponent,
    StackPageComponent,
    ContainersComponent,
    SecurityComponent,
    HostsComponent,
    NetworkComponent,
    ResourcesComponent,
    SettingsComponent,
    AccountComponent,
    PreviewComponent,
    ActionCenterComponent,
    ToastsComponent,
    UserMenuComponent,
  ],
  providers: [ArcaneStore],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { '(document:keydown)': 'onKey($event)' },
  styleUrl: './design.component.css',
  template: `
    <div class="oa-root" [class.dark]="!light()" [class.oa-light]="light()" [class.oa-nav-open]="navOpen()">
      <oa-primitives-base />
      <oa-primitives-theme />
      <oa-primitives-forms />
      <oa-primitives-controls />
      <oa-primitives-shell />
      <a class="oa-skip" href="#oa-main" (click)="focusMain($event)">Zum Inhalt springen</a>

      <aside class="oa-side" id="oa-side" aria-label="Hauptnavigation">
        <div class="oa-brand">
          <span class="oa-brand-mark"><oa-icon name="logo" [size]="18" /></span>
          <div class="oa-sp">
            <strong>Docklet</strong>
            <small>Arcane-Richtung · Demo</small>
          </div>
          <button type="button" class="oa-ibtn oa-side-close" (click)="navOpen.set(false)" aria-label="Navigation schließen"><oa-icon name="x" /></button>
        </div>

        <div class="oa-hf" role="group" aria-labelledby="oa-hf-l">
          <div class="oa-hf-head">
            <span id="oa-hf-l">Hostfilter</span>
            <button type="button" class="oa-hf-all" [attr.aria-pressed]="store.allHosts()" (click)="store.hostSel.set([])">Alle Hosts</button>
          </div>
          @for (h of store.hosts(); track h.id) {
            <button
              type="button"
              class="oa-hf-host"
              [attr.aria-pressed]="store.hostOn(h.id)"
              (click)="store.toggleHost(h.id)"
              [attr.aria-label]="h.name + (h.status === 'online' ? ', online' : ', getrennt') + (store.hostOn(h.id) ? ', angezeigt' : ', ausgeblendet')"
            >
              <span class="oa-hf-box" [style.--hc]="h.color">
                @if (store.hostOn(h.id)) {
                  <oa-icon name="check" [size]="11" [stroke]="3" />
                }
              </span>
              <span class="oa-sp">{{ h.name }}</span>
              <span class="oa-dot" [attr.data-tone]="h.status === 'online' ? 'ok' : 'warn'"></span>
            </button>
          }
        </div>

        <button type="button" class="oa-nav-item oa-activity" (click)="store.openAction(null)">
          <oa-icon name="bell" [size]="16" />
          <span>Aktivitäten</span>
          @if (store.runningActions()) {
            <span class="oa-nav-badge">{{ store.runningActions() }} laufend</span>
          }
        </button>

        <nav class="oa-nav">
          @for (g of nav; track g.label) {
            <div class="oa-nav-group">
              <div class="oa-nav-label">{{ g.label }}</div>
              @for (item of g.items; track item.id) {
                <button type="button" class="oa-nav-item" [attr.aria-current]="isActive(item.id) ? 'page' : null" (click)="go(item.id)">
                  <oa-icon [name]="item.icon" [size]="16" />
                  <span>{{ item.label }}</span>
                  @switch (item.id) {
                    @case ('stacks') { <span class="oa-nav-count">{{ store.visibleStacks().length }}</span> }
                    @case ('hosts') { <span class="oa-nav-count">{{ store.agentCount() }}/{{ store.hosts().length }}</span> }
                    @case ('security') {
                      @if (store.scanEnabled() && store.scanTotals().critical) {
                        <span class="oa-nav-count oa-nav-crit">{{ store.scanTotals().critical }}</span>
                      }
                    }
                    @case ('preview') { <span class="oa-nav-badge">Vorschau</span> }
                  }
                </button>
              }
            </div>
          }
        </nav>

        <div class="oa-side-foot">
          <oa-user-menu (navigated)="navOpen.set(false)" />
          <p>Docklet Demo · synthetische Daten</p>
        </div>
      </aside>
      <button type="button" class="oa-side-backdrop" tabindex="-1" aria-hidden="true" (click)="navOpen.set(false)"></button>

      <div class="oa-main">
        <header class="oa-top">
          <button type="button" class="oa-ibtn" (click)="navOpen.set(true)" aria-label="Navigation öffnen" aria-controls="oa-side" [attr.aria-expanded]="navOpen()">
            <oa-icon name="menu" [size]="18" />
          </button>
          <strong class="oa-sp">{{ title() }}</strong>
          <button type="button" class="oa-ibtn" (click)="store.openAction(null)" aria-label="Aktivitäten öffnen"><oa-icon name="bell" [size]="18" /></button>
        </header>

        <main id="oa-main" #main class="oa-content" tabindex="-1">
          @switch (store.page()) {
            @case ('dashboard') { <oa-dashboard /> }
            @case ('stacks') { <oa-stacks /> }
            @case ('stack') { <oa-stack-page /> }
            @case ('containers') { <oa-containers /> }
            @case ('security') { <oa-security /> }
            @case ('hosts') { <oa-hosts /> }
            @case ('networks') { <oa-network /> }
            @case ('resources') { <oa-resources /> }
            @case ('settings') { <oa-settings /> }
            @case ('account') { <oa-account /> }
            @case ('preview') { <oa-preview /> }
          }
        </main>
      </div>

      @if (store.drawerOpen()) {
        <oa-action-center />
      }
      <oa-toasts />

      @if (store.loggedOut()) {
        <div class="oa-logout" role="dialog" aria-modal="true" aria-labelledby="oa-lo-t">
          <div class="oa-card oa-logout-card">
            <span class="oa-brand-mark"><oa-icon name="logo" [size]="20" /></span>
            <h2 id="oa-lo-t">Abgemeldet</h2>
            @switch (store.hub().auth) {
              @case ('none') { <p class="oa-muted">Die Anmeldung ist deaktiviert – Abmelden hat in diesem Modus keine Wirkung (Simulation).</p> }
              @case ('proxy') { <p class="oa-muted">Die Sitzung wird vom Reverse-Proxy verwaltet. Docklet würde zur Abmeldeseite des Proxys weiterleiten (Simulation).</p> }
              @default { <p class="oa-muted">Lokaler Admin-Login. Es werden keine echten Zugangsdaten geprüft (Simulation).</p> }
            }
            <button z-button type="button" (click)="store.loggedOut.set(false)"><oa-icon name="logout" [size]="14" /> Wieder anmelden</button>
          </div>
        </div>
      }
    </div>
  `,
})
export class DesignComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly nav = NAV;
  protected readonly navOpen = signal(false);
  protected readonly title = computed(() => (this.store.page() === 'stack' ? (this.store.selectedStack()?.name ?? 'Neuer Stack') : TITLES[this.store.page()]));
  protected readonly light = computed(() => {
    const t = this.store.profile().theme;
    if (t === 'system') return typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-color-scheme: light)').matches;
    return t === 'light';
  });
  private readonly main = viewChild.required<ElementRef<HTMLElement>>('main');

  protected isActive(id: PageId): boolean {
    const p = this.store.page();
    return p === id || (id === 'stacks' && p === 'stack');
  }

  protected go(id: PageId): void {
    this.store.go(id);
    this.navOpen.set(false);
    window.scrollTo?.({ top: 0 });
  }

  protected focusMain(e: Event): void {
    e.preventDefault();
    this.main().nativeElement.focus();
  }

  protected onKey(e: KeyboardEvent): void {
    if (e.key !== 'Escape' || overlayState.stack.length) return;
    if (this.navOpen()) this.navOpen.set(false);
  }
}
