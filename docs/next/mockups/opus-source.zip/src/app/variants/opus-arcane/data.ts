/* Synthetische Beispieldaten für die Arcane-Richtung. Keine realen Betriebsdaten. */

export type PageId =
  | 'dashboard'
  | 'stacks'
  | 'stack'
  | 'containers'
  | 'hosts'
  | 'networks'
  | 'resources'
  | 'security'
  | 'settings'
  | 'account'
  | 'preview';
export type HostMode = 'direct' | 'edge';
export type SvcState = 'running' | 'stopped' | 'restarting';
export type Health = 'healthy' | 'unhealthy' | 'starting' | 'none';
export type AutoUpdate = 'check' | 'nightly' | 'weekly';
export type Origin = 'unraid' | 'unknown' | 'standalone' | 'foreign';
export type Tone = 'ok' | 'warn' | 'err' | 'info' | 'accent' | 'gray' | 'orange' | 'violet' | 'sky' | 'lime' | 'pink';

export interface Host {
  id: string;
  name: string;
  color: string;
  colorName: string;
  status: 'online' | 'offline';
  cpu: number;
  mem: number;
  memTotal: string;
  disk: number;
  diskTotal: string;
  address: string;
  mode: HostMode;
  agent: string;
  projectDir: string;
  os: string;
  lastSeen: string;
  cpuHistory: number[];
}

export interface Service {
  name: string;
  image: string;
  state: SvcState;
  health: Health;
  cpu: number;
  mem: string;
  ports: string[];
  updateTo?: string;
  previousImage?: string;
}

export interface Stack {
  id: string;
  name: string;
  hostId: string;
  description: string;
  labels: string[];
  url?: string;
  services: Service[];
  compose: string;
  env: string;
  autoUpdate: AutoUpdate;
  autoTime: string;
  mounts: string[];
  lastDeploy: string;
  backupLast: string;
  backupTarget: string;
}

export interface Standalone {
  id: string;
  name: string;
  image: string;
  hostId: string;
  state: SvcState;
  detected: Origin;
  origin: Origin;
  cpu: number;
  mem: string;
  ports: string[];
}

export type WidgetId = 'kpis' | 'resources' | 'problems' | 'hosts' | 'updates' | 'load' | 'activity' | 'apps' | 'scan';

export interface WidgetCfg {
  id: WidgetId;
  title: string;
  desc: string;
  visible: boolean;
}

export type StepState = 'pending' | 'running' | 'done' | 'error';

export interface ActionStep {
  label: string;
  detail: string;
  state: StepState;
}

export interface ActionItem {
  id: number;
  title: string;
  target: string;
  status: 'running' | 'done' | 'error';
  progress: number;
  phase: string;
  steps: ActionStep[];
  services: string[];
  log: string[];
  started: string;
}

export interface EventItem {
  id: number;
  time: string;
  level: 'info' | 'warn' | 'error' | 'ok';
  text: string;
  source: string;
}

export interface LogLine {
  t: string;
  svc: string;
  level: 'info' | 'warn' | 'error';
  msg: string;
}

/* ---------- Labels ---------- */

const LABEL_TONES: Record<string, Tone> = {
  media: 'violet',
  produktiv: 'ok',
  'spiele': 'orange',
  intern: 'sky',
  test: 'warn',
};
const CYCLE: Tone[] = ['pink', 'lime', 'info', 'accent', 'orange'];

export function labelTone(name: string): Tone {
  const known = LABEL_TONES[name];
  if (known) return known;
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) % 997;
  return CYCLE[h % CYCLE.length];
}

/* ---------- Hosts ---------- */

export const HOSTS: Host[] = [
  {
    id: 'atlas',
    name: 'Atlas',
    color: '#3b82f6',
    colorName: 'Blau',
    status: 'online',
    cpu: 28,
    mem: 41,
    memTotal: '32 GB',
    disk: 63,
    diskTotal: '4 TB',
    address: 'atlas.example.com:3552',
    mode: 'direct',
    agent: 'v0.9.2',
    projectDir: '/opt/stacks',
    os: 'Unraid 7.0 · Docker 27.3',
    lastSeen: 'gerade eben',
    cpuHistory: [22, 25, 31, 27, 24, 30, 35, 29, 26, 24, 28, 33, 30, 27, 25, 28],
  },
  {
    id: 'boreal',
    name: 'Boreal',
    color: '#8b5cf6',
    colorName: 'Violett',
    status: 'online',
    cpu: 46,
    mem: 58,
    memTotal: '64 GB',
    disk: 47,
    diskTotal: '2 TB',
    address: 'boreal.example.com:3552',
    mode: 'direct',
    agent: 'v0.9.2',
    projectDir: '/srv/docklet/stacks',
    os: 'Debian 12 · Docker 27.3',
    lastSeen: 'gerade eben',
    cpuHistory: [38, 41, 44, 52, 49, 45, 43, 47, 55, 51, 46, 42, 44, 48, 50, 46],
  },
  {
    id: 'cedar',
    name: 'Cedar',
    color: '#f97316',
    colorName: 'Orange',
    status: 'offline',
    cpu: 0,
    mem: 0,
    memTotal: '16 GB',
    disk: 0,
    diskTotal: '512 GB',
    address: 'hub.example.com (Edge)',
    mode: 'edge',
    agent: 'v0.9.1',
    projectDir: '/home/docklet/stacks',
    os: 'Ubuntu 24.04 · Docker 26.1',
    lastSeen: 'vor 2 Std.',
    cpuHistory: [12, 14, 11, 15, 13, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  },
];

/* ---------- Compose-Dateien ---------- */

const MEDIA_COMPOSE = `# Media-Stack auf Atlas (synthetisch)
name: media
services:
  jellyfin:
    image: jellyfin/jellyfin:10.9.11
    container_name: jellyfin
    restart: unless-stopped
    ports:
      - "8096:8096"
    volumes:
      - media_config:/config
      - /srv/media/movies:/media/movies:ro
    environment:
      TZ: Europe/Berlin
      JELLYFIN_PublishedServerUrl: https://media.example.com
    depends_on:
      - redis
    healthcheck:
      test: ["CMD-SHELL", "curl -fs http://localhost:8096/health || exit 1"]
      interval: 30s
      retries: 3
    labels:
      docklet.widget: "true"
  redis:
    image: redis:7.2-alpine
    restart: unless-stopped
    volumes:
      - redis_data:/data
volumes:
  media_config:
  redis_data:
`;

const CLOUD_COMPOSE = `# Cloud-Stack auf Boreal (synthetisch)
name: cloud
services:
  nextcloud:
    image: nextcloud:29-apache
    restart: unless-stopped
    ports:
      - "8443:80"
    volumes:
      - cloud_data:/var/www/html
    environment:
      POSTGRES_HOST: postgres
      POSTGRES_PASSWORD: \${DB_PASSWORD}
      NEXTCLOUD_TRUSTED_DOMAINS: cloud.example.com
    networks: [cloud_web, cloud_internal]
  postgres:
    image: postgres:16-alpine
    restart: unless-stopped
    volumes:
      - pg_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=\${DB_PASSWORD}
    networks: [cloud_internal]
networks:
  cloud_web: {}
  cloud_internal:
    internal: true
volumes:
  cloud_data:
  pg_data:
`;

const CRAFT_COMPOSE = `# Craft-Stack auf Boreal (synthetisch)
name: craft
x-docklet-game:
  console: rcon
services:
  minecraft:
    image: itzg/minecraft-server:2024.10.0
    restart: unless-stopped
    ports:
      - "25565:25565"
    volumes:
      - craft_world:/data
    environment:
      EULA: "TRUE"
      MEMORY: 4G
    healthcheck:
      test: ["CMD", "mc-health"]
      interval: 60s
      start_period: 2m
    stop_grace_period: 1m
volumes:
  craft_world:
`;

export const NEW_DRAFT = `# Neuer Entwurf – unbekannte Felder bleiben beim Umschalten erhalten
name: whoami
x-docklet:
  notiz: Dieses Feld kennt das Formular nicht und bleibt trotzdem erhalten
services:
  web:
    image: traefik/whoami:v1.10
    container_name: whoami
    restart: unless-stopped
    ports:
      - "8081:80"
    environment:
      TZ: Europe/Berlin
    labels:
      - traefik.http.routers.whoami.rule=Host(\`whoami.example.com\`)
    healthcheck:
      test: ["CMD-SHELL", "wget -qO- http://localhost/health || exit 1"]
      interval: 30s
`;

export const STACKS: Stack[] = [
  {
    id: 'media',
    name: 'Media',
    hostId: 'atlas',
    description: 'Jellyfin-Mediathek mit Redis-Cache',
    labels: ['media', 'produktiv'],
    url: 'https://media.example.com',
    services: [
      { name: 'jellyfin', image: 'jellyfin/jellyfin:10.9.11', state: 'running', health: 'healthy', cpu: 12, mem: '1,4 GB', ports: ['8096:8096'], updateTo: 'jellyfin/jellyfin:10.10.3' },
      { name: 'redis', image: 'redis:7.2-alpine', state: 'running', health: 'none', cpu: 1, mem: '48 MB', ports: [], updateTo: 'redis:7.4-alpine' },
    ],
    compose: MEDIA_COMPOSE,
    env: 'TZ=Europe/Berlin\n',
    autoUpdate: 'check',
    autoTime: '03:30',
    mounts: ['media_config:/config', '/srv/media/movies:/media/movies:ro', 'redis_data:/data'],
    lastDeploy: 'vor 6 Tagen',
    backupLast: 'heute, 02:00',
    backupTarget: 'Lokal · /mnt/backup/docklet',
  },
  {
    id: 'cloud',
    name: 'Cloud',
    hostId: 'boreal',
    description: 'Nextcloud mit PostgreSQL',
    labels: ['produktiv', 'intern'],
    url: 'https://cloud.example.com',
    services: [
      { name: 'nextcloud', image: 'nextcloud:29-apache', state: 'running', health: 'healthy', cpu: 9, mem: '820 MB', ports: ['8443:80'] },
      { name: 'postgres', image: 'postgres:16-alpine', state: 'running', health: 'healthy', cpu: 4, mem: '310 MB', ports: [] },
    ],
    compose: CLOUD_COMPOSE,
    env: 'DB_PASSWORD=bitte-in-env-setzen\n',
    autoUpdate: 'weekly',
    autoTime: 'So 04:00',
    mounts: ['cloud_data:/var/www/html', 'pg_data:/var/lib/postgresql/data'],
    lastDeploy: 'vor 2 Tagen',
    backupLast: 'heute, 02:15',
    backupTarget: 'NFS · nas.example.com:/backup',
  },
  {
    id: 'craft',
    name: 'Craft',
    hostId: 'boreal',
    description: 'Minecraft-Server für die Familie',
    labels: ['spiele'],
    url: 'mc.example.com:25565',
    services: [
      { name: 'minecraft', image: 'itzg/minecraft-server:2024.10.0', state: 'running', health: 'unhealthy', cpu: 31, mem: '3,6 GB', ports: ['25565:25565'] },
    ],
    compose: CRAFT_COMPOSE,
    env: '',
    autoUpdate: 'check',
    autoTime: '05:00',
    mounts: ['craft_world:/data'],
    lastDeploy: 'gestern',
    backupLast: 'gestern, 23:00',
    backupTarget: 'SMB · //nas.example.com/games',
  },
];

export const STANDALONE: Standalone[] = [
  {
    id: 'legacy',
    name: 'Legacy',
    image: 'lscr.io/linuxserver/duplicati:2.0.8',
    hostId: 'atlas',
    state: 'running',
    detected: 'unraid',
    origin: 'unraid',
    cpu: 2,
    mem: '210 MB',
    ports: ['8200:8200'],
  },
];

export const DEFAULT_WIDGETS: WidgetCfg[] = [
  { id: 'kpis', title: 'Kennzahlen', desc: 'Container, Updates, Probleme und Hosts', visible: true },
  { id: 'resources', title: 'Ressourcen je Host', desc: 'CPU, RAM und Speicher live (simuliert)', visible: true },
  { id: 'problems', title: 'Probleme', desc: 'Unhealthy-Container und Hostwarnungen', visible: true },
  { id: 'updates', title: 'Updates', desc: 'Verfügbare Image-Updates', visible: true },
  { id: 'load', title: 'CPU-Verlauf', desc: 'Auslastung der letzten Minuten', visible: true },
  { id: 'activity', title: 'Letzte Ereignisse', desc: 'Auszug aus dem Ereignisverlauf', visible: true },
  { id: 'scan', title: 'Schwachstellen', desc: 'Optionaler Scan-Überblick', visible: true },
  { id: 'hosts', title: 'Hoststatus', desc: 'Verbindung je Host als Liste', visible: false },
  { id: 'apps', title: 'Anwendungslinks', desc: 'Schnellzugriff im Homepage-Stil', visible: false },
];

export const SEED_EVENTS: EventItem[] = [
  { id: 1, time: '09:42', level: 'error', text: 'minecraft ist unhealthy (Healthcheck 3× fehlgeschlagen)', source: 'Craft · Boreal' },
  { id: 2, time: '09:30', level: 'warn', text: 'Cedar hat die Verbindung verloren', source: 'Cedar' },
  { id: 3, time: '08:05', level: 'info', text: '2 Image-Updates gefunden (nur prüfen)', source: 'Media · Atlas' },
  { id: 4, time: '02:15', level: 'ok', text: 'Backup cloud_data abgeschlossen (NFS)', source: 'Cloud · Boreal' },
  { id: 5, time: '02:00', level: 'ok', text: 'Backup media_config abgeschlossen (lokal)', source: 'Media · Atlas' },
];

export const SEED_ACTIONS: ActionItem[] = [
  {
    id: 1,
    title: 'Update-Prüfung',
    target: 'Alle Hosts',
    status: 'done',
    progress: 100,
    phase: 'Abgeschlossen',
    steps: [
      { label: 'Registries abfragen', detail: 'simuliert, keine Netzwerkanfrage', state: 'done' },
      { label: 'Digests vergleichen', detail: 'jellyfin 10.10.3, redis 7.4-alpine verfügbar', state: 'done' },
      { label: 'Ergebnis speichern', detail: 'Modus „nur prüfen“ – nichts installiert', state: 'done' },
    ],
    services: ['jellyfin', 'redis'],
    log: ['Registries abgefragt (simuliert)', 'jellyfin: 10.10.3 verfügbar', 'redis: 7.4-alpine verfügbar', 'Fertig – keine Installation (Modus: nur prüfen)'],
    started: '08:05',
  },
];

/* ---------- Logs (gemeinsamer Stream je Stack) ---------- */

export const LOGS: Record<string, LogLine[]> = {
  media: [
    { t: '09:40:12', svc: 'jellyfin', level: 'info', msg: '[INF] Startup complete 0:00:04.21' },
    { t: '09:40:13', svc: 'jellyfin', level: 'info', msg: '[INF] Kestrel listening on 0.0.0.0:8096' },
    { t: '09:40:14', svc: 'redis', level: 'info', msg: 'Ready to accept connections tcp' },
    { t: '09:41:02', svc: 'redis', level: 'info', msg: 'DB saved on disk' },
    { t: '09:41:40', svc: 'jellyfin', level: 'warn', msg: '[WRN] Slow response from metadata provider (simuliert)' },
    { t: '09:42:30', svc: 'jellyfin', level: 'info', msg: '[INF] Scheduled task "Scan Media Library" completed' },
  ],
  cloud: [
    { t: '09:30:01', svc: 'postgres', level: 'info', msg: 'database system is ready to accept connections' },
    { t: '09:30:05', svc: 'nextcloud', level: 'info', msg: 'AH00094: Command line: apache2 -D FOREGROUND' },
    { t: '09:33:12', svc: 'postgres', level: 'info', msg: 'checkpoint complete: wrote 312 buffers' },
    { t: '09:35:44', svc: 'nextcloud', level: 'info', msg: 'cron.php ausgeführt (12 Jobs)' },
  ],
  craft: [
    { t: '09:38:10', svc: 'minecraft', level: 'info', msg: '[Server thread/INFO]: Done (14.211s)!' },
    { t: '09:40:52', svc: 'minecraft', level: 'warn', msg: "[Server thread/WARN]: Can't keep up! Is the server overloaded?" },
    { t: '09:41:30', svc: 'minecraft', level: 'error', msg: 'healthcheck: mc-health exit 1 (timeout)' },
    { t: '09:42:00', svc: 'minecraft', level: 'error', msg: 'healthcheck: mc-health exit 1 (timeout)' },
  ],
};

export const LIVE_MESSAGES: string[] = [
  'GET /health 200 (simuliert)',
  'Heartbeat ok',
  'Cache-Treffer 98 %',
  'Hintergrundaufgabe abgeschlossen',
  'Verbindung aus 172.x angenommen',
];

/* ---------- Netzwerktopologie (feste Koordinaten im 840×440-Raster) ---------- */

export interface TopoNode {
  id: string;
  kind: 'network' | 'service';
  label: string;
  sub: string;
  hostId: string;
  x: number;
  y: number;
  stackId?: string;
}

export interface TopoLink {
  from: string;
  to: string;
  ip: string;
}

/** Tatsächlich beobachtete Verbindungen (z. B. aus conntrack) – ohne Messwerte. */
export interface TopoComm {
  from: string;
  to: string;
  port: string;
}

export const TOPO_NODES: TopoNode[] = [
  { id: 'n-media', kind: 'network', label: 'media_default', sub: 'bridge · 192.0.2.32/27', hostId: 'atlas', x: 220, y: 155, stackId: 'media' },
  { id: 'n-bridge', kind: 'network', label: 'bridge', sub: 'Standard · 192.0.2.0/27', hostId: 'atlas', x: 220, y: 345 },
  { id: 'n-web', kind: 'network', label: 'cloud_web', sub: 'bridge · 192.0.2.64/27', hostId: 'boreal', x: 590, y: 110, stackId: 'cloud' },
  { id: 'n-int', kind: 'network', label: 'cloud_internal', sub: 'intern · 198.51.100.0/27', hostId: 'boreal', x: 590, y: 250, stackId: 'cloud' },
  { id: 'n-craft', kind: 'network', label: 'craft_default', sub: 'bridge · 198.51.100.32/27', hostId: 'boreal', x: 590, y: 375, stackId: 'craft' },
  { id: 's-jellyfin', kind: 'service', label: 'jellyfin', sub: 'Media', hostId: 'atlas', x: 74, y: 95, stackId: 'media' },
  { id: 's-redis', kind: 'service', label: 'redis', sub: 'Media', hostId: 'atlas', x: 74, y: 225, stackId: 'media' },
  { id: 's-legacy', kind: 'service', label: 'legacy', sub: 'Unraid', hostId: 'atlas', x: 74, y: 355 },
  { id: 's-nextcloud', kind: 'service', label: 'nextcloud', sub: 'Cloud', hostId: 'boreal', x: 770, y: 150, stackId: 'cloud' },
  { id: 's-postgres', kind: 'service', label: 'postgres', sub: 'Cloud', hostId: 'boreal', x: 770, y: 280, stackId: 'cloud' },
  { id: 's-minecraft', kind: 'service', label: 'minecraft', sub: 'Craft', hostId: 'boreal', x: 770, y: 390, stackId: 'craft' },
];

export const TOPO_LINKS: TopoLink[] = [
  { from: 's-jellyfin', to: 'n-media', ip: '192.0.2.34' },
  { from: 's-redis', to: 'n-media', ip: '192.0.2.35' },
  { from: 's-legacy', to: 'n-bridge', ip: '192.0.2.4' },
  { from: 's-nextcloud', to: 'n-web', ip: '192.0.2.66' },
  { from: 's-nextcloud', to: 'n-int', ip: '198.51.100.2' },
  { from: 's-postgres', to: 'n-int', ip: '198.51.100.3' },
  { from: 's-minecraft', to: 'n-craft', ip: '198.51.100.34' },
];

export const TOPO_COMM: TopoComm[] = [
  { from: 's-jellyfin', to: 's-redis', port: 'TCP 6379' },
  { from: 's-nextcloud', to: 's-postgres', port: 'TCP 5432' },
];

/* ---------- Images & Volumes ---------- */

export interface ImageRow {
  repo: string;
  tag: string;
  size: string;
  hostId: string;
  usedBy: string;
  update?: string;
}

export const IMAGES: ImageRow[] = [
  { repo: 'jellyfin/jellyfin', tag: '10.9.11', size: '1,21 GB', hostId: 'atlas', usedBy: 'Media / jellyfin', update: '10.10.3' },
  { repo: 'redis', tag: '7.2-alpine', size: '41 MB', hostId: 'atlas', usedBy: 'Media / redis', update: '7.4-alpine' },
  { repo: 'lscr.io/linuxserver/duplicati', tag: '2.0.8', size: '540 MB', hostId: 'atlas', usedBy: 'Legacy (Unraid)' },
  { repo: 'nextcloud', tag: '29-apache', size: '1,08 GB', hostId: 'boreal', usedBy: 'Cloud / nextcloud' },
  { repo: 'postgres', tag: '16-alpine', size: '243 MB', hostId: 'boreal', usedBy: 'Cloud / postgres' },
  { repo: 'itzg/minecraft-server', tag: '2024.10.0', size: '812 MB', hostId: 'boreal', usedBy: 'Craft / minecraft' },
  { repo: 'jellyfin/jellyfin', tag: '10.9.8', size: '1,19 GB', hostId: 'atlas', usedBy: '– (früheres Image)' },
];

export interface VolumeRow {
  name: string;
  hostId: string;
  kind: 'volume' | 'bind';
  path: string;
  size: string;
  usedBy: string;
  backup: string;
}

export const VOLUMES: VolumeRow[] = [
  { name: 'media_config', hostId: 'atlas', kind: 'volume', path: '/var/lib/docker/volumes/media_config', size: '2,3 GB', usedBy: 'jellyfin', backup: 'täglich · lokal' },
  { name: 'redis_data', hostId: 'atlas', kind: 'volume', path: '/var/lib/docker/volumes/redis_data', size: '64 MB', usedBy: 'redis', backup: '–' },
  { name: '/srv/media/movies', hostId: 'atlas', kind: 'bind', path: '/srv/media/movies', size: '1,8 TB', usedBy: 'jellyfin (ro)', backup: 'ausgenommen' },
  { name: 'cloud_data', hostId: 'boreal', kind: 'volume', path: '/var/lib/docker/volumes/cloud_data', size: '148 GB', usedBy: 'nextcloud', backup: 'täglich · NFS' },
  { name: 'pg_data', hostId: 'boreal', kind: 'volume', path: '/var/lib/docker/volumes/pg_data', size: '3,1 GB', usedBy: 'postgres', backup: 'täglich · NFS' },
  { name: 'craft_world', hostId: 'boreal', kind: 'volume', path: '/var/lib/docker/volumes/craft_world', size: '6,7 GB', usedBy: 'minecraft', backup: 'täglich · SMB' },
];

export interface FileEntry {
  name: string;
  dir: boolean;
  size: string;
  modified: string;
}

export const FILES: Record<string, FileEntry[]> = {
  media_config: [
    { name: 'data', dir: true, size: '–', modified: 'heute 09:12' },
    { name: 'metadata', dir: true, size: '–', modified: 'gestern' },
    { name: 'network.xml', dir: false, size: '2 KB', modified: 'vor 6 Tagen' },
    { name: 'system.xml', dir: false, size: '5 KB', modified: 'vor 6 Tagen' },
  ],
  '/srv/media/movies': [
    { name: 'Dokumentationen', dir: true, size: '–', modified: 'letzte Woche' },
    { name: 'Spielfilme', dir: true, size: '–', modified: 'gestern' },
    { name: 'README.txt', dir: false, size: '1 KB', modified: 'vor 3 Monaten' },
  ],
  cloud_data: [
    { name: 'config', dir: true, size: '–', modified: 'vor 2 Tagen' },
    { name: 'data', dir: true, size: '–', modified: 'heute 09:40' },
    { name: 'apps', dir: true, size: '–', modified: 'vor 2 Tagen' },
  ],
  pg_data: [
    { name: 'base', dir: true, size: '–', modified: 'heute' },
    { name: 'pg_wal', dir: true, size: '–', modified: 'heute' },
    { name: 'postgresql.conf', dir: false, size: '29 KB', modified: 'vor 2 Tagen' },
  ],
  craft_world: [
    { name: 'world', dir: true, size: '–', modified: 'heute 09:41' },
    { name: 'logs', dir: true, size: '–', modified: 'heute 09:42' },
    { name: 'server.properties', dir: false, size: '1 KB', modified: 'gestern' },
    { name: 'whitelist.json', dir: false, size: '1 KB', modified: 'letzte Woche' },
  ],
  '/opt/stacks/media': [
    { name: 'compose.yaml', dir: false, size: '1 KB', modified: 'vor 6 Tagen' },
    { name: '.env', dir: false, size: '1 KB', modified: 'vor 6 Tagen' },
  ],
};

/* ---------- Sicherheit (synthetische Befunde) ---------- */

export type Severity = 'critical' | 'high' | 'medium' | 'low';

export interface ScanImage {
  ref: string;
  hostId: string;
  stackId?: string;
  usage: 'running' | 'stopped' | 'unused';
  critical: number;
  high: number;
  medium: number;
  low: number;
  scanned: string;
}

export interface Finding {
  id: string;
  severity: Severity;
  pkg: string;
  installed: string;
  fixed: string;
  image: string;
  hostId: string;
  cvss: number;
}

export interface ScanRun {
  when: string;
  kind: 'geplant' | 'manuell';
  critical: number;
  high: number;
  medium: number;
  low: number;
}

export const SCAN_IMAGES: ScanImage[] = [
  { ref: 'jellyfin/jellyfin:10.9.11', hostId: 'atlas', stackId: 'media', usage: 'running', critical: 0, high: 2, medium: 5, low: 9, scanned: 'heute 03:00' },
  { ref: 'redis:7.2-alpine', hostId: 'atlas', stackId: 'media', usage: 'running', critical: 0, high: 0, medium: 1, low: 2, scanned: 'heute 03:00' },
  { ref: 'lscr.io/linuxserver/duplicati:2.0.8', hostId: 'atlas', usage: 'running', critical: 1, high: 1, medium: 3, low: 4, scanned: 'heute 03:01' },
  { ref: 'nextcloud:29-apache', hostId: 'boreal', stackId: 'cloud', usage: 'running', critical: 0, high: 1, medium: 4, low: 12, scanned: 'heute 03:02' },
  { ref: 'postgres:16-alpine', hostId: 'boreal', stackId: 'cloud', usage: 'running', critical: 0, high: 0, medium: 1, low: 3, scanned: 'heute 03:02' },
  { ref: 'itzg/minecraft-server:2024.10.0', hostId: 'boreal', stackId: 'craft', usage: 'running', critical: 0, high: 1, medium: 2, low: 6, scanned: 'heute 03:03' },
  { ref: 'jellyfin/jellyfin:10.9.8', hostId: 'atlas', usage: 'unused', critical: 1, high: 3, medium: 6, low: 9, scanned: 'heute 03:00' },
];

export const FINDINGS: Finding[] = [
  { id: 'CVE-2026-10421', severity: 'critical', pkg: 'openssl', installed: '3.0.13', fixed: '3.0.15', image: 'lscr.io/linuxserver/duplicati:2.0.8', hostId: 'atlas', cvss: 9.1 },
  { id: 'CVE-2026-10388', severity: 'critical', pkg: 'libxml2', installed: '2.11.5', fixed: '2.11.9', image: 'jellyfin/jellyfin:10.9.8', hostId: 'atlas', cvss: 9.0 },
  { id: 'CVE-2026-09977', severity: 'high', pkg: 'ffmpeg', installed: '6.0.1', fixed: '6.0.2', image: 'jellyfin/jellyfin:10.9.11', hostId: 'atlas', cvss: 8.1 },
  { id: 'CVE-2026-09831', severity: 'high', pkg: 'libcurl', installed: '8.5.0', fixed: '8.9.1', image: 'nextcloud:29-apache', hostId: 'boreal', cvss: 7.5 },
  { id: 'CVE-2026-09720', severity: 'high', pkg: 'netty-codec', installed: '4.1.100', fixed: '4.1.108', image: 'itzg/minecraft-server:2024.10.0', hostId: 'boreal', cvss: 7.5 },
  { id: 'CVE-2026-09514', severity: 'medium', pkg: 'busybox', installed: '1.36.1', fixed: '1.36.1-r5', image: 'redis:7.2-alpine', hostId: 'atlas', cvss: 5.5 },
  { id: 'CVE-2026-09402', severity: 'medium', pkg: 'zlib', installed: '1.2.13', fixed: '1.3.1', image: 'postgres:16-alpine', hostId: 'boreal', cvss: 5.3 },
  { id: 'CVE-2026-09233', severity: 'low', pkg: 'tar', installed: '1.34', fixed: '–', image: 'nextcloud:29-apache', hostId: 'boreal', cvss: 3.3 },
];

export const SCAN_HISTORY: ScanRun[] = [
  { when: '03.10.', kind: 'geplant', critical: 3, high: 12, medium: 25, low: 48 },
  { when: '04.10.', kind: 'geplant', critical: 3, high: 11, medium: 25, low: 47 },
  { when: '05.10.', kind: 'geplant', critical: 2, high: 11, medium: 24, low: 46 },
  { when: '06.10.', kind: 'manuell', critical: 2, high: 9, medium: 23, low: 46 },
  { when: '07.10.', kind: 'geplant', critical: 2, high: 9, medium: 22, low: 45 },
  { when: '08.10.', kind: 'geplant', critical: 2, high: 8, medium: 22, low: 45 },
  { when: '09.10.', kind: 'geplant', critical: 2, high: 8, medium: 22, low: 45 },
  { when: '10.10.', kind: 'geplant', critical: 2, high: 8, medium: 22, low: 45 },
];

/* ---------- Hub-Einstellungen ---------- */

export type AuthMode = 'none' | 'local' | 'proxy';
export type ChannelKind = 'email' | 'discord' | 'telegram' | 'signal' | 'slack' | 'ntfy' | 'pushover' | 'gotify' | 'matrix' | 'gchat' | 'generic';

export const CHANNEL_LABELS: Record<ChannelKind, string> = {
  email: 'E-Mail',
  discord: 'Discord',
  telegram: 'Telegram',
  signal: 'Signal',
  slack: 'Slack',
  ntfy: 'ntfy',
  pushover: 'Pushover',
  gotify: 'Gotify',
  matrix: 'Matrix',
  gchat: 'Google Chat',
  generic: 'Generischer Webhook',
};

export interface NotifyChannel {
  id: number;
  kind: ChannelKind;
  name: string;
  target: string;
  events: string[];
}

export interface HubUser {
  id: number;
  name: string;
  role: 'admin' | 'user';
  access: { stackId: string; level: 'full' | 'limited' }[];
}

export interface BackupTarget {
  id: number;
  kind: 'local' | 'hostmount' | 'smb' | 'nfs';
  name: string;
  path: string;
}

export interface HubSettings {
  auth: AuthMode;
  adminUser: string;
  proxyHeader: string;
  users: HubUser[];
  channels: NotifyChannel[];
  updateMode: AutoUpdate;
  updateCheck: string;
  backupTargets: BackupTarget[];
  scanSchedule: 'manual' | 'daily' | 'weekly';
  scanWidget: boolean;
  healMax: number;
  healWindow: string;
  healExclude: string[];
}

export const DEFAULT_HUB: HubSettings = {
  auth: 'local',
  adminUser: 'admin',
  proxyHeader: 'Remote-User',
  users: [
    { id: 1, name: 'admin', role: 'admin', access: [] },
    { id: 2, name: 'lena', role: 'user', access: [{ stackId: 'craft', level: 'limited' }] },
  ],
  channels: [
    { id: 1, kind: 'discord', name: 'Discord · #betrieb', target: 'https://discord.example.com/api/webhooks/…', events: ['Fehler', 'Updates'] },
    { id: 2, kind: 'ntfy', name: 'ntfy · docklet', target: 'https://ntfy.example.com/docklet', events: ['Fehler', 'Backups'] },
  ],
  updateMode: 'check',
  updateCheck: 'alle 6 Stunden',
  backupTargets: [
    { id: 1, kind: 'local', name: 'Lokal', path: '/mnt/backup/docklet' },
    { id: 2, kind: 'hostmount', name: 'Unraid-Share', path: '/mnt/user/backups' },
    { id: 3, kind: 'smb', name: 'NAS Spiele', path: '//nas.example.com/games' },
    { id: 4, kind: 'nfs', name: 'NAS Backup', path: 'nas.example.com:/backup' },
  ],
  scanSchedule: 'daily',
  scanWidget: true,
  healMax: 3,
  healWindow: '1 Stunde',
  healExclude: [],
};

export interface Profile {
  name: string;
  email: string;
  lang: 'de' | 'en';
  theme: 'dark' | 'light' | 'system';
  animations: boolean;
}
