import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { Host, WidgetId } from './data';
import { DialogComponent } from './dialog.component';
import { IconComponent, IconName } from './icon.component';
import { ArcaneStore } from './store';

const CW = 300;
const CH = 120;

/** Stil-Host für die Arcane-Metrikkacheln (metric-tile: Großbuchstaben-Label, Wert, Meter mit Ticks). */
@Component({
  selector: 'oa-metric-styles',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-res{display:flex;flex-direction:column;gap:10px}
    .oa-res-host{padding-bottom:10px;border-bottom:1px solid color-mix(in oklch,var(--oa-line) 60%,transparent)}
    .oa-res-host:last-child{border-bottom:0;padding-bottom:0}
    .oa-res-name i{width:4px;height:16px;border-radius:4px;background:var(--hc)}
    .oa-res-tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:6px}
    .oa-mt-top{display:flex;justify-content:space-between;align-items:center;font-size:10.5px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;color:color-mix(in oklch,var(--oa-fg) 70%,transparent)}
    .oa-mt-top span{display:inline-flex;gap:4px;align-items:center}
    .oa-mt-top b{font-size:13px;letter-spacing:0;color:var(--oa-fg);font-variant-numeric:tabular-nums}
    .oa-mt-bar{position:relative;height:6px;margin-top:6px;border-radius:99px;background:color-mix(in oklch,var(--oa-mbg) 60%,transparent);overflow:hidden}
    .oa-mt-bar i{position:absolute;top:0;width:1px;height:100%;background:color-mix(in oklch,var(--oa-fg) 15%,transparent)}
    .oa-mt-bar span{position:absolute;inset:0 auto 0 0;border-radius:99px;background:linear-gradient(90deg,color-mix(in oklch,var(--oa-accent) 65%,transparent),var(--oa-accent));transition:width .7s ease-out}
    .oa-mt-bar .oa-mt-hi{background:linear-gradient(90deg,var(--oa-accent),var(--oa-err))}
    .oa-mt small{font-size:11px;color:var(--oa-muted)}
    .oa-res-off{display:flex;gap:6px;align-items:center;margin:6px 0 0;color:var(--oa-warn)}
  `,
})
export class MetricStylesComponent {}

interface Meter {
  key: string;
  label: string;
  icon: IconName;
  value: number;
  sub: string;
}

@Component({
  selector: 'oa-dashboard',
  imports: [ZardButtonComponent, IconComponent, DialogComponent, MetricStylesComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-metric-styles />
    <div class="oa-page-head">
      <div>
        <h1>Dashboard</h1>
        <p>{{ scopeLabel() }} – Kennzahlen, Ressourcen, Probleme und Updates. Stacks findest du separat.</p>
      </div>
      <div class="oa-sp"></div>
      <button type="button" class="oa-btn" [attr.aria-pressed]="store.live()" (click)="store.live.set(!store.live())">
        <oa-icon [name]="store.live() ? 'pause' : 'play'" [size]="13" /> {{ store.live() ? 'Live (simuliert)' : 'Pausiert' }}
      </button>
      <button z-button zType="outline" type="button" (click)="customize.set(true)"><oa-icon name="sliders" [size]="15" /> Anpassen</button>
    </div>

    <div class="oa-dash">
      @for (w of visible(); track w.id) {
        <section class="oa-card oa-widget" [attr.aria-labelledby]="'w-' + w.id">
          @switch (w.id) {
            @case ('kpis') {
              <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="activity" /></span><h3 [id]="'w-' + w.id">{{ w.title }}</h3></div>
              <div class="oa-kpis">
                <button type="button" class="oa-kpi" (click)="store.go('containers')">
                  <span>Container laufen</span><strong>{{ store.runningCount() }}</strong><small>inkl. Docklet-Agenten</small>
                </button>
                <button type="button" class="oa-kpi" (click)="store.go('stacks')">
                  <span>Updates</span><strong data-tone="info">{{ store.updates().length }}</strong><small>nur geprüft</small>
                </button>
                <button type="button" class="oa-kpi" (click)="openFirstProblem()">
                  <span>Probleme</span><strong [attr.data-tone]="store.problems().length ? 'err' : null">{{ store.problems().length }}</strong><small>unhealthy</small>
                </button>
                <button type="button" class="oa-kpi" (click)="store.go('hosts')">
                  <span>Hosts online</span><strong>{{ onlineVisible() }}/{{ store.visibleHosts().length }}</strong><small>{{ store.offlineHosts().length }} getrennt</small>
                </button>
              </div>
            }
            @case ('resources') {
              <div class="oa-card-head">
                <span class="oa-card-ico" data-tone="info"><oa-icon name="cpu" /></span>
                <h3 [id]="'w-' + w.id">{{ w.title }}</h3>
                <span class="oa-sp"></span>
                <span class="oa-pill" [attr.data-tone]="store.live() ? 'ok' : null"><span class="oa-dot" [attr.data-tone]="store.live() ? 'ok' : null"></span>{{ store.live() ? 'live' : 'pausiert' }}</span>
              </div>
              <div class="oa-res">
                @for (h of store.visibleHosts(); track h.id) {
                  <div class="oa-res-host" [style.--hc]="h.color">
                    <div class="oa-row oa-res-name">
                      <i></i><strong>{{ h.name }}</strong>
                      <span class="oa-pill" [attr.data-tone]="h.mode === 'edge' ? 'info' : 'accent'">{{ h.mode === 'edge' ? 'Edge' : 'Direkt' }}</span>
                      <span class="oa-sp"></span>
                      <span class="oa-small oa-muted">{{ stackCount(h.id) }} Stacks</span>
                    </div>
                    @if (h.status === 'online') {
                      <div class="oa-res-tiles">
                        @for (m of meters(h); track m.key) {
                          <div class="oa-mt">
                            <div class="oa-mt-top"><span><oa-icon [name]="m.icon" [size]="12" /> {{ m.label }}</span><b>{{ m.value }} %</b></div>
                            <div class="oa-mt-bar" role="meter" [attr.aria-valuenow]="m.value" aria-valuemin="0" aria-valuemax="100" [attr.aria-label]="m.label + ' ' + h.name">
                              <i style="left:25%"></i><i style="left:50%"></i><i style="left:75%"></i>
                              <span [style.width.%]="m.value" [class.oa-mt-hi]="m.value >= 90"></span>
                            </div>
                            <small>{{ m.sub }}</small>
                          </div>
                        }
                      </div>
                    } @else {
                      <p class="oa-small oa-res-off"><oa-icon name="alert" [size]="13" /> Nicht erreichbar – letzter Kontakt {{ h.lastSeen }}. Werte veraltet.</p>
                    }
                  </div>
                }
              </div>
            }
            @case ('problems') {
              <div class="oa-card-head">
                <span class="oa-card-ico" data-tone="err"><oa-icon name="alert" /></span>
                <h3 [id]="'w-' + w.id">{{ w.title }}</h3>
                <span class="oa-sp"></span>
                <span class="oa-pill" [attr.data-tone]="store.problems().length ? 'err' : 'ok'">{{ store.problems().length }} offen</span>
              </div>
              <ul class="oa-list">
                @for (p of store.problems(); track p.svc.name) {
                  <li>
                    <span class="oa-dot" data-tone="err"></span>
                    <div class="oa-sp">
                      <div><strong>{{ p.svc.name }}</strong> ist unhealthy</div>
                      <div class="oa-small oa-muted">{{ p.stack.name }} · {{ store.hn(p.stack.hostId) }}</div>
                    </div>
                    <button type="button" class="oa-btn" (click)="store.openStack(p.stack.id, 'logs')">Logs</button>
                    <button type="button" class="oa-btn" data-tone="accent" (click)="store.restartService(p.stack.id, p.svc.name)"><oa-icon name="restart" [size]="14" /> Neustart</button>
                  </li>
                } @empty {
                  <li><oa-icon name="circleCheck" class="oa-ok" /> Keine Container-Probleme</li>
                }
                @for (h of store.offlineHosts(); track h.id) {
                  <li>
                    <span class="oa-dot" data-tone="warn"></span>
                    <div class="oa-sp">
                      <div><strong>{{ h.name }}</strong> getrennt</div>
                      <div class="oa-small oa-muted">Letzter Kontakt {{ h.lastSeen }} · Hostwarnung</div>
                    </div>
                    <button type="button" class="oa-btn" (click)="store.reconnect(h.id)">Prüfen</button>
                  </li>
                }
              </ul>
              <div class="oa-heal">
                <oa-icon name="zap" [size]="15" />
                <span class="oa-sp oa-small">Auto Heal: unhealthy-Container max. {{ store.hub().healMax }}× pro {{ store.hub().healWindow }} neu starten</span>
                <button type="button" class="oa-switch" role="switch" [attr.aria-checked]="store.autoHeal()" aria-label="Auto Heal" (click)="store.autoHeal.set(!store.autoHeal())"></button>
              </div>
            }
            @case ('hosts') {
              <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="server" /></span><h3 [id]="'w-' + w.id">{{ w.title }}</h3></div>
              <ul class="oa-list">
                @for (h of store.visibleHosts(); track h.id) {
                  <li>
                    <span class="oa-host" [style.--hc]="h.color"><i></i></span>
                    <strong class="oa-sp">{{ h.name }}</strong>
                    <span class="oa-small oa-muted">{{ h.address }}</span>
                    <span class="oa-pill oa-pill--status" [attr.data-tone]="h.status === 'online' ? 'ok' : 'warn'">{{ h.status === 'online' ? 'Online' : 'Getrennt' }}</span>
                  </li>
                }
              </ul>
            }
            @case ('updates') {
              <div class="oa-card-head">
                <span class="oa-card-ico" data-tone="info"><oa-icon name="download" /></span>
                <h3 [id]="'w-' + w.id">{{ w.title }}</h3>
                <span class="oa-sp"></span>
                <span class="oa-pill" data-tone="info">{{ store.updates().length }} verfügbar</span>
              </div>
              <ul class="oa-list">
                @for (u of store.updates(); track u.svc.name) {
                  <li>
                    <oa-icon name="package" class="oa-muted" />
                    <div class="oa-sp">
                      <div><strong>{{ u.svc.name }}</strong> <span class="oa-small oa-muted">· {{ u.stack.name }}</span></div>
                      <div class="oa-mono oa-small oa-muted">{{ tag(u.svc.image) }} → {{ tag(u.svc.updateTo ?? '') }}</div>
                    </div>
                    <button type="button" class="oa-btn" (click)="store.openStack(u.stack.id, 'updates')">Öffnen</button>
                  </li>
                } @empty {
                  <li><oa-icon name="circleCheck" class="oa-ok" /> Alle Images aktuell</li>
                }
              </ul>
            }
            @case ('load') {
              <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="activity" /></span><h3 [id]="'w-' + w.id">{{ w.title }}</h3></div>
              <svg class="oa-chart" [attr.viewBox]="'0 0 ' + cw + ' ' + (ch + 18)" role="img" [attr.aria-label]="chartLabel()">
                @for (g of grid; track g) {
                  <line x1="26" [attr.x2]="cw" [attr.y1]="y(g)" [attr.y2]="y(g)" class="oa-chart-grid" />
                  <text x="0" [attr.y]="y(g) + 3" class="oa-chart-ax">{{ g }}%</text>
                }
                @for (l of lines(); track l.id) {
                  <polyline [attr.points]="l.points" fill="none" [attr.stroke]="l.color" stroke-width="2" stroke-linejoin="round" [attr.stroke-dasharray]="l.offline ? '4 4' : null" />
                }
                <text x="26" [attr.y]="ch + 16" class="oa-chart-ax">−40 s</text>
                <text [attr.x]="cw - 30" [attr.y]="ch + 16" class="oa-chart-ax">jetzt</text>
              </svg>
              <div class="oa-row oa-small oa-muted">
                @for (h of store.visibleHosts(); track h.id) {
                  <span class="oa-host" [style.--hc]="h.color"><i></i>{{ h.name }} {{ h.status === 'online' ? h.cpu + ' %' : '(getrennt)' }}</span>
                }
              </div>
            }
            @case ('activity') {
              <div class="oa-card-head">
                <span class="oa-card-ico"><oa-icon name="history" /></span>
                <h3 [id]="'w-' + w.id">{{ w.title }}</h3>
                <span class="oa-sp"></span>
                <button type="button" class="oa-btn" (click)="store.openAction(null)">Alle</button>
              </div>
              <ul class="oa-list">
                @for (e of recent(); track e.id) {
                  <li>
                    <span class="oa-dot" [attr.data-tone]="e.level === 'error' ? 'err' : e.level === 'warn' ? 'warn' : e.level === 'ok' ? 'ok' : null"></span>
                    <div class="oa-sp">
                      <div class="oa-small">{{ e.text }}</div>
                      <div class="oa-small oa-muted">{{ e.time }} · {{ e.source }}</div>
                    </div>
                  </li>
                }
              </ul>
            }
            @case ('apps') {
              <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="globe" /></span><h3 [id]="'w-' + w.id">{{ w.title }}</h3></div>
              <div class="oa-applinks">
                @for (s of store.visibleStacks(); track s.id) {
                  <button type="button" class="oa-applink" (click)="store.showToast('Demo: würde ' + (s.url ?? s.name) + ' öffnen')">
                    <span class="oa-applink-ico" [style.--hc]="store.hc(s.hostId)"><oa-icon name="layers" [size]="16" /></span>
                    <span><strong>{{ s.name }}</strong><small>{{ s.url ?? 'kein Link' }}</small></span>
                  </button>
                }
              </div>
            }
            @case ('scan') {
              <div class="oa-card-head">
                <span class="oa-card-ico" data-tone="warn"><oa-icon name="shield" /></span>
                <h3 [id]="'w-' + w.id">{{ w.title }}</h3>
                <span class="oa-sp"></span>
                <span class="oa-pill">optional</span>
              </div>
              @if (store.scanEnabled()) {
                @let t = store.scanTotals();
                <div class="oa-scan">
                  <div data-tone="err"><strong>{{ t.critical }}</strong><span>Kritisch</span></div>
                  <div data-tone="orange"><strong>{{ t.high }}</strong><span>Hoch</span></div>
                  <div data-tone="warn"><strong>{{ t.medium }}</strong><span>Mittel</span></div>
                  <div data-tone="lime"><strong>{{ t.low }}</strong><span>Niedrig</span></div>
                </div>
                <p class="oa-small oa-muted">Getrennt von der Update-Erkennung. Diagramme und Befunde auf der Sicherheitsseite.</p>
                <button type="button" class="oa-btn" (click)="store.go('security')">Sicherheit öffnen <oa-icon name="chevronRight" [size]="13" /></button>
              } @else {
                <p class="oa-small oa-muted">Schwachstellenscans sind deaktiviert. Sie laufen manuell oder geplant und sind unabhängig von Updates.</p>
                <button z-button zType="outline" zSize="sm" type="button" (click)="store.runScan()"><oa-icon name="shield" [size]="14" /> Aktivieren &amp; scannen</button>
              }
            }
          }
        </section>
      } @empty {
        <div class="oa-card oa-widget">
          <p class="oa-muted">Alle Widgets sind ausgeblendet.</p>
          <button z-button type="button" (click)="customize.set(true)">Widgets auswählen</button>
        </div>
      }
    </div>

    @if (customize()) {
      <oa-dialog heading="Dashboard anpassen" description="Widgets ein- oder ausblenden und die Reihenfolge festlegen. Alle Karten haben eine einheitliche Größe." icon="sliders" (closed)="customize.set(false)">
        <ol class="oa-wlist" aria-label="Widgets">
          @for (w of store.widgets(); track w.id; let i = $index, last = $last, first = $first) {
            <li class="oa-witem" [class.oa-witem--off]="!w.visible" (keydown)="onWidgetKey($event, w.id)">
              <label class="oa-check oa-sp">
                <input type="checkbox" [checked]="w.visible" (change)="store.toggleWidget(w.id)" />
                <span><strong>{{ w.title }}</strong><small class="oa-muted">{{ w.desc }}</small></span>
              </label>
              <span class="oa-muted oa-small" aria-hidden="true">{{ i + 1 }}</span>
              <button type="button" class="oa-ibtn" [disabled]="first" (click)="store.moveWidget(w.id, -1)" [attr.aria-label]="w.title + ' nach oben'"><oa-icon name="arrowUp" [size]="15" /></button>
              <button type="button" class="oa-ibtn" [disabled]="last" (click)="store.moveWidget(w.id, 1)" [attr.aria-label]="w.title + ' nach unten'"><oa-icon name="arrowDown" [size]="15" /></button>
            </li>
          }
        </ol>
        <p class="oa-help">Tipp: In einer Zeile verschiebt Alt + Pfeil hoch/runter das Widget.</p>
        <div dlgFooter class="oa-row">
          <button z-button zType="ghost" type="button" (click)="store.resetWidgets()">Standard wiederherstellen</button>
          <button z-button type="button" (click)="customize.set(false)">Fertig</button>
        </div>
      </oa-dialog>
    }
  `,
  styles: `
    .oa-dash{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(360px,100%),1fr));gap:16px}
    .oa-widget{min-height:320px;display:flex;flex-direction:column}
    .oa-widget .oa-list{flex:1}
    .oa-kpis{display:grid;grid-template-columns:1fr 1fr;gap:10px;flex:1}
    .oa-kpi{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:12px;border-radius:12px;border:1px solid var(--oa-line);background:none;color:var(--oa-fg);cursor:pointer}
    .oa-kpi:hover{background:var(--oa-mbg)}
    .oa-kpi span{font-size:13px;color:var(--oa-muted)}
    .oa-kpi strong{font-size:28px;font-weight:600;line-height:1.1;font-variant-numeric:tabular-nums;color:var(--t,var(--oa-fg))}
    .oa-kpi small{font-size:12px;color:var(--oa-muted)}
    .oa-heal{display:flex;align-items:center;gap:10px;margin-top:auto;padding-top:12px;border-top:1px solid var(--oa-line);color:var(--oa-muted)}
    .oa-chart{width:100%;height:auto;margin:4px 0 10px;overflow:visible}
    .oa-chart-grid{stroke:var(--oa-line)}
    .oa-chart-ax{fill:var(--oa-muted);font-size:9px}
    .oa-applinks{display:grid;grid-template-columns:1fr 1fr;gap:8px}
    .oa-applink{display:flex;align-items:center;gap:10px;padding:10px;border-radius:12px;border:1px solid var(--oa-line);background:none;color:var(--oa-fg);text-align:left;cursor:pointer;min-width:0}
    .oa-applink small{display:block;color:var(--oa-muted);font-size:11.5px}
    .oa-applink-ico{display:grid;place-items:center;width:32px;height:32px;border-radius:9px;flex-shrink:0;color:var(--hc);background:color-mix(in oklch,var(--hc) 15%,transparent)}
    .oa-scan{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px}
    .oa-scan>div{padding:10px 4px;border-radius:12px;border:1px solid var(--oa-line);text-align:center}
    .oa-scan strong{display:block;font-size:22px;color:var(--t)}
    .oa-scan span{font-size:12px;color:var(--oa-muted)}
    .oa-wlist{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}
    .oa-witem{display:flex;align-items:center;gap:6px;padding:8px 8px 8px 12px;border-radius:12px;border:1px solid var(--oa-line)}
    .oa-witem--off{opacity:.6}
    .oa-witem small{display:block;font-size:11.5px}
    .oa-ok{color:var(--oa-ok)}
  `,
})
export class DashboardComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly customize = signal(false);
  protected readonly cw = CW;
  protected readonly ch = CH;
  protected readonly grid = [0, 25, 50, 75, 100];
  protected readonly visible = computed(() => this.store.widgets().filter((w) => w.visible));
  protected readonly recent = computed(() => this.store.events().slice(0, 5));
  protected readonly onlineVisible = computed(() => this.store.visibleHosts().filter((h) => h.status === 'online').length);
  protected readonly scopeLabel = computed(() =>
    this.store.allHosts() ? 'Alle Hosts gemeinsam' : 'Gefiltert: ' + this.store.visibleHosts().map((h) => h.name).join(', '),
  );

  protected readonly lines = computed(() =>
    this.store.visibleHosts().map((h) => {
      const n = h.cpuHistory.length;
      const pts = h.cpuHistory.map((v, i) => `${(26 + (i / (n - 1)) * (CW - 26)).toFixed(1)},${this.y(v).toFixed(1)}`);
      return { id: h.id, color: h.color, offline: h.status === 'offline', points: pts.join(' ') };
    }),
  );

  protected readonly chartLabel = computed(
    () => 'CPU-Verlauf (simuliert): ' + this.store.visibleHosts().map((h) => `${h.name} ${h.status === 'online' ? h.cpu + ' Prozent' : 'getrennt'}`).join(', '),
  );

  protected meters(h: Host): Meter[] {
    return [
      { key: 'cpu', label: 'CPU', icon: 'cpu', value: h.cpu, sub: `${h.cpuHistory.length} Messpunkte` },
      { key: 'mem', label: 'RAM', icon: 'database', value: h.mem, sub: `von ${h.memTotal}` },
      { key: 'disk', label: 'Disk', icon: 'archive', value: h.disk, sub: `von ${h.diskTotal}` },
    ];
  }

  protected stackCount(hostId: string): number {
    return this.store.stacks().filter((s) => s.hostId === hostId).length;
  }

  protected y(v: number): number {
    return 6 + (1 - v / 100) * (CH - 6);
  }

  protected tag(image: string): string {
    const i = image.lastIndexOf(':');
    return i < 0 ? 'latest' : image.slice(i + 1);
  }

  protected openFirstProblem(): void {
    const p = this.store.problems()[0];
    if (p) this.store.openStack(p.stack.id, 'services');
  }

  protected onWidgetKey(e: KeyboardEvent, id: WidgetId): void {
    if (!e.altKey || (e.key !== 'ArrowUp' && e.key !== 'ArrowDown')) return;
    e.preventDefault();
    this.store.moveWidget(id, e.key === 'ArrowUp' ? -1 : 1);
  }
}
