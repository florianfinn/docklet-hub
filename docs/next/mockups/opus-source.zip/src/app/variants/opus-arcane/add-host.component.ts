import { ChangeDetectionStrategy, Component, computed, inject, OnDestroy, output, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { HostMode } from './data';
import { DialogComponent } from './dialog.component';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const COLORS = [
  { value: '#10b981', name: 'Smaragd' },
  { value: '#ec4899', name: 'Pink' },
  { value: '#eab308', name: 'Gelb' },
  { value: '#06b6d4', name: 'Cyan' },
  { value: '#f43f5e', name: 'Rot' },
];

interface CheckStep {
  label: string;
  detail: string;
  state: 'wait' | 'run' | 'ok' | 'warn';
}

/** Host-Onboarding: Direkt (Standard) oder Edge, Compose-Vorschau, Download, Installer. Alles simuliert. */
@Component({
  selector: 'oa-add-host-dialog',
  imports: [ZardButtonComponent, IconComponent, DialogComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-dialog
      heading="Host hinzufügen"
      description="Agent auf dem Zielhost installieren. Es werden keine echten Schlüssel erzeugt und keine Verbindungen aufgebaut."
      icon="server"
      [wide]="true"
      (closed)="closed.emit()"
    >
      <div class="oa-ah">
        <div class="oa-ah-form">
          <div class="oa-field">
            <span class="oa-label" id="ah-mode-l">Verbindungsart</span>
            <div class="oa-ah-modes" role="radiogroup" aria-labelledby="ah-mode-l">
              <button type="button" role="radio" class="oa-ah-mode" [attr.aria-checked]="mode() === 'direct'" (click)="setMode('direct')">
                <oa-icon name="plug" [size]="18" />
                <span><strong>Direkt</strong> <span class="oa-pill" data-tone="accent">Standard</span>
                  <small>Docklet verbindet sich zum Agent-Port des Hosts.</small></span>
              </button>
              <button type="button" role="radio" class="oa-ah-mode" [attr.aria-checked]="mode() === 'edge'" (click)="setMode('edge')">
                <oa-icon name="globe" [size]="18" />
                <span><strong>Edge</strong>
                  <small>Agent verbindet sich ausgehend zum Hub – kein öffentlicher Port.</small></span>
              </button>
            </div>
          </div>

          <div class="oa-grid2">
            <div class="oa-field">
              <label class="oa-label" for="ah-name">Name <span class="oa-req" aria-hidden="true">*</span></label>
              <input id="ah-name" class="oa-input" placeholder="z. B. Delta" required [attr.aria-invalid]="touched() && !name().trim()" [value]="name()" (input)="name.set($any($event.target).value)" (blur)="touched.set(true)" />
              @if (touched() && !name().trim()) {
                <span class="oa-errtxt"><oa-icon name="alert" [size]="13" /> Pflichtfeld</span>
              }
            </div>
            <div class="oa-field">
              <span class="oa-label" id="ah-color-l">Hostfarbe</span>
              <div class="oa-row" role="radiogroup" aria-labelledby="ah-color-l">
                @for (c of colors; track c.value) {
                  <button type="button" role="radio" class="oa-swatch" [style.background]="c.value" [attr.aria-checked]="color() === c.value" [attr.aria-label]="c.name" (click)="color.set(c.value)"></button>
                }
              </div>
            </div>
          </div>

          @if (mode() === 'direct') {
            <div class="oa-field">
              <label class="oa-label" for="ah-addr">Adresse des Agents</label>
              <input id="ah-addr" class="oa-input oa-mono" [value]="address()" (input)="address.set($any($event.target).value)" />
              <span class="oa-help">Hostname oder IP mit Agent-Port (Standard 3552).</span>
            </div>
          } @else {
            <div class="oa-field">
              <label class="oa-label" for="ah-hub">Hub-Adresse</label>
              <input id="ah-hub" class="oa-input oa-mono" readonly value="wss://hub.example.com/edge" />
              <span class="oa-help">Der Agent baut die Verbindung selbst auf. Kein WireGuard nötig.</span>
            </div>
          }

          <div class="oa-grid2">
            <div class="oa-field">
              <label class="oa-label" for="ah-proj"><oa-icon name="folder" [size]="14" /> Projektverzeichnis</label>
              <input id="ah-proj" class="oa-input oa-mono" [value]="projectDir()" (input)="projectDir.set($any($event.target).value)" />
              <span class="oa-help">Hier liegen die Stacks (compose.yaml, .env).</span>
            </div>
            <div class="oa-field">
              <label class="oa-label" for="ah-inst"><oa-icon name="box" [size]="14" /> Installationsverzeichnis</label>
              <input id="ah-inst" class="oa-input oa-mono" [value]="installDir()" (input)="installDir.set($any($event.target).value)" />
              <span class="oa-help">Nur für den Agent selbst – getrennt vom Projektverzeichnis.</span>
            </div>
          </div>

          <button type="button" class="oa-ah-adv" [attr.aria-expanded]="advanced()" aria-controls="ah-adv" (click)="advanced.set(!advanced())">
            <oa-icon [name]="advanced() ? 'chevronDown' : 'chevronRight'" [size]="14" /> Erweitert
          </button>
          @if (advanced()) {
            <div id="ah-adv" class="oa-ah-advbox">
              <div class="oa-grid2">
                <div class="oa-field">
                  <label class="oa-label" for="ah-uid">PUID (Dateirechte)</label>
                  <input id="ah-uid" class="oa-input oa-mono" inputmode="numeric" placeholder="automatisch" [value]="uid()" (input)="uid.set($any($event.target).value)" />
                </div>
                <div class="oa-field">
                  <label class="oa-label" for="ah-gid">PGID (Dateirechte)</label>
                  <input id="ah-gid" class="oa-input oa-mono" inputmode="numeric" placeholder="automatisch" [value]="gid()" (input)="gid.set($any($event.target).value)" />
                </div>
              </div>
              <div class="oa-callout" data-tone="info">
                <oa-icon name="info" [size]="15" />
                <span>Die Docker-Socket-Gruppe wird beim Start automatisch erkannt. Sie ist unabhängig von PUID/PGID, die nur Dateirechte im Projektverzeichnis steuern.</span>
              </div>
            </div>
          }

          <div class="oa-ah-check">
            <div class="oa-row">
              <strong class="oa-small">Rechte &amp; Verbindung</strong>
              <span class="oa-sp"></span>
              <button type="button" class="oa-btn" data-tone="accent" (click)="runCheck()" [disabled]="checking()">
                <oa-icon [name]="checking() ? 'loader' : 'shield'" [size]="14" [class.oa-spin]="checking()" /> Prüfen (simuliert)
              </button>
            </div>
            @if (steps().length) {
              <ul class="oa-ah-steps" aria-live="polite">
                @for (s of steps(); track s.label) {
                  <li [attr.data-state]="s.state">
                    <oa-icon [name]="s.state === 'ok' ? 'circleCheck' : s.state === 'warn' ? 'alert' : s.state === 'run' ? 'loader' : 'clock'" [size]="15" [class.oa-spin]="s.state === 'run'" />
                    <span class="oa-sp"><strong>{{ s.label }}</strong> <span class="oa-dim">{{ s.detail }}</span></span>
                  </li>
                }
              </ul>
              @if (suggest()) {
                <div class="oa-row oa-small" style="margin-top:8px">
                  <span class="oa-sp">Vorschlag: PUID/PGID 1000:1000 für {{ projectDir() }}</span>
                  <button type="button" class="oa-btn" (click)="applySuggestion()">Übernehmen</button>
                </div>
              }
            }
          </div>
        </div>

        <div class="oa-ah-out">
          <div class="oa-tabs" role="tablist" aria-label="Installationsart">
            <button type="button" role="tab" class="oa-tab" id="ah-t1" aria-controls="ah-p" [attr.aria-selected]="out() === 'compose'" (click)="out.set('compose')"><oa-icon name="fileCode" [size]="14" /> compose.yaml</button>
            <button type="button" role="tab" class="oa-tab" id="ah-t2" aria-controls="ah-p" [attr.aria-selected]="out() === 'installer'" (click)="out.set('installer')"><oa-icon name="terminal" [size]="14" /> Installer</button>
          </div>
          <div id="ah-p" role="tabpanel" [attr.aria-labelledby]="out() === 'compose' ? 'ah-t1' : 'ah-t2'">
            @if (out() === 'compose') {
              <pre class="oa-code oa-ah-pre">{{ compose() }}</pre>
              <div class="oa-row" style="margin-top:10px">
                <button z-button zType="outline" zSize="sm" type="button" (click)="download()"><oa-icon name="download" [size]="14" /> Herunterladen</button>
                <button z-button zType="ghost" zSize="sm" type="button" (click)="copy(compose(), 'Compose-Datei')"><oa-icon name="copy" [size]="14" /> Kopieren</button>
              </div>
            } @else {
              <pre class="oa-code oa-ah-pre oa-ah-cmd">{{ installer() }}</pre>
              <div class="oa-row" style="margin-top:10px">
                <button z-button zType="outline" zSize="sm" type="button" (click)="copy(installer(), 'Installer-Befehl')"><oa-icon name="copy" [size]="14" /> Befehl kopieren</button>
              </div>
              <p class="oa-help" style="margin-top:8px">Der Installer prüft Verzeichnisrechte und schlägt PUID/PGID vor. Der Token ist ein Platzhalter.</p>
            }
          </div>
        </div>
      </div>

      <div dlgFooter class="oa-row">
        @if (!checked()) {
          <span class="oa-small oa-dim">Tipp: vorher Rechte &amp; Verbindung prüfen</span>
        }
        <button z-button zType="ghost" type="button" (click)="closed.emit()">Abbrechen</button>
        <button z-button type="button" [zDisabled]="!name().trim()" (click)="add()"><oa-icon name="plus" [size]="14" /> Host hinzufügen</button>
      </div>
    </oa-dialog>
  `,
  styles: `
    .oa-ah{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:18px}
    @media (max-width:820px){.oa-ah{grid-template-columns:1fr}}
    .oa-ah-form{display:flex;flex-direction:column;gap:14px}
    .oa-ah-modes{display:grid;grid-template-columns:1fr 1fr;gap:8px}
    @media (max-width:480px){.oa-ah-modes{grid-template-columns:1fr}}
    .oa-ah-mode{display:flex;gap:10px;align-items:flex-start;padding:12px;border-radius:12px;border:1px solid var(--oa-line2);background:rgb(255 255 255/.02);color:var(--oa-fg);text-align:left;cursor:pointer;transition:all .15s}
    .oa-ah-mode:hover{border-color:rgb(255 255 255/.22)}
    .oa-ah-mode[aria-checked=true]{border-color:var(--oa-accent);background:var(--oa-accent-soft);box-shadow:0 0 0 3px rgb(139 124 246/.15)}
    .oa-ah-mode small{display:block;color:var(--oa-muted);font-size:12px;margin-top:3px}
    .oa-swatch{width:26px;height:26px;border-radius:8px;border:2px solid transparent;cursor:pointer}
    .oa-swatch[aria-checked=true]{border-color:#fff;box-shadow:0 0 0 2px var(--oa-accent)}
    .oa-ah-adv{display:inline-flex;align-items:center;gap:6px;align-self:flex-start;border:0;background:none;color:var(--oa-muted);font-size:13px;font-weight:500;cursor:pointer;padding:2px 0}
    .oa-ah-adv:hover{color:var(--oa-fg)}
    .oa-ah-advbox{display:flex;flex-direction:column;gap:12px;padding:12px;border-radius:12px;border:1px solid var(--oa-line);background:rgb(0 0 0/.18)}
    .oa-ah-check{padding:12px;border-radius:12px;border:1px solid var(--oa-line);background:rgb(255 255 255/.02)}
    .oa-ah-steps{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column;gap:7px;font-size:12.5px}
    .oa-ah-steps li{display:flex;gap:8px;align-items:flex-start;color:var(--oa-muted)}
    .oa-ah-steps li[data-state=ok] oa-icon{color:#4ade80}
    .oa-ah-steps li[data-state=warn] oa-icon{color:#fbbf24}
    .oa-ah-steps li[data-state=run] oa-icon{color:var(--oa-accent-fg)}
    .oa-ah-out{min-width:0}
    .oa-ah-pre{margin-top:12px;max-height:380px;font-size:11.5px}
    .oa-ah-cmd{white-space:pre-wrap;word-break:break-all}
  `,
})
export class AddHostDialogComponent implements OnDestroy {
  private readonly store = inject(ArcaneStore);
  readonly closed = output<void>();
  protected readonly colors = COLORS;
  protected readonly mode = signal<HostMode>('direct');
  protected readonly name = signal('');
  protected readonly touched = signal(false);
  protected readonly color = signal(COLORS[0].value);
  protected readonly address = signal('delta.example.com:3552');
  protected readonly projectDir = signal('/opt/stacks');
  protected readonly installDir = signal('/opt/docklet-agent');
  protected readonly advanced = signal(false);
  protected readonly uid = signal('');
  protected readonly gid = signal('');
  protected readonly out = signal<'compose' | 'installer'>('compose');
  protected readonly steps = signal<CheckStep[]>([]);
  protected readonly checking = signal(false);
  protected readonly checked = signal(false);
  protected readonly suggest = signal(false);
  private readonly timers: ReturnType<typeof setTimeout>[] = [];

  protected readonly compose = computed(() => {
    const edge = this.mode() === 'edge';
    const env = [
      `      DOCKLET_MODE: ${edge ? 'edge' : 'direct'}`,
      ...(edge ? ['      DOCKLET_HUB_URL: wss://hub.example.com/edge'] : []),
      '      DOCKLET_TOKEN: <EINMAL-TOKEN>   # Platzhalter, kein echter Schlüssel',
      `      DOCKLET_PROJECT_DIR: ${this.projectDir()}`,
      ...(this.uid().trim() ? [`      PUID: "${this.uid().trim()}"`] : []),
      ...(this.gid().trim() ? [`      PGID: "${this.gid().trim()}"`] : []),
    ];
    return [
      `# Docklet-Agent für ${this.name().trim() || '<Hostname>'} (${edge ? 'Edge' : 'Direkt'})`,
      `# Ablage: ${this.installDir()}/compose.yaml`,
      'services:',
      '  docklet-agent:',
      '    image: ghcr.io/example/docklet-agent:0.9.2',
      '    container_name: docklet-agent',
      '    restart: unless-stopped',
      '    environment:',
      ...env,
      ...(edge ? [] : ['    ports:', '      - "3552:3552"']),
      '    volumes:',
      '      - /var/run/docker.sock:/var/run/docker.sock',
      `      - ${this.projectDir()}:${this.projectDir()}`,
      `      - ${this.installDir()}/data:/data`,
      '    # Socket-Gruppe wird beim Start automatisch erkannt (group_add)',
      '',
    ].join('\n');
  });

  protected readonly installer = computed(() => {
    const parts = [
      'curl -fsSL https://get.example.com/docklet-agent.sh | sudo sh -s --',
      `  --mode ${this.mode()}`,
      ...(this.mode() === 'edge' ? ['  --hub wss://hub.example.com/edge'] : ['  --port 3552']),
      `  --project-dir ${this.projectDir()}`,
      `  --install-dir ${this.installDir()}`,
      ...(this.uid().trim() ? [`  --puid ${this.uid().trim()}`] : []),
      ...(this.gid().trim() ? [`  --pgid ${this.gid().trim()}`] : []),
      '  --token <EINMAL-TOKEN>',
    ];
    return parts.join(' \\\n');
  });

  ngOnDestroy(): void {
    this.timers.forEach((t) => clearTimeout(t));
  }

  protected setMode(m: HostMode): void {
    this.mode.set(m);
    this.steps.set([]);
    this.checked.set(false);
    this.suggest.set(false);
  }

  protected runCheck(): void {
    const edge = this.mode() === 'edge';
    const plan: CheckStep[] = [
      { label: 'Docker-Socket gefunden', detail: 'Gruppe 998 automatisch erkannt', state: 'wait' },
      {
        label: 'Projektverzeichnis',
        detail: this.uid().trim() ? `${this.projectDir()} beschreibbar für ${this.uid()}:${this.gid() || this.uid()}` : `${this.projectDir()} gehört 1000:1000`,
        state: 'wait',
      },
      { label: 'Installationsverzeichnis', detail: `${this.installDir()} wird angelegt`, state: 'wait' },
      { label: edge ? 'Edge-Tunnel zum Hub' : 'Agent erreichbar', detail: edge ? 'ausgehend über 443 (simuliert)' : `${this.address()} antwortet (simuliert)`, state: 'wait' },
    ];
    this.steps.set(plan);
    this.checking.set(true);
    this.suggest.set(false);
    plan.forEach((_, i) => {
      this.timers.push(
        setTimeout(() => {
          this.steps.update((s) => s.map((x, j) => (j === i ? { ...x, state: 'run' } : x)));
        }, 450 * i + 50),
      );
      this.timers.push(
        setTimeout(() => {
          const warn = i === 1 && !this.uid().trim();
          this.steps.update((s) => s.map((x, j) => (j === i ? { ...x, state: warn ? 'warn' : 'ok' } : x)));
          if (warn) this.suggest.set(true);
          if (i === plan.length - 1) {
            this.checking.set(false);
            this.checked.set(true);
          }
        }, 450 * i + 400),
      );
    });
  }

  protected applySuggestion(): void {
    this.uid.set('1000');
    this.gid.set('1000');
    this.advanced.set(true);
    this.suggest.set(false);
    this.steps.update((s) => s.map((x, j) => (j === 1 ? { ...x, state: 'ok', detail: `${this.projectDir()} beschreibbar für 1000:1000` } : x)));
  }

  protected download(): void {
    const blob = new Blob([this.compose()], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `docklet-agent-${(this.name().trim() || 'host').toLowerCase()}.yaml`;
    a.click();
    this.timers.push(setTimeout(() => URL.revokeObjectURL(url), 1000));
    this.store.showToast('compose.yaml lokal erzeugt und heruntergeladen');
  }

  protected copy(text: string, what: string): void {
    const clip = typeof navigator !== 'undefined' ? navigator.clipboard : undefined;
    if (!clip) {
      this.store.showToast('Kopieren nicht verfügbar – Text bitte markieren');
      return;
    }
    clip.writeText(text).then(
      () => this.store.showToast(`${what} kopiert`),
      () => this.store.showToast('Kopieren nicht erlaubt – Text bitte markieren'),
    );
  }

  protected add(): void {
    const n = this.name().trim();
    if (!n) {
      this.touched.set(true);
      return;
    }
    const edge = this.mode() === 'edge';
    this.store.addHost({
      id: n.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Date.now().toString(36).slice(-4),
      name: n,
      color: this.color(),
      colorName: COLORS.find((c) => c.value === this.color())?.name ?? '',
      status: 'online',
      cpu: 6,
      mem: 18,
      memTotal: '8 GB',
      disk: 22,
      diskTotal: '500 GB',
      address: edge ? 'hub.example.com (Edge)' : this.address(),
      mode: this.mode(),
      agent: 'v0.9.2',
      projectDir: this.projectDir(),
      os: 'Linux · Docker 27 (simuliert)',
      lastSeen: 'gerade eben',
      cpuHistory: [4, 5, 6, 5, 7, 6, 5, 6, 8, 6, 5, 6, 7, 6, 5, 6],
    });
    this.store.showToast(`Host ${n} hinzugefügt (simuliert)`);
    this.closed.emit();
  }
}
