import { ChangeDetectionStrategy, Component, computed, inject, output, signal, ViewEncapsulation } from '@angular/core';
import { stringify } from 'yaml';

import { ZardButtonComponent } from '../../shared/components/button';
import { convertDockerRun, ImportResult, ops, simulateImport, uniqueKey } from './compose';
import { DialogComponent } from './dialog.component';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const SAMPLE = `docker run -d --name uptime \\
  -p 3001:3001 \\
  -v uptime_data:/app/data \\
  -e TZ=Europe/Berlin \\
  --restart unless-stopped \\
  louislam/uptime-kuma:1`;

const IMP_STYLES = `
  .oa-imp-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
  @media (max-width:760px){.oa-imp-grid{grid-template-columns:1fr}}
  .oa-imp-pre{max-height:260px;min-height:120px}
  .oa-imp-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px;font-size:13px}
  .oa-imp-list li{display:flex;gap:8px;align-items:flex-start}
  .oa-imp-ok{color:#4ade80}
  .oa-imp-miss{color:#fbbf24}
  .oa-imp-ex{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
`;

/** Easy-Button: docker run → Compose-Service */
@Component({
  selector: 'oa-dockerrun-dialog',
  imports: [ZardButtonComponent, IconComponent, DialogComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-dialog
      heading="docker run konvertieren"
      description="Einen docker-run-Befehl einfügen. Erkannte Werte werden als neuer Service in den gleichen Entwurf übernommen."
      icon="wand"
      [wide]="true"
      (closed)="closed.emit()"
    >
      <div class="oa-imp-grid">
        <div class="oa-field">
          <div class="oa-row">
            <label class="oa-label" for="dr-in">Befehl</label>
            <span class="oa-sp"></span>
            <button type="button" class="oa-btn" (click)="cmd.set(sample)">Beispiel einfügen</button>
          </div>
          <textarea id="dr-in" class="oa-textarea oa-mono" rows="9" spellcheck="false" placeholder="docker run -d --name … image:tag" [value]="cmd()" (input)="cmd.set($any($event.target).value)"></textarea>
          <span class="oa-help">Unterstützt u. a. --name, -p, -v, -e, --restart, --network, -l, --health-cmd. Nichts wird ausgeführt.</span>
        </div>
        <div class="oa-field">
          <span class="oa-label">Vorschau</span>
          @if (result(); as r) {
            @if (r.ok) {
              <pre class="oa-code oa-imp-pre">{{ r.yaml }}</pre>
              @for (h of r.hints; track h) {
                <span class="oa-warntxt"><oa-icon name="info" [size]="13" /> {{ h }}</span>
              }
            } @else {
              <div class="oa-callout" data-tone="err"><oa-icon name="alert" [size]="15" /> {{ r.error }}</div>
            }
          } @else {
            <div class="oa-callout"><oa-icon name="info" [size]="15" /> Noch kein Befehl eingegeben.</div>
          }
        </div>
      </div>
      <div dlgFooter class="oa-row">
        <button z-button zType="ghost" type="button" (click)="closed.emit()">Abbrechen</button>
        <button z-button type="button" [zDisabled]="!result()?.ok" (click)="apply()"><oa-icon name="plus" [size]="14" /> Als Service übernehmen</button>
      </div>
    </oa-dialog>
  `,
  styles: IMP_STYLES,
})
export class DockerRunDialogComponent {
  private readonly store = inject(ArcaneStore);
  readonly closed = output<void>();
  protected readonly sample = SAMPLE;
  protected readonly cmd = signal('');

  protected readonly result = computed(() => {
    const c = this.cmd().trim();
    if (!c) return null;
    try {
      const existing = this.store.model()?.services.map((s) => s.key) ?? [];
      const conv = convertDockerRun(c, existing);
      return { ok: true as const, conv, yaml: stringify({ [conv.key]: conv.body }), hints: conv.hints, error: '' };
    } catch (e) {
      return { ok: false as const, conv: null, yaml: '', hints: [] as string[], error: e instanceof Error ? e.message : String(e) };
    }
  });

  protected apply(): void {
    const r = this.result();
    if (!r || !r.ok) return;
    if (this.store.edit(ops.addService(r.conv.key, r.conv.body))) {
      this.store.editorStep.set(2);
      this.store.editorService.set(r.conv.key);
      this.store.editorSub.set('image');
      this.store.showToast(`Service „${r.conv.key}“ aus docker run übernommen`);
      this.closed.emit();
    }
  }
}

/** Easy-Button: einmaliger Import aus Docker Hub oder GitHub (simuliert) */
@Component({
  selector: 'oa-import-dialog',
  imports: [ZardButtonComponent, IconComponent, DialogComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-dialog
      heading="Einmalig importieren"
      description="Werte aus Docker Hub oder einem GitHub-Repository übernehmen. Keine dauerhafte Verbindung, kein Git Sync."
      icon="download"
      [wide]="true"
      (closed)="closed.emit()"
    >
      <div class="oa-seg" role="radiogroup" aria-label="Quelle" style="margin-bottom:12px">
        <button type="button" role="radio" [attr.aria-checked]="kind() === 'dockerhub'" (click)="setKind('dockerhub')"><oa-icon name="package" [size]="14" /> Docker Hub</button>
        <button type="button" role="radio" [attr.aria-checked]="kind() === 'github'" (click)="setKind('github')"><oa-icon name="git" [size]="14" /> GitHub</button>
      </div>
      <form class="oa-field" (submit)="lookup($event)">
        <label class="oa-label" for="imp-ref">{{ kind() === 'github' ? 'Repository' : 'Image' }}</label>
        <div class="oa-row" style="flex-wrap:nowrap">
          <input id="imp-ref" class="oa-input oa-mono" [placeholder]="kind() === 'github' ? 'github.com/example/notes-app' : 'traefik/whoami'" [value]="ref()" (input)="ref.set($any($event.target).value)" />
          <button z-button zType="outline" type="submit"><oa-icon name="search" [size]="14" /> Abrufen</button>
        </div>
        <div class="oa-imp-ex">
          <span class="oa-small oa-dim">Beispiele:</span>
          @for (ex of examples(); track ex) {
            <button type="button" class="oa-chip" (click)="ref.set(ex); lookup()">{{ ex }}</button>
          }
        </div>
      </form>

      @if (error()) {
        <div class="oa-callout" data-tone="err" style="margin-top:12px"><oa-icon name="alert" [size]="15" /> {{ error() }}</div>
      }
      @if (res(); as r) {
        <div class="oa-imp-grid" style="margin-top:14px">
          <div>
            <h3 class="oa-section-title" style="margin-top:0">{{ r.title }}</h3>
            <ul class="oa-imp-list">
              @for (f of r.found; track f) {
                <li><oa-icon name="circleCheck" [size]="15" class="oa-imp-ok" /> {{ f }}</li>
              }
              @for (f of r.missing; track f) {
                <li><oa-icon name="alert" [size]="15" class="oa-imp-miss" /> {{ f }}</li>
              }
            </ul>
            <p class="oa-help" style="margin-top:10px">Simulierter Abruf – es findet keine Netzwerkanfrage statt. Fehlende Werte bleiben leer und werden im Wizard als Pflichtfeld markiert.</p>
          </div>
          <pre class="oa-code oa-imp-pre">{{ preview() }}</pre>
        </div>
      }
      <div dlgFooter class="oa-row">
        <button z-button zType="ghost" type="button" (click)="closed.emit()">Abbrechen</button>
        <button z-button type="button" [zDisabled]="!res()" (click)="apply()">In Entwurf übernehmen</button>
      </div>
    </oa-dialog>
  `,
  styles: IMP_STYLES,
})
export class ImportDialogComponent {
  private readonly store = inject(ArcaneStore);
  readonly closed = output<void>();
  protected readonly kind = signal<'dockerhub' | 'github'>('dockerhub');
  protected readonly ref = signal('');
  protected readonly res = signal<ImportResult | null>(null);
  protected readonly error = signal('');
  protected readonly examples = computed(() =>
    this.kind() === 'github' ? ['github.com/example/notes-app', 'github.com/example/tools'] : ['traefik/whoami', 'linuxserver/syncthing', 'example/app:2.1'],
  );
  protected readonly preview = computed(() => {
    const r = this.res();
    if (!r) return '';
    const obj: Record<string, unknown> = {};
    for (const s of r.services) obj[s.key] = s.body;
    return stringify({ services: obj });
  });

  protected setKind(k: 'dockerhub' | 'github'): void {
    this.kind.set(k);
    this.res.set(null);
    this.error.set('');
    this.ref.set('');
  }

  protected lookup(e?: Event): void {
    e?.preventDefault();
    try {
      this.res.set(simulateImport(this.kind(), this.ref()));
      this.error.set('');
    } catch (err) {
      this.res.set(null);
      this.error.set(err instanceof Error ? err.message : String(err));
    }
  }

  protected apply(): void {
    const r = this.res();
    if (!r) return;
    const keys = [...(this.store.model()?.services.map((s) => s.key) ?? [])];
    let first = '';
    const ok = this.store.edit((doc) => {
      for (const s of r.services) {
        const key = uniqueKey(keys, s.key);
        keys.push(key);
        if (!first) first = key;
        ops.addService(key, s.body)(doc);
      }
    });
    if (ok) {
      this.store.editorStep.set(2);
      this.store.editorService.set(first);
      this.store.editorSub.set('image');
      this.store.showToast(`${r.services.length} Service(s) importiert – fehlende Werte prüfen`);
      this.closed.emit();
    }
  }
}
