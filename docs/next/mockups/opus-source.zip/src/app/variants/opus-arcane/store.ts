import { computed, Injectable, OnDestroy, signal } from '@angular/core';

import { ComposeModel, mutate, Mutator, parseCompose } from './compose';
import {
  ActionItem,
  ActionStep,
  AutoUpdate,
  DEFAULT_HUB,
  DEFAULT_WIDGETS,
  EventItem,
  Host,
  HOSTS,
  HubSettings,
  LIVE_MESSAGES,
  LogLine,
  LOGS,
  NEW_DRAFT,
  Origin,
  PageId,
  Profile,
  SCAN_HISTORY,
  SCAN_IMAGES,
  ScanImage,
  ScanRun,
  SEED_ACTIONS,
  SEED_EVENTS,
  Service,
  Stack,
  STACKS,
  Standalone,
  STANDALONE,
  WidgetCfg,
  WidgetId,
} from './data';

export type StackTab = 'services' | 'editor' | 'logs' | 'files' | 'updates' | 'backup';
export type SubStep = 'image' | 'ports' | 'mounts' | 'env' | 'health';
export type ViewMode = 'easy' | 'full';

export interface StepDef {
  label: string;
  detail?: string;
}

export interface RunOptions {
  title: string;
  target: string;
  steps: StepDef[];
  services?: string[];
  failAt?: number;
  failMsg?: string;
  onDone?: () => void;
}

export interface Toast {
  id: number;
  text: string;
  tone: 'info' | 'ok' | 'err';
  actionId?: number;
}

/** Lokaler Zustand der Arcane-Variante. Alle Aktionen sind simuliert. */
@Injectable()
export class ArcaneStore implements OnDestroy {
  readonly page = signal<PageId>('dashboard');
  readonly hosts = signal<Host[]>(HOSTS.map((h) => ({ ...h, cpuHistory: [...h.cpuHistory] })));
  readonly stacks = signal<Stack[]>(STACKS.map((s) => ({ ...s, labels: [...s.labels], services: s.services.map((x) => ({ ...x })) })));
  readonly standalone = signal<Standalone[]>(STANDALONE.map((c) => ({ ...c })));
  readonly widgets = signal<WidgetCfg[]>(DEFAULT_WIDGETS.map((w) => ({ ...w })));
  readonly actions = signal<ActionItem[]>(SEED_ACTIONS.map((a) => ({ ...a, log: [...a.log], steps: a.steps.map((s) => ({ ...s })) })));
  readonly events = signal<EventItem[]>([...SEED_EVENTS]);
  readonly toasts = signal<Toast[]>([]);
  readonly drawerOpen = signal(false);
  readonly focusAction = signal<number | null>(null);
  readonly filesTarget = signal<string>('media_config');
  readonly resourcesTab = signal<'images' | 'volumes' | 'files'>('images');
  readonly autoHeal = signal(true);
  readonly viewMode = signal<ViewMode>('easy');
  readonly live = signal(true);
  readonly loggedOut = signal(false);
  readonly settingsSection = signal<string>('auth');
  readonly hub = signal<HubSettings>(structuredClone(DEFAULT_HUB));
  readonly profile = signal<Profile>({ name: 'Alex Beispiel', email: 'alex@example.com', lang: 'de', theme: 'dark', animations: true });

  /* Sicherheit */
  readonly scanEnabled = signal(true);
  readonly scanImages = signal<ScanImage[]>(SCAN_IMAGES.map((i) => ({ ...i })));
  readonly scanHistory = signal<ScanRun[]>([...SCAN_HISTORY]);
  readonly scanRunning = signal(false);

  /* Globaler Hostfilter: leer = alle Hosts */
  readonly hostSel = signal<string[]>([]);

  /* Stack-Seite */
  readonly selectedStackId = signal<string | null>(null);
  readonly draft = signal(false);
  readonly stackTab = signal<StackTab>('services');
  readonly logs = signal<Record<string, LogLine[]>>(structuredClone(LOGS));

  /* Editor: Rohtext ist die einzige Quelle */
  readonly editorText = signal(NEW_DRAFT);
  readonly editorEnv = signal('TZ=Europe/Berlin\n');
  readonly editorHost = signal('atlas');
  readonly editorLabels = signal<string[]>([]);
  readonly editorStackId = signal<string | null>(null);
  readonly editorMode = signal<'easy' | 'advanced'>('easy');
  readonly editorFile = signal<'compose' | 'env'>('compose');
  readonly parsed = computed(() => parseCompose(this.editorText()));
  private lastValid: ComposeModel | null = null;
  readonly model = computed(() => {
    const m = this.parsed().model;
    if (m) this.lastValid = m;
    return m;
  });
  readonly lastValidModel = computed(() => this.model() ?? this.lastValid);
  readonly editorStep = signal<1 | 2 | 3>(1);
  readonly editorService = signal<string | null>(null);
  readonly editorSub = signal<SubStep>('image');

  private nextId = 100;
  private readonly timers = new Set<ReturnType<typeof setTimeout>>();
  private readonly liveTimer: ReturnType<typeof setInterval>;

  constructor() {
    this.liveTimer = setInterval(() => this.tick(), 2500);
  }

  ngOnDestroy(): void {
    clearInterval(this.liveTimer);
    this.timers.forEach((t) => clearTimeout(t));
    this.timers.clear();
  }

  /* ---------- Abgeleitete Werte ---------- */

  readonly hostMap = computed(() => {
    const m: Record<string, Host> = {};
    for (const h of this.hosts()) m[h.id] = h;
    return m;
  });

  host(id: string): Host | undefined {
    return this.hostMap()[id];
  }

  hc(id: string): string {
    return this.hostMap()[id]?.color ?? '#71717a';
  }

  hn(id: string): string {
    return this.hostMap()[id]?.name ?? id;
  }

  hostOn(id: string): boolean {
    const s = this.hostSel();
    return s.length === 0 || s.includes(id);
  }

  readonly allHosts = computed(() => this.hostSel().length === 0);
  readonly visibleHosts = computed(() => this.hosts().filter((h) => this.hostOn(h.id)));
  readonly visibleStacks = computed(() => this.stacks().filter((s) => this.hostOn(s.hostId)));
  readonly visibleStandalone = computed(() => this.standalone().filter((c) => this.hostOn(c.hostId)));
  readonly agentCount = computed(() => this.hosts().filter((h) => h.status === 'online').length);
  readonly offlineHosts = computed(() => this.visibleHosts().filter((h) => h.status === 'offline'));

  readonly runningCount = computed(() => {
    let n = this.visibleHosts().filter((h) => h.status === 'online').length;
    for (const s of this.visibleStacks()) n += s.services.filter((x) => x.state === 'running').length;
    n += this.visibleStandalone().filter((c) => c.state === 'running').length;
    return n;
  });

  readonly updates = computed(() => {
    const out: { stack: Stack; svc: Service }[] = [];
    for (const s of this.visibleStacks()) for (const svc of s.services) if (svc.updateTo) out.push({ stack: s, svc });
    return out;
  });

  readonly problems = computed(() => {
    const out: { stack: Stack; svc: Service }[] = [];
    for (const s of this.visibleStacks()) for (const svc of s.services) if (svc.health === 'unhealthy') out.push({ stack: s, svc });
    return out;
  });

  readonly allLabels = computed(() => {
    const set = new Set<string>();
    for (const s of this.stacks()) s.labels.forEach((l) => set.add(l));
    this.editorLabels().forEach((l) => set.add(l));
    return [...set].sort();
  });

  readonly runningActions = computed(() => this.actions().filter((a) => a.status === 'running').length);
  readonly selectedStack = computed(() => this.stacks().find((s) => s.id === this.selectedStackId()) ?? null);

  readonly editorDirty = computed(() => {
    const s = this.selectedStack();
    if (!s || this.draft()) return true;
    return this.editorText() !== s.compose || this.editorEnv() !== s.env;
  });

  readonly scanTotals = computed(() => {
    const t = { critical: 0, high: 0, medium: 0, low: 0 };
    for (const i of this.scanImages()) {
      if (!this.hostOn(i.hostId)) continue;
      t.critical += i.critical;
      t.high += i.high;
      t.medium += i.medium;
      t.low += i.low;
    }
    return t;
  });

  /* ---------- Hilfen ---------- */

  private later(fn: () => void, ms: number): void {
    const t = setTimeout(() => {
      this.timers.delete(t);
      fn();
    }, ms);
    this.timers.add(t);
  }

  now(withSeconds = false): string {
    const d = new Date();
    const p = (n: number) => String(n).padStart(2, '0');
    return `${p(d.getHours())}:${p(d.getMinutes())}${withSeconds ? ':' + p(d.getSeconds()) : ''}`;
  }

  private jitter(v: number, spread: number, min = 1, max = 98): number {
    return Math.max(min, Math.min(max, Math.round(v + (Math.random() - 0.5) * spread)));
  }

  /** Simulierte Live-Werte: CPU/RAM je Host und Service, neue Logzeilen. Keine Messung. */
  private tick(): void {
    if (!this.live()) return;
    this.hosts.update((hs) =>
      hs.map((h) => {
        if (h.status !== 'online') return h;
        const cpu = this.jitter(h.cpu, 10, 5, 95);
        return { ...h, cpu, mem: this.jitter(h.mem, 3, 10, 95), cpuHistory: [...h.cpuHistory.slice(1), cpu] };
      }),
    );
    this.stacks.update((ss) =>
      ss.map((s) => ({
        ...s,
        services: s.services.map((x) => (x.state === 'running' ? { ...x, cpu: this.jitter(x.cpu, 6, 0, 90) } : x)),
      })),
    );
    if (this.page() === 'stack' && this.stackTab() === 'logs') {
      const st = this.selectedStack();
      if (st && st.services.length) {
        const svc = st.services[Math.floor(Math.random() * st.services.length)];
        const msg = LIVE_MESSAGES[Math.floor(Math.random() * LIVE_MESSAGES.length)];
        this.appendLog(st.id, { t: this.now(true), svc: svc.name, level: 'info', msg });
      }
    }
  }

  appendLog(stackId: string, line: LogLine): void {
    this.logs.update((l) => ({ ...l, [stackId]: [...(l[stackId] ?? []), line].slice(-200) }));
  }

  clearLogs(stackId: string): void {
    this.logs.update((l) => ({ ...l, [stackId]: [] }));
  }

  /* ---------- Hostfilter ---------- */

  toggleHost(id: string): void {
    const all = this.hosts().map((h) => h.id);
    const cur = this.hostSel().length ? this.hostSel() : all;
    let next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    if (!next.length) {
      this.showToast('Mindestens ein Host bleibt ausgewählt');
      return;
    }
    if (all.every((x) => next.includes(x))) next = [];
    this.hostSel.set(next);
  }

  onlyHost(id: string): void {
    this.hostSel.set([id]);
  }

  /* ---------- Navigation ---------- */

  go(page: PageId): void {
    this.page.set(page);
  }

  openStack(id: string, tab: StackTab = 'services'): void {
    const s = this.stacks().find((x) => x.id === id);
    if (!s) return;
    if (this.editorStackId() !== id || this.draft()) this.loadEditor(s);
    this.draft.set(false);
    this.selectedStackId.set(id);
    this.stackTab.set(tab);
    this.page.set('stack');
  }

  editStack(id: string): void {
    this.openStack(id, 'editor');
  }

  private loadEditor(s: Stack): void {
    this.editorText.set(s.compose);
    this.editorEnv.set(s.env);
    this.editorHost.set(s.hostId);
    this.editorLabels.set([...s.labels]);
    this.editorStackId.set(s.id);
    this.editorMode.set('advanced');
    this.editorFile.set('compose');
    this.resetWizard();
  }

  private resetWizard(): void {
    this.editorStep.set(1);
    this.editorService.set(null);
    this.editorSub.set('image');
  }

  newStack(): void {
    this.editorText.set(NEW_DRAFT);
    this.editorEnv.set('TZ=Europe/Berlin\n');
    const firstOnline = this.hosts().find((h) => h.status === 'online' && this.hostOn(h.id)) ?? this.hosts()[0];
    this.editorHost.set(firstOnline?.id ?? 'atlas');
    this.editorLabels.set([]);
    this.editorStackId.set(null);
    this.editorMode.set('easy');
    this.editorFile.set('compose');
    this.resetWizard();
    this.selectedStackId.set(null);
    this.draft.set(true);
    this.stackTab.set('editor');
    this.page.set('stack');
  }

  openFiles(target: string): void {
    this.filesTarget.set(target);
    this.resourcesTab.set('files');
    this.page.set('resources');
  }

  openSettings(section: string): void {
    this.settingsSection.set(section);
    this.page.set('settings');
  }

  /* ---------- Toasts & Aktionszentrum ---------- */

  showToast(text: string, tone: Toast['tone'] = 'info'): void {
    const id = this.nextId++;
    this.toasts.update((t) => [...t, { id, text, tone }].slice(-4));
    this.later(() => this.dismissToast(id), 3800);
  }

  dismissToast(id: number): void {
    this.toasts.update((t) => t.filter((x) => x.id !== id));
  }

  openAction(id: number | null): void {
    this.focusAction.set(id);
    this.drawerOpen.set(true);
  }

  /* ---------- Editor ---------- */

  edit(fn: Mutator): boolean {
    try {
      this.editorText.set(mutate(this.editorText(), fn));
      return true;
    } catch (e) {
      this.showToast(e instanceof Error ? e.message : String(e), 'err');
      return false;
    }
  }

  setEditorLabels(labels: string[]): void {
    const clean = [...new Set(labels.map((l) => l.trim().toLowerCase()).filter((l) => !!l))];
    this.editorLabels.set(clean);
    const id = this.editorStackId();
    if (id && !this.draft()) this.patchStack(id, (s) => ({ ...s, labels: clean }));
  }

  setStackLabels(stackId: string, labels: string[]): void {
    this.patchStack(stackId, (s) => ({ ...s, labels }));
    if (this.editorStackId() === stackId) this.editorLabels.set([...labels]);
  }

  saveEditor(): void {
    const id = this.editorStackId();
    if (!id || this.draft()) {
      this.showToast('Entwurf lokal gespeichert – noch nicht deployt', 'ok');
      return;
    }
    const text = this.editorText();
    const env = this.editorEnv();
    this.patchStack(id, (s) => ({ ...s, compose: text, env }));
    this.showToast('compose.yaml und .env gespeichert – Änderungen wirken nach dem Deploy', 'ok');
  }

  resetEditor(): void {
    const s = this.selectedStack();
    if (s) this.loadEditor(s);
  }

  /* ---------- Widgets ---------- */

  toggleWidget(id: WidgetId): void {
    this.widgets.update((ws) => ws.map((w) => (w.id === id ? { ...w, visible: !w.visible } : w)));
  }

  moveWidget(id: WidgetId, dir: -1 | 1): void {
    this.widgets.update((ws) => {
      const i = ws.findIndex((w) => w.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= ws.length) return ws;
      const next = [...ws];
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  }

  resetWidgets(): void {
    this.widgets.set(DEFAULT_WIDGETS.map((w) => ({ ...w })));
  }

  /* ---------- Simulierte Aktionen ---------- */

  pushEvent(level: EventItem['level'], text: string, source: string): void {
    this.events.update((es) => [{ id: this.nextId++, time: this.now(), level, text, source }, ...es]);
  }

  /** Startet eine simulierte Aktion mit Ablaufschritten und zeigt ein Popup rechts oben. */
  run(o: RunOptions): number {
    const id = this.nextId++;
    const steps: ActionStep[] = o.steps.map((s, i): ActionStep => ({ label: s.label, detail: s.detail ?? '', state: i === 0 ? 'running' : 'pending' }));
    const item: ActionItem = {
      id,
      title: o.title,
      target: o.target,
      status: 'running',
      progress: 0,
      phase: steps[0]?.label ?? 'Start',
      steps,
      services: o.services ?? [],
      log: ['Gestartet (Simulation, keine Live-Aktion)'],
      started: this.now(),
    };
    this.actions.update((as) => [item, ...as]);
    this.toasts.update((t) => [...t, { id: this.nextId++, text: o.title, tone: 'info' as const, actionId: id }].slice(-4));
    const patch = (fn: (a: ActionItem) => ActionItem) => this.actions.update((as) => as.map((a) => (a.id === id ? fn(a) : a)));
    const n = o.steps.length;
    o.steps.forEach((step, i) => {
      this.later(() => {
        const cur = this.actions().find((a) => a.id === id);
        if (!cur || cur.status !== 'running') return;
        if (o.failAt === i) {
          const msg = o.failMsg ?? `${step.label} fehlgeschlagen`;
          patch((a) => ({
            ...a,
            status: 'error',
            phase: `${step.label} fehlgeschlagen`,
            steps: a.steps.map((s, k): ActionStep => (k === i ? { ...s, state: 'error', detail: msg } : s)),
            log: [...a.log, `Fehler: ${msg}`],
          }));
          this.pushEvent('error', `${o.title}: ${msg}`, o.target);
          return;
        }
        const done = i === n - 1;
        patch((a) => ({
          ...a,
          progress: Math.round(((i + 1) / n) * 100),
          status: done ? 'done' : 'running',
          phase: done ? 'Abgeschlossen' : (a.steps[i + 1]?.label ?? ''),
          steps: a.steps.map((s, k): ActionStep => (k === i ? { ...s, state: 'done' } : k === i + 1 ? { ...s, state: 'running' } : s)),
          log: [...a.log, `${step.label}${step.detail ? ': ' + step.detail : ''}`, ...(done ? ['Abgeschlossen'] : [])],
        }));
        if (done) {
          o.onDone?.();
          this.pushEvent('ok', `${o.title} abgeschlossen`, o.target);
          this.later(() => this.toasts.update((t) => t.filter((x) => x.actionId !== id)), 6000);
        }
      }, 800 * (i + 1));
    });
    return id;
  }

  clearFinished(): void {
    this.actions.update((as) => as.filter((a) => a.status === 'running'));
  }

  private deploySteps(stack: { services: { name: string; image: string }[] }, hostName: string, verb: string): StepDef[] {
    return [
      { label: 'Prüfung', detail: `Compose gültig, ${hostName} erreichbar` },
      { label: 'Image-Pull', detail: stack.services.map((s) => s.image || '(Image fehlt)').join(', ') },
      { label: verb === 'deploy' ? 'Erstellung' : 'Austausch', detail: `${stack.services.length} Container ${verb === 'deploy' ? 'erstellt' : 'ersetzt'}` },
      { label: 'Start', detail: stack.services.map((s) => s.name).join(', ') },
      { label: 'Zustandsprüfung', detail: 'Healthchecks bestanden' },
    ];
  }

  private patchStack(id: string, fn: (s: Stack) => Stack): void {
    this.stacks.update((ss) => ss.map((s) => (s.id === id ? fn(s) : s)));
  }

  private offlineFail(hostId: string): { failAt?: number; failMsg?: string } {
    const h = this.hostMap()[hostId];
    return h?.status === 'offline' ? { failAt: 0, failMsg: `${h.name} ist nicht verbunden` } : {};
  }

  installUpdates(stackId: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    const pending = s.services.filter((x) => x.updateTo);
    if (!pending.length) return;
    this.run({
      title: `Updates installieren · ${s.name}`,
      target: `${s.name} · ${this.hn(s.hostId)}`,
      services: pending.map((p) => p.name),
      steps: [
        { label: 'Prüfung', detail: 'Vorheriges Image und Konfiguration für manuelle Wiederherstellung gesichert' },
        { label: 'Image-Pull', detail: pending.map((p) => p.updateTo ?? '').join(', ') },
        { label: 'Austausch', detail: pending.map((p) => p.name).join(', ') + ' neu erstellt' },
        { label: 'Start', detail: 'Container gestartet' },
        { label: 'Zustandsprüfung', detail: 'Healthchecks bestanden' },
      ],
      onDone: () =>
        this.patchStack(stackId, (st) => {
          let compose = st.compose;
          const services = st.services.map((svc) => {
            if (!svc.updateTo) return svc;
            compose = compose.replace(svc.image, svc.updateTo);
            return { ...svc, previousImage: svc.image, image: svc.updateTo, updateTo: undefined };
          });
          return { ...st, services, compose, lastDeploy: 'gerade eben' };
        }),
    });
  }

  restoreImage(stackId: string, svcName: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    const svc = s?.services.find((x) => x.name === svcName);
    if (!s || !svc?.previousImage) return;
    const prev = svc.previousImage;
    this.run({
      title: `Wiederherstellung · ${svcName}`,
      target: s.name,
      services: [svcName],
      steps: [
        { label: 'Prüfung', detail: `Vorheriges Image ${prev} vorhanden` },
        { label: 'Austausch', detail: 'Vorherige Konfiguration eingespielt' },
        { label: 'Start', detail: svcName },
        { label: 'Zustandsprüfung', detail: 'Container läuft' },
      ],
      onDone: () =>
        this.patchStack(stackId, (st) => ({
          ...st,
          compose: st.compose.replace(svc.image, prev),
          services: st.services.map((x) => (x.name === svcName ? { ...x, image: prev, previousImage: undefined, updateTo: svc.image } : x)),
        })),
    });
  }

  restartService(stackId: string, svcName: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    this.patchStack(stackId, (st) => ({ ...st, services: st.services.map((x): Service => (x.name === svcName ? { ...x, state: 'restarting', health: x.health === 'none' ? 'none' : 'starting' } : x)) }));
    this.run({
      title: `Neustart · ${svcName}`,
      target: s.name,
      services: [svcName],
      steps: [{ label: 'Stopp', detail: 'SIGTERM gesendet' }, { label: 'Start', detail: 'Container gestartet' }, { label: 'Zustandsprüfung', detail: 'Healthcheck erfolgreich' }],
      onDone: () =>
        this.patchStack(stackId, (st) => ({ ...st, services: st.services.map((x): Service => (x.name === svcName ? { ...x, state: 'running', health: x.health === 'none' ? 'none' : 'healthy' } : x)) })),
    });
  }

  stackAction(stackId: string, action: 'start' | 'stop' | 'restart' | 'redeploy'): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    const names = s.services.map((x) => x.name);
    const fail = this.offlineFail(s.hostId);
    if (action === 'redeploy') {
      this.run({
        title: `Pull & Redeploy · ${s.name}`,
        target: `${s.name} · ${this.hn(s.hostId)}`,
        services: names,
        steps: this.deploySteps(s, this.hn(s.hostId), 'redeploy'),
        ...fail,
        onDone: () => this.patchStack(stackId, (st) => ({ ...st, lastDeploy: 'gerade eben', services: st.services.map((x): Service => ({ ...x, state: 'running' })) })),
      });
      return;
    }
    const label = action === 'start' ? 'Start' : action === 'stop' ? 'Stopp' : 'Neustart';
    const steps: StepDef[] =
      action === 'stop'
        ? [{ label: 'Stopp', detail: names.join(', ') }, { label: 'Abschluss', detail: 'Alle Container gestoppt' }]
        : [
            { label: 'Prüfung', detail: 'Konfiguration unverändert' },
            { label: 'Start', detail: names.join(', ') },
            { label: 'Zustandsprüfung', detail: 'Container laufen' },
          ];
    const state = action === 'stop' ? ('stopped' as const) : ('running' as const);
    this.run({
      title: `${label} · ${s.name}`,
      target: `${s.name} · ${this.hn(s.hostId)}`,
      services: names,
      steps,
      ...fail,
      onDone: () => this.patchStack(stackId, (st) => ({ ...st, services: st.services.map((x) => ({ ...x, state })) })),
    });
  }

  setAutoUpdate(stackId: string, mode: AutoUpdate): void {
    this.patchStack(stackId, (s) => ({ ...s, autoUpdate: mode }));
    const label = mode === 'check' ? 'nur prüfen' : mode === 'nightly' ? 'automatisch nachts' : 'automatisch wöchentlich';
    this.showToast(`Update-Modus: ${label}`, 'ok');
  }

  backupNow(stackId: string, target: string): void {
    const s = this.stacks().find((x) => x.id === stackId);
    if (!s) return;
    this.run({
      title: `Backup · ${s.name}`,
      target,
      services: s.services.map((x) => x.name),
      steps: [
        { label: 'Prüfung', detail: `Ziel ${target} erreichbar` },
        ...s.mounts.map((m) => ({ label: 'Sichern', detail: m.split(':')[0] })),
        { label: 'Aufbewahrung', detail: '7 täglich, 4 wöchentlich angewendet' },
      ],
      onDone: () => this.patchStack(stackId, (st) => ({ ...st, backupLast: `heute, ${this.now()}`, backupTarget: target })),
    });
  }

  setOrigin(id: string, origin: Origin): void {
    this.standalone.update((cs) => cs.map((c) => (c.id === id ? { ...c, origin } : c)));
    this.showToast('Zuordnung gespeichert (lokal)', 'ok');
  }

  standaloneAction(id: string, verb: 'Start' | 'Stopp' | 'Neustart' | 'Recreate'): void {
    const c = this.standalone().find((x) => x.id === id);
    if (!c) return;
    const steps: StepDef[] =
      verb === 'Recreate'
        ? [
            { label: 'Prüfung', detail: 'Aktuelle Konfiguration gelesen' },
            { label: 'Image-Pull', detail: c.image },
            { label: 'Austausch', detail: 'Alter Container entfernt, neuer erstellt' },
            { label: 'Start', detail: c.name },
            { label: 'Zustandsprüfung', detail: 'Container läuft' },
          ]
        : [{ label: verb, detail: `${verb} angefordert` }, { label: 'Zustandsprüfung', detail: verb === 'Stopp' ? 'Container gestoppt' : 'Container läuft' }];
    this.run({
      title: `${verb} · ${c.name}`,
      target: this.hn(c.hostId),
      services: [c.name.toLowerCase()],
      steps,
      onDone: () => this.standalone.update((cs) => cs.map((x): Standalone => (x.id === id ? { ...x, state: verb === 'Stopp' ? 'stopped' : 'running' } : x))),
    });
  }

  reconnect(hostId: string): void {
    const h = this.hostMap()[hostId];
    if (!h) return;
    this.run({
      title: `Verbindung prüfen · ${h.name}`,
      target: h.name,
      steps: [{ label: 'Edge-Tunnel', detail: 'Tunnel zum Hub prüfen' }, { label: 'Heartbeat', detail: 'Agent-Heartbeat abwarten' }, { label: 'Synchronisieren', detail: 'Status abgleichen' }],
      failAt: 1,
      failMsg: 'Kein Heartbeat von Cedar seit 2 Std. (simuliert) – Agent auf dem Host prüfen',
    });
  }

  addHost(h: Host): void {
    this.hosts.update((hs) => [...hs, h]);
    this.pushEvent('ok', `Host ${h.name} hinzugefügt (simuliert)`, h.name);
  }

  runScan(): void {
    if (this.scanRunning()) return;
    this.scanEnabled.set(true);
    this.scanRunning.set(true);
    const imgs = this.scanImages().filter((i) => this.hostMap()[i.hostId]?.status === 'online');
    this.run({
      title: 'Schwachstellenscan',
      target: `${imgs.length} Images`,
      steps: [
        { label: 'Datenbank', detail: 'Schwachstellendatenbank aktualisiert (simuliert)' },
        { label: 'Analyse', detail: imgs.map((i) => i.ref.split(':')[0]).join(', ') },
        { label: 'Ergebnis', detail: 'Befunde gespeichert' },
      ],
      onDone: () => {
        this.scanRunning.set(false);
        this.scanImages.update((is) => is.map((i) => ({ ...i, scanned: `heute ${this.now()}` })));
        const t = this.scanTotals();
        const d = new Date();
        this.scanHistory.update((h) => [...h.slice(-7), { when: `${d.getDate()}.${d.getMonth() + 1}. ${this.now()}`, kind: 'manuell', ...t }]);
      },
    });
  }

  bulk(ids: string[], action: 'start' | 'stop' | 'restart' | 'redeploy' | 'update'): void {
    for (const id of ids) {
      if (action === 'update') this.installUpdates(id);
      else this.stackAction(id, action);
    }
  }

  deployDraft(): void {
    const m = this.parsed().model;
    if (!m) return;
    const hostId = this.editorHost();
    const host = this.hostMap()[hostId];
    const existingId = this.draft() ? null : this.editorStackId();
    const text = this.editorText();
    const env = this.editorEnv();
    const labels = [...this.editorLabels()];
    const svcs = m.services.map((s) => ({ name: s.key, image: s.image }));
    this.run({
      title: `Deployment · ${m.name || 'Entwurf'}`,
      target: host?.name ?? '',
      services: svcs.map((s) => s.name),
      steps: [
        { label: 'Prüfung', detail: `compose.yaml nach ${host?.projectDir ?? '/opt/stacks'}/${m.name} schreiben` },
        ...this.deploySteps({ services: svcs }, host?.name ?? '', existingId ? 'redeploy' : 'deploy').slice(1),
      ],
      ...this.offlineFail(hostId),
      onDone: () => {
        const services: Service[] = m.services.map((s) => ({
          name: s.key,
          image: s.image,
          state: 'running',
          health: s.health.enabled ? 'healthy' : 'none',
          cpu: 2,
          mem: '64 MB',
          ports: s.ports.filter((p) => p.editable).map((p) => p.raw),
        }));
        const mounts = m.services.flatMap((s) => s.mounts.filter((x) => x.editable).map((x) => x.raw));
        if (existingId) {
          this.patchStack(existingId, (st) => ({ ...st, compose: text, env, services, mounts, labels, hostId, lastDeploy: 'gerade eben' }));
          return;
        }
        const id = `${m.name || 'stack'}-${this.nextId++}`;
        const name = m.name ? m.name.charAt(0).toUpperCase() + m.name.slice(1) : 'Neuer Stack';
        this.stacks.update((ss) => [
          ...ss,
          { id, name, hostId, description: 'Im Editor erstellt', labels, services, compose: text, env, autoUpdate: 'check', autoTime: '03:00', mounts, lastDeploy: 'gerade eben', backupLast: 'noch keins', backupTarget: 'Lokal · /mnt/backup/docklet' },
        ]);
        this.logs.update((l) => ({ ...l, [id]: services.map((s) => ({ t: this.now(true), svc: s.name, level: 'info' as const, msg: 'Container gestartet' })) }));
        if (this.page() === 'stack' && this.draft()) {
          this.editorStackId.set(id);
          this.selectedStackId.set(id);
          this.draft.set(false);
        }
      },
    });
  }
}
