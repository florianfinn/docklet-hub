import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { FINDINGS, ScanImage, Severity } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const SEV: { key: Severity; label: string; color: string; tone: string }[] = [
  { key: 'critical', label: 'Kritisch', color: 'var(--oa-err)', tone: 'err' },
  { key: 'high', label: 'Hoch', color: 'var(--oa-orange)', tone: 'orange' },
  { key: 'medium', label: 'Mittel', color: 'var(--oa-warn)', tone: 'warn' },
  { key: 'low', label: 'Niedrig', color: 'var(--oa-lime)', tone: 'lime' },
];

const TW = 520;
const TH = 150;

/**
 * Sicherheitsseite nach Arcanes Security-Übersicht: Risiko-Anzeige, Verlauf je Scan,
 * Verteilungsbalken, Kennzahlenleiste, Top-Befunde und Befunde je Image/Stack.
 * Scans sind optional (manuell oder geplant) und getrennt von der Update-Erkennung.
 */
@Component({
  selector: 'oa-security',
  imports: [ZardButtonComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Sicherheit</h1>
        <p>Schwachstellen in Images aller gefilterten Hosts. Optional – unabhängig von Image-Updates. Befunde sind synthetisch.</p>
      </div>
      <div class="oa-sp"></div>
      @if (store.scanEnabled()) {
        <button type="button" class="oa-btn" (click)="store.openSettings('scan')"><oa-icon name="clock" [size]="13" /> {{ scheduleLabel() }}</button>
      }
      <button z-button type="button" [zDisabled]="store.scanRunning()" (click)="store.runScan()">
        <oa-icon [name]="store.scanRunning() ? 'loader' : 'scan'" [size]="15" [class.oa-spin]="store.scanRunning()" /> {{ store.scanRunning() ? 'Scan läuft …' : 'Jetzt scannen' }}
      </button>
    </div>

    @if (!store.scanEnabled()) {
      <section class="oa-card oa-sec-off">
        <oa-icon name="shield" [size]="34" class="oa-muted" />
        <h2>Schwachstellenscans sind deaktiviert</h2>
        <p class="oa-muted">Scans laufen nur nach Aktivierung – manuell oder nach Zeitplan. Die Update-Erkennung ist davon unabhängig.</p>
        <div class="oa-row" style="justify-content:center">
          <button z-button type="button" (click)="store.runScan()">Aktivieren &amp; ersten Scan starten</button>
          <button z-button zType="outline" type="button" (click)="store.openSettings('scan')">Einstellungen</button>
        </div>
      </section>
    } @else {
      <div class="oa-tabs" role="tablist" aria-label="Sicherheitsbereiche" style="margin-bottom:6px">
        @for (t of tabs; track t.id) {
          <button type="button" role="tab" class="oa-tab" [attr.aria-selected]="tab() === t.id" (click)="tab.set(t.id)"><oa-icon [name]="t.icon" [size]="14" /> {{ t.label }}</button>
        }
      </div>

      @switch (tab()) {
        @case ('overview') {
          <section class="oa-sec-top">
            <div class="oa-sec-gauge">
              <svg viewBox="0 0 200 118" role="img" [attr.aria-label]="'Risikowert ' + risk().score + ' von 100, ' + risk().label">
                <path d="M20 104 A80 80 0 0 1 180 104" pathLength="100" class="oa-sec-track" />
                <path d="M20 104 A80 80 0 0 1 180 104" pathLength="100" class="oa-sec-val" [attr.stroke]="risk().color" [attr.stroke-dasharray]="risk().score + ' 100'" />
                <text x="100" y="92" text-anchor="middle" class="oa-sec-score">{{ risk().score }}</text>
                <text x="100" y="112" text-anchor="middle" class="oa-sec-band" [attr.fill]="risk().color">{{ risk().label }}</text>
              </svg>
              <p class="oa-small oa-muted">Patch-Priorität aus Schweregrad und Nutzung (laufende Images zählen voll)</p>
              @if (topFindings()[0]; as f) {
                <button type="button" class="oa-sec-driver" (click)="focusFinding(f.id)">
                  Treiber: <span class="oa-mono">{{ f.id }}</span> in {{ short(f.image) }}
                  <span class="oa-mono oa-small oa-muted">{{ f.pkg }} → {{ f.fixed }}</span>
                </button>
              }
            </div>
            <div class="oa-sec-right">
              <div class="oa-row">
                <h3 class="oa-sp">Befunde je Scan</h3>
                <span class="oa-small oa-muted">{{ store.scanHistory().length }} Scans · ▲ manuell</span>
              </div>
              <svg class="oa-sec-trend" [attr.viewBox]="'0 0 ' + tw + ' ' + (th + 22)" role="img" [attr.aria-label]="trendLabel()">
                @for (b of bars(); track $index) {
                  @for (seg of b.segs; track seg.key) {
                    <rect [attr.x]="b.x" [attr.y]="seg.y" [attr.width]="b.w" [attr.height]="seg.h" [attr.fill]="seg.color" rx="2"><title>{{ b.when }} · {{ seg.label }}: {{ seg.n }}</title></rect>
                  }
                  <text [attr.x]="b.x + b.w / 2" [attr.y]="th + 16" text-anchor="middle" class="oa-sec-ax">{{ b.when }}</text>
                  @if (b.manual) {
                    <text [attr.x]="b.x + b.w / 2" [attr.y]="b.top - 4" text-anchor="middle" class="oa-sec-ax">▲</text>
                  }
                }
              </svg>
              <div class="oa-grid2">
                <div>
                  <h4>Schweregrade</h4>
                  <div class="oa-share">
                    @for (s of sevShare(); track s.key) {
                      <span [style.flex-grow]="s.n" [style.background]="s.color" [title]="s.label + ': ' + s.n"></span>
                    }
                  </div>
                  <ul class="oa-share-l">
                    @for (s of sevShare(); track s.key) {
                      <li><i [style.background]="s.color"></i>{{ s.label }} <b>{{ s.n }}</b></li>
                    }
                  </ul>
                </div>
                <div>
                  <h4>Nutzung der betroffenen Images</h4>
                  <div class="oa-share">
                    @for (s of exposure(); track s.key) {
                      <span [style.flex-grow]="s.n" [style.background]="s.color" [title]="s.label + ': ' + s.n"></span>
                    }
                  </div>
                  <ul class="oa-share-l">
                    @for (s of exposure(); track s.key) {
                      <li><i [style.background]="s.color"></i>{{ s.label }} <b>{{ s.n }}</b></li>
                    }
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <dl class="oa-strip oa-sec-strip">
            <div><dt>Kritisch</dt><dd style="color:var(--oa-err)">{{ store.scanTotals().critical }}</dd></div>
            <div><dt>Hoch</dt><dd style="color:var(--oa-orange)">{{ store.scanTotals().high }}</dd></div>
            <div><dt>Mit Fix verfügbar</dt><dd>{{ fixable() }}<small>von {{ findings().length }} Top-Befunden</small></dd></div>
            <div><dt>Images gescannt</dt><dd>{{ images().length }}<small>{{ lastScan() }}</small></dd></div>
          </dl>

          <div class="oa-grid2 oa-sec-lists">
            <section>
              <h3>Wichtigste Befunde</h3>
              <ol class="oa-sec-ol">
                @for (f of topFindings(); track f.id; let i = $index) {
                  <li>
                    <button type="button" (click)="focusFinding(f.id)">
                      <span class="oa-muted oa-small">{{ i + 1 }}</span>
                      <span class="oa-sp" style="min-width:0">
                        <span class="oa-row"><i class="oa-sev" [style.background]="sevColor(f.severity)"></i><span class="oa-mono">{{ f.id }}</span></span>
                        <span class="oa-mono oa-small oa-muted oa-ell">{{ f.pkg }} → {{ f.fixed }} · {{ short(f.image) }}</span>
                      </span>
                      <b>{{ f.cvss.toFixed(1) }}</b>
                    </button>
                  </li>
                }
              </ol>
            </section>
            <section>
              <h3>Befunde je Image / Stack</h3>
              <ul class="oa-sec-ol">
                @for (im of images(); track im.ref) {
                  <li class="oa-sec-img">
                    <div class="oa-row" style="flex-wrap:nowrap">
                      <span class="oa-mono oa-small oa-sp oa-ell">{{ im.ref }}</span>
                      @if (stackName(im); as sn) { <span class="oa-pill" data-tone="accent">{{ sn }}</span> }
                      <b class="oa-small">{{ total(im) }}</b>
                    </div>
                    <div class="oa-share oa-share--thin" [style.width.%]="barWidth(im)">
                      @for (s of sev; track s.key) {
                        @if (im[s.key]) { <span [style.flex-grow]="im[s.key]" [style.background]="s.color"></span> }
                      }
                    </div>
                  </li>
                }
              </ul>
            </section>
          </div>
        }
        @case ('findings') {
          <div class="oa-row" style="margin:12px 0">
            @for (s of sev; track s.key) {
              <button type="button" class="oa-chip" [attr.aria-pressed]="sevFilter().includes(s.key)" (click)="toggleSev(s.key)"><i class="oa-sev" [style.background]="s.color"></i>{{ s.label }}</button>
            }
            <label class="oa-check oa-small"><input type="checkbox" [checked]="onlyFix()" (change)="onlyFix.set(!onlyFix())" /> nur mit Fix</label>
          </div>
          <div class="oa-card oa-scroll-x" style="padding:4px">
            <table class="oa-table">
              <thead><tr><th>ID</th><th>Schweregrad</th><th>Paket</th><th>Installiert</th><th>Behoben in</th><th>Image</th><th>Host</th><th>CVSS</th></tr></thead>
              <tbody>
                @for (f of filteredFindings(); track f.id) {
                  <tr [class.oa-sec-hl]="highlight() === f.id">
                    <td class="oa-mono">{{ f.id }}</td>
                    <td><span class="oa-pill" [attr.data-tone]="sevTone(f.severity)">{{ sevLabel(f.severity) }}</span></td>
                    <td class="oa-mono">{{ f.pkg }}</td>
                    <td class="oa-mono oa-muted">{{ f.installed }}</td>
                    <td class="oa-mono">{{ f.fixed }}</td>
                    <td class="oa-mono oa-small">{{ short(f.image) }}</td>
                    <td><span class="oa-host" [style.--hc]="store.hc(f.hostId)"><i></i>{{ store.hn(f.hostId) }}</span></td>
                    <td><b>{{ f.cvss.toFixed(1) }}</b></td>
                  </tr>
                } @empty {
                  <tr><td colspan="8" class="oa-muted" style="text-align:center;padding:20px">Keine Befunde für diese Filter.</td></tr>
                }
              </tbody>
            </table>
          </div>
        }
        @case ('images') {
          <div class="oa-card oa-scroll-x" style="padding:4px;margin-top:12px">
            <table class="oa-table">
              <thead><tr><th>Image</th><th>Stack</th><th>Host</th><th>Nutzung</th><th>K</th><th>H</th><th>M</th><th>N</th><th>Gescannt</th></tr></thead>
              <tbody>
                @for (im of images(); track im.ref) {
                  <tr>
                    <td class="oa-mono">{{ im.ref }}</td>
                    <td>
                      @if (im.stackId; as sid) {
                        <button type="button" class="oa-btn" style="height:26px" (click)="store.openStack(sid)">{{ stackName(im) }}</button>
                      } @else { <span class="oa-muted">–</span> }
                    </td>
                    <td><span class="oa-host" [style.--hc]="store.hc(im.hostId)"><i></i>{{ store.hn(im.hostId) }}</span></td>
                    <td class="oa-small">{{ im.usage === 'running' ? 'läuft' : im.usage === 'stopped' ? 'gestoppt' : 'ungenutzt' }}</td>
                    @for (s of sev; track s.key) {
                      <td><span class="oa-pill" [attr.data-tone]="im[s.key] ? s.tone : null">{{ im[s.key] }}</span></td>
                    }
                    <td class="oa-small oa-muted">{{ im.scanned }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      }
    }
  `,
  styles: `
    .oa-sec-off{display:flex;flex-direction:column;align-items:center;gap:8px;padding:48px 20px;text-align:center}
    .oa-sec-off h2{font-size:17px;margin:6px 0 0}
    .oa-sec-top{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr);gap:32px;align-items:center;padding:20px 0}
    @media (max-width:980px){.oa-sec-top{grid-template-columns:1fr}}
    .oa-sec-gauge{display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center}
    .oa-sec-gauge svg{width:min(320px,100%)}
    .oa-sec-track,.oa-sec-val{fill:none;stroke-width:14;stroke-linecap:round}
    .oa-sec-track{stroke:var(--oa-mbg)}
    .oa-sec-val{transition:stroke-dasharray .6s ease}
    .oa-sec-score{font-size:34px;font-weight:600;fill:var(--oa-fg)}
    .oa-sec-band{font-size:12px;font-weight:500}
    .oa-sec-driver{display:flex;flex-direction:column;gap:2px;border:0;border-radius:10px;padding:6px 10px;background:none;color:var(--oa-muted);font-size:13px;cursor:pointer}
    .oa-sec-driver:hover{background:var(--oa-mbg);color:var(--oa-fg)}
    .oa-sec-right h3,.oa-sec-lists h3{font-size:14px;font-weight:500;margin:0 0 10px}
    .oa-sec-right h4{font-size:13px;font-weight:400;color:var(--oa-muted);margin:12px 0 8px}
    .oa-sec-trend{width:100%;height:auto;display:block}
    .oa-sec-ax{fill:var(--oa-muted);font-size:10px}
    .oa-share{display:flex;gap:2px;height:8px}
    .oa-share span{border-radius:99px;min-width:4px}
    .oa-share--thin{height:6px;margin-top:6px}
    .oa-share-l{list-style:none;display:flex;flex-wrap:wrap;gap:4px 16px;margin:10px 0 0;padding:0;font-size:13px;color:var(--oa-muted)}
    .oa-share-l li{display:flex;align-items:center;gap:6px}
    .oa-share-l i,.oa-sev{display:inline-block;width:8px;height:8px;border-radius:50%}
    .oa-share-l b{color:var(--oa-fg);font-weight:500}
    .oa-sec-strip{grid-template-columns:repeat(4,minmax(0,1fr))}
    .oa-sec-lists{gap:40px}
    .oa-sec-ol{list-style:none;margin:0;padding:0}
    .oa-sec-ol>li{border-top:1px solid color-mix(in oklch,var(--oa-line) 50%,transparent)}
    .oa-sec-ol>li:first-child{border-top:0}
    .oa-sec-ol button{display:flex;align-items:center;gap:12px;width:100%;padding:10px 6px;border:0;border-radius:8px;background:none;color:var(--oa-fg);text-align:left;cursor:pointer}
    .oa-sec-ol button:hover{background:var(--oa-mbg)}
    .oa-sec-img{padding:10px 6px}
    .oa-ell{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-sec-hl td{background:var(--oa-accent-soft)}
  `,
})
export class SecurityComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly sev = SEV;
  protected readonly tw = TW;
  protected readonly th = TH;
  protected readonly tab = signal<'overview' | 'findings' | 'images'>('overview');
  protected readonly sevFilter = signal<Severity[]>([]);
  protected readonly onlyFix = signal(false);
  protected readonly highlight = signal<string | null>(null);
  protected readonly tabs: { id: 'overview' | 'findings' | 'images'; label: string; icon: 'activity' | 'alert' | 'package' }[] = [
    { id: 'overview', label: 'Übersicht', icon: 'activity' },
    { id: 'findings', label: 'Schwachstellen', icon: 'alert' },
    { id: 'images', label: 'Images', icon: 'package' },
  ];

  protected readonly images = computed(() =>
    this.store
      .scanImages()
      .filter((i) => this.store.hostOn(i.hostId))
      .sort((a, b) => this.weight(b) - this.weight(a)),
  );
  protected readonly findings = computed(() => FINDINGS.filter((f) => this.store.hostOn(f.hostId)));
  protected readonly topFindings = computed(() => [...this.findings()].sort((a, b) => b.cvss - a.cvss).slice(0, 6));
  protected readonly fixable = computed(() => this.findings().filter((f) => f.fixed !== '–').length);
  protected readonly filteredFindings = computed(() => {
    const sf = this.sevFilter();
    return this.findings().filter((f) => (!sf.length || sf.includes(f.severity)) && (!this.onlyFix() || f.fixed !== '–'));
  });
  protected readonly lastScan = computed(() => this.images()[0]?.scanned ?? '–');
  protected readonly scheduleLabel = computed(() => {
    const s = this.store.hub().scanSchedule;
    return s === 'manual' ? 'Nur manuell' : s === 'daily' ? 'Geplant: täglich 03:00' : 'Geplant: wöchentlich';
  });

  protected readonly risk = computed(() => {
    let score = 0;
    for (const i of this.images()) {
      const f = i.usage === 'running' ? 1 : 0.4;
      score += f * (i.critical * 12 + i.high * 4 + i.medium * 1 + i.low * 0.2);
    }
    const s = Math.min(100, Math.round(score));
    const band = s >= 75 ? ['Kritisch', 'var(--oa-err)'] : s >= 50 ? ['Hoch', 'var(--oa-orange)'] : s >= 25 ? ['Mittel', 'var(--oa-warn)'] : s > 0 ? ['Niedrig', 'var(--oa-lime)'] : ['Keine', 'var(--oa-ok)'];
    return { score: s, label: band[0], color: band[1] };
  });

  protected readonly sevShare = computed(() => {
    const t = this.store.scanTotals();
    return SEV.map((s) => ({ key: s.key, label: s.label, color: s.color, n: t[s.key] }));
  });

  protected readonly exposure = computed(() => {
    const sum = (u: ScanImage['usage']) => this.images().filter((i) => i.usage === u).reduce((n, i) => n + this.total(i), 0);
    return [
      { key: 'running', label: 'Laufend', color: 'var(--oa-accent)', n: sum('running') },
      { key: 'stopped', label: 'Gestoppt', color: 'color-mix(in oklch,var(--oa-accent) 50%,transparent)', n: sum('stopped') },
      { key: 'unused', label: 'Ungenutzt', color: 'color-mix(in oklch,var(--oa-muted) 40%,transparent)', n: sum('unused') },
    ];
  });

  protected readonly bars = computed(() => {
    const runs = this.store.scanHistory();
    const max = Math.max(1, ...runs.map((r) => r.critical + r.high + r.medium + r.low));
    const slot = TW / Math.max(1, runs.length);
    const w = Math.min(38, slot * 0.6);
    return runs.map((r, i) => {
      let y = TH;
      const segs = SEV.map((s) => {
        const n = r[s.key];
        const h = (n / max) * (TH - 16);
        y -= h;
        return { key: s.key, label: s.label, color: s.color, n, y, h };
      });
      return { x: i * slot + (slot - w) / 2, w, when: r.when, manual: r.kind === 'manuell', top: y, segs };
    });
  });

  protected readonly trendLabel = computed(() =>
    'Befunde je Scan: ' + this.store.scanHistory().map((r) => `${r.when} ${r.critical} kritisch, ${r.high} hoch`).join('; '),
  );

  private weight(i: ScanImage): number {
    return i.critical * 1000 + i.high * 50 + i.medium * 5 + i.low;
  }

  protected total(i: ScanImage): number {
    return i.critical + i.high + i.medium + i.low;
  }

  protected barWidth(i: ScanImage): number {
    const max = Math.max(1, ...this.images().map((x) => this.total(x)));
    return Math.max(6, (this.total(i) / max) * 100);
  }

  protected stackName(i: ScanImage): string {
    return i.stackId ? (this.store.stacks().find((s) => s.id === i.stackId)?.name ?? '') : '';
  }

  protected short(ref: string): string {
    return ref.split('/').pop() ?? ref;
  }

  protected sevColor(s: Severity): string {
    return SEV.find((x) => x.key === s)?.color ?? 'var(--oa-muted)';
  }

  protected sevTone(s: Severity): string {
    return SEV.find((x) => x.key === s)?.tone ?? 'gray';
  }

  protected sevLabel(s: Severity): string {
    return SEV.find((x) => x.key === s)?.label ?? s;
  }

  protected toggleSev(s: Severity): void {
    this.sevFilter.update((f) => (f.includes(s) ? f.filter((x) => x !== s) : [...f, s]));
  }

  protected focusFinding(id: string): void {
    this.highlight.set(id);
    this.sevFilter.set([]);
    this.tab.set('findings');
  }
}
