import { ChangeDetectionStrategy, Component, inject, signal, ViewEncapsulation } from '@angular/core';

import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const ROUTES = [
  { host: 'media.example.com', target: 'jellyfin:8096', stack: 'Media', tls: 'Let’s Encrypt', mw: 'Sicherheitsheader' },
  { host: 'cloud.example.com', target: 'nextcloud:80', stack: 'Cloud', tls: 'Let’s Encrypt', mw: 'Upload 10 GB' },
  { host: 'whoami.example.com', target: 'web:80', stack: 'Entwurf', tls: 'ausstehend', mw: '–' },
];

/** Erklärte Vorschau: Proxy- und Games-Modul sind spätere Evaluationen, keine Hauptfunktionen. */
@Component({
  selector: 'oa-preview',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Proxy &amp; Games <span class="oa-pill" data-tone="info">Vorschau</span></h1>
        <p>Zwei mögliche Module, die später evaluiert werden. Diese Seite zeigt nur das Zielbild – nichts ist angebunden.</p>
      </div>
    </div>

    <div class="oa-callout" data-tone="info" style="margin-bottom:16px">
      <oa-icon name="info" />
      <span>Projektbasis, Einbindung und Platzierung (eigene Navigation oder Tab im Stack) sind offen. Zuerst HTTP/HTTPS; TCP/UDP später.</span>
    </div>

    <div class="oa-pv-grid">
      <section class="oa-card" aria-labelledby="pv-proxy">
        <div class="oa-card-head">
          <span class="oa-card-ico"><oa-icon name="route" /></span>
          <h3 id="pv-proxy">Reverse Proxy</h3>
          <span class="oa-sp"></span>
          <span class="oa-pill">Traefik / Caddy</span>
        </div>
        <div class="oa-scroll-x">
          <table class="oa-table">
            <thead><tr><th>Domain</th><th>Ziel</th><th>Zertifikat</th><th>Middleware</th></tr></thead>
            <tbody>
              @for (r of routes; track r.host) {
                <tr>
                  <td><span class="oa-row"><oa-icon name="lock" [size]="13" class="oa-muted" /><span class="oa-mono">{{ r.host }}</span></span></td>
                  <td><span class="oa-mono oa-small">{{ r.target }}</span> <span class="oa-small oa-dim">· {{ r.stack }}</span></td>
                  <td><span class="oa-pill" [attr.data-tone]="r.tls === 'ausstehend' ? 'warn' : 'ok'">{{ r.tls }}</span></td>
                  <td class="oa-small oa-muted">{{ r.mw }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
        <p class="oa-help" style="margin-top:10px">Vorhandene Installation übernehmen oder gebündelt migrieren. Routen, Ziele, Middleware, Zertifikate.</p>
      </section>

      <section class="oa-card" aria-labelledby="pv-games">
        <div class="oa-card-head">
          <span class="oa-card-ico" data-tone="ok"><oa-icon name="gamepad" /></span>
          <h3 id="pv-games">Games · Craft</h3>
          <span class="oa-sp"></span>
          <span class="oa-pill" data-tone="warn"><span class="oa-dot" data-tone="warn"></span> unhealthy</span>
        </div>
        <div class="oa-pv-stats">
          <div><strong>3 / 20</strong><span>Spieler</span></div>
          <div><strong>14,2</strong><span>TPS</span></div>
          <div><strong>1.21.1</strong><span>Version</span></div>
        </div>
        <pre class="oa-code oa-pv-console" aria-label="Spielkonsole (Demo)">{{ consoleLines().join('\n') }}</pre>
        <form class="oa-row" style="margin-top:8px;flex-wrap:nowrap" (submit)="send($event)">
          <label for="pv-cmd" class="oa-sr">Konsolenbefehl</label>
          <input id="pv-cmd" class="oa-input oa-mono" placeholder="/list" [value]="cmd()" (input)="cmd.set($any($event.target).value)" />
          <button type="submit" class="oa-btn" data-tone="accent">Senden</button>
        </form>
        <p class="oa-help" style="margin-top:8px">Konsole über Docker Attach/RCON. Start/Stopp, Updates, Dateien und Backups kommen aus der allgemeinen Verwaltung.</p>
      </section>
    </div>
  `,
  styles: `
    .oa-pv-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(440px,100%),1fr));gap:14px}
    .oa-page-head h1 .oa-pill{vertical-align:middle;margin-left:6px}
    .oa-pv-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
    .oa-pv-stats>div{padding:10px;border-radius:11px;border:1px solid var(--oa-line);background:rgb(0 0 0/.18)}
    .oa-pv-stats strong{display:block;font-size:17px}
    .oa-pv-stats span{font-size:12px;color:var(--oa-dim)}
    .oa-pv-console{height:150px}
  `,
})
export class PreviewComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly routes = ROUTES;
  protected readonly cmd = signal('');
  protected readonly consoleLines = signal<string[]>([
    '[09:38:10] Done (14.211s)! For help, type "help"',
    '[09:40:52] Can\'t keep up! Is the server overloaded?',
    '[09:41:05] Alex joined the game',
  ]);

  protected send(e: Event): void {
    e.preventDefault();
    const c = this.cmd().trim();
    if (!c) return;
    const reply = c.replace(/^\//, '') === 'list' ? 'There are 3 of a max of 20 players online: Alex, Sam, Kim' : 'Demo: Befehl nicht gesendet (Vorschau)';
    this.consoleLines.update((l) => [...l, `> ${c}`, reply].slice(-12));
    this.cmd.set('');
  }
}
