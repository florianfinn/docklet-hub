import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { Health, Origin, Standalone, SvcState } from './data';
import { DialogComponent } from './dialog.component';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const ORIGIN_LABEL: Record<Origin, string> = {
  unraid: 'Unraid-verwaltet',
  foreign: 'Fremdverwaltet',
  unknown: 'Herkunft unklar',
  standalone: 'Docklet-Einzelcontainer',
};

type Kind = 'stack' | 'single' | 'system';

interface Row {
  id: string;
  name: string;
  image: string;
  hostId: string;
  state: SvcState;
  health: Health;
  cpu: number;
  mem: string;
  ports: string[];
  kind: Kind;
  stackId?: string;
  stackName?: string;
  single?: Standalone;
}

/** Container-Seite nach Arcane: alle Container aller Hosts; Einzelcontainer (inkl. Unraid) mit eigener Verwaltung. */
@Component({
  selector: 'oa-containers',
  imports: [ZardButtonComponent, IconComponent, DialogComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Container</h1>
        <p>Alle Container der gefilterten Hosts. Stack-Container öffnen ihren Stack, Einzelcontainer werden hier verwaltet.</p>
      </div>
    </div>

    <dl class="oa-strip">
      <div><dt>Gesamt</dt><dd>{{ rows().length }}</dd></div>
      <div><dt>Laufend</dt><dd>{{ runningCount() }}</dd></div>
      <div><dt>In Stacks</dt><dd>{{ countKind('stack') }}</dd></div>
      <div><dt>Einzelcontainer</dt><dd>{{ countKind('single') }}</dd></div>
    </dl>

    <section class="oa-card" style="padding:14px">
      <div class="oa-row" style="margin-bottom:8px">
        <label class="oa-ct-search">
          <oa-icon name="search" [size]="15" />
          <span class="oa-sr">Container durchsuchen</span>
          <input class="oa-input" type="search" placeholder="Name oder Image …" [value]="query()" (input)="query.set($any($event.target).value)" />
        </label>
        <div class="oa-seg" role="radiogroup" aria-label="Art">
          @for (f of kinds; track f.id) {
            <button type="button" role="radio" [attr.aria-checked]="kind() === f.id" (click)="kind.set(f.id)">{{ f.label }}</button>
          }
        </div>
      </div>
      <div class="oa-scroll-x">
        <table class="oa-table">
          <thead><tr><th>Name</th><th>Status</th><th>Zugehörigkeit</th><th>Host</th><th>Image</th><th>CPU</th><th>RAM</th><th>Ports</th></tr></thead>
          <tbody>
            @for (r of filtered(); track r.id) {
              <tr>
                <td>
                  <button type="button" class="oa-ct-link" (click)="open(r)" [disabled]="r.kind === 'system'">
                    <span class="oa-dot" [attr.data-tone]="r.health === 'unhealthy' ? 'err' : r.state === 'running' ? 'ok' : 'warn'"></span>{{ r.name }}
                  </button>
                </td>
                <td><span class="oa-pill oa-pill--status" [attr.data-tone]="r.health === 'unhealthy' ? 'err' : r.state === 'running' ? 'ok' : 'gray'">{{ r.health === 'unhealthy' ? 'Unhealthy' : r.state === 'running' ? 'Läuft' : 'Gestoppt' }}</span></td>
                <td>
                  @switch (r.kind) {
                    @case ('stack') { <span class="oa-pill" data-tone="accent"><oa-icon name="layers" [size]="11" /> {{ r.stackName }}</span> }
                    @case ('single') {
                      <span class="oa-pill" [attr.data-tone]="restricted(r) ? 'warn' : 'info'">
                        @if (restricted(r)) { <oa-icon name="lock" [size]="11" /> }
                        {{ originLabel[r.single?.origin ?? 'unknown'] }}
                      </span>
                    }
                    @case ('system') { <span class="oa-pill">Docklet-Agent</span> }
                  }
                </td>
                <td><span class="oa-host" [style.--hc]="store.hc(r.hostId)"><i></i>{{ store.hn(r.hostId) }}</span></td>
                <td class="oa-mono oa-muted">{{ r.image }}</td>
                <td class="oa-mono">{{ r.state === 'running' ? r.cpu + ' %' : '–' }}</td>
                <td>{{ r.state === 'running' ? r.mem : '–' }}</td>
                <td class="oa-mono oa-small">{{ r.ports.join(', ') || '–' }}</td>
              </tr>
            } @empty {
              <tr><td colspan="8" class="oa-muted" style="text-align:center;padding:24px">Keine Container für diese Filter.</td></tr>
            }
          </tbody>
        </table>
      </div>
    </section>

    @if (detail(); as c) {
      <oa-dialog [heading]="c.name" description="Einzelcontainer ohne Compose-Stack" icon="box" [side]="true" (closed)="detailId.set(null)">
        <dl class="oa-kv" style="margin-bottom:14px">
          <dt>Host</dt><dd>{{ store.hn(c.hostId) }}</dd>
          <dt>Image</dt><dd class="oa-mono">{{ c.image }}</dd>
          <dt>Status</dt><dd>{{ c.state === 'running' ? 'Läuft' : 'Gestoppt' }} · CPU {{ c.cpu }} % · {{ c.mem }}</dd>
          <dt>Ports</dt><dd class="oa-mono">{{ c.ports.join(', ') || '–' }}</dd>
        </dl>
        <div class="oa-field">
          <label class="oa-label" for="ct-origin">Zuordnung</label>
          <select class="oa-select" id="ct-origin" [value]="c.origin" (change)="store.setOrigin(c.id, $any($event.target).value)">
            <option value="unraid">Unraid-verwaltet (eingeschränkt)</option>
            <option value="foreign">Fremdverwaltet (eingeschränkt)</option>
            <option value="unknown">Herkunft unklar (eingeschränkt)</option>
            <option value="standalone">Docklet-Einzelcontainer (voll bearbeitbar)</option>
          </select>
          <span class="oa-help">Automatisch erkannt: {{ originLabel[c.detected] }}. Manuelle Zuordnung pro Container möglich.</span>
        </div>
        @if (c.origin !== 'standalone') {
          <div class="oa-callout" data-tone="warn" style="margin-top:12px">
            <oa-icon name="lock" [size]="15" />
            <span>Eingeschränkt: Status, Logs, Shell, Auslastung und Start/Stopp/Neustart. Editor und Recreate sind deaktiviert.</span>
          </div>
        } @else {
          <div class="oa-callout" data-tone="info" style="margin-top:12px">
            <oa-icon name="info" [size]="15" />
            <span>Voll bearbeitbar. Recreate erstellt den Container mit den bearbeiteten Werten neu – Daten in Volumes bleiben erhalten.</span>
          </div>
        }
        <div class="oa-row" style="margin-top:14px">
          <button type="button" class="oa-btn" (click)="sub.set('logs')"><oa-icon name="fileText" [size]="14" /> Logs</button>
          <button type="button" class="oa-btn" (click)="sub.set('shell')"><oa-icon name="terminal" [size]="14" /> Shell</button>
          <button type="button" class="oa-btn" (click)="store.standaloneAction(c.id, c.state === 'running' ? 'Stopp' : 'Start')">
            <oa-icon [name]="c.state === 'running' ? 'stop' : 'play'" [size]="14" /> {{ c.state === 'running' ? 'Stoppen' : 'Starten' }}
          </button>
          <button type="button" class="oa-btn" (click)="store.standaloneAction(c.id, 'Neustart')"><oa-icon name="restart" [size]="14" /> Neustart</button>
        </div>
        @if (sub() === 'logs') {
          <pre class="oa-code" style="margin-top:12px">09:12:01 duplicati  Server gestartet auf Port 8200
09:30:00 duplicati  Geplante Sicherung „Fotos“ gestartet
09:41:12 duplicati  Sicherung abgeschlossen (1.204 Dateien)</pre>
        }
        @if (sub() === 'shell') {
          <pre class="oa-code" style="margin-top:12px;min-height:110px">{{ shellLog().join('\n') }}</pre>
          <form class="oa-row" style="margin-top:8px;flex-wrap:nowrap" (submit)="runShell($event)">
            <label class="oa-sr" for="ct-shell">Befehl</label>
            <input id="ct-shell" class="oa-input oa-mono" placeholder="z. B. ls /config" [value]="shellInput()" (input)="shellInput.set($any($event.target).value)" />
            <button z-button zSize="sm" type="submit">Senden</button>
          </form>
        }
        <div dlgFooter class="oa-row">
          <button z-button zType="outline" type="button" [zDisabled]="c.origin !== 'standalone'" (click)="store.standaloneAction(c.id, 'Recreate')" [title]="c.origin !== 'standalone' ? 'Für eingeschränkte Container nicht verfügbar' : 'Bearbeiten und neu erstellen'">
            <oa-icon name="pencil" [size]="14" /> Bearbeiten &amp; Recreate
          </button>
          <button z-button type="button" (click)="detailId.set(null)">Schließen</button>
        </div>
      </oa-dialog>
    }
  `,
  styles: `
    .oa-ct-search{position:relative;width:min(300px,100%)}
    .oa-ct-search oa-icon{position:absolute;left:10px;top:10px;color:var(--oa-muted)}
    .oa-ct-search .oa-input{padding-left:32px}
    .oa-ct-link{display:inline-flex;align-items:center;gap:8px;border:0;background:none;padding:0;color:var(--oa-fg);font:inherit;font-weight:500;cursor:pointer}
    .oa-ct-link:hover:not(:disabled){text-decoration:underline}
    .oa-ct-link:disabled{cursor:default}
  `,
})
export class ContainersComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly originLabel = ORIGIN_LABEL;
  protected readonly query = signal('');
  protected readonly kind = signal<'all' | Kind>('all');
  protected readonly detailId = signal<string | null>(null);
  protected readonly sub = signal<'logs' | 'shell' | null>(null);
  protected readonly shellInput = signal('');
  protected readonly shellLog = signal<string[]>(['root@legacy:/# ']);
  protected readonly kinds: { id: 'all' | Kind; label: string }[] = [
    { id: 'all', label: 'Alle' },
    { id: 'stack', label: 'In Stacks' },
    { id: 'single', label: 'Einzelcontainer' },
    { id: 'system', label: 'System' },
  ];

  protected readonly rows = computed<Row[]>(() => {
    const out: Row[] = [];
    for (const s of this.store.visibleStacks()) {
      for (const x of s.services) {
        out.push({ id: `${s.id}-${x.name}`, name: `${s.id}-${x.name}-1`, image: x.image, hostId: s.hostId, state: x.state, health: x.health, cpu: x.cpu, mem: x.mem, ports: x.ports, kind: 'stack', stackId: s.id, stackName: s.name });
      }
    }
    for (const c of this.store.visibleStandalone()) {
      out.push({ id: c.id, name: c.name.toLowerCase(), image: c.image, hostId: c.hostId, state: c.state, health: 'none', cpu: c.cpu, mem: c.mem, ports: c.ports, kind: 'single', single: c });
    }
    for (const h of this.store.visibleHosts()) {
      if (h.status !== 'online') continue;
      out.push({ id: `agent-${h.id}`, name: 'docklet-agent', image: `ghcr.io/example/docklet-agent:${h.agent}`, hostId: h.id, state: 'running', health: 'healthy', cpu: 1, mem: '38 MB', ports: h.mode === 'direct' ? ['3552:3552'] : [], kind: 'system' });
    }
    return out;
  });

  protected readonly filtered = computed(() => {
    const q = this.query().trim().toLowerCase();
    const k = this.kind();
    return this.rows().filter((r) => (k === 'all' || r.kind === k) && (!q || `${r.name} ${r.image}`.toLowerCase().includes(q)));
  });

  protected readonly runningCount = computed(() => this.rows().filter((r) => r.state === 'running').length);
  protected readonly detail = computed(() => this.store.standalone().find((c) => c.id === this.detailId()) ?? null);

  protected countKind(k: Kind): number {
    return this.rows().filter((r) => r.kind === k).length;
  }

  protected restricted(r: Row): boolean {
    return (r.single?.origin ?? 'unknown') !== 'standalone';
  }

  protected open(r: Row): void {
    if (r.kind === 'stack' && r.stackId) this.store.openStack(r.stackId);
    else if (r.kind === 'single') {
      this.sub.set(null);
      this.detailId.set(r.id);
    }
  }

  protected runShell(e: Event): void {
    e.preventDefault();
    const cmd = this.shellInput().trim();
    if (!cmd) return;
    this.shellLog.update((l) => [...l.slice(0, -1), `root@legacy:/# ${cmd}`, 'Demo: Befehl wurde nicht ausgeführt.', 'root@legacy:/# ']);
    this.shellInput.set('');
  }
}
