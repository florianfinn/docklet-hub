import { ChangeDetectionStrategy, Component, computed, inject, linkedSignal, ViewEncapsulation } from '@angular/core';

import { FileEntry, FILES, IMAGES, VOLUMES } from './data';
import { IconComponent, IconName } from './icon.component';
import { ArcaneStore } from './store';

type Tab = 'images' | 'volumes' | 'files';

const TABS: { id: Tab; label: string; icon: IconName }[] = [
  { id: 'images', label: 'Images', icon: 'package' },
  { id: 'volumes', label: 'Volumes & Bind-Mounts', icon: 'database' },
  { id: 'files', label: 'Dateibrowser', icon: 'folder' },
];

@Component({
  selector: 'oa-resources',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Images &amp; Volumes</h1>
        <p>Späteres Zielbild in kompakter Form. Die gemeinsame Gruppierung unter „Ressourcen“ ist experimentell.</p>
      </div>
    </div>

    <div class="oa-tabs" role="tablist" aria-label="Ressourcen" (keydown)="onTabKey($event)">
      @for (t of tabs; track t.id) {
        <button
          type="button"
          role="tab"
          class="oa-tab"
          [id]="'rs-tab-' + t.id"
          aria-controls="rs-panel"
          [attr.aria-selected]="store.resourcesTab() === t.id"
          [attr.tabindex]="store.resourcesTab() === t.id ? 0 : -1"
          (click)="store.resourcesTab.set(t.id)"
        >
          <oa-icon [name]="t.icon" [size]="15" /> {{ t.label }}
        </button>
      }
    </div>

    <div id="rs-panel" role="tabpanel" [attr.aria-labelledby]="'rs-tab-' + store.resourcesTab()" class="oa-rs-panel">
      @switch (store.resourcesTab()) {
        @case ('images') {
          <div class="oa-card oa-scroll-x">
            <table class="oa-table">
              <thead><tr><th>Repository</th><th>Tag</th><th>Host</th><th>Größe</th><th>Verwendet von</th><th>Status</th></tr></thead>
              <tbody>
                @for (i of images(); track i.repo + i.tag) {
                  <tr>
                    <td class="oa-mono">{{ i.repo }}</td>
                    <td class="oa-mono">{{ i.tag }}</td>
                    <td><span class="oa-host" [style.--hc]="store.hc(i.hostId)"><i></i>{{ store.hn(i.hostId) }}</span></td>
                    <td>{{ i.size }}</td>
                    <td class="oa-small" [class.oa-dim]="i.usedBy.startsWith('–')">{{ i.usedBy }}</td>
                    <td>
                      <span class="oa-row">
                        @if (i.update) {
                          <span class="oa-pill" data-tone="info">→ {{ i.update }}</span>
                        }
                        @if (store.scanEnabled() && i.vulns) {
                          <span class="oa-pill" [attr.data-tone]="i.crit ? 'err' : 'warn'">{{ i.vulns }}</span>
                        }
                        @if (!i.update && !(store.scanEnabled() && i.vulns)) {
                          <span class="oa-pill" data-tone="ok">aktuell</span>
                        }
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
          <div class="oa-callout" style="margin-top:12px">
            <oa-icon name="shield" [size]="15" />
            <span class="oa-sp">Schwachstellenscans sind optional und getrennt von der Update-Erkennung. Diagramme und Befunde auf der Sicherheitsseite.</span>
            <button type="button" class="oa-btn" (click)="store.go('security')">Sicherheit öffnen</button>
          </div>
        }
        @case ('volumes') {
          <div class="oa-card oa-scroll-x">
            <table class="oa-table">
              <thead><tr><th>Name</th><th>Art</th><th>Host</th><th>Größe</th><th>Verwendet von</th><th>Backup</th><th><span class="oa-sr">Aktion</span></th></tr></thead>
              <tbody>
                @for (v of volumes(); track v.name) {
                  <tr>
                    <td><span class="oa-row"><oa-icon [name]="v.kind === 'bind' ? 'folder' : 'database'" [size]="15" class="oa-muted" /><span class="oa-mono">{{ v.name }}</span></span></td>
                    <td><span class="oa-pill" [attr.data-tone]="v.kind === 'bind' ? 'info' : 'accent'">{{ v.kind === 'bind' ? 'Bind-Mount' : 'Volume' }}</span></td>
                    <td><span class="oa-host" [style.--hc]="store.hc(v.hostId)"><i></i>{{ store.hn(v.hostId) }}</span></td>
                    <td>{{ v.size }}</td>
                    <td class="oa-small">{{ v.usedBy }}</td>
                    <td class="oa-small oa-muted">{{ v.backup }}</td>
                    <td><button type="button" class="oa-btn" (click)="store.openFiles(v.name)">Durchsuchen</button></td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
        @case ('files') {
          <div class="oa-files">
            <nav class="oa-card oa-files-roots" aria-label="Speicherorte">
              <div class="oa-section-title" style="margin-top:0">Volumes</div>
              @for (v of volRoots(); track v) {
                <button type="button" class="oa-files-root" [attr.aria-current]="current() === v ? 'true' : null" (click)="open(v)">
                  <oa-icon name="database" [size]="15" /> <span class="oa-mono">{{ v }}</span>
                </button>
              }
              <div class="oa-section-title">Bind-Mounts &amp; Projekte</div>
              @for (v of bindRoots(); track v) {
                <button type="button" class="oa-files-root" [attr.aria-current]="current() === v ? 'true' : null" (click)="open(v)">
                  <oa-icon name="folder" [size]="15" /> <span class="oa-mono">{{ v }}</span>
                </button>
              }
            </nav>
            <section class="oa-card oa-files-main" aria-label="Dateien">
              <div class="oa-files-path">
                <button type="button" class="oa-files-crumb" (click)="sub.set([])">{{ current() }}</button>
                @for (p of sub(); track $index; let i = $index) {
                  <oa-icon name="chevronRight" [size]="13" class="oa-dim" />
                  <button type="button" class="oa-files-crumb" (click)="sub.set(sub().slice(0, i + 1))">{{ p }}</button>
                }
                <span class="oa-sp"></span>
                <span class="oa-pill"><oa-icon name="eye" [size]="12" /> nur lesen (Demo)</span>
              </div>
              <ul class="oa-list">
                @for (f of entries(); track f.name) {
                  <li>
                    <oa-icon [name]="f.dir ? 'folder' : 'file'" [size]="16" [class]="f.dir ? 'oa-files-dir' : 'oa-muted'" />
                    @if (f.dir) {
                      <button type="button" class="oa-files-name oa-sp" (click)="enter(f.name)">{{ f.name }}</button>
                    } @else {
                      <span class="oa-files-name oa-sp">{{ f.name }}</span>
                    }
                    <span class="oa-small oa-dim oa-files-meta">{{ f.size }}</span>
                    <span class="oa-small oa-dim oa-files-meta">{{ f.modified }}</span>
                  </li>
                } @empty {
                  <li class="oa-muted oa-small">Leeres Verzeichnis (synthetische Demo)</li>
                }
              </ul>
            </section>
          </div>
        }
      }
    </div>
  `,
  styles: `
    .oa-rs-panel{margin-top:14px}
    .oa-files{display:grid;grid-template-columns:260px minmax(0,1fr);gap:14px;align-items:start}
    @media (max-width:820px){.oa-files{grid-template-columns:1fr}}
    .oa-files-roots{display:flex;flex-direction:column;gap:2px;padding:12px}
    .oa-files-root{display:flex;align-items:center;gap:8px;padding:7px 9px;border:0;border-radius:9px;background:none;color:var(--oa-muted);text-align:left;cursor:pointer;min-width:0}
    .oa-files-root span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-files-root:hover{background:rgb(255 255 255/.045);color:var(--oa-fg)}
    .oa-files-root[aria-current=true]{background:var(--oa-accent-soft);color:var(--oa-fg)}
    .oa-files-path{display:flex;align-items:center;gap:4px;flex-wrap:wrap;padding-bottom:10px;margin-bottom:4px;border-bottom:1px solid var(--oa-line)}
    .oa-files-crumb{border:0;background:none;color:var(--oa-fg);font:12.5px 'JetBrains Mono',ui-monospace,monospace;padding:3px 5px;border-radius:6px;cursor:pointer}
    .oa-files-crumb:hover{background:rgb(255 255 255/.06)}
    .oa-files-name{border:0;background:none;padding:0;color:var(--oa-fg);font:inherit;text-align:left;cursor:pointer;min-width:0;overflow:hidden;text-overflow:ellipsis}
    button.oa-files-name:hover{color:var(--oa-accent-fg);text-decoration:underline}
    .oa-files-dir{color:#fbbf24}
    .oa-files-meta{white-space:nowrap}
    @media (max-width:560px){.oa-files-meta:last-child{display:none}}
  `,
})
export class ResourcesComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly tabs = TABS;
  /** Unterpfad im Dateibrowser – wird bei neuem Ziel (z. B. Link aus dem Editor) zurückgesetzt. */
  protected readonly sub = linkedSignal<string[]>(() => {
    this.store.filesTarget();
    return [];
  });

  protected readonly images = computed(() => {
    const scans = this.store.scanImages();
    return IMAGES.filter((i) => this.store.hostOn(i.hostId)).map((i) => {
      const sc = scans.find((s) => s.ref === `${i.repo}:${i.tag}`);
      const n = sc ? sc.critical + sc.high + sc.medium + sc.low : 0;
      return { ...i, vulns: n ? `${n} Befunde` : '', crit: !!sc && sc.critical > 0 };
    });
  });

  protected readonly volumes = computed(() => VOLUMES.filter((v) => this.store.hostOn(v.hostId)));

  protected readonly volRoots = computed(() => VOLUMES.filter((v) => v.kind === 'volume').map((v) => v.name));
  protected readonly bindRoots = computed(() => {
    const base = ['/srv/media/movies', '/opt/stacks/media'];
    const t = this.store.filesTarget();
    const known = [...VOLUMES.map((v) => v.name), ...base];
    return known.includes(t) ? base : [...base, t];
  });

  protected readonly current = computed(() => this.store.filesTarget());

  protected readonly entries = computed<FileEntry[]>(() => {
    if (this.sub().length) {
      const depth = this.sub().length;
      return [
        { name: depth > 2 ? 'beispiel.dat' : 'unterordner', dir: depth <= 2, size: depth > 2 ? '12 KB' : '–', modified: 'heute' },
        { name: 'notiz.txt', dir: false, size: '1 KB', modified: 'gestern' },
      ];
    }
    return FILES[this.current()] ?? [];
  });

  protected enter(name: string): void {
    this.sub.update((s) => [...s, name]);
  }

  protected open(root: string): void {
    this.store.filesTarget.set(root);
    this.sub.set([]);
  }

  protected onTabKey(e: KeyboardEvent): void {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    const ids = TABS.map((t) => t.id);
    const i = ids.indexOf(this.store.resourcesTab());
    const next = ids[(i + (e.key === 'ArrowRight' ? 1 : -1) + ids.length) % ids.length];
    this.store.resourcesTab.set(next);
    (e.currentTarget as HTMLElement).querySelector<HTMLElement>(`#rs-tab-${next}`)?.focus();
  }
}
