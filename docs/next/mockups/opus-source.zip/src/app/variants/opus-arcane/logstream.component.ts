import { ChangeDetectionStrategy, Component, computed, effect, ElementRef, inject, input, signal, viewChild, ViewEncapsulation } from '@angular/core';

import { LogLine, Stack } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const PALETTE = ['var(--oa-violet)', 'var(--oa-cyan)', 'var(--oa-orange)', 'var(--oa-lime)', 'var(--oa-pink)', 'var(--oa-sky)'];

type Level = 'all' | 'warn' | 'error';

/** Gemeinsamer Logstream aller Services eines Stacks (Docklet-Vorbild, Darstellung nach Arcanes log-viewer). */
@Component({
  selector: 'oa-logstream',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <section class="oa-card oa-ls" aria-label="Gemeinsamer Logstream">
      <div class="oa-ls-bar">
        <div class="oa-row" role="group" aria-label="Services filtern">
          <button type="button" class="oa-chip" [attr.aria-pressed]="!hidden().length" (click)="hidden.set([])">Alle Services</button>
          @for (svc of stack().services; track svc.name) {
            <button type="button" class="oa-chip" [attr.aria-pressed]="!hidden().includes(svc.name)" (click)="toggle(svc.name)">
              <span class="oa-ls-sw" [style.background]="color(svc.name)"></span>{{ svc.name }}
            </button>
          }
        </div>
        <span class="oa-sp"></span>
        <div class="oa-seg" role="radiogroup" aria-label="Level">
          <button type="button" role="radio" [attr.aria-checked]="level() === 'all'" (click)="level.set('all')">Alle</button>
          <button type="button" role="radio" [attr.aria-checked]="level() === 'warn'" (click)="level.set('warn')">Warnungen+</button>
          <button type="button" role="radio" [attr.aria-checked]="level() === 'error'" (click)="level.set('error')">Fehler</button>
        </div>
      </div>
      <div class="oa-ls-bar">
        <label class="oa-ls-search">
          <oa-icon name="search" [size]="14" />
          <span class="oa-sr">Logs durchsuchen</span>
          <input class="oa-input" type="search" placeholder="In Logs suchen …" [value]="query()" (input)="query.set($any($event.target).value)" />
        </label>
        <label class="oa-check oa-small"><input type="checkbox" [checked]="stamps()" (change)="stamps.set(!stamps())" /> Zeitstempel</label>
        <span class="oa-sp"></span>
        <button type="button" class="oa-btn" [attr.aria-pressed]="store.live()" (click)="store.live.set(!store.live())">
          <oa-icon [name]="store.live() ? 'pause' : 'play'" [size]="13" /> {{ store.live() ? 'Live folgen' : 'Pausiert' }}
        </button>
        <button type="button" class="oa-btn" (click)="store.clearLogs(stack().id)"><oa-icon name="trash" [size]="13" /> Leeren</button>
      </div>

      <div #box class="oa-ls-box" role="log" aria-live="off" tabindex="0" aria-label="Logausgabe aller Services">
        @for (l of lines(); track $index) {
          <div class="oa-ls-line" [attr.data-level]="l.level">
            @if (stamps()) {
              <span class="oa-ls-ts">{{ l.t }}</span>
            }
            <span class="oa-ls-svc" [style.color]="color(l.svc)">{{ l.svc }}</span>
            <span class="oa-ls-msg">{{ l.msg }}</span>
          </div>
        } @empty {
          <p class="oa-muted oa-small" style="padding:12px">Keine Zeilen für diese Filter.</p>
        }
      </div>
      <p class="oa-small oa-muted oa-ls-foot">
        {{ lines().length }} Zeilen aus {{ stack().services.length }} Service(s) · Herkunft je Zeile farbig markiert · neue Zeilen werden simuliert
      </p>
    </section>
  `,
  styles: `
    .oa-ls{display:flex;flex-direction:column;gap:10px}
    .oa-ls-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .oa-ls-sw{width:8px;height:8px;border-radius:3px}
    .oa-ls-search{position:relative;width:min(280px,100%)}
    .oa-ls-search oa-icon{position:absolute;left:10px;top:11px;color:var(--oa-muted)}
    .oa-ls-search .oa-input{padding-left:30px}
    .oa-ls-box{height:min(52vh,460px);overflow:auto;padding:8px 4px;border-radius:12px;border:1px solid var(--oa-line);background:var(--oa-code);font:12.5px/1.6 'JetBrains Mono','Cascadia Code',ui-monospace,monospace}
    .oa-ls-line{display:flex;align-items:flex-start;gap:10px;padding:2px 8px;border-radius:6px}
    .oa-ls-line:hover{background:color-mix(in oklch,var(--oa-fg) 4%,transparent)}
    .oa-ls-line[data-level=warn]{background:color-mix(in oklch,var(--oa-warn) 7%,transparent)}
    .oa-ls-line[data-level=error]{background:color-mix(in oklch,var(--oa-err) 9%,transparent)}
    .oa-ls-ts{flex-shrink:0;padding:0 7px;border-radius:7px;border:1px solid color-mix(in oklch,var(--oa-info) 18%,transparent);color:var(--oa-info);font-size:11.5px;font-weight:600}
    .oa-ls-svc{flex-shrink:0;width:96px;overflow:hidden;text-overflow:ellipsis;font-weight:600}
    .oa-ls-msg{min-width:0;white-space:pre-wrap;overflow-wrap:anywhere}
    .oa-ls-foot{margin:0}
    @media (max-width:560px){.oa-ls-svc{width:70px}}
  `,
})
export class LogstreamComponent {
  protected readonly store = inject(ArcaneStore);
  readonly stack = input.required<Stack>();
  protected readonly hidden = signal<string[]>([]);
  protected readonly level = signal<Level>('all');
  protected readonly query = signal('');
  protected readonly stamps = signal(true);
  private readonly box = viewChild<ElementRef<HTMLElement>>('box');

  protected readonly lines = computed<LogLine[]>(() => {
    const all = this.store.logs()[this.stack().id] ?? [];
    const hid = this.hidden();
    const lv = this.level();
    const q = this.query().trim().toLowerCase();
    return all.filter(
      (l) =>
        !hid.includes(l.svc) &&
        (lv === 'all' || (lv === 'warn' ? l.level !== 'info' : l.level === 'error')) &&
        (!q || l.msg.toLowerCase().includes(q) || l.svc.includes(q)),
    );
  });

  constructor() {
    effect(() => {
      this.lines();
      const el = this.box()?.nativeElement;
      if (el && this.store.live()) setTimeout(() => (el.scrollTop = el.scrollHeight));
    });
  }

  protected color(svc: string): string {
    const i = this.stack().services.findIndex((s) => s.name === svc);
    return PALETTE[(i < 0 ? 0 : i) % PALETTE.length];
  }

  protected toggle(name: string): void {
    this.hidden.update((h) => (h.includes(name) ? h.filter((x) => x !== name) : [...h, name]));
  }
}
