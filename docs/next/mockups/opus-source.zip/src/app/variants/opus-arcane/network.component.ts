import { ChangeDetectionStrategy, Component, computed, inject, linkedSignal, signal, ViewEncapsulation } from '@angular/core';

import { Service, TOPO_COMM, TOPO_LINKS, TOPO_NODES, TopoNode } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

const NET_INFO: Record<string, { driver: string; subnet: string; gateway: string; isInternal: boolean; scope: string }> = {
  'n-media': { driver: 'bridge', subnet: '192.0.2.32/27', gateway: '192.0.2.33', isInternal: false, scope: 'Stack Media' },
  'n-bridge': { driver: 'bridge', subnet: '192.0.2.0/27', gateway: '192.0.2.1', isInternal: false, scope: 'Docker-Standard' },
  'n-web': { driver: 'bridge', subnet: '192.0.2.64/27', gateway: '192.0.2.65', isInternal: false, scope: 'Stack Cloud' },
  'n-int': { driver: 'bridge', subnet: '198.51.100.0/27', gateway: '198.51.100.1', isInternal: true, scope: 'Stack Cloud' },
  'n-craft': { driver: 'bridge', subnet: '198.51.100.32/27', gateway: '198.51.100.33', isInternal: false, scope: 'Stack Craft' },
};

const W = 840;
const H = 440;

/** Stil-Host für die Topologie-Leinwand (Farben nach Arcanes network-diagram, Dark). */
@Component({
  selector: 'oa-topo-styles',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-tp-shell{position:relative;border-radius:24px;border:1px solid var(--oa-line);overflow:hidden;background:radial-gradient(circle at top left,rgb(14 165 233/.12),transparent 30%),radial-gradient(circle at top right,rgb(124 58 237/.14),transparent 26%),linear-gradient(180deg,#0c1220,#080c18)}
    .oa-tp-svg{display:block;width:100%;height:auto;min-height:300px;touch-action:none;cursor:grab;font-family:inherit}
    .oa-tp-dot{fill:rgb(148 163 184/.22)}
    .oa-tp-zone{fill:color-mix(in oklch,var(--hc) 5%,transparent);stroke:color-mix(in oklch,var(--hc) 35%,transparent);stroke-dasharray:6 6}
    .oa-tp-zone-t{font-size:12px;font-weight:600;letter-spacing:.05em}
    .oa-tp-link{stroke:rgb(148 163 184/.45);stroke-width:1.5;transition:opacity .2s}
    .oa-tp-on{stroke:#38bdf8;stroke-width:2.5}
    .oa-tp-comm{fill:none;stroke:#a78bfa;stroke-width:2;stroke-dasharray:6 6}
    .oa-tp-anim .oa-tp-comm{animation:oa-tp-flow 1.6s linear infinite}
    @keyframes oa-tp-flow{to{stroke-dashoffset:-24}}
    .oa-tp-ip{font-size:10px;fill:#cbd5e1;paint-order:stroke;stroke:#0f172a;stroke-width:3px}
    .oa-tp-dim{opacity:.18}
    .oa-tp-node{cursor:pointer;outline:none;transition:opacity .2s}
    .oa-tp-box{fill:#0f172a;stroke:#94a3b8;stroke-width:1.5;filter:drop-shadow(0 10px 18px rgb(2 6 23/.45))}
    [data-status=network] .oa-tp-box{fill:#083344;stroke:#22d3ee}
    [data-status=internal] .oa-tp-box{fill:#3b0764;stroke:#a855f7}
    [data-status=running] .oa-tp-box{fill:#062a22;stroke:#34d399}
    [data-status=unhealthy] .oa-tp-box{fill:#3a1414;stroke:#f87171}
    .oa-tp-led{fill:#34d399}
    [data-status=unhealthy] .oa-tp-led{fill:#f87171;animation:oa-pulse 1.6s infinite}
    [data-status=stopped] .oa-tp-led{fill:#94a3b8}
    .oa-tp-t{fill:#e2e8f0;font-size:12px;font-weight:600}
    .oa-tp-s{fill:#94a3b8;font-size:10px}
    .oa-tp-cpu-bg{fill:rgb(148 163 184/.2)}
    .oa-tp-cpu{fill:#38bdf8;transition:width .7s ease}
    .oa-tp-node:hover .oa-tp-box,.oa-tp-node:focus-visible .oa-tp-box{stroke-width:2.5}
    .oa-tp-sel .oa-tp-box{stroke:#38bdf8;stroke-width:3}
  `,
})
export class TopoStylesComponent {}

interface NodeView {
  node: TopoNode;
  status: 'running' | 'unhealthy' | 'stopped' | 'network' | 'internal';
  cpu: number;
  dim: boolean;
}

/**
 * Netzwerke mit dynamischer Topologie (nach Arcanes network-diagram): Hostzonen, Netzwerk- und
 * Containerknoten mit Live-Status und Auslastung, Netzwerkzuordnung (durchgezogen) getrennt von
 * beobachteter Kommunikation (gestrichelt). Keine Durchsatzzahlen; Animation nur dekorativ.
 */
@Component({
  selector: 'oa-network',
  imports: [IconComponent, TopoStylesComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-topo-styles />
    <div class="oa-page-head">
      <div>
        <h1>Netzwerke</h1>
        <p>Topologie aller gefilterten Hosts. Knoten anklicken oder per Tastatur auswählen, Hintergrund ziehen zum Verschieben.</p>
      </div>
    </div>

    <div class="oa-row oa-tp-bar">
      <label class="oa-tp-search">
        <oa-icon name="search" [size]="14" />
        <span class="oa-sr">Knoten suchen</span>
        <input class="oa-input" type="search" placeholder="Container oder Netzwerk …" [value]="query()" (input)="query.set($any($event.target).value)" />
      </label>
      <button type="button" class="oa-chip" [attr.aria-pressed]="showLinks()" (click)="showLinks.set(!showLinks())"><i class="oa-tp-lg oa-tp-lg--link"></i> Netzwerkzuordnung</button>
      <button type="button" class="oa-chip" [attr.aria-pressed]="showComm()" (click)="showComm.set(!showComm())"><i class="oa-tp-lg oa-tp-lg--comm"></i> Beobachtete Verbindungen</button>
      <button type="button" class="oa-chip" [attr.aria-pressed]="onlyProblems()" (click)="onlyProblems.set(!onlyProblems())"><oa-icon name="alert" [size]="13" /> Nur Probleme</button>
      <span class="oa-sp"></span>
      <label class="oa-check oa-small" title="Bewegte Linien sind reine Gestaltung und zeigen keinen gemessenen Datenverkehr">
        <input type="checkbox" [checked]="anim()" (change)="anim.set(!anim())" /> Animation (dekorativ, kein Messwert)
      </label>
    </div>

    <div class="oa-tp">
      <div class="oa-tp-shell" [class.oa-tp-anim]="anim()">
        <svg
          class="oa-tp-svg"
          [attr.viewBox]="viewBox()"
          role="group"
          aria-label="Netzwerktopologie"
          (pointerdown)="dragStart($event)"
          (pointermove)="dragMove($event)"
          (pointerup)="dragEnd()"
          (pointerleave)="dragEnd()"
          (wheel)="onWheel($event)"
        >
          <defs>
            <pattern id="oa-tp-dots" width="18" height="18" patternUnits="userSpaceOnUse"><circle cx="1.2" cy="1.2" r="1.2" class="oa-tp-dot" /></pattern>
          </defs>
          <rect x="-2000" y="-2000" width="4840" height="4440" fill="url(#oa-tp-dots)" />
          @for (z of zones(); track z.id) {
            <rect [attr.x]="z.x" y="8" [attr.width]="z.w" height="424" rx="22" class="oa-tp-zone" [style.--hc]="z.color" />
            <text [attr.x]="z.x + 16" y="30" class="oa-tp-zone-t" [attr.fill]="z.color">{{ z.name }} · {{ z.status }}</text>
          }
          @if (showLinks()) {
            @for (l of links(); track l.key) {
              <line [attr.x1]="l.x1" [attr.y1]="l.y1" [attr.x2]="l.x2" [attr.y2]="l.y2" class="oa-tp-link" [class.oa-tp-on]="l.active" [class.oa-tp-dim]="l.dim" />
              @if (l.active) {
                <text [attr.x]="(l.x1 + l.x2) / 2" [attr.y]="(l.y1 + l.y2) / 2 - 6" text-anchor="middle" class="oa-tp-ip">{{ l.ip }}</text>
              }
            }
          }
          @if (showComm()) {
            @for (c of comms(); track c.key) {
              <path [attr.d]="c.d" class="oa-tp-comm" [class.oa-tp-dim]="c.dim" />
              <text [attr.x]="c.lx" [attr.y]="c.ly" text-anchor="middle" class="oa-tp-ip" [class.oa-tp-dim]="c.dim">{{ c.port }} · beobachtet</text>
            }
          }
          @for (v of nodes(); track v.node.id) {
            <g
              class="oa-tp-node"
              [attr.data-status]="v.status"
              [class.oa-tp-sel]="selected() === v.node.id"
              [class.oa-tp-dim]="v.dim"
              [attr.transform]="'translate(' + v.node.x + ' ' + v.node.y + ')'"
              tabindex="0"
              role="button"
              [attr.aria-pressed]="selected() === v.node.id"
              [attr.aria-label]="label(v)"
              (click)="select(v.node.id)"
              (keydown.enter)="select(v.node.id)"
              (keydown.space)="$event.preventDefault(); select(v.node.id)"
            >
              @if (v.node.kind === 'network') {
                <rect x="-78" y="-24" width="156" height="48" rx="14" class="oa-tp-box" />
                <text x="0" y="-3" text-anchor="middle" class="oa-tp-t">{{ v.node.label }}</text>
                <text x="0" y="13" text-anchor="middle" class="oa-tp-s">{{ v.node.sub }}</text>
              } @else {
                <rect x="-62" y="-26" width="124" height="52" rx="12" class="oa-tp-box" />
                <rect x="-62" y="-26" width="4" height="52" rx="2" [attr.fill]="store.hc(v.node.hostId)" />
                <circle cx="-44" cy="-8" r="4" class="oa-tp-led" />
                <text x="-34" y="-4" class="oa-tp-t">{{ v.node.label }}</text>
                <text x="-50" y="12" class="oa-tp-s">{{ v.node.sub }} · {{ statusText(v.status) }}</text>
                <rect x="-50" y="17" width="96" height="3" rx="1.5" class="oa-tp-cpu-bg" />
                <rect x="-50" y="17" [attr.width]="(v.cpu / 100) * 96" height="3" rx="1.5" class="oa-tp-cpu" />
              }
            </g>
          }
        </svg>
        <div class="oa-tp-ctrl" role="group" aria-label="Ansicht">
          <button type="button" (click)="zoomBy(1.25)" aria-label="Vergrößern"><oa-icon name="zoomIn" [size]="15" /></button>
          <button type="button" (click)="zoomBy(0.8)" aria-label="Verkleinern"><oa-icon name="zoomOut" [size]="15" /></button>
          <button type="button" (click)="reset()" aria-label="Ansicht zurücksetzen"><oa-icon name="maximize" [size]="15" /></button>
          <span>{{ (zoom() * 100).toFixed(0) }} %</span>
        </div>
        <div class="oa-tp-legend oa-small">
          <span><i class="oa-tp-lg oa-tp-lg--link"></i> Zuordnung zum Netzwerk</span>
          <span><i class="oa-tp-lg oa-tp-lg--comm"></i> Beobachtete Verbindung (ohne Messwert)</span>
          <span><i class="oa-tp-lg oa-tp-lg--cpu"></i> CPU-Auslastung (simuliert)</span>
        </div>
      </div>

      <aside class="oa-card oa-tp-detail" aria-live="polite" aria-label="Details">
        @if (detail(); as d) {
          <div class="oa-card-head">
            <span class="oa-card-ico" [attr.data-tone]="d.tone"><oa-icon [name]="d.node.kind === 'network' ? 'network' : 'box'" /></span>
            <div class="oa-sp" style="min-width:0">
              <h3>{{ d.node.label }}</h3>
              <span class="oa-small oa-muted">{{ d.node.kind === 'network' ? 'Netzwerk' : 'Container' }} · {{ store.hn(d.node.hostId) }}</span>
            </div>
            <button type="button" class="oa-ibtn" (click)="selected.set(null)" aria-label="Auswahl aufheben"><oa-icon name="x" [size]="15" /></button>
          </div>
          @if (d.net; as ni) {
            <dl class="oa-kv">
              <dt>Treiber</dt><dd>{{ ni.driver }}</dd>
              <dt>Subnetz</dt><dd class="oa-mono">{{ ni.subnet }}</dd>
              <dt>Gateway</dt><dd class="oa-mono">{{ ni.gateway }}</dd>
              <dt>Intern</dt><dd>{{ ni.isInternal ? 'ja – kein Zugriff nach außen' : 'nein' }}</dd>
              <dt>Herkunft</dt><dd>{{ ni.scope }}</dd>
            </dl>
          } @else {
            <dl class="oa-kv">
              <dt>Status</dt><dd><span class="oa-pill oa-pill--status" [attr.data-tone]="d.tone">{{ statusText(d.status) }}</span></dd>
              <dt>Image</dt><dd class="oa-mono">{{ d.image }}</dd>
              <dt>CPU</dt><dd>{{ d.cpu }} % <span class="oa-muted oa-small">(simuliert)</span></dd>
              <dt>RAM</dt><dd>{{ d.mem }}</dd>
              <dt>Ports</dt><dd class="oa-mono">{{ d.ports || '–' }}</dd>
            </dl>
          }
          <div class="oa-section-title">{{ d.node.kind === 'network' ? 'Zugeordnete Container' : 'Netzwerkzuordnung' }}</div>
          <ul class="oa-list">
            @for (p of d.peers; track p.node.id) {
              <li>
                <oa-icon [name]="p.node.kind === 'network' ? 'network' : 'box'" [size]="15" class="oa-muted" />
                <button type="button" class="oa-tp-peer oa-sp" (click)="select(p.node.id)">{{ p.node.label }}</button>
                <span class="oa-mono oa-small oa-muted">{{ p.ip }}</span>
              </li>
            } @empty {
              <li class="oa-muted oa-small">Keine Zuordnungen</li>
            }
          </ul>
          @if (d.node.kind === 'service') {
            <div class="oa-section-title">Beobachtete Kommunikation</div>
            <ul class="oa-list">
              @for (c of d.comm; track c.peer.id) {
                <li>
                  <oa-icon name="activity" [size]="15" class="oa-muted" />
                  <button type="button" class="oa-tp-peer oa-sp" (click)="select(c.peer.id)">{{ c.peer.label }}</button>
                  <span class="oa-mono oa-small oa-muted">{{ c.port }}</span>
                </li>
              } @empty {
                <li class="oa-muted oa-small">Keine Verbindungen beobachtet</li>
              }
            </ul>
            <p class="oa-help">Verbindungen stammen aus einer Beobachtung (z. B. conntrack). Container-Metriken sind kein Traffic pro Verbindung – daher keine Durchsatzzahlen.</p>
          }
          @if (d.node.stackId; as sid) {
            <div class="oa-row" style="margin-top:12px">
              <button type="button" class="oa-btn" data-tone="accent" (click)="store.openStack(sid)">Stack öffnen</button>
              @if (d.node.kind === 'service') {
                <button type="button" class="oa-btn" (click)="store.openStack(sid, 'logs')">Logs</button>
              }
            </div>
          }
        } @else {
          <div class="oa-tp-empty">
            <oa-icon name="network" [size]="28" class="oa-muted" />
            <p class="oa-muted">Wähle ein Netzwerk oder einen Container, um Status, IP-Adressen und Verbindungen zu sehen.</p>
          </div>
        }
      </aside>
    </div>

    <h2 class="oa-section-title">Alle Netzwerke</h2>
    <div class="oa-card oa-scroll-x" style="padding:4px">
      <table class="oa-table">
        <thead><tr><th>Name</th><th>Host</th><th>Treiber</th><th>Subnetz</th><th>Container</th></tr></thead>
        <tbody>
          @for (n of netRows(); track n.id) {
            <tr>
              <td><button type="button" class="oa-tp-peer" (click)="select(n.id)"><strong>{{ n.label }}</strong></button></td>
              <td><span class="oa-host" [style.--hc]="store.hc(n.hostId)"><i></i>{{ store.hn(n.hostId) }}</span></td>
              <td>{{ n.driver }}{{ n.isInternal ? ' · intern' : '' }}</td>
              <td class="oa-mono">{{ n.subnet }}</td>
              <td>{{ n.count }}</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  `,
  styles: `
    .oa-tp-bar{margin-bottom:12px}
    .oa-tp-search{position:relative;width:min(240px,100%)}
    .oa-tp-search oa-icon{position:absolute;left:10px;top:11px;color:var(--oa-muted)}
    .oa-tp-search .oa-input{padding-left:30px}
    .oa-tp{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:14px;align-items:start}
    @media (max-width:1100px){.oa-tp{grid-template-columns:1fr}}
    .oa-tp-ctrl{position:absolute;left:12px;bottom:12px;display:flex;align-items:center;gap:2px;padding:3px;border-radius:12px;background:rgb(15 23 42/.92);border:1px solid rgb(148 163 184/.18)}
    .oa-tp-ctrl button{display:grid;place-items:center;width:28px;height:28px;border:0;border-radius:8px;background:none;color:#e2e8f0;cursor:pointer}
    .oa-tp-ctrl button:hover{background:rgb(148 163 184/.18)}
    .oa-tp-ctrl span{padding:0 6px;font-size:11px;color:#94a3b8}
    .oa-tp-legend{display:flex;flex-wrap:wrap;gap:6px 14px;padding:8px 14px 10px;color:#94a3b8}
    .oa-tp-legend span{display:inline-flex;align-items:center;gap:6px}
    .oa-tp-lg{display:inline-block;width:16px;height:0;border-top:2px solid rgb(148 163 184/.7)}
    .oa-tp-lg--comm{border-top:2px dashed var(--oa-violet)}
    .oa-tp-lg--cpu{height:3px;border:0;border-radius:2px;background:#38bdf8}
    .oa-tp-detail{position:sticky;top:16px;min-height:280px}
    .oa-tp-detail h3{font-size:15px;margin:0;overflow:hidden;text-overflow:ellipsis}
    .oa-tp-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:10px;min-height:240px}
    .oa-tp-peer{border:0;background:none;padding:0;color:var(--oa-fg);font:inherit;text-align:left;cursor:pointer}
    .oa-tp-peer:hover{color:var(--oa-accent-fg);text-decoration:underline}
  `,
})
export class NetworkComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly selected = signal<string | null>('s-nextcloud');
  protected readonly query = signal('');
  protected readonly showLinks = signal(true);
  protected readonly showComm = signal(true);
  protected readonly onlyProblems = signal(false);
  protected readonly anim = linkedSignal(() => this.store.profile().animations);
  protected readonly zoom = signal(1);
  protected readonly pan = signal({ x: 0, y: 0 });
  private drag: { x: number; y: number; px: number; py: number; scale: number } | null = null;

  private readonly byId = new Map(TOPO_NODES.map((n) => [n.id, n]));

  protected readonly viewBox = computed(() => {
    const z = this.zoom();
    const w = W / z;
    const h = H / z;
    const p = this.pan();
    return `${(W - w) / 2 + p.x} ${(H - h) / 2 + p.y} ${w} ${h}`;
  });

  private svc(n: TopoNode): Service | undefined {
    if (n.kind !== 'service' || !n.stackId) return undefined;
    return this.store.stacks().find((s) => s.id === n.stackId)?.services.find((x) => x.name === n.label);
  }

  private statusOf(n: TopoNode): NodeView['status'] {
    if (n.kind === 'network') return NET_INFO[n.id]?.isInternal ? 'internal' : 'network';
    if (n.id === 's-legacy') {
      const c = this.store.standalone().find((x) => x.id === 'legacy');
      return c?.state === 'running' ? 'running' : 'stopped';
    }
    const s = this.svc(n);
    if (!s) return 'stopped';
    if (s.health === 'unhealthy') return 'unhealthy';
    return s.state === 'running' ? 'running' : 'stopped';
  }

  private cpuOf(n: TopoNode): number {
    if (n.id === 's-legacy') return this.store.standalone().find((x) => x.id === 'legacy')?.cpu ?? 0;
    const s = this.svc(n);
    return s && s.state === 'running' ? s.cpu : 0;
  }

  private readonly visibleIds = computed(() => new Set(TOPO_NODES.filter((n) => this.store.hostOn(n.hostId)).map((n) => n.id)));

  private readonly matchIds = computed(() => {
    const q = this.query().trim().toLowerCase();
    const prob = this.onlyProblems();
    const out = new Set<string>();
    for (const n of TOPO_NODES) {
      if (!this.visibleIds().has(n.id)) continue;
      const okQ = !q || `${n.label} ${n.sub}`.toLowerCase().includes(q);
      const okP = !prob || this.statusOf(n) === 'unhealthy';
      if (okQ && okP) out.add(n.id);
    }
    return out;
  });

  private readonly focusSet = computed(() => {
    const s = this.selected();
    if (!s) return null;
    const set = new Set<string>([s]);
    for (const l of TOPO_LINKS) {
      if (l.from === s) set.add(l.to);
      if (l.to === s) set.add(l.from);
    }
    for (const c of TOPO_COMM) {
      if (c.from === s) set.add(c.to);
      if (c.to === s) set.add(c.from);
    }
    return set;
  });

  protected readonly nodes = computed<NodeView[]>(() => {
    const vis = this.visibleIds();
    const match = this.matchIds();
    const filterActive = !!this.query().trim() || this.onlyProblems();
    const focus = this.focusSet();
    return TOPO_NODES.filter((n) => vis.has(n.id)).map((n) => ({
      node: n,
      status: this.statusOf(n),
      cpu: this.cpuOf(n),
      dim: (filterActive && !match.has(n.id)) || (!!focus && !focus.has(n.id)),
    }));
  });

  protected readonly zones = computed(() => {
    const out: { id: string; name: string; status: string; x: number; w: number; color: string }[] = [];
    const defs = [
      { id: 'atlas', x: 6, w: 410 },
      { id: 'boreal', x: 426, w: 408 },
    ];
    for (const d of defs) {
      const h = this.store.host(d.id);
      if (!h || !this.store.hostOn(d.id)) continue;
      out.push({ id: d.id, name: h.name.toUpperCase(), status: h.status === 'online' ? 'online' : 'getrennt', x: d.x, w: d.w, color: h.color });
    }
    return out;
  });

  protected readonly links = computed(() => {
    const vis = this.visibleIds();
    const s = this.selected();
    return TOPO_LINKS.filter((l) => vis.has(l.from) && vis.has(l.to)).map((l) => {
      const a = this.byId.get(l.from);
      const b = this.byId.get(l.to);
      const active = !!s && (l.from === s || l.to === s);
      return { key: l.from + l.to, ip: l.ip, x1: a?.x ?? 0, y1: a?.y ?? 0, x2: b?.x ?? 0, y2: b?.y ?? 0, active, dim: !!s && !active };
    });
  });

  protected readonly comms = computed(() => {
    const vis = this.visibleIds();
    const s = this.selected();
    return TOPO_COMM.filter((c) => vis.has(c.from) && vis.has(c.to)).map((c) => {
      const a = this.byId.get(c.from);
      const b = this.byId.get(c.to);
      const ax = a?.x ?? 0;
      const ay = a?.y ?? 0;
      const bx = b?.x ?? 0;
      const by = b?.y ?? 0;
      const bend = ax < W / 2 ? -70 : 70;
      const cx = (ax + bx) / 2 + bend;
      const cy = (ay + by) / 2;
      const active = !!s && (c.from === s || c.to === s);
      return { key: c.from + c.to, port: c.port, d: `M${ax} ${ay} Q${cx} ${cy} ${bx} ${by}`, lx: (ax + bx) / 4 + cx / 2, ly: cy + 4, dim: !!s && !active };
    });
  });

  protected readonly detail = computed(() => {
    const id = this.selected();
    const node = id ? this.byId.get(id) : undefined;
    if (!node) return null;
    const peers = TOPO_LINKS.filter((l) => l.from === node.id || l.to === node.id).flatMap((l) => {
      const p = this.byId.get(l.from === node.id ? l.to : l.from);
      return p ? [{ node: p, ip: l.ip }] : [];
    });
    const comm = TOPO_COMM.filter((c) => c.from === node.id || c.to === node.id).flatMap((c) => {
      const p = this.byId.get(c.from === node.id ? c.to : c.from);
      return p ? [{ peer: p, port: c.port }] : [];
    });
    const svc = this.svc(node);
    const status = this.statusOf(node);
    const legacy = node.id === 's-legacy' ? this.store.standalone().find((x) => x.id === 'legacy') : undefined;
    return {
      node,
      peers,
      comm,
      status,
      tone: status === 'unhealthy' ? 'err' : status === 'running' ? 'ok' : status === 'stopped' ? 'gray' : 'info',
      net: node.kind === 'network' ? (NET_INFO[node.id] ?? null) : null,
      image: svc?.image ?? legacy?.image ?? '–',
      cpu: this.cpuOf(node),
      mem: svc?.mem ?? legacy?.mem ?? '–',
      ports: (svc?.ports ?? legacy?.ports ?? []).join(', '),
    };
  });

  protected readonly netRows = computed(() =>
    TOPO_NODES.filter((n) => n.kind === 'network' && this.store.hostOn(n.hostId)).map((n) => {
      const info = NET_INFO[n.id];
      return {
        id: n.id,
        label: n.label,
        hostId: n.hostId,
        driver: info?.driver ?? '–',
        subnet: info?.subnet ?? '–',
        isInternal: info?.isInternal ?? false,
        count: TOPO_LINKS.filter((l) => l.to === n.id).length,
      };
    }),
  );

  protected statusText(s: NodeView['status']): string {
    return s === 'running' ? 'läuft' : s === 'unhealthy' ? 'unhealthy' : s === 'stopped' ? 'gestoppt' : s === 'internal' ? 'intern' : 'bridge';
  }

  protected label(v: NodeView): string {
    return v.node.kind === 'network' ? `Netzwerk ${v.node.label}, ${v.node.sub}` : `Container ${v.node.label}, ${this.statusText(v.status)}, CPU ${v.cpu} Prozent`;
  }

  protected select(id: string): void {
    this.selected.set(this.selected() === id ? null : id);
  }

  protected zoomBy(f: number): void {
    this.zoom.update((z) => Math.min(3, Math.max(0.6, +(z * f).toFixed(2))));
  }

  protected reset(): void {
    this.zoom.set(1);
    this.pan.set({ x: 0, y: 0 });
  }

  protected onWheel(e: WheelEvent): void {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    this.zoomBy(e.deltaY < 0 ? 1.1 : 0.9);
  }

  protected dragStart(e: PointerEvent): void {
    const t = e.target as Element | null;
    if (t?.closest('.oa-tp-node')) return;
    const svg = e.currentTarget as SVGSVGElement;
    const rect = svg.getBoundingClientRect();
    const scale = W / this.zoom() / Math.max(1, rect.width);
    this.drag = { x: e.clientX, y: e.clientY, px: this.pan().x, py: this.pan().y, scale };
    svg.setPointerCapture?.(e.pointerId);
  }

  protected dragMove(e: PointerEvent): void {
    const d = this.drag;
    if (!d) return;
    this.pan.set({ x: d.px - (e.clientX - d.x) * d.scale, y: d.py - (e.clientY - d.y) * d.scale });
  }

  protected dragEnd(): void {
    this.drag = null;
  }
}
