import { ChangeDetectionStrategy, Component, computed, ElementRef, inject, signal, viewChild, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { Issue, ops, validateModel } from './compose';
import { labelTone } from './data';
import { IconComponent } from './icon.component';
import { DockerRunDialogComponent, ImportDialogComponent } from './import-dialogs.component';
import { ServiceFormComponent } from './service-form.component';
import { ArcaneStore } from './store';

/** Stil-Host für den Easy-Wizard (Schritte, Vorschau, Zusammenfassung). */
@Component({
  selector: 'oa-wizard-styles',
  template: '',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { hidden: '' },
  styles: `
    .oa-ed-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px}
    .oa-ok{color:var(--oa-ok)}
    .oa-err{color:var(--oa-err)}
    .oa-warn{color:var(--oa-warn)}
    .oa-ed-layout{display:grid;grid-template-columns:minmax(0,1fr);gap:14px;align-items:start}
    .oa-ed-layout--preview{grid-template-columns:minmax(0,1fr) minmax(280px,380px)}
    @media (max-width:1180px){.oa-ed-layout--preview{grid-template-columns:minmax(0,1fr)}}
    .oa-ed-preview{position:sticky;top:16px}
    .oa-ed-preview .oa-code{max-height:62vh;font-size:11.5px}
    .oa-steps{list-style:none;margin:0 0 14px;padding:0;display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
    .oa-steps button{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;border-radius:12px;border:1px solid var(--oa-line);background:none;color:var(--oa-muted);text-align:left;cursor:pointer}
    .oa-steps button:hover{background:var(--oa-mbg);color:var(--oa-fg)}
    .oa-steps button[aria-current=step]{border-color:color-mix(in oklch,var(--oa-accent) 50%,transparent);background:var(--oa-accent-soft);color:var(--oa-fg)}
    .oa-step-n{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:var(--oa-mbg);font-size:12px;font-weight:600;flex-shrink:0}
    .oa-steps button[aria-current=step] .oa-step-n{background:var(--oa-accent);color:#fff}
    .oa-step-n[data-state=err]{background:color-mix(in oklch,var(--oa-err) 20%,transparent)!important;color:var(--oa-err)!important}
    .oa-step-t{display:flex;flex-direction:column;min-width:0;line-height:1.3}
    .oa-step-t strong{font-size:13px}
    .oa-step-t small{font-size:11.5px;color:var(--oa-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    @media (max-width:640px){.oa-step-t small{display:none}}
    .oa-ed-foot{margin-top:16px;padding-top:12px;border-top:1px solid var(--oa-line)}
    .oa-ed-extras{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:14px;font-size:12px;color:var(--oa-muted)}
    .oa-ed-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px}
    @media (max-width:640px){.oa-ed-summary{grid-template-columns:1fr 1fr}}
    .oa-ed-summary>div{padding:10px 12px;border-radius:12px;border:1px solid var(--oa-line)}
    .oa-ed-summary strong{display:block;font-size:18px}
    .oa-ed-summary span{font-size:12px;color:var(--oa-muted)}
  `,
})
export class WizardStylesComponent {}

/**
 * Editor-Tab der Stack-Seite. „Editor“ bildet Arcanes Arbeitsbereich nach (Dateiliste links,
 * Tab-Leiste, Code mit Zeilennummern, Speichern/Deploy). „Easy-Wizard“ bearbeitet denselben Entwurf.
 */
@Component({
  selector: 'oa-editor',
  imports: [ZardButtonComponent, IconComponent, ServiceFormComponent, DockerRunDialogComponent, ImportDialogComponent, WizardStylesComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-wizard-styles />
    @let m = store.model();
    <div class="oa-ed-bar">
      <div class="oa-seg" role="radiogroup" aria-label="Bearbeitungsmodus">
        <button type="button" role="radio" [attr.aria-checked]="store.editorMode() === 'easy'" (click)="store.editorMode.set('easy')"><oa-icon name="wand" [size]="14" /> Easy-Wizard</button>
        <button type="button" role="radio" [attr.aria-checked]="store.editorMode() === 'advanced'" (click)="store.editorMode.set('advanced')"><oa-icon name="fileCode" [size]="14" /> Editor</button>
      </div>
      @if (store.editorMode() === 'easy') {
        <button z-button zType="outline" zSize="sm" type="button" (click)="dlg.set('run')" [zDisabled]="!m"><oa-icon name="terminal" [size]="14" /> Aus docker run</button>
        <button z-button zType="outline" zSize="sm" type="button" (click)="dlg.set('import')" [zDisabled]="!m"><oa-icon name="download" [size]="14" /> GitHub / Docker Hub</button>
      }
      <span class="oa-sp"></span>
      @if (m) {
        <span class="oa-pill" data-tone="ok"><oa-icon name="check" [size]="12" /> YAML gültig · synchron</span>
      } @else {
        <span class="oa-pill" data-tone="err"><oa-icon name="alert" [size]="12" /> YAML ungültig</span>
      }
      <span class="oa-pill" [attr.data-tone]="errors().length ? 'err' : warns().length ? 'warn' : 'ok'">{{ errors().length }} Fehler · {{ warns().length }} Hinweise</span>
      <button z-button zType="outline" zSize="sm" type="button" (click)="store.saveEditor()" [zDisabled]="!store.editorDirty()"><oa-icon name="save" [size]="14" /> Speichern</button>
      <button z-button zSize="sm" type="button" [zDisabled]="!m || errors().length > 0" (click)="store.deployDraft()"><oa-icon name="play" [size]="14" /> {{ store.draft() ? 'Deploy' : 'Speichern & Redeploy' }}</button>
    </div>

    @if (store.editorMode() === 'advanced') {
      <section class="oa-ws" aria-label="Arbeitsbereich">
        <nav class="oa-ws-files" aria-label="Projektdateien">
          <div class="oa-ws-h">Dateien</div>
          <div class="oa-ws-row oa-ws-dir"><oa-icon name="folder" [size]="15" /> <span>{{ m?.name || 'entwurf' }}</span></div>
          <button type="button" class="oa-ws-row oa-ws-file" [attr.aria-current]="store.editorFile() === 'compose' ? 'true' : null" (click)="store.editorFile.set('compose')">
            <oa-icon name="fileCode" [size]="15" /> <span class="oa-sp">compose.yaml</span>
            @if (composeDirty()) { <i class="oa-ws-dot" title="Ungespeichert"></i> }
          </button>
          <button type="button" class="oa-ws-row oa-ws-file" [attr.aria-current]="store.editorFile() === 'env' ? 'true' : null" (click)="store.editorFile.set('env')">
            <oa-icon name="key" [size]="15" /> <span class="oa-sp">.env</span>
            @if (envDirty()) { <i class="oa-ws-dot" title="Ungespeichert"></i> }
          </button>
          @if (mounts().length) {
            <div class="oa-ws-h oa-ws-h2">Gemountet</div>
            @for (mt of mounts(); track mt) {
              <button type="button" class="oa-ws-row oa-ws-file" (click)="store.openFiles(mt)" [title]="mt + ' im Dateibrowser öffnen'">
                <oa-icon [name]="mt.startsWith('/') ? 'folder' : 'database'" [size]="15" /> <span class="oa-sp oa-mono">{{ mt }}</span> <oa-icon name="external" [size]="12" />
              </button>
            }
          }
          <p class="oa-ws-dirnote">{{ projectDir() }}</p>
        </nav>

        <div class="oa-ws-main">
          <div class="oa-ws-tabs" role="tablist" aria-label="Geöffnete Dateien">
            <button type="button" role="tab" class="oa-ws-tab" [attr.aria-selected]="store.editorFile() === 'compose'" (click)="store.editorFile.set('compose')">
              <oa-icon name="fileText" [size]="13" /> compose.yaml
              @if (composeDirty()) { <i class="oa-ws-dot"></i> }
            </button>
            <button type="button" role="tab" class="oa-ws-tab" [attr.aria-selected]="store.editorFile() === 'env'" (click)="store.editorFile.set('env')">
              <oa-icon name="fileText" [size]="13" /> .env
              @if (envDirty()) { <i class="oa-ws-dot"></i> }
            </button>
            <span class="oa-sp"></span>
            @if (!store.draft()) {
              <button type="button" class="oa-ibtn" (click)="store.resetEditor()" title="Änderungen verwerfen" aria-label="Änderungen verwerfen"><oa-icon name="history" [size]="14" /></button>
            }
            <button type="button" class="oa-ibtn" (click)="download()" title="Datei herunterladen" aria-label="Datei herunterladen"><oa-icon name="download" [size]="14" /></button>
          </div>
          <div class="oa-ws-code">
            <div class="oa-ws-gutter" #gutter aria-hidden="true">
              @for (n of lineNumbers(); track n) {
                <span [class.oa-ws-errline]="store.editorFile() === 'compose' && errorLines().includes(n)">{{ n }}</span>
              }
            </div>
            <label class="oa-sr" for="oa-raw">{{ store.editorFile() === 'compose' ? 'compose.yaml' : '.env' }}</label>
            <textarea
              id="oa-raw"
              #raw
              class="oa-ws-text"
              spellcheck="false"
              wrap="off"
              aria-describedby="oa-raw-help"
              [value]="currentText()"
              (input)="setText($any($event.target).value)"
              (scroll)="syncScroll()"
              (keydown)="onRawKey($event)"
            ></textarea>
          </div>
          <div class="oa-ws-status">
            @if (store.editorFile() === 'env') {
              <span>.env · Stack-Variablen · {{ lineNumbers().length }} Zeilen</span>
            } @else if (m) {
              <span class="oa-ok"><oa-icon name="check" [size]="12" /> YAML gültig</span>
              <span>Stack „{{ m.name || '—' }}“ · {{ m.services.length }} Service(s) · synchron mit dem Easy-Wizard</span>
            } @else {
              <span class="oa-err"><oa-icon name="alert" [size]="12" /> Ungültig – nichts wird überschrieben</span>
              @for (e of store.parsed().errors; track $index) {
                <span class="oa-mono">{{ e }}</span>
              }
            }
          </div>
        </div>
      </section>
      <p id="oa-raw-help" class="oa-help" style="margin-top:8px">Tab fügt zwei Leerzeichen ein, Escape und danach Tab verlässt das Feld. Unbekannte Felder bleiben beim Umschalten erhalten. Es gibt bewusst keinen zentralen Variableneditor.</p>
    } @else {
      @if (!m) {
        <div class="oa-callout" data-tone="err" role="alert">
          <oa-icon name="lock" />
          <div class="oa-sp">
            <strong>Easy-Wizard gesperrt, bis das YAML wieder gültig ist.</strong>
            <div class="oa-small">Der Rohtext bleibt unverändert erhalten – es gehen keine Daten verloren.</div>
            @for (e of store.parsed().errors; track $index) {
              <div class="oa-mono oa-small">{{ e }}</div>
            }
          </div>
          <button type="button" class="oa-btn" (click)="store.editorMode.set('advanced')">Im Editor beheben</button>
        </div>
      } @else {
        <div class="oa-ed-layout" [class.oa-ed-layout--preview]="preview()">
          <div class="oa-ed-main">
            <ol class="oa-steps" aria-label="Wizard-Schritte">
              @for (st of steps; track st.n) {
                <li>
                  <button type="button" [attr.aria-current]="store.editorStep() === st.n ? 'step' : null" (click)="store.editorStep.set(st.n)">
                    <span class="oa-step-n" [attr.data-state]="stepState(st.n)">
                      @if (stepState(st.n) === 'err') { <oa-icon name="alert" [size]="13" /> } @else { {{ st.n }} }
                    </span>
                    <span class="oa-step-t"><strong>{{ st.label }}</strong><small>{{ st.sub }}</small></span>
                  </button>
                </li>
              }
            </ol>

            @switch (store.editorStep()) {
              @case (1) {
                <section class="oa-card" aria-labelledby="ed-s1">
                  <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="layers" /></span><h3 id="ed-s1">Stack-Grundlagen</h3></div>
                  <div class="oa-grid2">
                    <div class="oa-field">
                      <label class="oa-label" for="ed-name">Stackname <span class="oa-req" aria-hidden="true">*</span></label>
                      <input id="ed-name" class="oa-input oa-mono" required placeholder="z. B. media" [attr.aria-invalid]="!m.name" aria-describedby="ed-name-h" [value]="m.name" (input)="store.edit(ops.setName($any($event.target).value))" />
                      @if (nameIssue(); as ni) {
                        <span id="ed-name-h" [class]="ni.level === 'error' ? 'oa-errtxt' : 'oa-warntxt'"><oa-icon name="alert" [size]="13" /> {{ ni.msg }}</span>
                      } @else {
                        <span id="ed-name-h" class="oa-help">Entspricht „name:“ im Compose – live synchron.</span>
                      }
                    </div>
                    <div class="oa-field">
                      <label class="oa-label" for="ed-host">Zielhost</label>
                      <select id="ed-host" class="oa-select" [value]="store.editorHost()" (change)="store.editorHost.set($any($event.target).value)">
                        @for (h of store.hosts(); track h.id) {
                          <option [value]="h.id" [disabled]="h.status === 'offline'">{{ h.name }}{{ h.status === 'offline' ? ' (getrennt)' : '' }}</option>
                        }
                      </select>
                      <span class="oa-help">Kein globaler Hostwechsel nötig – der Host gilt nur für diesen Stack.</span>
                    </div>
                  </div>

                  <div class="oa-field" style="margin-top:12px">
                    <span class="oa-label" id="ed-labels-l">Labels</span>
                    <div class="oa-row" role="group" aria-labelledby="ed-labels-l">
                      @for (l of store.editorLabels(); track l) {
                        <span class="oa-tag" [attr.data-tone]="tone(l)">{{ l }}
                          <button type="button" (click)="removeLabel(l)" [attr.aria-label]="'Label ' + l + ' entfernen'"><oa-icon name="x" [size]="11" /></button>
                        </span>
                      } @empty {
                        <span class="oa-small oa-muted">Noch keine Labels.</span>
                      }
                    </div>
                    <form class="oa-row" (submit)="addLabel($event)">
                      <input class="oa-input" style="max-width:220px" placeholder="Label hinzufügen" aria-label="Neues Label" [value]="labelInput()" (input)="labelInput.set($any($event.target).value)" />
                      <button type="submit" class="oa-btn"><oa-icon name="plus" [size]="13" /> Hinzufügen</button>
                      @for (l of suggestions(); track l) {
                        <button type="button" class="oa-chip" (click)="addNamed(l)"><span class="oa-dot" [attr.data-tone]="tone(l)"></span>{{ l }}</button>
                      }
                    </form>
                    <span class="oa-help">Labels erscheinen als Chips in der Stack-Übersicht und auf der Stack-Seite und dienen als Filter.{{ store.draft() ? '' : ' Änderungen werden sofort übernommen.' }}</span>
                  </div>

                  <div class="oa-field" style="margin-top:12px">
                    <label class="oa-label" for="ed-dir">Projektverzeichnis</label>
                    <input id="ed-dir" class="oa-input oa-mono" readonly [value]="projectDir()" />
                    <span class="oa-help">compose.yaml und .env werden hier abgelegt. Nicht zu verwechseln mit dem Installationsverzeichnis des Agents.</span>
                  </div>
                  <div class="oa-field" style="margin-top:12px">
                    <label class="oa-label" for="ed-env">Stack-.env</label>
                    <textarea id="ed-env" class="oa-textarea oa-mono" rows="3" spellcheck="false" [value]="store.editorEnv()" (input)="store.editorEnv.set($any($event.target).value)"></textarea>
                    <span class="oa-help">Variablen dieses Stacks – dieselbe Datei wie „.env“ im Editor.</span>
                  </div>
                  @if (m.extras.length) {
                    <div class="oa-ed-extras">
                      <oa-icon name="lock" [size]="13" /> Zusätzliche Wurzelfelder bleiben erhalten:
                      @for (x of m.extras; track x) {
                        <span class="oa-pill oa-mono">{{ x }}</span>
                      }
                    </div>
                  }
                  <div class="oa-row oa-ed-foot">
                    <span class="oa-sp"></span>
                    <button z-button zSize="sm" type="button" (click)="store.editorStep.set(2)">Weiter zu Services <oa-icon name="chevronRight" [size]="14" /></button>
                  </div>
                </section>
              }
              @case (2) {
                <oa-service-form />
              }
              @case (3) {
                <section class="oa-card" aria-labelledby="ed-s3">
                  <div class="oa-card-head"><span class="oa-card-ico" data-tone="ok"><oa-icon name="circleCheck" /></span><h3 id="ed-s3">Prüfen &amp; deployen</h3></div>
                  <div class="oa-ed-summary">
                    <div><strong>{{ m.services.length }}</strong><span>Services</span></div>
                    <div><strong>{{ portCount() }}</strong><span>Ports</span></div>
                    <div><strong>{{ mountCount() }}</strong><span>Mounts</span></div>
                    <div><strong>{{ store.hn(store.editorHost()) }}</strong><span>Zielhost</span></div>
                  </div>
                  @if (issues().length) {
                    <ul class="oa-list">
                      @for (i of issues(); track $index) {
                        <li>
                          <oa-icon [name]="i.level === 'error' ? 'circleX' : 'info'" [class]="i.level === 'error' ? 'oa-err' : 'oa-warn'" />
                          <span class="oa-sp">{{ i.service ? i.service + ': ' : '' }}{{ i.msg }}</span>
                          <button type="button" class="oa-btn" (click)="fix(i)">Beheben</button>
                        </li>
                      }
                    </ul>
                  } @else {
                    <div class="oa-callout" data-tone="ok"><oa-icon name="circleCheck" /> Alle Pflichtfelder sind ausgefüllt.</div>
                  }
                  <p class="oa-help" style="margin-top:10px">Der Deploy läuft in Schritten (Prüfung, Image-Pull, Erstellung/Austausch, Start, Zustandsprüfung) und erscheint als Popup rechts oben.</p>
                  <div class="oa-row oa-ed-foot">
                    <button z-button zType="ghost" zSize="sm" type="button" (click)="store.editorStep.set(2)"><oa-icon name="chevronLeft" [size]="14" /> Zurück</button>
                    <span class="oa-sp"></span>
                    <button z-button zType="outline" zSize="sm" type="button" (click)="download()"><oa-icon name="download" [size]="14" /> compose.yaml</button>
                    <button z-button type="button" [zDisabled]="errors().length > 0" (click)="store.deployDraft()"><oa-icon name="play" [size]="14" /> {{ store.draft() ? 'Deploy' : 'Redeploy' }}</button>
                  </div>
                </section>
              }
            }
          </div>

          @if (preview()) {
            <aside class="oa-card oa-ed-preview" aria-label="Live-YAML-Vorschau">
              <div class="oa-row" style="margin-bottom:8px">
                <strong class="oa-small">compose.yaml · live</strong>
                <span class="oa-sp"></span>
                <button type="button" class="oa-ibtn" (click)="preview.set(false)" aria-label="Vorschau ausblenden"><oa-icon name="x" [size]="14" /></button>
              </div>
              <pre class="oa-code">{{ store.editorText() }}</pre>
            </aside>
          }
        </div>
        @if (!preview()) {
          <button type="button" class="oa-btn" style="margin-top:12px" (click)="preview.set(true)"><oa-icon name="eye" [size]="14" /> YAML-Vorschau einblenden</button>
        }
      }
    }

    @switch (dlg()) {
      @case ('run') { <oa-dockerrun-dialog (closed)="dlg.set(null)" /> }
      @case ('import') { <oa-import-dialog (closed)="dlg.set(null)" /> }
    }
  `,
  styles: `
    .oa-ws{display:grid;grid-template-columns:230px minmax(0,1fr);height:min(64vh,600px);border:1px solid var(--oa-line);border-radius:var(--oa-r);background:var(--oa-card);overflow:hidden}
    @media (max-width:760px){.oa-ws{grid-template-columns:1fr;height:auto}.oa-ws-files{display:none!important}}
    .oa-ws-files{display:flex;flex-direction:column;gap:1px;padding:0 6px 8px;border-right:1px solid var(--oa-line);overflow:auto}
    .oa-ws-h{display:flex;align-items:center;height:36px;margin:0 -6px 4px;padding:0 10px;border-bottom:1px solid var(--oa-line);font-size:10.5px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--oa-muted)}
    .oa-ws-h2{margin-top:10px;border-top:1px solid var(--oa-line)}
    .oa-ws-row{display:flex;align-items:center;gap:7px;min-height:28px;padding:0 8px;border:0;border-radius:7px;background:none;color:var(--oa-fg);font-size:13px;text-align:left;min-width:0}
    .oa-ws-row span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-ws-dir oa-icon{color:var(--oa-warn)}
    .oa-ws-file{padding-left:24px;cursor:pointer;color:var(--oa-muted)}
    .oa-ws-file:hover{background:var(--oa-mbg);color:var(--oa-fg)}
    .oa-ws-file[aria-current=true]{background:var(--oa-mbg);color:var(--oa-fg)}
    .oa-ws-dot{width:6px;height:6px;border-radius:50%;background:var(--oa-accent);flex-shrink:0}
    .oa-ws-dirnote{margin:auto 4px 0;padding-top:8px;font:11px 'JetBrains Mono',ui-monospace,monospace;color:var(--oa-dim);overflow-wrap:anywhere}
    .oa-ws-main{display:flex;flex-direction:column;min-width:0;min-height:0}
    .oa-ws-tabs{display:flex;align-items:center;height:36px;flex-shrink:0;border-bottom:1px solid var(--oa-line);background:color-mix(in oklch,var(--oa-mbg) 30%,transparent);padding-right:4px}
    .oa-ws-tab{position:relative;display:flex;align-items:center;gap:6px;height:100%;padding:0 14px;border:0;border-right:1px solid var(--oa-line);background:none;color:var(--oa-muted);font-size:12.5px;cursor:pointer}
    .oa-ws-tab[aria-selected=true]{background:var(--oa-card);color:var(--oa-fg)}
    .oa-ws-tab[aria-selected=true]::before{content:'';position:absolute;inset:0 0 auto;height:2px;background:var(--oa-accent)}
    .oa-ws-code{display:flex;flex:1;min-height:260px;background:var(--oa-code)}
    .oa-ws-gutter{flex-shrink:0;width:46px;padding:12px 0;overflow:hidden;text-align:right;color:var(--oa-dim);font:12.5px/1.6 'JetBrains Mono','Cascadia Code',ui-monospace,monospace;user-select:none;border-right:1px solid var(--oa-line)}
    .oa-ws-gutter span{display:block;padding-right:10px}
    .oa-ws-errline{color:var(--oa-err);background:color-mix(in oklch,var(--oa-err) 14%,transparent)}
    .oa-ws-text{flex:1;min-width:0;padding:12px 14px;border:0;resize:none;background:transparent;color:var(--oa-fg);font:12.5px/1.6 'JetBrains Mono','Cascadia Code',ui-monospace,monospace;tab-size:2;white-space:pre;overflow:auto}
    .oa-ws-text:focus{outline:none;box-shadow:inset 0 0 0 2px color-mix(in oklch,var(--oa-accent) 50%,transparent)}
    .oa-ws-status{display:flex;align-items:center;gap:10px;flex-wrap:wrap;min-height:30px;padding:4px 12px;border-top:1px solid var(--oa-line);font-size:12px;color:var(--oa-muted)}
  `,
})
export class EditorComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly ops = ops;
  protected readonly dlg = signal<'run' | 'import' | null>(null);
  protected readonly preview = signal(true);
  protected readonly labelInput = signal('');
  private tabEscape = false;
  private readonly gutter = viewChild<ElementRef<HTMLElement>>('gutter');
  private readonly raw = viewChild<ElementRef<HTMLTextAreaElement>>('raw');

  protected readonly steps: { n: 1 | 2 | 3; label: string; sub: string }[] = [
    { n: 1, label: 'Grundlagen', sub: 'Name, Host, Labels, .env' },
    { n: 2, label: 'Services', sub: 'Image, Ports, Mounts …' },
    { n: 3, label: 'Prüfen', sub: 'Hinweise & Deploy' },
  ];

  protected readonly issues = computed(() => {
    const m = this.store.model();
    return m ? validateModel(m) : [];
  });
  protected readonly errors = computed(() => this.issues().filter((i) => i.level === 'error'));
  protected readonly warns = computed(() => this.issues().filter((i) => i.level === 'warn'));
  protected readonly nameIssue = computed(() => this.issues().find((i) => i.field === 'name') ?? null);
  protected readonly projectDir = computed(() => `${this.store.host(this.store.editorHost())?.projectDir ?? '/opt/stacks'}/${this.store.model()?.name || '<stackname>'}`);
  protected readonly portCount = computed(() => (this.store.model()?.services ?? []).reduce((n, s) => n + s.ports.length, 0));
  protected readonly mountCount = computed(() => (this.store.model()?.services ?? []).reduce((n, s) => n + s.mounts.length, 0));
  protected readonly mounts = computed(() => {
    const out = new Set<string>();
    for (const s of this.store.model()?.services ?? []) for (const mt of s.mounts) if (mt.editable && mt.source) out.add(mt.source);
    return [...out];
  });
  protected readonly composeDirty = computed(() => {
    const s = this.store.selectedStack();
    return this.store.draft() || !s ? true : this.store.editorText() !== s.compose;
  });
  protected readonly envDirty = computed(() => {
    const s = this.store.selectedStack();
    return this.store.draft() || !s ? false : this.store.editorEnv() !== s.env;
  });
  protected readonly currentText = computed(() => (this.store.editorFile() === 'compose' ? this.store.editorText() : this.store.editorEnv()));
  protected readonly lineNumbers = computed(() => Array.from({ length: this.currentText().split('\n').length }, (_, i) => i + 1));
  protected readonly errorLines = computed(() =>
    this.store
      .parsed()
      .errors.map((e) => /Zeile (\d+)/.exec(e)?.[1])
      .filter((x): x is string => !!x)
      .map(Number),
  );
  protected readonly suggestions = computed(() => this.store.allLabels().filter((l) => !this.store.editorLabels().includes(l)).slice(0, 5));

  protected tone(l: string): string {
    return labelTone(l);
  }

  protected setText(v: string): void {
    if (this.store.editorFile() === 'compose') this.store.editorText.set(v);
    else this.store.editorEnv.set(v);
  }

  protected addLabel(e: Event): void {
    e.preventDefault();
    this.addNamed(this.labelInput());
    this.labelInput.set('');
  }

  protected addNamed(l: string): void {
    const v = l.trim().toLowerCase();
    if (!v) return;
    this.store.setEditorLabels([...this.store.editorLabels(), v]);
  }

  protected removeLabel(l: string): void {
    this.store.setEditorLabels(this.store.editorLabels().filter((x) => x !== l));
  }

  protected stepState(n: 1 | 2 | 3): 'err' | 'ok' {
    const errs = this.errors();
    if (n === 1) return errs.some((i) => i.field === 'name') ? 'err' : 'ok';
    if (n === 2) return errs.some((i) => !!i.service) ? 'err' : 'ok';
    return 'ok';
  }

  protected fix(i: Issue): void {
    if (i.field === 'name' || !i.service) {
      this.store.editorStep.set(i.field === 'name' ? 1 : 2);
      return;
    }
    this.store.editorStep.set(2);
    this.store.editorService.set(i.service);
    const f = i.field;
    this.store.editorSub.set(f === 'ports' || f === 'mounts' || f === 'env' || f === 'health' ? f : 'image');
  }

  protected download(): void {
    const isEnv = this.store.editorMode() === 'advanced' && this.store.editorFile() === 'env';
    const blob = new Blob([isEnv ? this.store.editorEnv() : this.store.editorText()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = isEnv ? '.env' : 'compose.yaml';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  protected syncScroll(): void {
    const g = this.gutter()?.nativeElement;
    const r = this.raw()?.nativeElement;
    if (g && r) g.scrollTop = r.scrollTop;
  }

  protected onRawKey(e: KeyboardEvent): void {
    if (e.key === 'Escape') {
      this.tabEscape = true;
      return;
    }
    if (e.key === 'Tab' && !e.shiftKey && !this.tabEscape) {
      e.preventDefault();
      const ta = e.target as HTMLTextAreaElement;
      const { selectionStart: s, selectionEnd: end, value } = ta;
      const next = value.slice(0, s) + '  ' + value.slice(end);
      ta.value = next;
      ta.selectionStart = ta.selectionEnd = s + 2;
      this.setText(next);
      return;
    }
    this.tabEscape = false;
  }
}
