import { ChangeDetectionStrategy, Component, computed, ElementRef, inject, output, signal, viewChild } from '@angular/core';

import { PageId } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

/** Benutzer unten links in der Seitenleiste (nach Arcanes sidebar-user): Avatar, Name, Menü. */
@Component({
  selector: 'oa-user-menu',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(document:click)': 'onDoc($event)', '(document:keydown.escape)': 'close(true)' },
  template: `
    <div class="oa-um">
      <button
        #trigger
        type="button"
        class="oa-um-btn"
        aria-haspopup="menu"
        [attr.aria-expanded]="open()"
        aria-controls="oa-um-menu"
        (click)="toggle()"
      >
        <span class="oa-um-av" aria-hidden="true">{{ initial() }}</span>
        <span class="oa-um-txt">
          <strong>{{ store.profile().name }}</strong>
          <small>{{ store.profile().email }}</small>
        </span>
        <oa-icon name="updown" [size]="15" class="oa-dim" />
      </button>
      @if (open()) {
        <div id="oa-um-menu" class="oa-menu oa-um-menu" role="menu" aria-label="Benutzermenü" (keydown)="onKey($event)">
          <div class="oa-um-head">
            <span class="oa-um-av" aria-hidden="true">{{ initial() }}</span>
            <span class="oa-um-txt">
              <strong>{{ store.profile().name }}</strong>
              <small>{{ store.profile().email }}</small>
            </span>
          </div>
          <div class="oa-menu-sep"></div>
          <button type="button" role="menuitem" class="oa-menu-item" (click)="go('account')"><oa-icon name="user" /> Profil</button>
          <button type="button" role="menuitem" class="oa-menu-item" (click)="go('settings')"><oa-icon name="settings" /> Hub-Einstellungen</button>
          <div class="oa-menu-sep"></div>
          <button type="button" role="menuitem" class="oa-menu-item" data-tone="err" (click)="logout()"><oa-icon name="logout" /> Abmelden</button>
        </div>
      }
    </div>
  `,
  styles: `
    .oa-um{position:relative}
    .oa-um-btn{display:flex;align-items:center;gap:10px;width:100%;height:48px;padding:0 8px;border:0;border-radius:10px;background:none;color:var(--oa-fg);text-align:left;cursor:pointer}
    .oa-um-btn:hover,.oa-um-btn[aria-expanded=true]{background:var(--oa-mbg)}
    .oa-um-av{display:grid;place-items:center;width:32px;height:32px;border-radius:50%;flex-shrink:0;background:var(--oa-accent-soft);color:var(--oa-accent-fg);font-weight:600;font-size:13px}
    .oa-um-txt{display:grid;flex:1;min-width:0;line-height:1.25}
    .oa-um-txt strong{font-size:13.5px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-um-txt small{font-size:12px;color:var(--oa-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-um-menu{left:0;right:0;bottom:calc(100% + 8px);min-width:240px}
    .oa-um-head{display:flex;align-items:center;gap:10px;padding:8px}
  `,
})
export class UserMenuComponent {
  protected readonly store = inject(ArcaneStore);
  readonly navigated = output<void>();
  protected readonly open = signal(false);
  protected readonly initial = computed(() => (this.store.profile().name.trim().charAt(0) || 'A').toUpperCase());
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  private readonly trigger = viewChild.required<ElementRef<HTMLButtonElement>>('trigger');

  protected toggle(): void {
    this.open.update((o) => !o);
    if (this.open()) {
      setTimeout(() => this.host.nativeElement.querySelector<HTMLElement>('[role=menuitem]')?.focus());
    }
  }

  protected close(refocus = false): void {
    if (!this.open()) return;
    this.open.set(false);
    if (refocus) this.trigger().nativeElement.focus();
  }

  protected onDoc(e: MouseEvent): void {
    if (this.open() && !this.host.nativeElement.contains(e.target as Node)) this.open.set(false);
  }

  protected onKey(e: KeyboardEvent): void {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    e.preventDefault();
    const items = Array.from(this.host.nativeElement.querySelectorAll<HTMLElement>('[role=menuitem]'));
    const i = items.indexOf(document.activeElement as HTMLElement);
    const next = (i + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
    items[next]?.focus();
  }

  protected go(page: PageId): void {
    this.store.go(page);
    this.open.set(false);
    this.navigated.emit();
  }

  protected logout(): void {
    this.open.set(false);
    this.store.loggedOut.set(true);
  }
}
