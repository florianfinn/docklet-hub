import {
  afterNextRender,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  input,
  OnDestroy,
  output,
  viewChild,
  ViewEncapsulation,
} from '@angular/core';

import { IconComponent, IconName } from './icon.component';

let uid = 0;
/** Zählt offene modale Ebenen, damit Escape nur die oberste schließt. */
export const overlayState = { stack: [] as number[] };

const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

/**
 * Modaler Dialog im Arcane-Stil: Icon-Kopf, Titel, Beschreibung, Fußleiste.
 * Wird vom Elternteil per @if eingeblendet. Escape, Backdrop-Klick und
 * Schließen-Button lösen (closed) aus. Fokus wird gefangen und danach zurückgegeben.
 */
@Component({
  selector: 'oa-dialog',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { '(document:keydown)': 'onDocKey($event)' },
  template: `
    <div class="oa-dlg-wrap" [class.oa-dlg-wrap--side]="side()" (mousedown)="onBackdrop($event)">
      <section
        #panel
        class="oa-dlg"
        [class.oa-dlg--wide]="wide()"
        [class.oa-dlg--side]="side()"
        role="dialog"
        aria-modal="true"
        [attr.aria-labelledby]="id + '-t'"
        [attr.aria-describedby]="description() ? id + '-d' : null"
        tabindex="-1"
        (keydown)="onKey($event)"
      >
        <header class="oa-dlg-head">
          @if (icon(); as ic) {
            <span class="oa-dlg-ico" [attr.data-tone]="tone()"><oa-icon [name]="ic" [size]="18" /></span>
          }
          <div class="oa-dlg-titles">
            <h2 [id]="id + '-t'">{{ heading() }}</h2>
            @if (description()) {
              <p [id]="id + '-d'">{{ description() }}</p>
            }
          </div>
          <button type="button" class="oa-ibtn" (click)="closed.emit()" aria-label="Schließen">
            <oa-icon name="x" />
          </button>
        </header>
        <div class="oa-dlg-body"><ng-content /></div>
        <footer class="oa-dlg-foot"><ng-content select="[dlgFooter]" /></footer>
      </section>
    </div>
  `,
  styles: `
    .oa-dlg-wrap{position:fixed;inset:0;z-index:60;display:grid;place-items:center;padding:16px;background:rgb(5 5 10/.62);backdrop-filter:blur(3px);animation:oa-fade .16s ease-out}
    .oa-dlg-wrap--side{place-items:stretch end;padding:0}
    .oa-dlg{width:min(560px,100%);max-height:calc(100dvh - 32px);display:flex;flex-direction:column;background:var(--oa-card);color:var(--oa-fg);border:1px solid var(--oa-line);border-radius:16px;box-shadow:0 30px 80px -20px rgb(0 0 0/.7);outline:none;animation:oa-pop .18s ease-out}
    .oa-dlg--wide{width:min(920px,100%)}
    .oa-dlg--side{width:min(440px,100%);max-height:100dvh;height:100dvh;border-radius:16px 0 0 16px;animation:oa-slide .2s ease-out}
    .oa-dlg-head{display:flex;gap:12px;align-items:flex-start;padding:18px 18px 12px}
    .oa-dlg-ico{display:grid;place-items:center;width:36px;height:36px;border-radius:10px;background:var(--oa-accent-soft);color:var(--oa-accent-fg);flex-shrink:0}
    .oa-dlg-ico[data-tone=warn]{background:rgb(245 158 11/.14);color:#fbbf24}
    .oa-dlg-ico[data-tone=ok]{background:rgb(34 197 94/.14);color:#4ade80}
    .oa-dlg-titles{flex:1;min-width:0}
    .oa-dlg-titles h2{font-size:16px;font-weight:600;margin:2px 0 0;letter-spacing:-.01em}
    .oa-dlg-titles p{margin:4px 0 0;font-size:13px;color:var(--oa-muted);line-height:1.45}
    .oa-dlg-body{padding:6px 18px 16px;overflow:auto;flex:1}
    .oa-dlg-foot{display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;padding:12px 18px;border-top:1px solid var(--oa-line);background:rgb(255 255 255/.015);border-radius:0 0 16px 16px}
    .oa-dlg-foot:empty{display:none}
    @keyframes oa-fade{from{opacity:0}}
    @keyframes oa-pop{from{opacity:0;transform:translateY(8px) scale(.98)}}
    @keyframes oa-slide{from{transform:translateX(40px);opacity:0}}
  `,
})
export class DialogComponent implements OnDestroy {
  readonly heading = input.required<string>();
  readonly description = input<string>('');
  readonly icon = input<IconName | null>(null);
  readonly tone = input<'accent' | 'warn' | 'ok'>('accent');
  readonly wide = input(false);
  readonly side = input(false);
  readonly closed = output<void>();

  protected readonly id = `oa-dlg-${++uid}`;
  private readonly key = uid;
  private readonly panel = viewChild.required<ElementRef<HTMLElement>>('panel');
  private readonly previous = (typeof document !== 'undefined' ? document.activeElement : null) as HTMLElement | null;

  constructor() {
    overlayState.stack.push(this.key);
    afterNextRender(() => {
      const el = this.panel().nativeElement;
      const first = el.querySelector<HTMLElement>('.oa-dlg-body ' + FOCUSABLE.split(',').join(',.oa-dlg-body '));
      (first ?? el).focus();
    });
  }

  ngOnDestroy(): void {
    overlayState.stack = overlayState.stack.filter((k) => k !== this.key);
    this.previous?.focus?.();
  }

  protected onBackdrop(e: MouseEvent): void {
    if (e.target === e.currentTarget) this.closed.emit();
  }

  protected onDocKey(e: KeyboardEvent): void {
    if (e.key === 'Escape' && overlayState.stack[overlayState.stack.length - 1] === this.key) {
      e.preventDefault();
      this.closed.emit();
    }
  }

  protected onKey(e: KeyboardEvent): void {
    if (e.key !== 'Tab') return;
    const items = Array.from(this.panel().nativeElement.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((x) => x.offsetParent !== null);
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }
}
