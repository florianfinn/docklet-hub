import { ChangeDetectionStrategy, Component, computed, inject, linkedSignal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { AutoUpdate, labelTone, Stack } from './data';
import { EditorComponent } from './editor.component';
import { IconComponent, IconName } from './icon.component';
import { LogstreamComponent } from './logstream.component';
import { ArcaneStore, StackTab } from './store';

const TABS: { id: StackTab; label: string; icon: IconName }[] = [
  { id: 'services', label: 'Services', icon: 'box' },
  { id: 'editor', label: 'Editor', icon: 'fileCode' },
  { id: 'logs', label: 'Logs', icon: 'fileText' },
  { id: 'files', label: 'Dateien', icon: 'folder' },
  { id: 'updates', label: 'Updates', icon: 'download' },
  { id: 'backup', label: 'Backups', icon: 'archive' },
];

/**
 * Eigene Stack-Seite nach Arcanes Projektseite: Kopf mit Status, Labels, Host und Aktionen,
 * darunter Tabs. „Neuer Stack“ öffnet dieselbe Seite im Entwurfsmodus mit Editor.
 */
@Component({
  selector: 'oa-stack-page',
  imports: [ZardButtonComponent, IconComponent, EditorComponent, LogstreamComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <button type="button" class="oa-btn oa-sp-back" (click)="store.go('stacks')"><oa-icon name="chevronLeft" [size]="14" /> Stacks</button>

    @let s = stack();
    <header class="oa-sp-head">
      <span class="oa-sp-ico" [style.--hc]="store.hc(s?.hostId ?? store.editorHost())"><oa-icon name="layers" [size]="22" /></span>
      <div class="oa-sp-info">
        @if (s) {
          <div class="oa-row">
            <h1>{{ s.name }}</h1>
            <span class="oa-pill oa-pill--status" [attr.data-tone]="statusTone()">{{ statusLabel() }}</span>
            @for (l of s.labels; track l) {
              <span class="oa-tag" [attr.data-tone]="tone(l)">{{ l }}</span>
            }
            <button type="button" class="oa-btn oa-sp-mini" (click)="editLabels()"><oa-icon name="tag" [size]="12" /> Labels</button>
            @if (pending().length) {
              <button type="button" class="oa-pill oa-sp-upd" data-tone="info" (click)="store.stackTab.set('updates')"><oa-icon name="download" [size]="12" /> {{ pending().length }} Update{{ pending().length > 1 ? 's' : '' }}</button>
            } @else {
              <span class="oa-pill" data-tone="ok"><oa-icon name="check" [size]="12" /> Aktuell</span>
            }
          </div>
          <div class="oa-row oa-small oa-muted oa-sp-meta">
            <span class="oa-host" [style.--hc]="store.hc(s.hostId)"><i></i>{{ store.hn(s.hostId) }}</span>
            <span>·</span><span>{{ s.services.length }} Services</span>
            <span>·</span><span>Deploy {{ s.lastDeploy }}</span>
            @if (s.url) {
              <span class="oa-sp-url"><oa-icon name="globe" [size]="12" /> {{ s.url }}</span>
            }
          </div>
        } @else {
          <div class="oa-row">
            <h1>{{ store.model()?.name || 'Neuer Stack' }}</h1>
            <span class="oa-pill oa-pill--status" data-tone="accent">Entwurf</span>
          </div>
          <div class="oa-small oa-muted oa-sp-meta">Noch nicht deployt · Ziel: {{ store.hn(store.editorHost()) }} · Easy-Wizard und Editor bearbeiten denselben Entwurf.</div>
        }
      </div>
      <div class="oa-row oa-sp-actions">
        @if (s) {
          @if (store.editorDirty()) {
            <button z-button zType="outline" zSize="sm" type="button" (click)="store.saveEditor()"><oa-icon name="save" [size]="14" /> Speichern</button>
          }
          @if (allStopped()) {
            <button z-button zType="outline" zSize="sm" type="button" (click)="store.stackAction(s.id, 'start')"><oa-icon name="play" [size]="14" /> Starten</button>
          } @else {
            <button z-button zType="outline" zSize="sm" type="button" (click)="store.stackAction(s.id, 'stop')"><oa-icon name="stop" [size]="14" /> Stoppen</button>
            <button z-button zType="outline" zSize="sm" type="button" (click)="store.stackAction(s.id, 'restart')"><oa-icon name="restart" [size]="14" /> Neustart</button>
          }
          <button z-button zSize="sm" type="button" (click)="store.stackAction(s.id, 'redeploy')"><oa-icon name="refresh" [size]="14" /> Pull &amp; Redeploy</button>
        } @else {
          <button z-button zType="ghost" zSize="sm" type="button" (click)="store.go('stacks')">Verwerfen</button>
        }
      </div>
    </header>

    <div class="oa-tabs oa-sp-tabs" role="tablist" aria-label="Stack-Bereiche" (keydown)="onTabKey($event)">
      @for (t of tabs; track t.id) {
        <button
          type="button"
          role="tab"
          class="oa-tab"
          [id]="'st-tab-' + t.id"
          [attr.aria-selected]="store.stackTab() === t.id"
          aria-controls="st-panel"
          [attr.tabindex]="store.stackTab() === t.id ? 0 : -1"
          [disabled]="!s && t.id !== 'editor'"
          [title]="!s && t.id !== 'editor' ? 'Erst nach dem ersten Deploy verfügbar' : ''"
          (click)="store.stackTab.set(t.id)"
        >
          <oa-icon [name]="t.icon" [size]="15" /> {{ t.label }}
          @if (t.id === 'updates' && pending().length) {
            <span class="oa-pill" data-tone="info">{{ pending().length }}</span>
          }
          @if (t.id === 'editor' && s && store.editorDirty()) {
            <span class="oa-sp-dirty" title="Ungespeicherte Änderungen"></span>
          }
        </button>
      }
    </div>

    <div id="st-panel" class="oa-sp-panel" role="tabpanel" [attr.aria-labelledby]="'st-tab-' + store.stackTab()">
      @if (!s || store.stackTab() === 'editor') {
        <oa-editor />
      } @else {
        @switch (store.stackTab()) {
          @case ('services') {
            <div class="oa-card oa-scroll-x" style="padding:4px 4px 0">
              <table class="oa-table">
                <thead>
                  <tr>
                    <th>Service</th><th>Status</th><th>Image</th><th>Ports</th>
                    @if (full()) { <th>CPU</th><th>RAM</th><th>Health</th> }
                    <th><span class="oa-sr">Aktionen</span></th>
                  </tr>
                </thead>
                <tbody>
                  @for (svc of s.services; track svc.name) {
                    <tr>
                      <td><span class="oa-row"><span class="oa-dot" [attr.data-tone]="svc.health === 'unhealthy' ? 'err' : svc.state === 'running' ? 'ok' : 'warn'"></span><strong>{{ svc.name }}</strong></span></td>
                      <td><span class="oa-pill oa-pill--status" [attr.data-tone]="svc.health === 'unhealthy' ? 'err' : svc.state === 'running' ? 'ok' : 'warn'">{{ svc.health === 'unhealthy' ? 'Unhealthy' : svc.state === 'running' ? 'Läuft' : svc.state === 'stopped' ? 'Gestoppt' : 'Startet neu' }}</span></td>
                      <td class="oa-mono oa-muted">{{ svc.image }}</td>
                      <td class="oa-mono oa-small">{{ svc.ports.join(', ') || '–' }}</td>
                      @if (full()) {
                        <td class="oa-mono">{{ svc.state === 'running' ? svc.cpu + ' %' : '–' }}</td>
                        <td>{{ svc.state === 'running' ? svc.mem : '–' }}</td>
                        <td class="oa-small">{{ svc.health === 'none' ? 'kein Healthcheck' : svc.health }}</td>
                      }
                      <td style="text-align:right">
                        <button type="button" class="oa-ibtn" (click)="openLogs(svc.name)" [attr.aria-label]="'Logs von ' + svc.name" title="Logs"><oa-icon name="fileText" [size]="15" /></button>
                        <button type="button" class="oa-ibtn" (click)="store.restartService(s.id, svc.name)" [attr.aria-label]="svc.name + ' neu starten'" title="Neu starten"><oa-icon name="restart" [size]="15" /></button>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
            <div class="oa-row oa-small oa-muted" style="margin-top:8px">
              <span class="oa-sp">{{ full() ? 'Full-Ansicht: alle Spalten' : 'Easy-Ansicht: kompakt' }}</span>
              <div class="oa-seg" role="radiogroup" aria-label="Ansicht">
                <button type="button" role="radio" [attr.aria-checked]="!full()" (click)="store.viewMode.set('easy')">Easy</button>
                <button type="button" role="radio" [attr.aria-checked]="full()" (click)="store.viewMode.set('full')">Full</button>
              </div>
            </div>
            <div class="oa-grid2" style="margin-top:14px">
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="info" /></span><h3>Details</h3></div>
                <dl class="oa-kv">
                  <dt>Host</dt><dd>{{ store.hn(s.hostId) }} ({{ store.host(s.hostId)?.mode === 'edge' ? 'Edge' : 'Direkt' }})</dd>
                  <dt>Projektverzeichnis</dt><dd class="oa-mono">{{ store.host(s.hostId)?.projectDir ?? '/opt/stacks' }}/{{ s.id }}</dd>
                  <dt>Updates</dt><dd>{{ autoLabel(s.autoUpdate) }}</dd>
                  <dt>Backup</dt><dd>{{ s.backupLast }} · {{ s.backupTarget }}</dd>
                </dl>
              </div>
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico" [attr.data-tone]="unhealthy().length ? 'err' : 'ok'"><oa-icon name="heart" /></span><h3>Healthcheck</h3></div>
                @if (unhealthy().length) {
                  <p class="oa-small oa-muted">{{ unhealthy().join(', ') }}: Healthcheck 3× fehlgeschlagen. Auto Heal ist {{ store.autoHeal() ? 'aktiv (max. ' + store.hub().healMax + ' Neustarts)' : 'deaktiviert' }}.</p>
                  <div class="oa-row">
                    <button type="button" class="oa-btn" (click)="openLogs(unhealthy()[0])">Logs ansehen</button>
                    <button type="button" class="oa-btn" data-tone="accent" (click)="store.restartService(s.id, unhealthy()[0])">Jetzt neu starten</button>
                  </div>
                } @else {
                  <p class="oa-small oa-muted">Alle Services mit Healthcheck sind gesund.</p>
                }
              </div>
            </div>
          }
          @case ('logs') {
            <oa-logstream [stack]="s" />
          }
          @case ('files') {
            <div class="oa-grid2">
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="fileCode" /></span><h3>Projektdateien</h3></div>
                <ul class="oa-list">
                  <li><oa-icon name="file" class="oa-muted" /><span class="oa-mono oa-sp">compose.yaml</span><button type="button" class="oa-btn" (click)="openEditor('compose')">Im Editor</button></li>
                  <li><oa-icon name="key" class="oa-muted" /><span class="oa-mono oa-sp">.env</span><button type="button" class="oa-btn" (click)="openEditor('env')">Im Editor</button></li>
                </ul>
              </div>
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="database" /></span><h3>Volumes &amp; Bind-Mounts</h3></div>
                <ul class="oa-list">
                  @for (m of s.mounts; track m) {
                    <li>
                      <oa-icon [name]="isBind(m) ? 'folder' : 'database'" class="oa-muted" />
                      <div class="oa-sp" style="min-width:0">
                        <div class="oa-mono oa-small">{{ src(m) }}</div>
                        <div class="oa-small oa-muted">{{ isBind(m) ? 'Bind-Mount' : 'Volume' }} → {{ dst(m) }}</div>
                      </div>
                      <button type="button" class="oa-btn" (click)="store.openFiles(src(m))"><oa-icon name="external" [size]="13" /> Durchsuchen</button>
                    </li>
                  }
                </ul>
              </div>
            </div>
          }
          @case ('updates') {
            <div class="oa-grid2">
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico" data-tone="info"><oa-icon name="download" /></span><h3>Image-Updates</h3></div>
                <ul class="oa-list">
                  @for (svc of s.services; track svc.name) {
                    <li>
                      <div class="oa-sp">
                        <strong>{{ svc.name }}</strong>
                        <div class="oa-mono oa-small oa-muted">{{ svc.image }}@if (svc.updateTo) { → <span style="color:var(--oa-info)">{{ svc.updateTo }}</span> }</div>
                      </div>
                      <span class="oa-pill" [attr.data-tone]="svc.updateTo ? 'info' : 'ok'">{{ svc.updateTo ? 'verfügbar' : 'aktuell' }}</span>
                    </li>
                  }
                </ul>
                @if (pending().length) {
                  <button z-button type="button" style="margin-top:10px" (click)="store.installUpdates(s.id)">Updates manuell installieren</button>
                }
              </div>
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="clock" /></span><h3>Automatik</h3></div>
                <div class="oa-seg" role="radiogroup" aria-label="Update-Modus">
                  @for (m of autoModes; track m.id) {
                    <button type="button" role="radio" [attr.aria-checked]="s.autoUpdate === m.id" (click)="store.setAutoUpdate(s.id, m.id)">{{ m.label }}</button>
                  }
                </div>
                <p class="oa-help" style="margin-top:8px">Standard ist „Nur prüfen“. Automatische Installation nur nach Aktivierung, mit Zeitplan ({{ s.autoTime }}).</p>
                <div class="oa-section-title">Wiederherstellung</div>
                @for (svc of restorable(); track svc.name) {
                  <div class="oa-row oa-small">
                    <oa-icon name="history" [size]="15" />
                    <span class="oa-sp">{{ svc.name }}: vorher <span class="oa-mono">{{ svc.previousImage }}</span></span>
                    <button type="button" class="oa-btn" (click)="store.restoreImage(s.id, svc.name)">Manuell wiederherstellen</button>
                  </div>
                } @empty {
                  <p class="oa-small oa-muted">Nach einem Update stehen hier das vorherige Image und die vorherige Konfiguration bereit.</p>
                }
                <p class="oa-help">Keine automatische Rückkehr. Anwendungsdaten werden nicht zurückgesetzt.</p>
              </div>
            </div>
          }
          @case ('backup') {
            <div class="oa-grid2">
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico" data-tone="ok"><oa-icon name="archive" /></span><h3>Backup</h3></div>
                <dl class="oa-kv">
                  <dt>Letztes Backup</dt><dd>{{ s.backupLast }}</dd>
                  <dt>Ziel</dt><dd>{{ s.backupTarget }}</dd>
                  <dt>Aufbewahrung</dt><dd>7 täglich · 4 wöchentlich</dd>
                  <dt>Zeitplan</dt><dd>täglich 02:00</dd>
                </dl>
                <div class="oa-row" style="margin-top:12px">
                  <button z-button type="button" (click)="store.backupNow(s.id, target())"><oa-icon name="archive" [size]="14" /> Backup jetzt starten</button>
                  <button z-button zType="outline" type="button" (click)="store.showToast('Demo: Wiederherstellungspunkt auswählen (simuliert)')">Wiederherstellen …</button>
                </div>
              </div>
              <div class="oa-card">
                <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="folder" /></span><h3>Umfang &amp; Ziel</h3></div>
                <div class="oa-field">
                  <label class="oa-label" for="bk-target">Backupziel</label>
                  <select id="bk-target" class="oa-select" [value]="target()" (change)="target.set($any($event.target).value)">
                    @for (t of targets(); track t) {
                      <option [value]="t">{{ t }}</option>
                    }
                  </select>
                  <span class="oa-help">Ziele werden in den Hub-Einstellungen gepflegt: lokal, Host-Mounts, SMB/NFS. Kein S3.</span>
                </div>
                <div class="oa-section-title">Enthaltene Mounts</div>
                @for (m of s.mounts; track m) {
                  <label class="oa-check" style="display:flex;margin-bottom:6px">
                    <input type="checkbox" [checked]="!m.includes(':ro')" />
                    <span class="oa-mono oa-small">{{ src(m) }}</span>
                    <span class="oa-small oa-muted">{{ isBind(m) ? 'Bind-Mount' : 'Volume' }}</span>
                  </label>
                }
              </div>
            </div>
          }
        }
      }
    </div>
  `,
  styles: `
    .oa-sp-back{margin-bottom:14px}
    .oa-sp-head{display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:16px}
    .oa-sp-ico{display:grid;place-items:center;width:40px;height:40px;border-radius:12px;flex-shrink:0;color:var(--hc);background:color-mix(in oklch,var(--hc) 15%,transparent)}
    .oa-sp-info{flex:1;min-width:min(100%,320px)}
    .oa-sp-info h1{font-size:22px;font-weight:600;letter-spacing:-.02em;margin:0}
    .oa-sp-meta{margin-top:4px}
    .oa-sp-mini{height:24px;padding:0 8px;font-size:12px;border-style:dashed}
    .oa-sp-upd{cursor:pointer}
    .oa-sp-url{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 9px;border-radius:9px;color:var(--oa-fg);font-weight:600;border:1px solid color-mix(in oklch,var(--oa-info) 25%,transparent);background:color-mix(in oklch,var(--oa-info) 14%,transparent)}
    .oa-sp-url oa-icon{color:var(--oa-info)}
    .oa-sp-actions{align-self:center}
    .oa-sp-tabs{margin-bottom:14px}
    .oa-sp-dirty{width:6px;height:6px;border-radius:50%;background:var(--oa-accent)}
    .oa-sp-panel{outline:none}
  `,
})
export class StackPageComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly tabs = TABS;
  protected readonly autoModes: { id: AutoUpdate; label: string }[] = [
    { id: 'check', label: 'Nur prüfen' },
    { id: 'nightly', label: 'Nachts' },
    { id: 'weekly', label: 'Wöchentlich' },
  ];

  protected readonly stack = computed<Stack | null>(() => (this.store.draft() ? null : this.store.selectedStack()));
  protected readonly full = computed(() => this.store.viewMode() === 'full');
  protected readonly targets = computed(() => this.store.hub().backupTargets.map((t) => `${this.kindLabel(t.kind)} · ${t.path}`));
  protected readonly target = linkedSignal(() => this.stack()?.backupTarget ?? this.targets()[0] ?? '');
  protected readonly pending = computed(() => (this.stack()?.services ?? []).filter((x) => !!x.updateTo));
  protected readonly restorable = computed(() => (this.stack()?.services ?? []).filter((x) => !!x.previousImage));
  protected readonly unhealthy = computed(() => (this.stack()?.services ?? []).filter((x) => x.health === 'unhealthy').map((x) => x.name));
  protected readonly allStopped = computed(() => (this.stack()?.services ?? []).every((x) => x.state === 'stopped'));

  protected readonly statusTone = computed(() => {
    const s = this.stack();
    if (!s) return 'accent';
    if (this.unhealthy().length) return 'err';
    if (this.allStopped()) return 'gray';
    return s.services.every((x) => x.state === 'running') ? 'ok' : 'warn';
  });

  protected readonly statusLabel = computed(() => {
    const s = this.stack();
    if (!s) return 'Entwurf';
    if (this.unhealthy().length) return 'Problem';
    if (this.allStopped()) return 'Gestoppt';
    return s.services.every((x) => x.state === 'running') ? 'Läuft' : 'Teilweise';
  });

  protected tone(l: string): string {
    return labelTone(l);
  }

  private kindLabel(k: 'local' | 'hostmount' | 'smb' | 'nfs'): string {
    return k === 'local' ? 'Lokal' : k === 'hostmount' ? 'Host-Mount' : k.toUpperCase();
  }

  protected autoLabel(m: AutoUpdate): string {
    return m === 'check' ? 'Nur prüfen' : m === 'nightly' ? 'Automatisch nachts' : 'Automatisch wöchentlich';
  }

  protected isBind(m: string): boolean {
    return m.startsWith('/') || m.startsWith('./');
  }

  protected src(m: string): string {
    return m.split(':')[0];
  }

  protected dst(m: string): string {
    return m.split(':')[1] ?? '';
  }

  protected editLabels(): void {
    this.store.stackTab.set('editor');
    this.store.editorMode.set('easy');
    this.store.editorStep.set(1);
  }

  protected openEditor(file: 'compose' | 'env'): void {
    this.store.editorMode.set('advanced');
    this.store.editorFile.set(file);
    this.store.stackTab.set('editor');
  }

  protected openLogs(_svc: string): void {
    this.store.stackTab.set('logs');
  }

  protected onTabKey(e: KeyboardEvent): void {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' && e.key !== 'Home' && e.key !== 'End') return;
    if (!this.stack()) return;
    e.preventDefault();
    const ids = TABS.map((t) => t.id);
    const i = ids.indexOf(this.store.stackTab());
    const next = e.key === 'Home' ? 0 : e.key === 'End' ? ids.length - 1 : (i + (e.key === 'ArrowRight' ? 1 : -1) + ids.length) % ids.length;
    this.store.stackTab.set(ids[next]);
    (e.currentTarget as HTMLElement).querySelector<HTMLElement>(`#st-tab-${ids[next]}`)?.focus();
  }
}
