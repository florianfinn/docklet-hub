import { ChangeDetectionStrategy, Component, inject, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { Profile } from './data';
import { IconComponent, IconName } from './icon.component';
import { ArcaneStore } from './store';

/** Profil (nach Arcanes Account-Seite): Name, Sprache, Theme. Lokal gespeichert. */
@Component({
  selector: 'oa-account',
  imports: [ZardButtonComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    @let p = store.profile();
    <div class="oa-page-head">
      <div>
        <h1>Profil</h1>
        <p>Persönliche Einstellungen. Hub-weite Optionen stehen unter <button type="button" class="oa-acc-link" (click)="store.go('settings')">Hub-Einstellungen</button>.</p>
      </div>
    </div>

    <div class="oa-acc">
      <section class="oa-card">
        <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="user" /></span><h3>Konto</h3></div>
        <div class="oa-acc-id">
          <span class="oa-acc-av" aria-hidden="true">{{ (p.name.charAt(0) || 'A').toUpperCase() }}</span>
          <div><strong>{{ p.name }}</strong><div class="oa-small oa-muted">{{ p.email }} · {{ store.hub().auth === 'proxy' ? 'über Reverse-Proxy' : store.hub().auth === 'none' ? 'ohne Login' : 'lokaler Admin' }}</div></div>
        </div>
        <div class="oa-grid2">
          <div class="oa-field">
            <label class="oa-label" for="acc-name">Anzeigename</label>
            <input id="acc-name" class="oa-input" [value]="p.name" (change)="set({ name: $any($event.target).value })" />
          </div>
          <div class="oa-field">
            <label class="oa-label" for="acc-mail">E-Mail</label>
            <input id="acc-mail" class="oa-input" type="email" [value]="p.email" (change)="set({ email: $any($event.target).value })" />
          </div>
        </div>
      </section>

      <section class="oa-card">
        <div class="oa-card-head"><span class="oa-card-ico"><oa-icon name="sliders" /></span><h3>Darstellung</h3></div>
        <div class="oa-field">
          <span class="oa-label" id="acc-theme-l">Theme</span>
          <div class="oa-acc-themes" role="radiogroup" aria-labelledby="acc-theme-l">
            @for (t of themes; track t.id) {
              <button type="button" role="radio" class="oa-acc-theme" [attr.aria-checked]="p.theme === t.id" (click)="set({ theme: t.id })">
                <oa-icon [name]="t.icon" [size]="18" /> {{ t.label }}
              </button>
            }
          </div>
          <span class="oa-help">Hell ist eine Vorschau auf Basis der Arcane-Light-Tokens; die Topologie-Leinwand bleibt dunkel.</span>
        </div>
        <div class="oa-field" style="margin-top:12px;max-width:280px">
          <label class="oa-label" for="acc-lang">Sprache</label>
          <select id="acc-lang" class="oa-select" [value]="p.lang" (change)="set({ lang: $any($event.target).value })">
            <option value="de">Deutsch</option>
            <option value="en">English (in der Demo nicht übersetzt)</option>
          </select>
        </div>
        <div class="oa-row" style="margin-top:14px">
          <button type="button" class="oa-switch" role="switch" [attr.aria-checked]="p.animations" aria-labelledby="acc-anim" (click)="set({ animations: !p.animations })"></button>
          <span id="acc-anim">Dekorative Animationen (z. B. Topologie-Linien)</span>
        </div>
      </section>

      <section class="oa-card">
        <div class="oa-card-head"><span class="oa-card-ico" data-tone="err"><oa-icon name="logout" /></span><h3>Sitzung</h3></div>
        <p class="oa-small oa-muted">Abmelden ist simuliert. Bei „Kein Login“ hat es keine Wirkung.</p>
        <button z-button zType="destructive" type="button" (click)="store.loggedOut.set(true)"><oa-icon name="logout" [size]="14" /> Abmelden</button>
      </section>
    </div>
  `,
  styles: `
    .oa-acc{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(420px,100%),1fr));gap:16px;align-items:start}
    .oa-acc-link{border:0;background:none;padding:0;color:var(--oa-accent-fg);font:inherit;cursor:pointer;text-decoration:underline}
    .oa-acc-id{display:flex;align-items:center;gap:12px;margin-bottom:14px}
    .oa-acc-av{display:grid;place-items:center;width:44px;height:44px;border-radius:50%;background:var(--oa-accent-soft);color:var(--oa-accent-fg);font-weight:600;font-size:17px}
    .oa-acc-themes{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
    .oa-acc-theme{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px;border-radius:12px;border:1px solid var(--oa-line2);background:none;color:var(--oa-fg);font-size:13px;cursor:pointer}
    .oa-acc-theme[aria-checked=true]{border-color:var(--oa-accent);background:var(--oa-accent-soft)}
  `,
})
export class AccountComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly themes: { id: Profile['theme']; label: string; icon: IconName }[] = [
    { id: 'dark', label: 'Dunkel', icon: 'moon' },
    { id: 'light', label: 'Hell', icon: 'sun' },
    { id: 'system', label: 'System', icon: 'dashboard' },
  ];

  protected set(p: Partial<Profile>): void {
    this.store.profile.update((cur) => ({ ...cur, ...p }));
  }
}
