import { ChangeDetectionStrategy, Component, computed, inject, ViewEncapsulation } from '@angular/core';

import { ActionItem } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore, Toast } from './store';

interface ToastView {
  toast: Toast;
  action: ActionItem | null;
}

/**
 * Kompakte Popups rechts oben. Aktionen zeigen Phase, Ablaufschritte, Fortschritt und
 * betroffene Services. Das Aktionszentrum öffnet sich nicht automatisch („Details“ öffnet es).
 */
@Component({
  selector: 'oa-toasts',
  imports: [IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <section class="oa-toasts" aria-label="Benachrichtigungen" aria-live="polite">
      @for (v of views(); track v.toast.id) {
        @if (v.action; as a) {
          <article class="oa-toast" [attr.data-status]="a.status" role="status">
            <header class="oa-toast-head">
              <span class="oa-toast-ico">
                @switch (a.status) {
                  @case ('running') { <oa-icon name="loader" [size]="16" class="oa-spin" /> }
                  @case ('done') { <oa-icon name="circleCheck" [size]="16" /> }
                  @case ('error') { <oa-icon name="circleX" [size]="16" /> }
                }
              </span>
              <div class="oa-sp oa-toast-t">
                <strong>{{ a.title }}</strong>
                <small>{{ a.status === 'error' ? 'Fehlgeschlagen' : a.phase }} · {{ a.progress }} %</small>
              </div>
              <button type="button" class="oa-ibtn" (click)="store.dismissToast(v.toast.id)" [attr.aria-label]="'Hinweis ' + a.title + ' schließen'"><oa-icon name="x" [size]="14" /></button>
            </header>
            <ol class="oa-toast-steps" aria-label="Ablauf">
              @for (s of a.steps; track $index) {
                <li [attr.data-state]="s.state" [title]="s.detail">
                  <span class="oa-toast-sd" aria-hidden="true"></span>
                  <span>{{ s.label }}</span>
                  <span class="oa-sr">{{ stateLabel(s.state) }}</span>
                </li>
              }
            </ol>
            <div class="oa-bar" role="progressbar" [attr.aria-valuenow]="a.progress" aria-valuemin="0" aria-valuemax="100" [attr.aria-label]="'Fortschritt ' + a.title">
              <span [style.width.%]="a.status === 'error' ? 100 : a.progress" [style.--bc]="a.status === 'error' ? 'var(--oa-err)' : a.status === 'done' ? 'var(--oa-ok)' : null"></span>
            </div>
            <footer class="oa-toast-foot">
              @if (a.services.length) {
                <span class="oa-small oa-muted oa-sp">Services: {{ a.services.join(', ') }}</span>
              } @else {
                <span class="oa-small oa-muted oa-sp">{{ a.target }}</span>
              }
              <button type="button" class="oa-toast-link" (click)="store.openAction(a.id)">Details</button>
            </footer>
          </article>
        } @else {
          <article class="oa-toast oa-toast--plain" [attr.data-tone]="v.toast.tone === 'info' ? null : v.toast.tone" role="status">
            <oa-icon [name]="v.toast.tone === 'err' ? 'circleX' : v.toast.tone === 'ok' ? 'circleCheck' : 'info'" [size]="16" />
            <span class="oa-sp">{{ v.toast.text }}</span>
            <button type="button" class="oa-ibtn" (click)="store.dismissToast(v.toast.id)" aria-label="Hinweis schließen"><oa-icon name="x" [size]="14" /></button>
          </article>
        }
      }
    </section>
  `,
  styles: `
    .oa-toasts{position:fixed;top:14px;right:14px;z-index:90;display:flex;flex-direction:column;gap:8px;width:min(360px,calc(100vw - 28px));pointer-events:none}
    .oa-toast{pointer-events:auto;display:flex;flex-direction:column;gap:9px;padding:12px;border-radius:14px;background:var(--oa-pop);border:1px solid var(--oa-line);box-shadow:0 16px 40px -12px rgb(0 0 0/.65);font-size:13px;animation:oa-toast-in .2s ease-out}
    .oa-toast[data-status=error]{border-color:color-mix(in oklch,var(--oa-err) 45%,transparent)}
    @keyframes oa-toast-in{from{opacity:0;transform:translateY(-6px)}}
    .oa-toast--plain{flex-direction:row;align-items:center;gap:10px;padding:8px 8px 8px 12px}
    .oa-toast--plain>oa-icon{color:var(--t,var(--oa-info))}
    .oa-toast-head{display:flex;align-items:center;gap:10px}
    .oa-toast-ico{display:grid;place-items:center;width:28px;height:28px;border-radius:9px;flex-shrink:0;color:var(--oa-accent-fg);background:var(--oa-accent-soft)}
    [data-status=done] .oa-toast-ico{color:var(--oa-ok);background:color-mix(in oklch,var(--oa-ok) 14%,transparent)}
    [data-status=error] .oa-toast-ico{color:var(--oa-err);background:color-mix(in oklch,var(--oa-err) 14%,transparent)}
    .oa-toast-t{min-width:0;display:grid;line-height:1.3}
    .oa-toast-t strong{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-toast-t small{font-size:12px;color:var(--oa-muted)}
    .oa-toast-steps{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:4px 10px;font-size:12px;color:var(--oa-dim)}
    .oa-toast-steps li{display:inline-flex;align-items:center;gap:5px}
    .oa-toast-sd{width:8px;height:8px;border-radius:50%;border:1.5px solid currentColor}
    .oa-toast-steps [data-state=running]{color:var(--oa-accent-fg)}
    .oa-toast-steps [data-state=running] .oa-toast-sd{animation:oa-pulse-s 1s infinite}
    .oa-toast-steps [data-state=done]{color:var(--oa-muted)}
    .oa-toast-steps [data-state=done] .oa-toast-sd{background:var(--oa-ok);border-color:var(--oa-ok)}
    .oa-toast-steps [data-state=error]{color:var(--oa-err)}
    .oa-toast-steps [data-state=error] .oa-toast-sd{background:var(--oa-err);border-color:var(--oa-err)}
    @keyframes oa-pulse-s{50%{opacity:.3}}
    .oa-toast-foot{display:flex;align-items:center;gap:8px;min-width:0}
    .oa-toast-foot .oa-sp{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-toast-link{border:0;background:none;padding:0;color:var(--oa-accent-fg);font-size:12.5px;font-weight:500;cursor:pointer}
    .oa-toast-link:hover{text-decoration:underline}
    @media (max-width:960px){.oa-toasts{top:64px}}
  `,
})
export class ToastsComponent {
  protected readonly store = inject(ArcaneStore);

  protected readonly views = computed<ToastView[]>(() => {
    const acts = this.store.actions();
    return this.store.toasts().map((t) => ({
      toast: t,
      action: t.actionId !== undefined ? (acts.find((a) => a.id === t.actionId) ?? null) : null,
    }));
  });

  protected stateLabel(s: string): string {
    return s === 'done' ? 'erledigt' : s === 'running' ? 'läuft' : s === 'error' ? 'Fehler' : 'ausstehend';
  }
}
