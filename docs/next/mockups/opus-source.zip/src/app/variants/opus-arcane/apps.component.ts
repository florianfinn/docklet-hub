import { ChangeDetectionStrategy, Component, computed, ElementRef, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { labelTone, Stack } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

type StatusFilter = 'all' | 'running' | 'problem' | 'updates' | 'stopped';

/**
 * Stacks-Übersicht nach Arcanes Projects-Tabelle: nur Stacks, ohne Aufklappen.
 * Zeilen sind als Karten voneinander abgesetzt (Docklet-Vorbild). Easy-Ansicht als Standard,
 * Full-Ansicht mit weiteren Spalten. Mehrfachauswahl standardmäßig aus.
 */
@Component({
  selector: 'oa-stacks',
  imports: [ZardButtonComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  host: { '(document:click)': 'onDoc($event)', '(document:keydown.escape)': 'menu.set(null)' },
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Stacks</h1>
        <p>{{ store.allHosts() ? 'Alle Hosts gemeinsam' : 'Hostfilter aktiv' }} · Einzelcontainer stehen unter <button type="button" class="oa-link" (click)="store.go('containers')">Container</button>.</p>
      </div>
      <div class="oa-sp"></div>
      <button z-button type="button" (click)="store.newStack()"><oa-icon name="plus" [size]="15" /> Neuer Stack</button>
    </div>

    <dl class="oa-strip">
      <div><dt><oa-icon name="layers" [size]="14" /> Stacks</dt><dd>{{ store.visibleStacks().length }}</dd></div>
      <div><dt><oa-icon name="play" [size]="14" /> Laufend</dt><dd>{{ countRunning() }}</dd></div>
      <div><dt><oa-icon name="alert" [size]="14" /> Probleme</dt><dd [style.color]="countProblems() ? 'var(--oa-err)' : null">{{ countProblems() }}</dd></div>
      <div><dt><oa-icon name="download" [size]="14" /> Updates</dt><dd>{{ store.updates().length }}<small>Images</small></dd></div>
    </dl>

    <section class="oa-card oa-st-card" aria-label="Stack-Tabelle">
      <div class="oa-st-bar">
        <label class="oa-st-search">
          <oa-icon name="search" [size]="15" />
          <span class="oa-sr">Stacks durchsuchen</span>
          <input class="oa-input" type="search" placeholder="Stacks oder Services suchen …" [value]="query()" (input)="query.set($any($event.target).value)" />
        </label>
        <div class="oa-seg" role="radiogroup" aria-label="Statusfilter">
          @for (f of statusFilters; track f.id) {
            <button type="button" role="radio" [attr.aria-checked]="status() === f.id" (click)="status.set(f.id)">{{ f.label }}</button>
          }
        </div>
        <span class="oa-sp"></span>
        <button type="button" class="oa-btn" [attr.aria-pressed]="selecting()" (click)="toggleSelecting()" [attr.data-tone]="selecting() ? 'accent' : null">
          <oa-icon name="listCheck" [size]="14" /> Mehrfachauswahl
        </button>
        <div class="oa-seg" role="radiogroup" aria-label="Ansicht">
          <button type="button" role="radio" [attr.aria-checked]="store.viewMode() === 'easy'" (click)="store.viewMode.set('easy')">Easy</button>
          <button type="button" role="radio" [attr.aria-checked]="store.viewMode() === 'full'" (click)="store.viewMode.set('full')">Full</button>
        </div>
      </div>

      <div class="oa-row oa-st-labels" role="group" aria-label="Nach Labels filtern">
        <oa-icon name="tag" [size]="14" class="oa-muted" />
        @for (l of store.allLabels(); track l) {
          <button type="button" class="oa-chip" [attr.aria-pressed]="labelSel().includes(l)" (click)="toggleLabel(l)">
            <span class="oa-dot" [attr.data-tone]="tone(l)"></span>{{ l }}
          </button>
        }
        @if (labelSel().length) {
          <button type="button" class="oa-link oa-small" (click)="labelSel.set([])">Filter zurücksetzen</button>
        }
      </div>

      @if (selecting() && selected().length) {
        <div class="oa-st-bulk" role="toolbar" aria-label="Aktionen für Auswahl">
          <strong>{{ selected().length }} ausgewählt</strong>
          <button type="button" class="oa-btn" (click)="bulk('start')"><oa-icon name="play" [size]="13" /> Starten</button>
          <button type="button" class="oa-btn" (click)="bulk('stop')"><oa-icon name="stop" [size]="13" /> Stoppen</button>
          <button type="button" class="oa-btn" (click)="bulk('restart')"><oa-icon name="restart" [size]="13" /> Neustart</button>
          <button type="button" class="oa-btn" (click)="bulk('redeploy')"><oa-icon name="refresh" [size]="13" /> Pull &amp; Redeploy</button>
          <button type="button" class="oa-btn" data-tone="info" (click)="bulk('update')"><oa-icon name="download" [size]="13" /> Updates</button>
          <span class="oa-sp"></span>
          <button type="button" class="oa-link oa-small" (click)="selected.set([])">Auswahl aufheben</button>
        </div>
      }

      <div class="oa-st-scroll" [class.oa-st-scroll--x]="full()">
        <table class="oa-table oa-st-table" [class.oa-st-full]="full()">
          <thead>
            <tr>
              @if (selecting()) {
                <th class="oa-st-sel"><input type="checkbox" aria-label="Alle sichtbaren auswählen" [checked]="allChecked()" (change)="toggleAll()" /></th>
              }
              <th>Name</th>
              <th>Status</th>
              <th>Host</th>
              <th>Services</th>
              <th>Updates</th>
              <th>Labels</th>
              @if (full()) {
                <th>CPU</th><th>Ports</th><th>Auto-Update</th><th>Letzter Deploy</th><th>Backup</th>
              }
              <th><span class="oa-sr">Aktionen</span></th>
            </tr>
          </thead>
          <tbody>
            @for (s of rows(); track s.id) {
              <tr [style.--hc]="store.hc(s.hostId)" [class.oa-st-checked]="selected().includes(s.id)">
                @if (selecting()) {
                  <td class="oa-st-sel"><input type="checkbox" [attr.aria-label]="s.name + ' auswählen'" [checked]="selected().includes(s.id)" (change)="toggleSel(s.id)" /></td>
                }
                <td>
                  <div class="oa-st-name">
                    <span class="oa-st-ico"><oa-icon name="layers" [size]="16" /></span>
                    <div>
                      <button type="button" class="oa-st-link" (click)="store.openStack(s.id)">{{ s.name }}</button>
                      @if (full()) {
                        <div class="oa-small oa-muted">{{ s.description }}</div>
                      }
                    </div>
                  </div>
                </td>
                <td><span class="oa-pill oa-pill--status" [attr.data-tone]="statusTone(s)">{{ statusLabel(s) }}</span></td>
                <td><span class="oa-host" [style.--hc]="store.hc(s.hostId)"><i></i>{{ store.hn(s.hostId) }}</span></td>
                <td>
                  <span class="oa-tipwrap" tabindex="0" [attr.aria-label]="running(s) + ' von ' + s.services.length + ' Services laufen'">
                    <span class="oa-st-count"><oa-icon name="box" [size]="13" /> {{ running(s) }}/{{ s.services.length }}</span>
                    <span class="oa-tip" role="tooltip">
                      <strong>Services</strong>
                      <ul>
                        @for (x of s.services; track x.name) {
                          <li>
                            <span class="oa-dot" [attr.data-tone]="x.health === 'unhealthy' ? 'err' : x.state === 'running' ? 'ok' : 'warn'"></span>
                            <span class="oa-sp">{{ x.name }}</span>
                            <span class="oa-mono oa-muted">{{ tag(x.image) }}</span>
                          </li>
                        }
                      </ul>
                    </span>
                  </span>
                </td>
                <td>
                  @if (pending(s); as n) {
                    <span class="oa-tipwrap" tabindex="0" [attr.aria-label]="n + ' Updates verfügbar'">
                      <span class="oa-pill" data-tone="info"><oa-icon name="download" [size]="12" /> {{ n }} verfügbar</span>
                      <span class="oa-tip" role="tooltip">
                        <strong>Image-Updates</strong>
                        <ul>
                          @for (x of s.services; track x.name) {
                            @if (x.updateTo) {
                              <li><span class="oa-sp">{{ x.name }}</span><span class="oa-mono oa-muted">{{ tag(x.image) }} → {{ tag(x.updateTo) }}</span></li>
                            }
                          }
                        </ul>
                        <span class="oa-small oa-muted">Modus: {{ s.autoUpdate === 'check' ? 'nur prüfen' : 'automatisch' }}</span>
                      </span>
                    </span>
                  } @else {
                    <span class="oa-pill" data-tone="ok"><oa-icon name="check" [size]="12" /> Aktuell</span>
                  }
                </td>
                <td>
                  <div class="oa-st-tags">
                    @for (l of s.labels; track l) {
                      <span class="oa-tag" [attr.data-tone]="tone(l)">{{ l }}</span>
                    }
                    <span class="oa-st-tagadd">
                      <button type="button" class="oa-ibtn oa-st-mini" [attr.aria-expanded]="menu() === 'tags:' + s.id" [attr.aria-label]="'Labels von ' + s.name + ' bearbeiten'" (click)="openMenu('tags:' + s.id, $event)">
                        <oa-icon name="plus" [size]="12" />
                      </button>
                      @if (menu() === 'tags:' + s.id) {
                        <div class="oa-menu oa-st-menu" role="group" [attr.aria-label]="'Labels für ' + s.name" (click)="$event.stopPropagation()">
                          @for (l of store.allLabels(); track l) {
                            <label class="oa-menu-item"><input type="checkbox" [checked]="s.labels.includes(l)" (change)="toggleStackLabel(s, l)" /> <span class="oa-dot" [attr.data-tone]="tone(l)"></span> {{ l }}</label>
                          }
                          <div class="oa-menu-sep"></div>
                          <form class="oa-row" style="padding:4px" (submit)="addLabel(s, $event)">
                            <input class="oa-input" style="height:30px" name="label" placeholder="Neues Label" aria-label="Neues Label" />
                            <button type="submit" class="oa-btn">Hinzufügen</button>
                          </form>
                        </div>
                      }
                    </span>
                  </div>
                </td>
                @if (full()) {
                  <td class="oa-mono">{{ cpu(s) }} %</td>
                  <td class="oa-mono oa-small">{{ ports(s) || '–' }}</td>
                  <td class="oa-small">{{ s.autoUpdate === 'check' ? 'nur prüfen' : s.autoUpdate === 'nightly' ? 'nachts' : 'wöchentlich' }}</td>
                  <td class="oa-small oa-muted">{{ s.lastDeploy }}</td>
                  <td class="oa-small oa-muted">{{ s.backupLast }}</td>
                }
                <td class="oa-st-act">
                  <button type="button" class="oa-ibtn" [attr.aria-expanded]="menu() === s.id" [attr.aria-label]="'Aktionen für ' + s.name" (click)="openMenu(s.id, $event)"><oa-icon name="more" /></button>
                  @if (menu() === s.id) {
                    <div class="oa-menu oa-st-menu" role="menu" [attr.aria-label]="'Aktionen für ' + s.name">
                      <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'open')"><oa-icon name="eye" /> Öffnen</button>
                      <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'edit')"><oa-icon name="pencil" /> Bearbeiten</button>
                      <div class="oa-menu-sep"></div>
                      @if (allStopped(s)) {
                        <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'start')"><oa-icon name="play" /> Starten</button>
                      } @else {
                        <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'stop')"><oa-icon name="stop" /> Stoppen</button>
                        <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'restart')"><oa-icon name="restart" /> Neustart</button>
                      }
                      <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'redeploy')"><oa-icon name="refresh" /> Pull &amp; Redeploy</button>
                      @if (pending(s)) {
                        <button type="button" role="menuitem" class="oa-menu-item" (click)="act(s, 'update')"><oa-icon name="download" /> Updates installieren</button>
                      }
                    </div>
                  }
                </td>
              </tr>
            } @empty {
              <tr class="oa-st-empty">
                <td [attr.colspan]="colCount()">
                  <oa-icon name="layers" [size]="22" class="oa-muted" />
                  <p class="oa-muted">Keine Stacks für diese Filter.</p>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
      <p class="oa-small oa-muted oa-st-foot">{{ rows().length }} von {{ store.stacks().length }} Stacks · Hover oder Fokus auf Services/Updates zeigt Details.</p>
    </section>
  `,
  styles: `
    .oa-link{border:0;background:none;padding:0;color:var(--oa-accent-fg);font:inherit;cursor:pointer;text-decoration:underline;text-underline-offset:3px}
    .oa-st-card{padding:14px}
    .oa-st-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
    .oa-st-search{position:relative;width:min(300px,100%)}
    .oa-st-search oa-icon{position:absolute;left:10px;top:10px;color:var(--oa-muted)}
    .oa-st-search .oa-input{padding-left:32px}
    .oa-st-labels{margin:10px 0 4px}
    .oa-st-labels .oa-chip{height:26px}
    .oa-st-bulk{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:10px;padding:8px 10px;border-radius:12px;background:var(--oa-accent-soft);border:1px solid color-mix(in oklch,var(--oa-accent) 35%,transparent)}
    .oa-st-scroll--x{overflow-x:auto;min-height:260px}
    @media (max-width:1100px){.oa-st-scroll{overflow-x:auto;min-height:260px}}
    .oa-st-table{border-collapse:separate;border-spacing:0 6px}
    .oa-st-table th{border:0;height:32px}
    .oa-st-table tbody td{background:color-mix(in oklch,var(--oa-mbg) 22%,transparent);border-top:1px solid var(--oa-line);border-bottom:1px solid var(--oa-line);white-space:nowrap}
    .oa-st-table tbody td:first-child{border-left:3px solid var(--hc,var(--oa-line));border-radius:12px 0 0 12px}
    .oa-st-table tbody td:last-child{border-right:1px solid var(--oa-line);border-radius:0 12px 12px 0}
    .oa-st-table tbody tr:hover td{background:color-mix(in oklch,var(--oa-mbg) 55%,transparent)}
    .oa-st-table tbody tr.oa-st-checked td{background:var(--oa-accent-soft)}
    .oa-st-sel{width:36px}
    .oa-st-name{display:flex;align-items:center;gap:10px}
    .oa-st-ico{display:grid;place-items:center;width:32px;height:32px;border-radius:10px;flex-shrink:0;color:var(--hc);background:color-mix(in oklch,var(--hc) 14%,transparent)}
    .oa-st-link{border:0;background:none;padding:0;color:var(--oa-fg);font:inherit;font-weight:600;font-size:14.5px;cursor:pointer}
    .oa-st-link:hover{text-decoration:underline}
    .oa-st-count{display:inline-flex;align-items:center;gap:5px;font-variant-numeric:tabular-nums;cursor:help;border-bottom:1px dashed var(--oa-line2)}
    .oa-st-tags{display:flex;align-items:center;gap:4px;flex-wrap:wrap;min-width:120px}
    .oa-st-tagadd,.oa-st-act{position:relative}
    .oa-st-mini{width:22px;height:22px;border:1px dashed var(--oa-line2);border-radius:7px}
    .oa-st-menu{right:0;top:calc(100% + 4px)}
    .oa-st-menu label.oa-menu-item{cursor:pointer}
    .oa-st-act{width:44px;text-align:right}
    .oa-st-empty td{text-align:center;padding:30px!important;white-space:normal!important}
    .oa-st-foot{margin:6px 2px 0}
  `,
})
export class StacksComponent {
  protected readonly store = inject(ArcaneStore);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  protected readonly query = signal('');
  protected readonly status = signal<StatusFilter>('all');
  protected readonly labelSel = signal<string[]>([]);
  protected readonly selecting = signal(false);
  protected readonly selected = signal<string[]>([]);
  protected readonly menu = signal<string | null>(null);
  protected readonly statusFilters: { id: StatusFilter; label: string }[] = [
    { id: 'all', label: 'Alle' },
    { id: 'running', label: 'Läuft' },
    { id: 'problem', label: 'Probleme' },
    { id: 'updates', label: 'Updates' },
    { id: 'stopped', label: 'Gestoppt' },
  ];

  protected readonly full = computed(() => this.store.viewMode() === 'full');
  protected readonly colCount = computed(() => 7 + (this.full() ? 5 : 0) + (this.selecting() ? 1 : 0));

  protected readonly rows = computed(() => {
    const q = this.query().trim().toLowerCase();
    const st = this.status();
    const labels = this.labelSel();
    return this.store.visibleStacks().filter((s) => {
      if (q && !`${s.name} ${s.description} ${s.services.map((x) => x.name + ' ' + x.image).join(' ')}`.toLowerCase().includes(q)) return false;
      if (labels.length && !labels.every((l) => s.labels.includes(l))) return false;
      switch (st) {
        case 'running':
          return s.services.every((x) => x.state === 'running') && !this.hasProblem(s);
        case 'problem':
          return this.hasProblem(s);
        case 'updates':
          return this.pending(s) > 0;
        case 'stopped':
          return this.allStopped(s);
        default:
          return true;
      }
    });
  });

  protected readonly countRunning = computed(() => this.store.visibleStacks().filter((s) => s.services.some((x) => x.state === 'running')).length);
  protected readonly countProblems = computed(() => this.store.visibleStacks().filter((s) => this.hasProblem(s)).length);
  protected readonly allChecked = computed(() => this.rows().length > 0 && this.rows().every((s) => this.selected().includes(s.id)));

  protected tone(l: string): string {
    return labelTone(l);
  }

  protected tag(image: string): string {
    const i = image.lastIndexOf(':');
    return i < 0 ? 'latest' : image.slice(i + 1);
  }

  protected running(s: Stack): number {
    return s.services.filter((x) => x.state === 'running').length;
  }

  protected pending(s: Stack): number {
    return s.services.filter((x) => !!x.updateTo).length;
  }

  protected cpu(s: Stack): number {
    return s.services.reduce((n, x) => n + (x.state === 'running' ? x.cpu : 0), 0);
  }

  protected ports(s: Stack): string {
    return s.services.flatMap((x) => x.ports).join(', ');
  }

  private hasProblem(s: Stack): boolean {
    return s.services.some((x) => x.health === 'unhealthy');
  }

  protected allStopped(s: Stack): boolean {
    return s.services.every((x) => x.state === 'stopped');
  }

  protected statusTone(s: Stack): string {
    if (this.hasProblem(s)) return 'err';
    if (this.allStopped(s)) return 'gray';
    if (s.services.some((x) => x.state !== 'running')) return 'warn';
    return 'ok';
  }

  protected statusLabel(s: Stack): string {
    if (this.hasProblem(s)) return 'Problem';
    if (this.allStopped(s)) return 'Gestoppt';
    if (s.services.some((x) => x.state === 'restarting')) return 'Startet neu';
    if (s.services.some((x) => x.state !== 'running')) return 'Teilweise';
    return 'Läuft';
  }

  protected toggleLabel(l: string): void {
    this.labelSel.update((s) => (s.includes(l) ? s.filter((x) => x !== l) : [...s, l]));
  }

  protected toggleSelecting(): void {
    this.selecting.update((v) => !v);
    if (!this.selecting()) this.selected.set([]);
  }

  protected toggleSel(id: string): void {
    this.selected.update((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  protected toggleAll(): void {
    this.selected.set(this.allChecked() ? [] : this.rows().map((s) => s.id));
  }

  protected bulk(action: 'start' | 'stop' | 'restart' | 'redeploy' | 'update'): void {
    const ids = this.selected();
    if (!ids.length) return;
    this.store.bulk(ids, action);
  }

  protected openMenu(key: string, e: Event): void {
    e.stopPropagation();
    this.menu.set(this.menu() === key ? null : key);
  }

  protected onDoc(e: MouseEvent): void {
    if (!this.menu()) return;
    const t = e.target as HTMLElement | null;
    if (!t || !this.host.nativeElement.contains(t) || !t.closest('.oa-menu')) this.menu.set(null);
  }

  protected act(s: Stack, a: 'open' | 'edit' | 'start' | 'stop' | 'restart' | 'redeploy' | 'update'): void {
    this.menu.set(null);
    if (a === 'open') this.store.openStack(s.id);
    else if (a === 'edit') this.store.editStack(s.id);
    else if (a === 'update') this.store.installUpdates(s.id);
    else this.store.stackAction(s.id, a);
  }

  protected toggleStackLabel(s: Stack, l: string): void {
    const next = s.labels.includes(l) ? s.labels.filter((x) => x !== l) : [...s.labels, l];
    this.store.setStackLabels(s.id, next);
  }

  protected addLabel(s: Stack, e: Event): void {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const input = form.elements.namedItem('label') as HTMLInputElement | null;
    const v = (input?.value ?? '').trim().toLowerCase();
    if (!v) return;
    if (!s.labels.includes(v)) this.store.setStackLabels(s.id, [...s.labels, v]);
    if (input) input.value = '';
  }
}
