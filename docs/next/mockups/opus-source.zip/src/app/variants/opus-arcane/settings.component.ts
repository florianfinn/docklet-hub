import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { AuthMode, AutoUpdate, BackupTarget, CHANNEL_LABELS, ChannelKind, HubSettings, HubUser } from './data';
import { IconComponent, IconName } from './icon.component';
import { ArcaneStore } from './store';

const SECTIONS: { id: string; label: string; desc: string; icon: IconName }[] = [
  { id: 'auth', label: 'Anmeldung', desc: 'Kein Login, lokaler Admin oder Reverse-Proxy', icon: 'lock' },
  { id: 'users', label: 'Benutzer', desc: 'Einfache Zugriffsrechte (niedrige Priorität)', icon: 'users' },
  { id: 'notify', label: 'Benachrichtigungen', desc: 'Nur eingerichtete Kanäle', icon: 'bell' },
  { id: 'updates', label: 'Updates & Zeitpläne', desc: 'Prüfen, automatisch installieren', icon: 'download' },
  { id: 'backup', label: 'Backupziele', desc: 'Lokal, Host-Mounts, SMB/NFS', icon: 'archive' },
  { id: 'scan', label: 'Schwachstellenscans', desc: 'Optional, manuell oder geplant', icon: 'shield' },
  { id: 'heal', label: 'Auto Heal', desc: 'Unhealthy-Container begrenzt neu starten', icon: 'zap' },
];

const CHANNEL_KINDS = Object.keys(CHANNEL_LABELS) as ChannelKind[];
const EVENTS = ['Fehler', 'Updates', 'Backups', 'Deployments', 'Hosts'];

/** Hub-Einstellungen mit Abschnitten (Seitenstruktur nach Arcanes Settings). Alles lokal und simuliert. */
@Component({
  selector: 'oa-settings',
  imports: [ZardButtonComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Hub-Einstellungen</h1>
        <p>Einstellungen für den gesamten Docklet-Hub. Änderungen werden nur lokal in dieser Demo gespeichert.</p>
      </div>
    </div>

    <div class="oa-set">
      <nav class="oa-set-nav" aria-label="Einstellungsbereiche">
        @for (s of sections; track s.id) {
          <button type="button" class="oa-set-item" [attr.aria-current]="store.settingsSection() === s.id ? 'page' : null" (click)="store.settingsSection.set(s.id)">
            <span class="oa-card-ico"><oa-icon [name]="s.icon" [size]="15" /></span>
            <span><strong>{{ s.label }}</strong><small>{{ s.desc }}</small></span>
          </button>
        }
      </nav>

      @let h = store.hub();
      <section class="oa-card oa-set-main" [attr.aria-label]="current().label">
        <header class="oa-set-head">
          <h2>{{ current().label }}</h2>
          <p class="oa-muted">{{ current().desc }}</p>
        </header>

        @switch (store.settingsSection()) {
          @case ('auth') {
            <div class="oa-set-radios" role="radiogroup" aria-label="Anmeldemodus">
              @for (a of authModes; track a.id) {
                <button type="button" role="radio" class="oa-set-radio" [attr.aria-checked]="h.auth === a.id" (click)="patch({ auth: a.id })">
                  <oa-icon [name]="a.icon" [size]="18" />
                  <span><strong>{{ a.label }}</strong><small>{{ a.desc }}</small></span>
                </button>
              }
            </div>
            @switch (h.auth) {
              @case ('none') {
                <div class="oa-callout" data-tone="warn"><oa-icon name="alert" [size]="15" /> Ohne Login hat jeder im Netzwerk vollen Zugriff. Nur für vertrauenswürdige, abgeschottete Netze.</div>
              }
              @case ('local') {
                <div class="oa-grid2">
                  <div class="oa-field">
                    <label class="oa-label" for="set-admin">Admin-Benutzername</label>
                    <input id="set-admin" class="oa-input" [value]="h.adminUser" (change)="patch({ adminUser: $any($event.target).value })" />
                  </div>
                  <div class="oa-field">
                    <span class="oa-label">Passwort</span>
                    <button type="button" class="oa-btn" (click)="store.showToast('Demo: Passwort-Dialog (keine echten Zugangsdaten)')"><oa-icon name="key" [size]="13" /> Passwort ändern …</button>
                  </div>
                </div>
              }
              @case ('proxy') {
                <div class="oa-grid2">
                  <div class="oa-field">
                    <label class="oa-label" for="set-hdr">Benutzer-Header</label>
                    <input id="set-hdr" class="oa-input oa-mono" [value]="h.proxyHeader" (change)="patch({ proxyHeader: $any($event.target).value })" />
                    <span class="oa-help">z. B. von Authelia oder Authentik gesetzt.</span>
                  </div>
                  <div class="oa-field">
                    <label class="oa-label" for="set-trust">Vertrauenswürdiger Proxy</label>
                    <input id="set-trust" class="oa-input oa-mono" value="proxy.example.com" />
                  </div>
                </div>
              }
            }
          }
          @case ('users') {
            <div class="oa-callout" data-tone="info"><oa-icon name="info" [size]="15" /> Niedrige Priorität: einfache Rechte pro Stack. Vollzugriff ist keine zugesicherte Sicherheitsgrenze für fremde Benutzer.</div>
            <table class="oa-table">
              <thead><tr><th>Benutzer</th><th>Rolle</th><th>Zugriff</th><th><span class="oa-sr">Aktion</span></th></tr></thead>
              <tbody>
                @for (u of h.users; track u.id) {
                  <tr>
                    <td><strong>{{ u.name }}</strong></td>
                    <td><span class="oa-pill" [attr.data-tone]="u.role === 'admin' ? 'accent' : null">{{ u.role === 'admin' ? 'Admin' : 'Benutzer' }}</span></td>
                    <td class="oa-small">{{ accessText(u) }}</td>
                    <td style="text-align:right">
                      @if (u.role !== 'admin') {
                        <button type="button" class="oa-ibtn" (click)="removeUser(u.id)" [attr.aria-label]="u.name + ' entfernen'"><oa-icon name="trash" [size]="14" /></button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
            <form class="oa-set-form" (submit)="addUser($event)">
              <strong class="oa-small">Benutzer hinzufügen</strong>
              <div class="oa-grid3">
                <input class="oa-input" placeholder="Name" aria-label="Name" [value]="newUser()" (input)="newUser.set($any($event.target).value)" />
                <select class="oa-select" aria-label="Stack" [value]="newStack()" (change)="newStack.set($any($event.target).value)">
                  @for (s of store.stacks(); track s.id) { <option [value]="s.id">{{ s.name }}</option> }
                </select>
                <select class="oa-select" aria-label="Recht" [value]="newLevel()" (change)="newLevel.set($any($event.target).value)">
                  <option value="limited">Eingeschränkt (Start/Stopp, Logs, Shell)</option>
                  <option value="full">Vollzugriff (inkl. Updates, Editor)</option>
                </select>
              </div>
              <button z-button zSize="sm" type="submit" [zDisabled]="!newUser().trim()"><oa-icon name="plus" [size]="13" /> Hinzufügen</button>
            </form>
          }
          @case ('notify') {
            <div class="oa-set-list">
              @for (c of h.channels; track c.id) {
                <div class="oa-set-row">
                  <span class="oa-card-ico"><oa-icon [name]="c.kind === 'email' ? 'mail' : 'bell'" [size]="15" /></span>
                  <div class="oa-sp" style="min-width:0">
                    <strong>{{ c.name }}</strong>
                    <div class="oa-small oa-muted oa-mono oa-ell">{{ c.target }}</div>
                    <div class="oa-row" style="margin-top:4px">
                      @for (e of c.events; track e) { <span class="oa-pill">{{ e }}</span> }
                    </div>
                  </div>
                  <button type="button" class="oa-btn" (click)="store.showToast('Testnachricht an ' + c.name + ' (simuliert)', 'ok')">Testen</button>
                  <button type="button" class="oa-ibtn" (click)="removeChannel(c.id)" [attr.aria-label]="c.name + ' entfernen'"><oa-icon name="trash" [size]="14" /></button>
                </div>
              } @empty {
                <p class="oa-muted">Noch kein Kanal eingerichtet.</p>
              }
            </div>
            @if (adding()) {
              <form class="oa-set-form" (submit)="addChannel($event)">
                <strong class="oa-small">Kanal hinzufügen</strong>
                <div class="oa-grid2">
                  <div class="oa-field">
                    <label class="oa-label" for="ch-kind">Kanal</label>
                    <select id="ch-kind" class="oa-select" [value]="chKind()" (change)="chKind.set($any($event.target).value)">
                      @for (k of channelKinds; track k) { <option [value]="k">{{ channelLabel(k) }}</option> }
                    </select>
                  </div>
                  <div class="oa-field">
                    <label class="oa-label" for="ch-target">{{ chKind() === 'email' ? 'Empfänger' : 'URL / Token' }}</label>
                    <input id="ch-target" class="oa-input oa-mono" [placeholder]="chKind() === 'email' ? 'ops@example.com' : 'https://hooks.example.com/…'" [value]="chTarget()" (input)="chTarget.set($any($event.target).value)" />
                  </div>
                </div>
                <div class="oa-row" role="group" aria-label="Ereignisse">
                  @for (e of events; track e) {
                    <button type="button" class="oa-chip" [attr.aria-pressed]="chEvents().includes(e)" (click)="toggleEvent(e)">{{ e }}</button>
                  }
                </div>
                <div class="oa-row">
                  <button z-button zSize="sm" type="submit" [zDisabled]="!chTarget().trim()">Speichern</button>
                  <button z-button zType="ghost" zSize="sm" type="button" (click)="adding.set(false)">Abbrechen</button>
                </div>
              </form>
            } @else {
              <button z-button zType="outline" zSize="sm" type="button" (click)="adding.set(true)"><oa-icon name="plus" [size]="13" /> Kanal hinzufügen</button>
            }
            <p class="oa-help">Verfügbar: E-Mail, Discord, Telegram, Signal, Slack, ntfy, Pushover, Gotify, Matrix, Google Chat, generischer Webhook. Nicht eingerichtete Kanäle werden nicht angezeigt.</p>
          }
          @case ('updates') {
            <div class="oa-field">
              <span class="oa-label">Standard für neue Stacks</span>
              <div class="oa-seg" role="radiogroup" aria-label="Standard-Update-Modus">
                @for (m of updateModes; track m.id) {
                  <button type="button" role="radio" [attr.aria-checked]="h.updateMode === m.id" (click)="patch({ updateMode: m.id })">{{ m.label }}</button>
                }
              </div>
              <span class="oa-help">Standard ist „Nur prüfen“. Automatische Installation nur nach Aktivierung. Keine automatische Rückkehr bei Fehlern.</span>
            </div>
            <div class="oa-field" style="max-width:320px">
              <label class="oa-label" for="upd-int">Update-Prüfung</label>
              <select id="upd-int" class="oa-select" [value]="h.updateCheck" (change)="patch({ updateCheck: $any($event.target).value })">
                <option>alle 6 Stunden</option><option>täglich</option><option>wöchentlich</option>
              </select>
            </div>
            <table class="oa-table">
              <thead><tr><th>Stack</th><th>Modus</th><th>Zeitplan</th></tr></thead>
              <tbody>
                @for (s of store.stacks(); track s.id) {
                  <tr>
                    <td><button type="button" class="oa-set-link" (click)="store.openStack(s.id, 'updates')">{{ s.name }}</button></td>
                    <td>
                      <select class="oa-select" style="height:30px;max-width:200px" [attr.aria-label]="'Update-Modus ' + s.name" [value]="s.autoUpdate" (change)="store.setAutoUpdate(s.id, $any($event.target).value)">
                        @for (m of updateModes; track m.id) { <option [value]="m.id">{{ m.label }}</option> }
                      </select>
                    </td>
                    <td class="oa-small oa-muted">{{ s.autoUpdate === 'check' ? '–' : s.autoTime }}</td>
                  </tr>
                }
              </tbody>
            </table>
          }
          @case ('backup') {
            <div class="oa-set-list">
              @for (t of h.backupTargets; track t.id) {
                <div class="oa-set-row">
                  <span class="oa-card-ico"><oa-icon [name]="t.kind === 'local' || t.kind === 'hostmount' ? 'folder' : 'network'" [size]="15" /></span>
                  <div class="oa-sp" style="min-width:0">
                    <strong>{{ t.name }}</strong> <span class="oa-pill">{{ kindLabel(t.kind) }}</span>
                    <div class="oa-small oa-muted oa-mono oa-ell">{{ t.path }}</div>
                  </div>
                  <button type="button" class="oa-btn" (click)="store.showToast(t.name + ': erreichbar, Schreibrechte ok (simuliert)', 'ok')">Prüfen</button>
                  <button type="button" class="oa-ibtn" (click)="removeTarget(t.id)" [attr.aria-label]="t.name + ' entfernen'"><oa-icon name="trash" [size]="14" /></button>
                </div>
              }
            </div>
            <form class="oa-set-form" (submit)="addTarget($event)">
              <strong class="oa-small">Ziel hinzufügen</strong>
              <div class="oa-grid3">
                <select class="oa-select" aria-label="Art" [value]="tKind()" (change)="tKind.set($any($event.target).value)">
                  <option value="local">Lokales Verzeichnis</option>
                  <option value="hostmount">Vorhandener Host-Mount</option>
                  <option value="smb">SMB-Freigabe</option>
                  <option value="nfs">NFS-Freigabe</option>
                </select>
                <input class="oa-input" placeholder="Name" aria-label="Name" [value]="tName()" (input)="tName.set($any($event.target).value)" />
                <input class="oa-input oa-mono" [placeholder]="tKind() === 'smb' ? '//nas.example.com/share' : tKind() === 'nfs' ? 'nas.example.com:/export' : '/mnt/backup'" aria-label="Pfad" [value]="tPath()" (input)="tPath.set($any($event.target).value)" />
              </div>
              <button z-button zSize="sm" type="submit" [zDisabled]="!tPath().trim()"><oa-icon name="plus" [size]="13" /> Hinzufügen</button>
            </form>
            <p class="oa-help">Volumes und Bind-Mounts, manuell oder geplant, mit Aufbewahrung. Kein S3. Genaue Rechte-/Mount-Umsetzung später evaluieren.</p>
          }
          @case ('scan') {
            <div class="oa-set-switch">
              <button type="button" class="oa-switch" role="switch" [attr.aria-checked]="store.scanEnabled()" aria-labelledby="sc-l" (click)="store.scanEnabled.set(!store.scanEnabled())"></button>
              <span id="sc-l"><strong>Schwachstellenscans aktivieren</strong><small>Getrennt von der Update-Erkennung</small></span>
            </div>
            <div class="oa-field">
              <span class="oa-label">Zeitplan</span>
              <div class="oa-seg" role="radiogroup" aria-label="Scan-Zeitplan">
                <button type="button" role="radio" [attr.aria-checked]="h.scanSchedule === 'manual'" (click)="patch({ scanSchedule: 'manual' })">Nur manuell</button>
                <button type="button" role="radio" [attr.aria-checked]="h.scanSchedule === 'daily'" (click)="patch({ scanSchedule: 'daily' })">Täglich 03:00</button>
                <button type="button" role="radio" [attr.aria-checked]="h.scanSchedule === 'weekly'" (click)="patch({ scanSchedule: 'weekly' })">Wöchentlich</button>
              </div>
            </div>
            <div class="oa-set-switch">
              <button type="button" class="oa-switch" role="switch" [attr.aria-checked]="h.scanWidget" aria-labelledby="sw-l" (click)="toggleScanWidget()"></button>
              <span id="sw-l"><strong>Dashboard-Widget anzeigen</strong><small>Kurzüberblick der Befunde</small></span>
            </div>
            <div class="oa-row">
              <button z-button zSize="sm" type="button" (click)="store.runScan()"><oa-icon name="scan" [size]="13" /> Jetzt scannen</button>
              <button z-button zType="outline" zSize="sm" type="button" (click)="store.go('security')">Zur Sicherheitsseite</button>
            </div>
          }
          @case ('heal') {
            <div class="oa-set-switch">
              <button type="button" class="oa-switch" role="switch" [attr.aria-checked]="store.autoHeal()" aria-labelledby="ah-l" (click)="store.autoHeal.set(!store.autoHeal())"></button>
              <span id="ah-l"><strong>Auto Heal aktiv</strong><small>Unhealthy-Container begrenzt neu starten</small></span>
            </div>
            <div class="oa-grid2">
              <div class="oa-field">
                <label class="oa-label" for="ah-max">Max. Neustarts</label>
                <input id="ah-max" class="oa-input" type="number" min="1" max="10" [value]="h.healMax" (change)="setHealMax($any($event.target).value)" />
              </div>
              <div class="oa-field">
                <label class="oa-label" for="ah-win">Zeitfenster</label>
                <select id="ah-win" class="oa-select" [value]="h.healWindow" (change)="patch({ healWindow: $any($event.target).value })">
                  <option>1 Stunde</option><option>6 Stunden</option><option>24 Stunden</option>
                </select>
              </div>
            </div>
            <div class="oa-field">
              <span class="oa-label">Ausnahmen</span>
              <div class="oa-row">
                @for (s of store.stacks(); track s.id) {
                  <label class="oa-check"><input type="checkbox" [checked]="h.healExclude.includes(s.id)" (change)="toggleExclude(s.id)" /> {{ s.name }}</label>
                }
              </div>
            </div>
            <p class="oa-help">Unerwartete Stopps regeln die Docker-Neustartregeln (restart:). Eine zusätzliche Selbstheilung gestoppter Container gibt es nicht.</p>
          }
        }
      </section>
    </div>
  `,
  styles: `
    .oa-set{display:grid;grid-template-columns:270px minmax(0,1fr);gap:16px;align-items:start}
    @media (max-width:900px){.oa-set{grid-template-columns:1fr}}
    .oa-set-nav{display:flex;flex-direction:column;gap:2px}
    .oa-set-item{display:flex;align-items:center;gap:10px;padding:8px;border:0;border-radius:12px;background:none;color:var(--oa-fg);text-align:left;cursor:pointer}
    .oa-set-item:hover{background:var(--oa-mbg)}
    .oa-set-item[aria-current=page]{background:var(--oa-mbg)}
    .oa-set-item strong{display:block;font-size:13.5px;font-weight:500}
    .oa-set-item small,.oa-set-radio small,.oa-set-switch small{display:block;font-size:12px;color:var(--oa-muted)}
    .oa-set-main{display:flex;flex-direction:column;gap:16px;padding:20px}
    .oa-set-head h2{font-size:17px;font-weight:600;margin:0}
    .oa-set-head p{margin:2px 0 0;font-size:13px}
    .oa-set-radios{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px}
    .oa-set-radio{display:flex;gap:10px;align-items:flex-start;padding:12px;border-radius:12px;border:1px solid var(--oa-line2);background:none;color:var(--oa-fg);text-align:left;cursor:pointer}
    .oa-set-radio[aria-checked=true]{border-color:var(--oa-accent);background:var(--oa-accent-soft)}
    .oa-set-list{display:flex;flex-direction:column;gap:8px}
    .oa-set-row{display:flex;align-items:center;gap:12px;padding:12px;border-radius:12px;border:1px solid var(--oa-line)}
    .oa-set-form{display:flex;flex-direction:column;gap:10px;padding:14px;border-radius:12px;border:1px dashed var(--oa-line2)}
    .oa-set-form>button{align-self:flex-start}
    .oa-set-switch{display:flex;align-items:center;gap:12px}
    .oa-set-link{border:0;background:none;padding:0;color:var(--oa-fg);font:inherit;font-weight:500;cursor:pointer}
    .oa-set-link:hover{text-decoration:underline}
    .oa-ell{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  `,
})
export class SettingsComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly sections = SECTIONS;
  protected readonly channelKinds = CHANNEL_KINDS;
  protected readonly events = EVENTS;
  protected readonly current = computed(() => SECTIONS.find((s) => s.id === this.store.settingsSection()) ?? SECTIONS[0]);
  protected readonly authModes: { id: AuthMode; label: string; desc: string; icon: IconName }[] = [
    { id: 'none', label: 'Kein Login', desc: 'Nur im abgeschotteten Netz', icon: 'globe' },
    { id: 'local', label: 'Lokaler Admin', desc: 'Benutzername und Passwort', icon: 'user' },
    { id: 'proxy', label: 'Reverse-Proxy', desc: 'Anmeldung über Header', icon: 'route' },
  ];
  protected readonly updateModes: { id: AutoUpdate; label: string }[] = [
    { id: 'check', label: 'Nur prüfen' },
    { id: 'nightly', label: 'Automatisch nachts' },
    { id: 'weekly', label: 'Automatisch wöchentlich' },
  ];

  protected readonly newUser = signal('');
  protected readonly newStack = signal('craft');
  protected readonly newLevel = signal<'full' | 'limited'>('limited');
  protected readonly adding = signal(false);
  protected readonly chKind = signal<ChannelKind>('telegram');
  protected readonly chTarget = signal('');
  protected readonly chEvents = signal<string[]>(['Fehler']);
  protected readonly tKind = signal<BackupTarget['kind']>('smb');
  protected readonly tName = signal('');
  protected readonly tPath = signal('');
  private nextId = 50;

  protected patch(p: Partial<HubSettings>): void {
    this.store.hub.update((h) => ({ ...h, ...p }));
  }

  protected channelLabel(k: ChannelKind): string {
    return CHANNEL_LABELS[k];
  }

  protected kindLabel(k: BackupTarget['kind']): string {
    return k === 'local' ? 'Lokal' : k === 'hostmount' ? 'Host-Mount' : k.toUpperCase();
  }

  protected accessText(u: HubUser): string {
    if (u.role === 'admin') return 'Alle Stacks und Einstellungen';
    return (
      u.access
        .map((a) => `${this.store.stacks().find((s) => s.id === a.stackId)?.name ?? a.stackId}: ${a.level === 'full' ? 'Vollzugriff' : 'eingeschränkt'}`)
        .join(', ') || 'kein Zugriff'
    );
  }

  protected addUser(e: Event): void {
    e.preventDefault();
    const name = this.newUser().trim();
    if (!name) return;
    const user: HubUser = { id: this.nextId++, name, role: 'user', access: [{ stackId: this.newStack(), level: this.newLevel() }] };
    this.patch({ users: [...this.store.hub().users, user] });
    this.newUser.set('');
    this.store.showToast(`Benutzer ${name} angelegt (simuliert)`, 'ok');
  }

  protected removeUser(id: number): void {
    this.patch({ users: this.store.hub().users.filter((u) => u.id !== id) });
  }

  protected toggleEvent(e: string): void {
    this.chEvents.update((l) => (l.includes(e) ? l.filter((x) => x !== e) : [...l, e]));
  }

  protected addChannel(e: Event): void {
    e.preventDefault();
    const target = this.chTarget().trim();
    if (!target) return;
    const kind = this.chKind();
    this.patch({ channels: [...this.store.hub().channels, { id: this.nextId++, kind, name: CHANNEL_LABELS[kind], target, events: [...this.chEvents()] }] });
    this.chTarget.set('');
    this.adding.set(false);
    this.store.showToast(`${CHANNEL_LABELS[kind]} eingerichtet (simuliert)`, 'ok');
  }

  protected removeChannel(id: number): void {
    this.patch({ channels: this.store.hub().channels.filter((c) => c.id !== id) });
  }

  protected addTarget(e: Event): void {
    e.preventDefault();
    const path = this.tPath().trim();
    if (!path) return;
    const kind = this.tKind();
    const t: BackupTarget = { id: this.nextId++, kind, name: this.tName().trim() || this.kindLabel(kind), path };
    this.patch({ backupTargets: [...this.store.hub().backupTargets, t] });
    this.tPath.set('');
    this.tName.set('');
  }

  protected removeTarget(id: number): void {
    this.patch({ backupTargets: this.store.hub().backupTargets.filter((t) => t.id !== id) });
  }

  protected toggleScanWidget(): void {
    const on = !this.store.hub().scanWidget;
    this.patch({ scanWidget: on });
    this.store.widgets.update((ws) => ws.map((w) => (w.id === 'scan' ? { ...w, visible: on } : w)));
  }

  protected setHealMax(v: string): void {
    const n = Math.min(10, Math.max(1, Number(v) || 1));
    this.patch({ healMax: n });
  }

  protected toggleExclude(id: string): void {
    const ex = this.store.hub().healExclude;
    this.patch({ healExclude: ex.includes(id) ? ex.filter((x) => x !== id) : [...ex, id] });
  }
}
