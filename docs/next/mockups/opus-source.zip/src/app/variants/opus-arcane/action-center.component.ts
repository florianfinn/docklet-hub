import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { DialogComponent } from './dialog.component';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

type Filter = 'all' | 'error' | 'warn' | 'ok';

/** Aktionszentrum (Drawer): Details, Ablaufschritte und Ausgaben plus Ereignisverlauf. Öffnet nur auf Wunsch. */
@Component({
  selector: 'oa-action-center',
  imports: [ZardButtonComponent, IconComponent, DialogComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <oa-dialog
      heading="Aktivitäten"
      description="Ablauf, Ausgaben und Fehler simulierter Aktionen sowie der Ereignisverlauf."
      icon="bell"
      [side]="true"
      (closed)="close()"
    >
      <div class="oa-tabs" role="tablist" aria-label="Bereich">
        <button type="button" role="tab" class="oa-tab" id="ac-t1" aria-controls="ac-p" [attr.aria-selected]="tab() === 'actions'" (click)="tab.set('actions')">
          Aktionen <span class="oa-pill">{{ store.actions().length }}</span>
        </button>
        <button type="button" role="tab" class="oa-tab" id="ac-t2" aria-controls="ac-p" [attr.aria-selected]="tab() === 'events'" (click)="tab.set('events')">
          Ereignisse <span class="oa-pill">{{ store.events().length }}</span>
        </button>
      </div>

      <div id="ac-p" role="tabpanel" [attr.aria-labelledby]="tab() === 'actions' ? 'ac-t1' : 'ac-t2'" class="oa-ac-panel">
        @if (tab() === 'actions') {
          @for (a of store.actions(); track a.id) {
            <article class="oa-ac-item" [attr.data-status]="a.status" [class.oa-ac-item--focus]="store.focusAction() === a.id">
              <div class="oa-row" style="flex-wrap:nowrap">
                <span class="oa-ac-ico">
                  @switch (a.status) {
                    @case ('running') { <oa-icon name="loader" [size]="16" class="oa-spin" /> }
                    @case ('done') { <oa-icon name="circleCheck" [size]="16" /> }
                    @case ('error') { <oa-icon name="circleX" [size]="16" /> }
                  }
                </span>
                <div class="oa-sp" style="min-width:0">
                  <strong class="oa-ac-title">{{ a.title }}</strong>
                  <div class="oa-small oa-muted">{{ a.target }} · {{ a.started }} · {{ a.status === 'running' ? a.phase : a.status === 'done' ? 'fertig' : 'fehlgeschlagen' }}</div>
                </div>
                <button type="button" class="oa-ibtn" [attr.aria-expanded]="isOpen(a.id)" [attr.aria-label]="'Details zu ' + a.title" (click)="toggle(a.id)">
                  <oa-icon [name]="isOpen(a.id) ? 'chevronUp' : 'chevronDown'" [size]="15" />
                </button>
              </div>
              <div class="oa-bar" role="progressbar" [attr.aria-valuenow]="a.progress" aria-valuemin="0" aria-valuemax="100" [attr.aria-label]="'Fortschritt ' + a.title">
                <span [style.width.%]="a.status === 'error' ? 100 : a.progress" [style.--bc]="a.status === 'error' ? 'var(--oa-err)' : a.status === 'done' ? 'var(--oa-ok)' : null"></span>
              </div>
              @if (isOpen(a.id) || a.status === 'error') {
                <ol class="oa-ac-steps">
                  @for (s of a.steps; track $index) {
                    <li [attr.data-state]="s.state">
                      <span class="oa-ac-sd">
                        @switch (s.state) {
                          @case ('done') { <oa-icon name="check" [size]="11" [stroke]="3" /> }
                          @case ('error') { <oa-icon name="x" [size]="11" [stroke]="3" /> }
                          @case ('running') { <oa-icon name="loader" [size]="11" class="oa-spin" /> }
                        }
                      </span>
                      <div><strong>{{ s.label }}</strong><div class="oa-small oa-muted">{{ s.detail }}</div></div>
                    </li>
                  }
                </ol>
                @if (a.services.length) {
                  <div class="oa-row oa-small"><span class="oa-muted">Betroffene Services:</span>
                    @for (sv of a.services; track sv) { <span class="oa-pill">{{ sv }}</span> }
                  </div>
                }
                <pre class="oa-code oa-ac-log">{{ a.log.join('\n') }}</pre>
              }
            </article>
          } @empty {
            <p class="oa-muted">Keine Aktionen.</p>
          }
        } @else {
          <div class="oa-row" role="group" aria-label="Ereignisfilter" style="margin-bottom:10px">
            @for (f of filters; track f.id) {
              <button type="button" class="oa-chip" [attr.aria-pressed]="filter() === f.id" (click)="filter.set(f.id)">{{ f.label }}</button>
            }
          </div>
          <ol class="oa-ac-events">
            @for (e of events(); track e.id) {
              <li>
                <span class="oa-dot" [attr.data-tone]="e.level === 'error' ? 'err' : e.level === 'warn' ? 'warn' : e.level === 'ok' ? 'ok' : null"></span>
                <div class="oa-sp">
                  <div class="oa-small">{{ e.text }}</div>
                  <div class="oa-small oa-muted">{{ e.time }} · {{ e.source }}</div>
                </div>
              </li>
            } @empty {
              <li class="oa-muted oa-small">Keine Ereignisse für diesen Filter.</li>
            }
          </ol>
        }
      </div>

      <div dlgFooter class="oa-ac-foot">
        <button type="button" class="oa-btn" (click)="toSettings()"><oa-icon name="bell" [size]="13" /> Benachrichtigungen</button>
        <span class="oa-sp"></span>
        @if (tab() === 'actions') {
          <button z-button zType="ghost" zSize="sm" type="button" (click)="store.clearFinished()">Abgeschlossene entfernen</button>
        }
        <button z-button zSize="sm" type="button" (click)="close()">Schließen</button>
      </div>
    </oa-dialog>
  `,
  styles: `
    .oa-ac-panel{display:flex;flex-direction:column;gap:10px;margin-top:12px}
    .oa-ac-item{display:flex;flex-direction:column;gap:10px;padding:12px;border-radius:12px;border:1px solid var(--oa-line);background:color-mix(in oklch,var(--oa-mbg) 30%,transparent)}
    .oa-ac-item--focus{border-color:color-mix(in oklch,var(--oa-accent) 55%,transparent)}
    .oa-ac-item[data-status=error]{border-color:color-mix(in oklch,var(--oa-err) 45%,transparent)}
    .oa-ac-ico{display:grid;place-items:center;width:30px;height:30px;border-radius:9px;background:var(--oa-accent-soft);color:var(--oa-accent-fg);flex-shrink:0}
    [data-status=done] .oa-ac-ico{background:color-mix(in oklch,var(--oa-ok) 14%,transparent);color:var(--oa-ok)}
    [data-status=error] .oa-ac-ico{background:color-mix(in oklch,var(--oa-err) 14%,transparent);color:var(--oa-err)}
    .oa-ac-title{display:block;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-ac-steps{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px;font-size:13px}
    .oa-ac-steps li{display:flex;gap:10px;align-items:flex-start}
    .oa-ac-sd{display:grid;place-items:center;width:18px;height:18px;margin-top:1px;border-radius:50%;border:1.5px solid var(--oa-line2);flex-shrink:0;color:#fff}
    [data-state=done]>.oa-ac-sd{background:var(--oa-ok);border-color:var(--oa-ok)}
    [data-state=error]>.oa-ac-sd{background:var(--oa-err);border-color:var(--oa-err)}
    [data-state=running]>.oa-ac-sd{border-color:var(--oa-accent);color:var(--oa-accent-fg)}
    [data-state=pending]{opacity:.6}
    .oa-ac-log{font-size:11.5px;max-height:160px;white-space:pre-wrap}
    .oa-ac-events{list-style:none;margin:0;padding:0 0 0 4px;border-left:1px solid var(--oa-line);display:flex;flex-direction:column;gap:12px}
    .oa-ac-events li{display:flex;gap:10px;align-items:flex-start;margin-left:-8px}
    .oa-ac-events .oa-dot{margin-top:5px;outline:3px solid var(--oa-card)}
    .oa-ac-foot{display:flex;align-items:center;gap:8px;width:100%;flex-wrap:wrap}
  `,
})
export class ActionCenterComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly tab = signal<'actions' | 'events'>('actions');
  protected readonly filter = signal<Filter>('all');
  protected readonly open = signal<number[]>([]);
  protected readonly filters: { id: Filter; label: string }[] = [
    { id: 'all', label: 'Alle' },
    { id: 'error', label: 'Fehler' },
    { id: 'warn', label: 'Warnungen' },
    { id: 'ok', label: 'Erfolgreich' },
  ];

  protected readonly events = computed(() => {
    const f = this.filter();
    return this.store.events().filter((e) => f === 'all' || e.level === f);
  });

  constructor() {
    const focus = this.store.focusAction();
    const running = this.store.actions().find((a) => a.status === 'running');
    const first = focus ?? running?.id;
    if (first !== undefined) this.open.set([first]);
  }

  protected isOpen(id: number): boolean {
    return this.open().includes(id);
  }

  protected toggle(id: number): void {
    this.open.update((o) => (o.includes(id) ? o.filter((x) => x !== id) : [...o, id]));
  }

  protected close(): void {
    this.store.drawerOpen.set(false);
    this.store.focusAction.set(null);
  }

  protected toSettings(): void {
    this.close();
    this.store.openSettings('notify');
  }
}
