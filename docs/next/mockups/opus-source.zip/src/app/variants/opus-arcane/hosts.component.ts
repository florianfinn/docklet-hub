import { ChangeDetectionStrategy, Component, inject, signal, ViewEncapsulation } from '@angular/core';

import { ZardButtonComponent } from '../../shared/components/button';
import { AddHostDialogComponent } from './add-host.component';
import { Host } from './data';
import { IconComponent } from './icon.component';
import { ArcaneStore } from './store';

@Component({
  selector: 'oa-hosts',
  imports: [ZardButtonComponent, IconComponent, AddHostDialogComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `
    <div class="oa-page-head">
      <div>
        <h1>Hosts</h1>
        <p>Alle verbundenen Docker-Hosts. Direkte Verbindung ist Standard, Edge für Hosts ohne öffentlichen Port. Der Hostfilter links wirkt auf alle Seiten.</p>
      </div>
      <div class="oa-sp"></div>
      <button z-button type="button" (click)="adding.set(true)"><oa-icon name="plus" [size]="15" /> Host hinzufügen</button>
    </div>

    <div class="oa-host-grid">
      @for (h of store.hosts(); track h.id) {
        <article class="oa-card oa-hcard" [style.--hc]="h.color" [class.oa-hcard--off]="h.status === 'offline'">
          <header class="oa-row oa-hcard-head">
            <span class="oa-hcard-ico"><oa-icon name="server" [size]="20" /></span>
            <div class="oa-sp" style="min-width:0">
              <h2>{{ h.name }}</h2>
              <div class="oa-small oa-muted oa-mono oa-hcard-addr">{{ h.address }}</div>
            </div>
            <span class="oa-pill" [attr.data-tone]="h.status === 'online' ? 'ok' : 'warn'">
              <span class="oa-dot" [attr.data-tone]="h.status === 'online' ? 'ok' : 'warn'"></span>
              {{ h.status === 'online' ? 'online' : 'getrennt' }}
            </span>
          </header>

          <div class="oa-gauges">
            @for (g of gauges(h); track g.label) {
              <div class="oa-gauge">
                <svg viewBox="0 0 44 44" role="img" [attr.aria-label]="g.label + ' ' + (h.status === 'online' ? g.value + ' Prozent' : 'unbekannt')">
                  <circle cx="22" cy="22" r="18" class="oa-gauge-track" />
                  <circle cx="22" cy="22" r="18" class="oa-gauge-val" [attr.stroke-dasharray]="dash(h.status === 'online' ? g.value : 0)" />
                </svg>
                <strong>{{ h.status === 'online' ? g.value + '%' : '–' }}</strong>
                <span>{{ g.label }}</span>
              </div>
            }
          </div>

          <dl class="oa-kv oa-small">
            <dt>Verbindung</dt>
            <dd>
              <span class="oa-pill" [attr.data-tone]="h.mode === 'edge' ? 'info' : 'accent'">{{ h.mode === 'edge' ? 'Edge' : 'Direkt' }}</span>
            </dd>
            <dt>System</dt><dd>{{ h.os }}</dd>
            <dt>Agent</dt><dd>{{ h.agent }} · {{ h.memTotal }} RAM</dd>
            <dt>Projektverzeichnis</dt><dd class="oa-mono">{{ h.projectDir }}</dd>
            <dt>Letzter Kontakt</dt><dd>{{ h.lastSeen }}</dd>
          </dl>

          <footer class="oa-row oa-hcard-foot">
            <span class="oa-small oa-dim">{{ stackCount(h.id) }} Stack(s)</span>
            <span class="oa-sp"></span>
            @if (h.status === 'offline') {
              <button type="button" class="oa-btn" data-tone="accent" (click)="store.reconnect(h.id)"><oa-icon name="refresh" [size]="14" /> Verbindung prüfen</button>
            }
            <button type="button" class="oa-btn" (click)="showApps(h)">Nur diesen Host zeigen <oa-icon name="chevronRight" [size]="14" /></button>
          </footer>
        </article>
      }

      <button type="button" class="oa-hcard-add" (click)="adding.set(true)">
        <span class="oa-hcard-ico"><oa-icon name="plus" [size]="20" /></span>
        <strong>Weiteren Host verbinden</strong>
        <span class="oa-small oa-muted">Compose-Datei oder Installer-Befehl erzeugen</span>
      </button>
    </div>

    @if (adding()) {
      <oa-add-host-dialog (closed)="adding.set(false)" />
    }
  `,
  styles: `
    .oa-host-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(380px,100%),1fr));gap:14px}
    .oa-hcard{display:flex;flex-direction:column;gap:14px;overflow:hidden}
    .oa-hcard::before{content:'';position:absolute;inset:0 0 auto;height:3px;background:var(--hc)}
    .oa-hcard--off{opacity:.85}
    .oa-hcard--off .oa-gauge-val{stroke:var(--oa-dim)}
    .oa-hcard-head{flex-wrap:nowrap}
    .oa-hcard-head h2{font-size:16px;font-weight:600;margin:0}
    .oa-hcard-addr{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .oa-hcard-ico{display:grid;place-items:center;width:42px;height:42px;border-radius:12px;flex-shrink:0;color:var(--hc,var(--oa-accent-fg));background:color-mix(in srgb,var(--hc,#8b7cf6) 15%,transparent);border:1px solid color-mix(in srgb,var(--hc,#8b7cf6) 30%,transparent)}
    .oa-gauges{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
    .oa-gauge{display:flex;flex-direction:column;align-items:center;gap:2px;padding:10px 6px;border-radius:12px;border:1px solid var(--oa-line);background:rgb(0 0 0/.18);position:relative}
    .oa-gauge svg{width:54px;height:54px;transform:rotate(-90deg)}
    .oa-gauge circle{fill:none;stroke-width:4}
    .oa-gauge-track{stroke:rgb(255 255 255/.08)}
    .oa-gauge-val{stroke:var(--hc);stroke-linecap:round;transition:stroke-dasharray .5s ease}
    .oa-gauge strong{position:absolute;top:28px;font-size:12.5px}
    .oa-gauge span{font-size:11.5px;color:var(--oa-dim)}
    .oa-hcard-foot{margin-top:auto;padding-top:12px;border-top:1px solid var(--oa-line)}
    .oa-hcard-add{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;min-height:280px;border-radius:14px;border:1px dashed var(--oa-line2);background:rgb(255 255 255/.015);color:var(--oa-fg);cursor:pointer;transition:border-color .15s,background .15s}
    .oa-hcard-add:hover{border-color:var(--oa-accent);background:var(--oa-accent-soft)}
  `,
})
export class HostsComponent {
  protected readonly store = inject(ArcaneStore);
  protected readonly adding = signal(false);

  protected gauges(h: Host): { label: string; value: number }[] {
    return [
      { label: 'CPU', value: h.cpu },
      { label: 'RAM', value: h.mem },
      { label: 'Disk', value: h.disk },
    ];
  }

  protected dash(v: number): string {
    const c = 2 * Math.PI * 18;
    return `${((v / 100) * c).toFixed(1)} ${c.toFixed(1)}`;
  }

  protected stackCount(id: string): number {
    return this.store.stacks().filter((s) => s.hostId === id).length;
  }

  protected showApps(h: Host): void {
    this.store.onlyHost(h.id);
    this.store.go('stacks');
  }
}
