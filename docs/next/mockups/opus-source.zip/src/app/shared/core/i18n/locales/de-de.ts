// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/locales/de-de.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import type { ZardI18nInterface } from '../i18n.types';

export const de_DE: ZardI18nInterface = {
  locale: 'de-DE',
  calendar: {
    weekStartsOn: 1,
    labels: {
      today: 'Heute',
      nextMonth: 'Nächster Monat',
      previousMonth: 'Vorheriger Monat',
      nextYear: 'Nächstes Jahr',
      previousYear: 'Vorheriges Jahr',
      chooseMonth: 'Monat auswählen',
      chooseYear: 'Jahr auswählen',
      selected: 'Ausgewählt',
      rangeStart: 'Bereichsbeginn',
      rangeEnd: 'Bereichsende',
      inRange: 'Im Bereich',
      outsideMonth: 'Außerhalb des Monats',
      disabled: 'Deaktiviert',
    },
  },
};
