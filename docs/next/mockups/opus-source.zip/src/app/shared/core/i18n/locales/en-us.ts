// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/locales/en-us.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import { DEFAULT_CALENDAR_I18N } from '../i18n.constants';
import type { ZardI18nInterface } from '../i18n.types';

export const en_US: ZardI18nInterface = {
  locale: 'en-US',
  calendar: DEFAULT_CALENDAR_I18N,
};
