// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/locales/pt-pt.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import type { ZardI18nInterface } from '../i18n.types';

export const pt_PT: ZardI18nInterface = {
  locale: 'pt-PT',
  calendar: {
    weekStartsOn: 1,
    labels: {
      today: 'Hoje',
      nextMonth: 'Mês seguinte',
      previousMonth: 'Mês anterior',
      nextYear: 'Ano seguinte',
      previousYear: 'Ano anterior',
      chooseMonth: 'Escolher mês',
      chooseYear: 'Escolher ano',
      selected: 'Selecionado',
      rangeStart: 'Início do intervalo',
      rangeEnd: 'Fim do intervalo',
      inRange: 'No intervalo',
      outsideMonth: 'Fora do mês',
      disabled: 'Desativado',
    },
  },
};
