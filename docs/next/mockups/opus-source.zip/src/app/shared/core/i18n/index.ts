// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/index.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
export * from './i18n.types';
export * from './i18n.constants';
export * from './i18n.tokens';
export * from './i18n.service';
export * from './i18n.provider';
export * from './locales/registry';
export * from './locales/en-us';
export * from './locales/fr-fr';
export * from './locales/es-es';
export * from './locales/de-de';
export * from './locales/it-it';
export * from './locales/pt-br';
export * from './locales/pt-pt';
