// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/locales/es-es.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import type { ZardI18nInterface } from '../i18n.types';

export const es_ES: ZardI18nInterface = {
  locale: 'es-ES',
  calendar: {
    weekStartsOn: 1,
    labels: {
      today: 'Hoy',
      nextMonth: 'Mes siguiente',
      previousMonth: 'Mes anterior',
      nextYear: 'Año siguiente',
      previousYear: 'Año anterior',
      chooseMonth: 'Elegir el mes',
      chooseYear: 'Elegir el año',
      selected: 'Seleccionado',
      rangeStart: 'Inicio de rango',
      rangeEnd: 'Fin de rango',
      inRange: 'En rango',
      outsideMonth: 'Fuera de mes',
      disabled: 'Deshabilitado',
    },
  },
};
