// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/locales/fr-fr.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import type { ZardI18nInterface } from '../i18n.types';

export const fr_FR: ZardI18nInterface = {
  locale: 'fr-FR',
  calendar: {
    weekStartsOn: 1,
    labels: {
      today: "Aujourd'hui",
      nextMonth: 'Mois suivant',
      previousMonth: 'Mois précédent',
      nextYear: 'Année suivante',
      previousYear: 'Année précédente',
      chooseMonth: 'Choisir le mois',
      chooseYear: "Choisir l'année",
      selected: 'Sélectionné',
      rangeStart: 'Début de plage',
      rangeEnd: 'Fin de plage',
      inRange: 'Dans la plage',
      outsideMonth: 'Hors du mois',
      disabled: 'Désactivé',
    },
  },
};
