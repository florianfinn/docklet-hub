// Source: zard-ui/zardui/libs/zard/src/lib/shared/core/i18n/locales/it-it.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import type { ZardI18nInterface } from '../i18n.types';

export const it_IT: ZardI18nInterface = {
  locale: 'it-IT',
  calendar: {
    weekStartsOn: 1,
    labels: {
      today: 'Oggi',
      nextMonth: 'Mese successivo',
      previousMonth: 'Mese precedente',
      nextYear: 'Anno successivo',
      previousYear: 'Anno precedente',
      chooseMonth: 'Scegli il mese',
      chooseYear: "Scegli l'anno",
      selected: 'Selezionato',
      rangeStart: 'Inizio intervallo',
      rangeEnd: 'Fine intervallo',
      inRange: "Nell'intervallo",
      outsideMonth: 'Fuori mese',
      disabled: 'Disabilitato',
    },
  },
};
