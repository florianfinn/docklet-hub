// Source: zard-ui/zardui/libs/zard/src/lib/shared/components/tabs/tabs.imports.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
/*
 * The alias, not a relative path: the Angular compiler re-emits these imports from
 * whichever module spreads the array, and it can only do that for a specifier the
 * consumer can resolve too. A relative path here fails with NG3004.
 */
import { ZardTabComponent, ZardTabGroupComponent } from '@/shared/components/tabs/tabs.component';

/** Every part of the tabs component, for a template that uses more than one. */
export const ZardTabsImports = [ZardTabGroupComponent, ZardTabComponent] as const;
