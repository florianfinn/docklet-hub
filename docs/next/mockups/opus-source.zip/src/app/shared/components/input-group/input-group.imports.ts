// Source: zard-ui/zardui/libs/zard/src/lib/shared/components/input-group/input-group.imports.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
export {
  ZardInputGroupAddonComponent,
  ZardInputGroupButtonDirective,
  ZardInputGroupComponent,
  ZardInputGroupTextComponent,
} from './input-group.component';

import {
  ZardInputGroupAddonComponent,
  ZardInputGroupButtonDirective,
  ZardInputGroupComponent,
  ZardInputGroupTextComponent,
} from './input-group.component';

export const ZardInputGroupImports = [
  ZardInputGroupComponent,
  ZardInputGroupAddonComponent,
  ZardInputGroupButtonDirective,
  ZardInputGroupTextComponent,
] as const;
