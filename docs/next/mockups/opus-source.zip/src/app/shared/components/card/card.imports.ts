// Source: zard-ui/zardui/libs/zard/src/lib/shared/components/card/card.imports.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
import {
  ZardCardActionComponent,
  ZardCardComponent,
  ZardCardContentComponent,
  ZardCardDescriptionComponent,
  ZardCardFooterComponent,
  ZardCardHeaderComponent,
  ZardCardTitleComponent,
} from '@/shared/components/card/card.component';

export const ZardCardImports = [
  ZardCardComponent,
  ZardCardHeaderComponent,
  ZardCardTitleComponent,
  ZardCardDescriptionComponent,
  ZardCardActionComponent,
  ZardCardContentComponent,
  ZardCardFooterComponent,
] as const;
