// Source: zard-ui/zardui/libs/zard/src/lib/shared/components/tabs/index.ts
// Commit: 434090942c850fd21546c25fed1fd0ddae72150b; retrieved 2026-10-10; MIT.
// Adaptation: installed by zard-cli 1.0.1; added provenance header only.
export * from './tabs.component';
export * from './tabs.imports';
export * from './tabs.variants';
