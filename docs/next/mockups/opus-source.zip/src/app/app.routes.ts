import { Component } from '@angular/core';
import { RouterLink, Routes } from '@angular/router';

const VARIANTS = ['opus-compact', 'opus-arcane'] as const;

@Component({
  selector: 'app-variant-index',
  imports: [RouterLink],
  template: `
    <main style="max-width:32rem;margin:4rem auto;padding:0 1.5rem;font-family:system-ui,sans-serif">
      <h1 style="font-size:1.5rem;font-weight:600;margin-bottom:1rem">Docklet Design Lab – Opus 5.5</h1>
      <ul style="display:grid;gap:.5rem;list-style:none;padding:0">
        @for (id of variants; track id) {
          <li><a [routerLink]="'/' + id" style="text-decoration:underline">{{ id }}</a></li>
        }
      </ul>
    </main>
  `,
})
class VariantIndex {
  readonly variants = VARIANTS;
}

export const routes: Routes = [
  { path: '', component: VariantIndex, title: 'Docklet Design Lab' },
  {
    path: 'opus-compact',
    title: 'opus-compact',
    loadComponent: () => import('./variants/opus-compact/design.component').then((m) => m.DesignComponent),
  },
  {
    path: 'opus-arcane',
    title: 'opus-arcane',
    loadComponent: () => import('./variants/opus-arcane/design.component').then((m) => m.DesignComponent),
  },
  { path: '**', redirectTo: '' },
];
