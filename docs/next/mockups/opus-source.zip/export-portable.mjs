import {readFileSync,readdirSync,writeFileSync,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {build} from 'esbuild';
const root='dist/docklet-design-lab';
const browser=root+'/browser';
const out='portable';
mkdirSync(out,{recursive:true});
const main=readdirSync(browser).find(f=>/^main-.*\.js$/.test(f));
const result=await build({entryPoints:[browser+'/'+main],bundle:true,format:'iife',platform:'browser',minify:true,write:false});
const code=result.outputFiles[0].text;
const payload=gzipSync(Buffer.from(code)).toString('base64');
const css=readdirSync(browser).filter(f=>f.endsWith('.css')).map(f=>readFileSync(browser+'/'+f,'utf8')).join('\n');
if(/url\(/.test(css)) console.log('CSS URL references:',css.match(/url\([^)]*\)/g));
for(const variant of ['compact','arcane']) {
 const compressedCss=gzipSync(Buffer.from(css)).toString('base64');
 const runner=`location.hash='#/opus-${variant}';(async()=>{const cssBytes=Uint8Array.from(atob('${compressedCss}'),c=>c.charCodeAt(0));const cssText=await new Response(new Blob([cssBytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();const style=document.createElement('style');style.textContent=cssText;document.head.append(style);const bytes=Uint8Array.from(atob('${payload}'),c=>c.charCodeAt(0));const code=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();Function(code)();})().catch(e=>{console.error(e);document.body.insertAdjacentHTML('beforeend','<pre role="alert">Start fehlgeschlagen</pre>');});`;
 const html=`<!doctype html>\n<!-- Generated Angular mockup. Source and licenses: README.md and opus-source.zip. -->\n<html lang="de"><head><meta charset="utf-8"><title>Docklet · Opus ${variant}</title><base href="./"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><app-root></app-root><script>${runner}</script></body></html>\n`;
 writeFileSync(out+'/opus-'+variant+'.html',html);
 console.log(variant,html.length);
}
writeFileSync(out+'/THIRD-PARTY-LICENSES.txt',readFileSync(root+'/3rdpartylicenses.txt'));
